Hi Abhilash Kumar,

For seamless processing of your exit and closure of Full and Final (F&F) settlement, it is crucial to complete all the pre-exit formalities before your last workday with the firm.

Actions required by you: 
•	Ensure all time and expense details are updated in DTE. Provision is available until your last working day to do so. Any missing time in your DTE will significantly delay the F&F settlement.
•	Clear all the dues on your Amex corporate card from the portal. Shred the card on your last working day.
•	Raise personal data retrieval request now if you haven't done so already. Kindly note that Data Removal Team will not address requests that are raised less than a week from your last working day. Restrict transfer/download of documents to important ones such as compensation revision/break-up, salary slips, form 16, tax slips, house rent documents, and other financial documents. Refer to this link for support.
•	Settle your car lease, if any, prior to your last date. Please reach out to usicarleaseadministration@deloitte.com in case of any questions.
Deloitte asset submission and personal property retrieval:
•	Virtual off-boarding email communication will be shared closer to your last working day on your personal and Deloitte email id. This operation is unique to each individual and the email should not be forwarded. Please ensure to update the survey BEFORE your last working day
•	You are required to visit the office directly to collect any of your personal belongings from your respective office/desk location BEFORE your last working day.
•	Please write to usindiasecurity@deloitte.com for any assistance or questions on personal property retrieval process and ensure to provide the below details in your email:

1.	Date of visit to office (please do not visit on the LWD (last working day) as the ID cards may be disabled during the day and may impede movement within office premises)
2.	Office City
3.	Building name (Tower 1, Tower 2, etc.)
4.	Floor
5.	Workstation number/ Office room number
Important points to note:
•	Visibility on notice period recovery and other recoveries can only be communicated post your Full and Final settlement, which will happen post your exit.
•	Make note of the bidding adieu email – it confirms your official last working date with the firm and serves as a resignation acceptance email. It is directed to your personal e-mail id as well.
Have questions?

Please refer to the Employee Exit Kit for detailed information on pre-exit formalities before reaching out to the USI contact center at 1800 2582 2222 (toll-free).

Note: This is an auto-generated communication. Please do not reply to this mail.

Regards,
USI Separations Team


mailto:usindiaelecertifications@deloitte.com
https://talentondemand.deloittenet.deloitte.com/apps/#!/my-information/certification/
https://th-cd-webapp.ame.intela.deloitte.com/talent/articles/usi-accrediation-guidelines
Hi , 

It is important that you complete and update the  Accreditation status in the Talent records. If you have updated the status, you can check the same in Talent on Demand (ToD)  or you can update it as mentioned below – 

•	Send an email to US India ELE Certifications mailbox with the accreditation completion proof
•	Also, update Certifications section under “My Information” on Talent On Demand 

Do complete the above-mentioned steps on or before Feb 28, 2023. 

If you have any further questions, please refer USI Tax Accreditation Guidelines. 


Thanks & Regards, 
Milita Mondol
Talent Engagement Specialist 
www.mmondol@deloitte.com




ITS Walk-up appointment confirmation
Guidance for your visit to office.
 
Dear Colleague,
You have successfully scheduled a visit to the ITS Walk-up support at our office. Meeting reminder is shared for your reference along with the details. Based on the information of the issue shared, the original resolution time may take longer than the estimated time calculated. We would recommend to accommodate additional time for the issue to be fixed.
Appointment Details: 
•	Project: ITS Self-Service Appointment Scheduling
•	Office: KOLKATA 
•	Date: 2/6/2023
•	Time: 10:00 AM(GMT + 05:30) Calcutta, Chennai, Mumbai, New Delhi
•	Estimation time required: 0 hour(s)
 
Click here if you need to reschedule your appointment. 
Note:
•	If you happen to reschedule / cancel the appointment, then a new meeting invite will be shared with revised timelines. Kindly, note the earlier appointment need to be deleted from the calendar manually.
•	Covid guidelines to be followed while visiting the office.        
•	Backup / Restore data on your own for a laptop repair incident.                                                                           
•	NOTE : Link to learn the back-up procedure Druva InSync Data Restore or Druva InSync Data Backup.                                
Regards,
Information Technology Services


rajbasu@deloitte.com
+919831066796




Dear Colleague,
As a part of the offboarding process, we request you to take the following steps for a seamless exit experience. Please complete the offboarding survey which will help us validate your address, contact details to communicate with you, if needed, and enable timely exit clearance. It is mandatory to complete the offboarding survey. Once you submit all the company-issued assets, you will be provided with the necessary exit clearances on the system, post which your F&F settlement will be initiated. Failure to submit the mandatory company-issued assets (IT and non-IT) will affect your F&F settlement and may entail legal action as well.

Submission of Deloitte assets
You are required to submit the assets ON YOUR LAST WORKING DATE before 7:00 PM. If you own a firm-issued personal digital assistant (PDA), a remote/in-person data wipe will be initiated. Please ensure to back up all personal data before your last working day.
You need to visit the nearest office / ITS hub to deposit your Deloitte assets. 
•	Hyderabad
•	Bengaluru
•	Gurgaon
•	Mumbai
•	Chennai
•	Pune
•	Kolkata

Submission of IT assets:
Please note the list of IT assets that need to / need not be returned along with the laptop. 

To be returned	Need not return
Additional laptops (Rental, ODC, Project procured)	PC headset  
Power adapter (defective / working)	Cable lock
Display / Ethernet connectors	Laptop bag 
Monitor	Mouse 
Wireless speaker	Network Cable
Project procured peripherals (wireless headsets, speakers, etc.)	

Submission of Deloitte-issued non-IT assets:
List of assets to be submitted along with your laptop and IT peripherals:
•	ID card – Mandatory to submit
•	Desk / cupboard keys
•	CE Gym assets


For more details, you may refer to the offboarding process FAQs appended with this email.
Regards,
USI Talent Exit team


https://talent--c.na225.visual.force.com/apex/EmployeeDashboard

usiindiaexitmanagement@deloitte.com
usiindiaexitmanagement@deloitte.com









