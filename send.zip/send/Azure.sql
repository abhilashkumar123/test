/* Must Complete */
i) Azure SQL :- 
ii) Azure Data Factory :- 
iii) Azure Data Bricks :- 
iv) Azure SQL Data Warehouse :- 
v) Azure Data Lake  :- 
vi) Power BI :- 
vii) Azure Analysis Services :- 
viii) NoSQL :- Azure Cosmos DB
ix) NoSQL :- MongoDB 
x) NoSQL :- Cassandra
xi) Graph DB :- 

Conclusion :- 
Azure SQL database Service in Azure Portal :- 
i) SQL server on a virtual machine (VM) :- IAAS Model
ii) Azure SQL database (Managed Instance) :- PAAS Model
iii)  Azure SQL database (Logical Server) :- PAAS Model

Elastic Pool :- Sharing of Resource among databases.
DTU :- Database Transactional Unit

Azure Data Warehouse(Azure Synapse Analytics) :- 

/* Subscription :- ES-LOB-USP-DEV */
Suppose we have created an account in portal.azure.com.Now we want to use services present in 
Azure portal.Now for each services it needs a "Subscription".This Subscription will be used in billing
method."Subscription" is also present as a service in portal.We can click and create a new "Subscription".
Subscription available in Azure portal are :- 
i) Free Trial :- Full access to all services. Explore any service that you want. 

ii) Pay-As-You-Go :- This flexible pay-as-you-go plan involves no up-front costs, 
and no long term commitment. You pay only for the resources that you use. 

iii) Azure for Students :- Innovate, explore and drive your career with Azure credits
 plus popular free products for 12 months. 

Select Free Trial and it will ask for credit card no and after completion this subscription
will show in "Subscription" services.
Suppose "Subscription" Name is :- "MrFreeTrialSubscription".
Now we can link this "MrFreeTrialSubscription" subscription whenever we will try to use any other services.

/* Resource Group :- uspstagingdbgroupdev */
After creating subscription we need to created "Resource Group".Inside a subscription we 
can create multiple "Resource Group".
Suppose we have three env. DEV, Test and UAT.Then we need to create 3 Resource Group.
"Resource Group" is a service in azure portal.Search for "Resource Group" and create a new one.
While creating it will ask 3 i/p.
i) Subscription 
ii) Resource Group Name
iii) Region
Click "Review & Create".Done.
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
Types Of Data :- 
A) Relational Data :- 
1) Structured :- 

B) Non-Relational Data :- 
2) Semi-structured :- 
3) Non-structured :- 

A) 1) Structured data can be stored in relational database.

B) Semi-structured & Non-structured database can be stored in Non-Relational/NoSQL Database.
2) Method to store Semi-structured :- 
i) JSON ii) Avro iii) ORC iv) Parquet

3) Non-structured can be stored in Non-Relational/NoSQL databases.
Types of Non-Relational/NoSQL databases.
i) Key-Value Stores :- Azure Table storage, Cosmos DB using Table API,Cassandra,LevelDB, Riak
ii) Document Databases :- Azure Cosmos DB in its Core (SQL) API,MongoDB, CouchDB
iii) Column Family Databases :- ORC Files,Parquet Files,Apache Cassandra,Azure Cosmos DB through the Cassandra API,
								HBase, BigTable, HyperTable.
iv) Graph Databases :- Azure Cosmos DB using the Gremlin API,Polyglot, Neo4J

ACID :- 
i) Atomicity :- 
ii) Consistency :- 
iii) Isolation :- 
iv) Durability :- 

Azure Data Services for Non relational Data :- 
i) Storage Account :- Here non structured data can be dumped.User can not do Query directly.
Through ETL will be moved to "Azure Synapse".This is called "Data Storage Layer".
Similar as "HDInsight Hadoop data store".

ii) Data Lake Store :- Same as "Storage Account" but with enhanced feature.
Similar as "Databricks, HDInsight and IOT data store".

iii) Azure Databricks :- 
iv) Azure CosmosDB :- OLTP System with No SQL env
v) Column-Family Databases :- 
vi) Azure Table Storage :- 
vii) Azure Blob Storage :- 
viii) Azure File Storage :- Network File Storage (NFS) :- 

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
Youtube Tutorials for Azure :- 
1) /* Must Watch */
https://www.youtube.com/channel/UC_n9wCmDG064tZUKZF2g4Aw/videos
WafaStudies
2) /* https://www.youtube.com/watch?v=CkoQPG78VxQ&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=5&ab_channel=Cloudpandith */
Cloudpandith
/* WAtch data bricks playlist :- very lengthy videos*/

3) https://www.youtube.com/playlist?list=PL50mYnndduIGmqjzJ8SDsa9BZoY7cvoeD
AZURE DATABRICKS TUTORIAL
/* Can be watched */

4) https://www.youtube.com/watch?v=eTAYSZ2NlDk&list=PL50mYnndduIGmqjzJ8SDsa9BZoY7cvoeD&index=7&ab_channel=TechLake
TechLake
/* Seems good.Try this */

5) https://www.youtube.com/playlist?list=PLxBNTxmktAw9GQpcsLNwZpKrkkk2-B5qW
ramit girdhar
/* Very short video.Can be watched */

6) https://www.youtube.com/playlist?list=PLY6Ag0EOw54xDIJssq7qPAAMdX5qugWwA
Azarudeen Shahul
/* Databricks using Spark */

7) https://www.youtube.com/c/Databricks/playlists
Databricks
/* look.So many playlist on Azure databricks */

8) Get location using ipaddress :- 
https://www.youtube.com/watch?v=9Itqm_bmUoU&ab_channel=Tech2etcTech2etc
/* Learn it */
https://youtube.com/playlist?list=PL9bD98LkBR7MiD-jeRLfaakke09zYSXrD
/* Try soem python projects */

9) 
https://www.youtube.com/watch?v=Fb5pO3-62Nc&ab_channel=ProgrammerInHouse
Create Azure functions in Python

10) https://www.youtube.com/watch?v=rGf421bvzSI&list=PL3JVwFmb_BnSB1UXpYjPkyBNB19pEowo-&index=4&ab_channel=JieJennJieJenn
/* Web scraping using Python */
/* So many scrapping methods are present.Look into it */

11) https://www.youtube.com/c/RavikiranS/playlists
/* Good for any kind of azure exam practise */

12) https://www.youtube.com/user/GeekyShow1/playlists
/* Lots of playlist on web.Must look */

13) https://www.youtube.com/watch?v=grTBr3xphAI&ab_channel=TechLake
Techlake /* Check this new channel */

14) https://www.youtube.com/channel/UCvpwST0Xcm7pOKkA65vS7ig/playlists
CloudFitness
/* See databricks from this tutorials */
https://www.youtube.com/playlist?list=PLtlmylp_ZK5wr1lyq76h1V4ZuWZYThgy0
Techlake /* Check this new channel */


15) 


Which Fundamental Azure Certification should I choose :- 
----------------------------------------------------------------
https://k21academy.com/microsoft-azure/azure-fundamental-certification-for-beginners-az-900-vs-ai-900-vs-dp-900/
AZ-900 vs AI-900 vs DP-900

AZ-900 :- Cloud Servers.AZ-900 is intended for candidates who are planning to take their first step in Cloud or are new to Azure. 
The job roles for AZ-900 include Azure Cloud Architect, Azure Cloud Administrator, Azure Consultant, and more.

AI-900 :- Artificial Intelligence (AI).
The job roles for AI-900 include AI/Machine Learning Engineers, AI Cloud Engineers, AI Consultants, and more.

DP-900 :- DP-900 is for candidates who want to start working with data on the cloud, get basic skills in cloud data services, and also build their foundational knowledge of cloud data services in Microsoft Azure.
The job roles for DP-900 include DBA, Data Engineers, and Data Analyst.

/* All types of certification */
https://docs.microsoft.com/en-us/learn/certifications/

/* Fundamental Certification */
https://docs.microsoft.com/en-us/learn/certifications/browse/?type=fundamentals
Here DP 900 will be present along with some other fundamental certification.

/* Role based certification */
https://docs.microsoft.com/en-us/learn/certifications/browse/?resource_type=certification
Once fundamental is completed can choose the appropriate certification.

/* Additional Certification */
https://docs.microsoft.com/en-us/learn/certifications/browse/?resource_type=certification
Not required as of now


For Me Path will be :- 
/* DP-900 (Fundamental) :- DP-203 */

EXAM DP-203 IS REPLACING EXAMS DP-200 AND DP-201. 
DP-200 and DP-201 will retire on June 30, 2021.

You will earn this certification if you complete one of the following options:
Pass DP-200 and DP-201 (retiring on June 30, 2021) or
Pass DP-203 (beta released February 23, 2021)

Certifications :- LTI partnership with Microsoft
--------------------------------------------------
/* Do this after completing training session from Video and Link provided in MS site */
https://esi.microsoft.com/ >>> Sign In Now :- Provide LTI EmailId
/* Redirected Page :- Learning for Data Engineer */
https://esi.microsoft.com/landing

Click on Schedule inside "Microsoft Certification"
New Page :- https://esi.microsoft.com/getcertification
Click On "Get Started" :- Microsoft Certified: Azure Data Fundamentals - DP-900
Before that do "Practice Test".
Here DP-201 is also present.Give this after fundamental.

ReSchedule Exam :- po
8093..
abhi.cv

https://www.microsoft.com/en-us/learning/dashboard.aspx


/* Exam Time :- */
DP 900 :- Scheduled on 31st July 7:15 AM.
AZ 900 :- 21st Aug 2021 :- 8:00 AM

/* New Registration :- */
1) 
Deloitte ID & abhi.k
7979

2) /* Latest One */
abhilaskumar@deloitte.com & abhilash080191@outlook.com
7979..
100% discount is available for each certification.

esi.microsoft.com
Login :- abhilas.kumar@deloite.com

DP 900 Exam :- 
26th Mar 2022 :- At 5:45 AM
Login :- abhilash080191@outlook.com
100 % discount using abhilaskumar@deloitte.com

Access Code :- 666-227-622
533-734-289
410-176-526
Sample Questions :- 
--------------------------
https://www.itexams.com/exam/DP-900
https://www.examtopics.com/exams/microsoft/dp-900/view/
https://www.testpreptraining.com/microsoft-azure-data-fundamentals-dp-900-free-practice-test
--------------------------------------------------------------------------------
Practice Paper for DP 900 :- 


What do you use to create Power BI paginated reports?
Power BI Report Builder



/* https://docs.microsoft.com/en-us/learn/certifications/exams/az-900 */
--------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/learn/paths/az-900-describe-cloud-concepts/ */
--------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/learn/modules/intro-to-azure-fundamentals/introduction */
--------------------------------------------------------------------------------
Preparation for Exam AZ-900 :- 
AZ-900 Domain Area              Weight
--------------------            --------
Describe cloud concepts         20-25%
Describe core Azure services    15-20%
Describe core solutions and management tools on Azure   10-15%
Describe general security and network security features 10-15%
Describe identity, governance, privacy, and compliance features 20-25%
Describe Azure cost management and Service Level Agreements 10-15%
--------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/learn/modules/intro-to-azure-fundamentals/what-is-cloud-computing */
/* https://docs.microsoft.com/en-us/learn/modules/intro-to-azure-fundamentals/what-is-microsoft-azure */
--------------------------------------------------------------------------------
Cloud computing is the delivery of computing services over the internet 
by using a pay-as-you-go pricing model.
















--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
DP-900 :- /* Online Preparation */
Skills Required :- Basic :- DP-900-azure-data-fundamentals-skills

/* Must Watch */
https://www.youtube.com/watch?v=Cd6srNeXTgY
[New] DP-900 Azure Data Fundamentals | Real Exam Questions & Answers | Pass DP-900 Exam (part 1)


Two ways to prepare :- 
https://docs.microsoft.com/en-us/learn/certifications/azure-data-fundamentals/?tab=tab-learning-paths

Go through Online-Free :- 
----------------------------------
1) https://docs.microsoft.com/en-us/learn/paths/azure-data-fundamentals-explore-core-data-concepts/
/* Azure Data Fundamentals: Explore core data concepts */

2) https://docs.microsoft.com/en-us/learn/paths/azure-data-fundamentals-explore-relational-data/
/* Azure Data Fundamentals: Explore relational data in Azure */

3) https://docs.microsoft.com/en-us/learn/paths/azure-data-fundamentals-explore-non-relational-data/
/* Azure Data Fundamentals: Explore non-relational data in Azure */

4) https://docs.microsoft.com/en-us/learn/paths/azure-data-fundamentals-explore-data-warehouse-analytics/
/* Azure Data Fundamentals: Explore modern data warehouse analytics in Azure */

KT session Video on DP-900 :- 
------------------------------------
https://event.on24.com/eventRegistration/console/EventConsoleApollo.jsp?simulive=y&eventid=2714514&sessionid=1&username=&partnerref=&format=fhvideo1&mobile=false&flashsupportedmobiledevice=false&helpcenter=false&key=8C15C0DB70D411F9F77D81F273FE5F43&text_language_id=en&playerwidth=1000&playerheight=650&overwritelobby=y&localeCountryCode=UK&newConsole=true&nxChe=true&newTabCon=true&eventuserid=427669420&contenttype=A&mediametricsessionid=369276141&mediametricid=3821811&usercd=427669420&mode=launch

======================================================================================
======================================================================================
https://docs.microsoft.com/en-us/learn/paths/azure-data-fundamentals-explore-core-data-concepts/
/* Azure Data Fundamentals: Explore core data concepts */

1) https://docs.microsoft.com/en-us/learn/modules/explore-core-data-concepts/
/* Explore core data concepts */
Data is a collection of facts such as numbers, descriptions, and observations used in decision making. 
It can be classified as structured, semi-structured, or unstructured data.

Structured data is typically tabular data that is represented by rows and columns in a database.
Databases that hold tables in this form are called relational databases.

Semi-structured data is information that does not reside in a relational database but 
still has some structure to it.Here data is stored in JSON format.
Other types of semi-structured data are i) key-value stores and ii) graph databases.

A key-value store is similar to a relational table, except that each row can have 
any number of columns.

graph database to store and query information about complex relationships.
A graph contains nodes (information about objects) and edges 
(information about the relationships between objects). 

 Audio and video files, and binary data files might not have a specific structure. 
 They are referred to as unstructured data.

How is data defined, stored, and accessed in cloud computing :- 
---------------------------------------------------------------------
Azure SQL Database is a service that runs in the cloud. 
provisioning :- The act of setting up the database server is called provisioning.
If we want to store unstructured data such as video or audio files,
We can use "Azure Blob storage"(Blob is an acronym for Binary Large Object).
If we want to store semi-structured data such as documents, you can use a 
service such as "Azure Cosmos DB".

Aftre service is provisioned, it needs to be configured so that users can be given access 
to the data. Level of Access are :- 
i) Read-only access means the users can read data but can’t modify any 
existing data or create new data.

ii) Read/write access gives users the ability to view and modify existing data.

iii) Owner privilege gives full access to the data including managing the security 
like adding new users and removing access to existing users.

Describe data processing solutions :- 
---------------------------------------------
Data processing solutions has two categories :- 
i) Transaction Processing Systems &
ii) Analytical Systems 

i) Transaction Systems :- 
A transactional system records transactions. A transaction could be financial, such as the 
movement of money between accounts in a banking system, or it might be part of a retail 
system, tracking payments for goods and services from customers. 

Transactional systems handles millions of transactions in a single day.
Online Transactional Processing (OLTP) :- The work performed by transactional systems 
is often referred to as Online Transactional Processing (OLTP).

To support fast processing in "Transaction Systems" tables are splitted into smaller table.
This process is called "Normalization".
Normalization can enable a transactional system to cache much of the information 
required to perform transactions in memory, and speed throughput.
But
Normalization makes SQL query complex.business user may face this difficulty.

ii) Analytical Systems :- 
In order to support OLTP,  analytical system is designed to support business users who
need to query data and get big picture view of data present in database.

Analytical data processing systems need to perform below tasks :- 
a) Data Ingestion b) Data transformation c) Data querying & d) Data visualization
C:\Users\10662208\Desktop\ABHILASH\Script\Azure\OLAP.png

a) Data Ingestion :- Data ingestion is the process of capturing the "raw data".
data can come from various devices/application like supermarket, bank accounts, weather stations,
temperature and pressure.All these data needs to be stored.It may be a file store,
a document database, or even a relational database.

b) Data Transformation/Data Processing :- Row data captured might not be usedful for query.
So data must be transformmed or filtered out invalid data.
During this step aggregation can also be done like calculating profit, margin, 
and other Key Performance Indicators (KPIs). 

c) Data Querying :- Once data is ingested and transformed, user can Query on data and 
generate report from it.

d) Data visualization :- Data present in table  are not always intuitive.
Visualizing the data can often be useful as a tool for examining data.
Charts are very useful in examining data.
Some famous charts are bar charts, line charts, plot results on geographical maps, pie charts etc..
Microsoft offers visualization tools like Power BI to provide rich graphical 
representation of your data.


Characteristics of relational and non-relational data :- 
---------------------------------------------------------------
1) Transactional Workloads :- 
-------------------------------
A transactional database must adhere to the ACID (Atomicity, Consistency, Isolation, Durability) 
properties to ensure that the database remains consistent while processing transactions.

i) Atomicity :- This feature guarantees that each transaction is treated as a single unit
which will successed or fail completely.
If any of the statements constituting a transaction fails then the entire transaction 
fails and the database is left unchanged.

ii) Consistency :- This feature ensures that  transaction can only take the data in 
the database from one valid state to another. 
A consistent database should never lose or create data in a manner that can not be 
accounted for.
In Bank transaction if in one account money got added then somewhere in other system
it must be deducted to maintain consistency.

iii) Isolation :- It ensures that concurrent execution of transactions leaves the database 
in the same state that would have been obtained if the transactions were executed 
sequentially. A concurrent process can not see the data in an inconsistent 
state (for example, the funds have been deducted from one account, but not yet 
credited to another.)

iv) Durability :- It guarantees that once a transaction has been committed, 
it will remain committed even if there is a system failure such as a power outage or crash.

2) Analytical Workloads :- 
---------------------------------
Analytical workloads are typically read-only systems that store vast volumes of 
historical data or business metrics, such as sales performance and inventory levels. 
Analytical workloads are used for data analysis and decision making. 
Analytics are generated by aggregating the facts presented by the raw data into summaries,
trends, and other kinds of “Business information.”

Difference between Batch and Streaming data :- 
------------------------------------------------------
Processing data as it arrives is called "Streaming".
Buffering and processing the data in groups is called "batch processing".

i) Batch Processing :- 
----------------------------
In batch processing, newly arriving data elements are collected 
into a group. The whole group is then processed at a future time as a batch. 
Batch data can be processed  on a scheduled time interval (for example, every hour),
or it could be triggered when a certain amount of data has arrived, 
or as the result of some other event.
Counting of votes is an example of batch Porcessing.

Advantages of batch processing :-
-------------------------------------------
i) Large volumes of data can be processed at a convenient time.
ii) We can run it  computers or systems might be idle such as overnight, or during off-peak hours.

Disadvantages of batch processing :- 
-------------------------------------------
i) The time delay between ingesting the data and getting the results.
ii) Since volume will be large. So minor error in data can halt entire process.

ii) Streaming and real-time Data :- 
---------------------------------------
In this processing data will be processed when it arrives.Streaming handles data in real time. 
Examples are stock market, Online Game, Mobile Apps etc..
Best example is a system that monitors a building for smoke and heat needs to trigger 
alarms and unlock doors to allow residents to escape immediately in the event of a fire.

Differences between BATCH and STREAMING Data :- 
--------------------------------------------------------
Apart from the way in which batch processing and streaming processing handle data, 
there are other differences:

2) https://docs.microsoft.com/en-us/learn/modules/explore-roles-responsibilities-world-of-data/?ns-enrollment-type=LearningPath&ns-enrollment-id=learn.wwl.azure-data-fundamentals-explore-core-data-concepts
/* Explore roles and responsibilities in the world of data */

Roles in the world of data :-
------------------------------------
1) Database Administrators :- 
a) Manage databases
b) Assigning permissions to users
c) Storing backup copies of data and 
d) Restore data in case of any failures
e) Managing the security of the data in the database
f) Granting privileges over the data
g) Granting or denying access to users as appropriate

2) Data Engineers :- 
a) Working with data,ingestion pipelines, cleansing and transformation activities
b) Applying data cleaning routines
c) Identifying business rules and
d) Turning data into useful information
They are also responsible for ensuring that the privacy of data is maintained 
within the cloud and spanning from on-premises to the cloud data stores. 
They also own the management and monitoring of data stores and data pipelines to ensure 
that data loads perform as expected.

3) Data Analysts :- EXPLORE and analyze data to create visualizations and charts 
to enable organizations to make informed decisions.
They are responsible for designing and building scalable models, cleaning and transforming data, 
and enabling advanced analytics capabilities through reports and visualizations.

A data analyst processes raw data into relevant insights based on identified business 
requirements to deliver relevant insights.

Review tasks and tools for database administration :- 
--------------------------------------------------------------
Database Administrator tasks and responsibilities :- 
--------------------------------------------------------------
●) Installing and upgrading the database server and application tools.
●) Allocating system storage and planning storage requirements for the database system.
●) Modifying the database structure, as necessary, from information given by application developers.
●) Enrolling users and maintaining system security.
●) Ensuring compliance with database vendor license agreement.
●) Controlling and monitoring user access to the database.
●) Monitoring and optimizing the performance of the database.
●) Planning for backup and recovery of database information.
●) Maintaining archived data.
●) Backing up and restoring databases.
●) Contacting database vendor for technical support.
●) Generating various reports by querying from database as per need.
●) Managing and monitoring data replication.

Database administrator tools :- 
---------------------------------
i) SQL Server Database :- SQL Server Management Studio
ii) PostgreSQL :- pgAdmin 
iii) MySQL :- MySQL Workbench
iv)  cross-platform database administration tools :- Azure Data Studio

Azure Data Studio :- 
-----------------------
It is a graphical user interface (GUI) for managing many different database systems.
Currently it provides connections to 
i) On-Premises SQL Server databases ii) Azure SQL Database
iii) PostgreSQL iv) Azure SQL Data Warehouse & v) SQL Server Big Data Clusters
Here 3rd party software can be downloaded and installed that connect to other systems.

SQL Server Management Studio :- (SSMS)
------------------------------------------
It provides a graphical interface, enabling you to query data, perform general 
database administration tasks, and generate scripts for automating database maintenance 
and support operations.
SSMS has the ability to generate Transact-SQL scripts.
/* Transact-SQL is a set of programming extensions from Microsoft that adds several features 
to the Structured Query Language (SQL), including transaction control, 
exception and error handling, row processing, and declared variables.
*/

Use Of Azure portal to manage Azure SQL Database :- 
--------------------------------------------------------
In Azure portal there is a Service called "Azure SQL database".
This is similar to SQL Server except that it runs in the cloud.
Task that can be done using azure portal :- 
a) Increasing the database size b) creating a new database and c) deleting an existing database

Data Engineer tasks and responsibilities :- 
---------------------------------------------------
●) Developing, constructing, testing, and maintaining databases and data structures.
●) Aligning the data architecture with business requirements.
●) Data acquisition.
●) Developing processes for creating and retrieving information from data sets.
●) Using programming languages and tools to examine the data.
●) Identifying ways to improve data reliability, efficiency, and quality.
●) Conducting research for industry and business questions.
●) Deploying sophisticated analytics programs, machine learning, and statistical methods.
●) Preparing data for predictive and prescriptive modeling.
●) Using data to discover tasks that can be automated.

Common data engineering tools :- 
-----------------------------------
A data engineer must have good knowledge on below points.
i) Architecture of the database management system
ii) Platform on which the system runs
iii) Business requirements for the data being stored in the database
iv) For RDBMS, proficiency in SQL database.
v) Run/Write SQL query manually.
vi) Interact with database from Command line(CLI).
/* sqlcmd utility to connect to Microsoft SQL Server and Azure SQL Database, 
and run ad-hoc queries and commands.
*/
vii) For RDBMS :- Knowledge of T-SQL, Azure Databricks, Azure HDInsight
viii) For Non RDBMS :- Azure Cosmos DB.
ix) To manipulate and query the data in Non relational field, knowledge of 
languages such as HiveQL, R, or Python.

Review tasks and tools for data visualization and reporting :- 
-------------------------------------------------------------------
Data Analyst tasks and responsibilities :- 
--------------------------------------------------
●) Making large or complex data more accessible, understandable, and usable.
●) Creating charts and graphs, histograms, geographical maps, and other visual models 
that help to explain the meaning of large volumes of data, and isolate areas of interest.
●) Transforming, improving, and integrating data from many sources, depending on 
the business requirements.
●) Combining the data result sets across multiple sources. 
For example, combining sales data and weather data provides a useful insight into how weather 
influenced sales of certain products such as ice creams.
●) Finding hidden patterns using data.
●) Delivering information in a useful and appealing way to users by creating rich graphical dashboards and reports.

Common data visualization tools :- 
-----------------------------------------
Data visualization tools are used by Data Analyst.Some examples are 
Microsoft Excel, Microsoft Power BI etc..

Power BI is a collection of software services, apps, and connectors which is used to connect 
to different data sources.
Data can be present in  local such as an Excel spreadsheet, or in a collection of 
cloud-based and on-premises databases, or some other set of data sources,Power BI can connect
to these source.


3) https://docs.microsoft.com/en-us/learn/modules/describe-concepts-of-relational-data/?ns-enrollment-type=LearningPath&ns-enrollment-id=learn.wwl.azure-data-fundamentals-explore-core-data-concepts
/* Describe concepts of relational data */
Normalization :- Split an entity into more than one table is called Normalization.
Main use of Relational Databases :- 
Online Transaction Processing (OLTP) :- OLTP applications are focused on transaction-oriented 
tasks that process a very large number of transactions per minute

Examples of OLTP applications that use relational databases are :- 
i) Banking solutions
ii) Online retail applications
iii) Flight reservation systems
iv) Many online purchasing applications.

Index :- In order to make retrival faster index is created.
Clustered Indexes :- A clustered index physically reorganizes a table by the index key.
A clustered index first sorts and then stores data row in the same table or view. 
So, it decides about storage order of data row in the table or view. 
The order is decided based clustered index key.

Note: A table can have only one clustered index. 
Primary key constraint in the table creates clustered index automatically. 
So if you have primary key already present in the table then you cannot create another clustered index.

Create Clustered Index demo_clustered_index
ON tblIndexDemo(FirstName)

After creating the clustered index, run select query for the table. 
You will see the table has been arranged in the alphabetical order on the first name basis.

select * from tblIndexDemo
/* Data will sorted on the baisc of FirstName column */

View :- A view is a virtual table based on the result set of a query.
On-Premises Vs Cloud :- 
----------------------------
i) Personal Control of Data security              a) On-Premises :- Yes  b) Cloud :- No
ii) Scalable                    a) On-Premises :- No  b) Cloud :- Yes
iii) Hardware Maintained        a) On-Premises :- No  b) Cloud :- Yes
iv) Software Maintained         a) On-Premises :- No  b) Cloud :- Yes
v) Low capital expenditure      a) On-Premises :- No  b) Cloud :- Yes
vi) Low Operation Expenditure   a) On-Premises :- Yes b) Cloud :- No

IaaS and PaaS :- 
-------------------------
i) IaaS :- IaaS is an acronym for "Infrastructure-as-a-Service".
Here we can create a virtual infrastructure in cloud.This is same as on-premises data center.
Here we can create set of virtual machines, connect them using a virtual network.
This approach is very similar to Running a system inside an organisation except hardware maintaining
part.Here day-to-day operations like installing and configuring the software, patching, 
taking backups, and restoring data will be done by user only.
IaaS as a half-way-house to fully managed operations in the cloud
Any licensed software can be run on virtually created machine.

Usage :- 
i) Migration of on-premises solution/data directly to a virtual machine in the cloud.
ii) Good for application where operating system level access is required.
/* Note :- Since here a virtual machine is getting created.Means user will get OS level access. */
/* Since OS got created.Now user needs to install a DB copy on that OS. */
iii) SQL virtual machines are lift-and-shift.

ii) PaaS :- PaaS stands for "Platform-as-a-service".
Here OS will not be created like IaaS.Directly Database will be created as per requirement.
Here user has to fill no of CPU, RAM etc and azure automatically creates the database/virtual machines.
Here Scaling will be done by Azure within few clicks.

PaaS solution for Relational Database available in Azure are :- 
a) Azure SQL Database           b) Azure Database for PostgreSQL
c) Azure Database for MySQL     d) Azure Database for MariaDB
/* Note :- Since here directly database is getting created.So OS and hardware will not be
exposed to application.If application is dependent on OS/hardware it needs to be removed.
*/

Comparision among SQL Server (On-Premises), Virtual machines in Azure (IaaS) & Azure SQL Database (PaaS)
Administrative Effort :- Low to High :- PaaS >>> IaaS >>> On-Premises
Capital Expenditure & day to day Control :- Low to High :- PaaS >>> IaaS >>> On-Premises


4) https://docs.microsoft.com/en-us/learn/modules/explore-concepts-of-non-relational-data/
/* Explore concepts of non-relational data */
Characteristics of non-relational data :- 
--------------------------------------------------
Non-relational databases don’t impose a schema on data. Instead, they focus on the data itself 
rather than how to structure it.
Example, a non-relational collection of customer entities might look like this :- 
## Customer 1
ID: 1
Name: Mark Hanson
Telephone: [ Home: 1-999-9999999, Business: 1-888-8888888, Cell: 1-777-7777777 ]
Address: [ Home: 121 Main Street, Some City, NY, 10110,
           Business: 87 Big Building, Some City, NY, 10111 ] 

## Customer 2
ID: 2
Title: Mr
Name: Jeff Hay
Telephone: [ Home: 0044-1999-333333, Mobile: 0044-17545-444444 ]
Address: [ UK: 86 High Street, Some Town, A County, GL8888, UK,
           US: 777 7th Street, Another City, CA, 90111 ]

Here fetching of data through ID will be easy.If user wants to fetch at some other attributes then
it will be complex.

Note :- 
Non-relational databases often provide their own proprietary language for managing and querying data. 
This language may be procedural (follow a set of commands, in order), or it may be similar to SQL; 
it depends on how the database is implemented by the database management system.

Non-relational database Use Cases :- 
i) IoT and telematics :- 
ii) Retail and marketing :- 
iii) Gaming :- 
iv) Web and mobile applications :- 

Types of Non-Relational data :- 
------------------------------------
Non-relational data has two category.
i) Semi-structured :- 
ii) Non-structured :- 

i) Semi-structured :- This kind of data contains fields.
Here the data must be formatted in such a way that an application can parse and process it. 
Common example to store the data for each entity as a JSON document.

a) JSON :- JavaScript Object Notation.
A JSON document is enclosed in curly brackets ({ and }).
Here each field has a name (a label), followed by a colon, and then the value of the field.
Ex :- 
{
  "ID": "1",
  "Name": "Mark Hanson",
  "Telephone": [ 
    { "Home": "1-999-9999999" }, 
    { "Business": "1-888-8888888" }, 
    { "Cell": "1-777-7777777" }
  ],
  "Address": [ 
    { "Home": [
      { "StreetAddress": "121 Main Street" }, 
      { "City": "Some City" },
      { "State": "NY" }, 
      { "Zip": "10110" }
    ] },
    { "Business": [
      { "StreetAddress": "87 Big Building" },
      { "City": "Some City" },
      { "State": "NY" },
      { "Zip": "10111" }
    ] }
  ] 
}

b) Avro :- Avro is a row-based format.  It was created by Apache.
Each record contains a header that describes the structure of the data in the record. 
This header is stored as JSON The data is stored as binary information.
Avro is a very good format for compressing data and minimizing storage and network bandwidth requirements.
Ex :- 
{
  "type": "record",
  "name": "contact_schema",
  "fields": [
   {
      "name": "id",
      "type": "int",
      "doc": "ID of the contact"
    },
    {
      "name": "name",
      "type": "string",
      "doc": "Name of the contact"
    },
{
      "name": "telephone",
      "type": [
        "null",
        {
          "type": "array",
          "items": {
            "type": "record",
            "name": "contact_schema.telephone",
            "fields": [
              {
                "name": "phoneid",
                "type": "int"
              },
              {
                "name": "phonetype",
                "type": [ "null", "string" ]
              }
            ]
          }
        }
      ]
    }
  ]
}

c) ORC (Optimized Row Columnar format) :- It organizes data into columns rather than rows.
It was developed by HortonWorks for optimizing read and write operations in Apache Hive.
Hive is a data warehouse system that supports fast data summarization and querying over
very large datasets. Hive supports SQL-like queries over unstructured data.
An ORC file contains stripes of data. Each stripe holds the data for a column or set of 
columns. A stripe contains an index into the rows in the stripe, the data for each row, 
and a footer that holds statistical information (count, sum, max, min, and so on) for each column.

d) Parquet :- Parquet is another columnar data format. It was created by Cloudera and Twitter. 
A Parquet file contains row groups. Data for each column is stored together in the same 
row group. Each row group contains one or more chunks of data. A Parquet file includes 
metadata that describes the set of rows found in each chunk. An application can use 
this metadata to quickly locate the correct chunk for a given set of rows, and retrieve 
the data in the specified columns for these rows. Parquet specializes in storing 
and processing nested data types efficiently. It supports very efficient compression 
and encoding schemes.

ii) Unstructured Data :- Unstructured data is data that doesn’t naturally contain fields. 
Examples include video, audio, and other media streams. 
Each item is an amorphous blob of binary data. 
You can’t search for specific elements in this data.
In Azure, you would probably store video and audio data as block blobs in an 
Azure Storage account. (The term blob stands for Binary Large Object*). 
A block blob only supports basic read and write operations.

Types of Non-Relational/NoSQL databases :- 
----------------------------------------------------
What is NoSQL :- NoSQL means Non-Relational.It is related to non-relational databases.
NoSQL (non-relational) databases generally fall into four categories :-
There are four types of NoSQL databases/Non-Relational database.
i) Key-Value Stores
ii) Document Databases
iii) Column Family Databases 
iv) Graph Databases. 

i) Key-Value Stores :- A key-value store is the simplest and often quickest type of 
NoSQL database for inserting and querying data.
Each data item has two elements a key and a value.The key uniquely identifies the item
and the value holds the data for the item.The value is OPAQUE to the DBMS.

OPAQUE :- OPAQUE means DB just see the value as an unstructured block.
Here only application will be able to understand how the data in the value is 
structured and what fields it contains
The opposite of OPAQUE is TRANSPARENT.If data is transparent DB can understand 
how the fields in the data are organized.A relational table is an example of a transparent structure.
Ex :- 
Key     Value
AAAA    1000010111010101010
BBBA    1001110111010101010
CFTR    1001110110010101010
ASJD    1001110111001010101

Here application will retrive the data on the basic of Key and after getting value
it will parse it.Here Query can not be done on "Value".
Here write operation are restricted to "Insert" and "Delete" only.
If any modification is required then at application end, it should be delete & Insert at "value".

The focus of a key-value store is the ability to read and write data very quickly. 
Search capabilities are secondary. A key-value store is an excellent choice for data 
ingestion, when a large volume of data arrives as a continual stream and must 
be stored immediately.

Example of key-value store in Azure :- 
i) Azure Table storage 
ii) Cosmos DB using Table API

Non Azure NOSQL Key-value Database Examples :- Cassandra, LevelDB, Riak

ii) Document Databases :- In a document database, each document has a unique ID, but 
the fields in the documents are transparent to the database management system.
Document databases stores data in JSON format,but they could be encoded using other formats 
such as XML, YAML, JSON, BSON. 
Documents could even be stored as plain text. The fields in documents are exposed 
to the storage management system, enabling an application to query and filter
data by using the values in these fields.

A document store does not require that all documents have the same structure. 
This free-form approach provides a great deal of flexibility. Applications 
can store different data in documents as business requirements change.

Key         Document
-----------------------------
1001        {
            "CustomerID": 99,
            "Orderitems":[
            {"ProductID": 2010,
            "Quantity": 2,
            "Cost": 520
            },
            { "ProductID": 4365,
            "Quantity": 1,
            "Cost": 18
            }]
            "OrderDate": "04/01/2017"
            }
1002        {
            "CustomerID": 220,
            "Orderitems":
            { "ProductID": 1285,
            "Quantity": 1,
            "Cost": 120
            }],
            "OrderDate": "05/08/2017"
            }
Here application can retrieve documents by using the document key.
The application can also query documents based on the value of one or more fields. 
Here indexing can also be created on document databases for faster retrival from it.

In some document database management provide facility to modify values of specific
field without rewriting the entire document. 

Example of document database in Azure :- 
i) Azure Cosmos DB in its Core (SQL) API.

Non Azure NOSQL Document Database Examples :- MongoDB, CouchDB.

iii) Column Family Databases/Column Store :- A column family database organizes data into rows and columns.
Example of Column Family database in Azure :- 
i) ORC Files
ii) Parquet Files
iii) Apache Cassandra
iv) Azure Cosmos DB through the Cassandra API

A column family database can appear very similar to a relational database, at least conceptually.

C:\Users\10662208\Desktop\ABHILASH\Script\Azure\column-family.png
C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Column-family-physical.png

Suppose we have two relational tables.
i) Customer Table ii) Address Table
Here in order to find customer details along with address needs a join.
If through application large no of request is coming then it will be time consuming process.
In order to handle this Column Family Databases came into picture.
Here similar kind of column is grouped together and it will be divided into groups
known as column-families.
Each column family holds a set of columns that are logically related together.

addressinfo
Row Key                         Column Families
--------                        --------------------
CustomerID          CustomerInfo                    Addressinfo
------------        -----------------------         --------------------
1                   Customerinfo:Title Mr           Addressinfo:StreetAddress 999 500th Ave
                    CustomerInfo:FirstName Mark     Addressinfo:City    Bellevue
                    CustomerInfo:LastName Hanson    AddressInfo:State   WA
                                                    AddressInfo:ZipCode 12345

2                   Customerinfo:Title Mr           Addressinfo:StreetAddress 999 500th Ave
                    CustomerInfo:FirstName Mark     Addressinfo:City    Bellevue
                    CustomerInfo:LastName Hanson    AddressInfo:State   WA
                                                    AddressInfo:ZipCode 12345

In most column family databases, the column-families are stored separately.
CustomerInfo column family might be held in one area of physical storage 
and the AddressInfo column family in another, in a simple form of vertical partitioning.
C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Column-family-physical.png

Non Azure NOSQL Column Family Examples :- HBase, BigTable, HyperTable.

iv) Graph Databases :- A graph database stores two types of information.
i) Nodes :- ii) Edges :- 
Nodes and edges can both have properties that provide information about that node 
or edge (like columns in a table). 
Additionally, edges can have a direction indicating the nature of the relationship.

The purpose of a graph database is to enable an application to efficiently perform 
queries that traverse the network of nodes and edges, and to analyze the relationships
between entities. The image below shows an organization’s personnel database 
structured as a graph. The entities are the employees and the departments in the 
organization, and the edges indicate reporting lines and the department in which 
employees work. In this graph, the arrows on the edges show the direction of the relationships.
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Graph DataBase.png

Example of Column Family database in Azure :- 
i) Azure Cosmos DB supports graph databases using the Gremlin API.

Non Azure NOSQL Graph database Examples :- Polyglot, Neo4J.

----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
5) https://docs.microsoft.com/en-us/learn/modules/explore-concepts-of-data-analytics/
/* Explore concepts of data analytics */

Wrangling :- It is the process by which you transform and map raw data into a 
more useful format for analysis. It can involve writing code to capture, filter, 
clean, combine, and aggregate data from many sources.

Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Data-Process_Diagram.png

Data Ingestion :- Data ingestion is the process of obtaining and 
importing data for immediate use or storage in a database.The data can arrive 
as a continuous stream, or in batches, depending on the source. 
This raw data can be held in a repository such as a DB, Files or some other type of fast 
& easily accessible storage.
Here first RAW data will stored from various sources and then we need to apply
transformation/Filter (ETL) and keep fresh data into DB which will be used for 
Reporting.At the time of filter data will be transformationed as per requirement
or reject suspicious, corrupt, or duplicated data.

Data Processing :- 
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Data_Processing.png
In data processing raw data is converted into business models.It can be 
a complex process which may involve  automated scripts, tools such as Azure Databricks, 
Azure Functions, and Azure Cognitive Services to examine and reformat the data, and generate models.
Data processing takes raw data and cleans it, and converts it into a more meaningful 
format (tables, graphs, documents, and so on).

Data cleaning is a generalized term that encompasses a range of actions, such as removing anomalies, 
and applying filters and transformations that would be too time-consuming to run 
during the ingestion stage.



What is ELT and ETL :- 
ETL :- Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure\ETL.png
ETL stands for Extract, Transform, and Load.
Here the raw data is retrieved and transformed before being saved.
It is suitable for systems that only require simple models, with little dependency 
between items. For example, this type of process is often used for basic data cleaning tasks, 
deduplicating data, and reformatting the contents of individual fields.

ELT :- Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure\ELT.png
It is an abbreviation of Extract, Load, and Transform.Here data is stored before being transformmed.
ELT is more suitable for constructing complex models that depend on multiple items in the 
database, often using periodic batch processing.

ETL Vs ELT Comparision :- 
--------------------------------
i) Improved data privacy & compliance :- Yes/No
ii) Data Lake Support :- No/Yes
iii) Does not require specialist skills :- Yes/No
iv) Ideal for large volumes of data :- No/Yes


What is reporting :- Reporting is the process of organizing data into informational
summaries to monitor how different areas of an organization are performing.

What is business intelligence :- 
The term Business Intelligence (BI) refers to technologies, applications, and practices 
for the collection, integration, analysis, and presentation of business information. 
The purpose of business intelligence is to support better decision making.

benchmarking :- Information is often gathered about other companies in the same industry for comparison. 
This process of comparison with other companies in the same industry is known as benchmarking.

What is data visualization :- 
Data visualization is the graphical representation of information and data.
For Azure most popular data visualization tool is "Power BI".
Powe BI can connect to multiple source of data and can combine them into a data model.
Using this data model visuals are build and all these visuals can be shared as Reports.

Visualization options to represent data :- The most common forms of visualizations are :- 
i) Bar and column charts :- Ex :- Volume of sales by month

ii) Line charts :- Ex :- Share Price

iii) Matrix :- A matrix visual is a tabular structure that summarizes data.

iv) Key influencers :- A key influencer chart displays the major contributors to a 
selected result or value.Ex :- what influences customers to place a 
second order or why sales were so high last June.

v) Treemap :- Treemaps are charts of colored rectangles, with size representing the 
relative value of each item.
They can be hierarchical, with rectangles nested within the main rectangles.

vi) Scatter :- A scatter chart shows the relationship between two numerical values. 
A bubble chart is a scatter chart that replaces data points with bubbles, 
with the bubble size representing an additional third data dimension.

vii) Filled map :- If you have geographical data, you can use a filled map to 
display how a value differs in proportion across a geography or region

Data Analytics :- The term data analytics is a catch-all that covers a range of 
activities, each with its own focus and goals. You can categorize these 
activities as 
i) descriptive :- Help answering on what has happend, based on historical data.
ii) diagnostic  :- Help answering on why things happend.
iii) predictive :- Help answering on what will happen in future.
iv) prescriptive :- Help answering on what action needs to be taken to achieve a goal.
v) cognitive analytics :- Help answering on draw inference from existing data and patterns.



Microsoft Azure Data Fundamentals: Explore core data concepts
Microsoft Azure Data Fundamentals: Explore relational data in Azure
Microsoft Azure Data Fundamentals: Explore non-relational data in Azure
Microsoft Azure Data Fundamentals: Explore modern data warehouse analytics in Azure


Go through Online-Free :- 
----------------------------------
1) https://docs.microsoft.com/en-us/learn/paths/azure-data-fundamentals-explore-core-data-concepts/
/* Azure Data Fundamentals: Explore core data concepts */

2) https://docs.microsoft.com/en-us/learn/paths/azure-data-fundamentals-explore-relational-data/
/* Azure Data Fundamentals: Explore relational data in Azure */

3) https://docs.microsoft.com/en-us/learn/paths/azure-data-fundamentals-explore-non-relational-data/
/* Azure Data Fundamentals: Explore non-relational data in Azure */

4) https://docs.microsoft.com/en-us/learn/paths/azure-data-fundamentals-explore-data-warehouse-analytics/
/* Azure Data Fundamentals: Explore modern data warehouse analytics in Azure */

----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
1) https://docs.microsoft.com/en-us/learn/paths/azure-data-fundamentals-explore-core-data-concepts/
/* Azure Data Fundamentals: Explore core data concepts */

/* Identify data formats */
Data is a collection of facts such as numbers, descriptions, and observations used to record information.
Identify data formats :- 
i) Structured data :- 
ii) Semi-structured data :- 
iii) Unstructured data :- 

Data stores :- 
i) File stores
ii) Databases

/* File stores */
i) Delimited text files
ii) JavaScript Object Notation (JSON) :- 
A JSON document is enclosed in curly brackets ({ and }).
Here each field has a name (a label), followed by a colon, and then the value of the field.
Ex :- 
{
  "ID": "1",
  "Name": "Mark Hanson",
  "Telephone": [ 
    { "Home": "1-999-9999999" }, 
    { "Business": "1-888-8888888" }, 
    { "Cell": "1-777-7777777" }
  ],
  "Address": [ 
    { "Home": [
      { "StreetAddress": "121 Main Street" }, 
      { "City": "Some City" },
      { "State": "NY" }, 
      { "Zip": "10110" }
    ] },
    { "Business": [
      { "StreetAddress": "87 Big Building" },
      { "City": "Some City" },
      { "State": "NY" },
      { "Zip": "10111" }
    ] }
  ] 
}


iii) Extensible Markup Language (XML) :- 
iv) Binary Large Object (BLOB) :- 
v) Optimized file formats :- 
a) Avro :- Avro is a row-based format.  It was created by Apache.
Each record contains a header that describes the structure of the data in the record. 
This header is stored as JSON The data is stored as binary information.
Avro is a very good format for compressing data and minimizing storage and network bandwidth requirements.
Ex :- 
{
  "type": "record",
  "name": "contact_schema",
  "fields": [
   {
      "name": "id",
      "type": "int",
      "doc": "ID of the contact"
    },
    {
      "name": "name",
      "type": "string",
      "doc": "Name of the contact"
    },
{
      "name": "telephone",
      "type": [
        "null",
        {
          "type": "array",
          "items": {
            "type": "record",
            "name": "contact_schema.telephone",
            "fields": [
              {
                "name": "phoneid",
                "type": "int"
              },
              {
                "name": "phonetype",
                "type": [ "null", "string" ]
              }
            ]
          }
        }
      ]
    }
  ]
}
b) ORC (Optimized Row Columnar format)  :- It organizes data into columns rather than rows.
It was developed by HortonWorks for optimizing read and write operations in Apache Hive.
Hive is a data warehouse system that supports fast data summarization and querying over
very large datasets. Hive supports SQL-like queries over unstructured data.
An ORC file contains stripes of data. Each stripe holds the data for a column or set of 
columns. A stripe contains an index into the rows in the stripe, the data for each row, 
and a footer that holds statistical information (count, sum, max, min, and so on) for each column.

c) Parquet :- Parquet is another columnar data format. It was created by Cloudera and Twitter. 
A Parquet file contains row groups. Data for each column is stored together in the same 
row group. Each row group contains one or more chunks of data. A Parquet file includes 
metadata that describes the set of rows found in each chunk. An application can use 
this metadata to quickly locate the correct chunk for a given set of rows, and retrieve 
the data in the specified columns for these rows. Parquet specializes in storing 
and processing nested data types efficiently. It supports very efficient compression 
and encoding schemes.

/* Databases */
Non-relational databases are often referred to as NoSQL database, even though some support a 
variant of the SQL language.
i) Key-value databases :- 
ii) Document databases :- 
iii) Column family databases :- 
iv) Graph databases :- 


1) Transactional Workloads :- 
-------------------------------
A transactional database must adhere to the ACID (Atomicity, Consistency, Isolation, Durability) 
properties to ensure that the database remains consistent while processing transactions.

i) Atomicity :- This feature guarantees that each transaction is treated as a single unit
which will successed or fail completely.
If any of the statements constituting a transaction fails then the entire transaction 
fails and the database is left unchanged.

ii) Consistency :- This feature ensures that  transaction can only take the data in 
the database from one valid state to another. 
A consistent database should never lose or create data in a manner that can not be 
accounted for.
In Bank transaction if in one account money got added then somewhere in other system
it must be deducted to maintain consistency.

iii) Isolation :- It ensures that concurrent execution of transactions leaves the database 
in the same state that would have been obtained if the transactions were executed 
sequentially. A concurrent process can not see the data in an inconsistent 
state (for example, the funds have been deducted from one account, but not yet 
credited to another.)

iv) Durability :- It guarantees that once a transaction has been committed, 
it will remain committed even if there is a system failure such as a power outage or crash.

OLTP systems are typically used to support live applications that process business
data - often referred to as line of business (LOB) applications.

/* Explore analytical data processing */
As we know.



Wrangling :- It is the process by which you transform and map raw data into a 
more useful format for analysis. It can involve writing code to capture, filter, 
clean, combine, and aggregate data from many sources.

Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Data-Process_Diagram.png

Data Ingestion :- Data ingestion is the process of obtaining and 
importing data for immediate use or storage in a database.The data can arrive 
as a continuous stream, or in batches, depending on the source. 
This raw data can be held in a repository such as a DB, Files or some other type of fast 
& easily accessible storage.
Here first RAW data will stored from various sources and then we need to apply
transformation/Filter (ETL) and keep fresh data into DB which will be used for 
Reporting.At the time of filter data will be transformationed as per requirement
or reject suspicious, corrupt, or duplicated data.

Data Processing :- 
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Data_Processing.png
In data processing raw data is converted into business models.It can be 
a complex process which may involve  automated scripts, tools such as Azure Databricks, 
Azure Functions, and Azure Cognitive Services to examine and reformat the data, and generate models.
Data processing takes raw data and cleans it, and converts it into a more meaningful 
format (tables, graphs, documents, and so on).

Data cleaning is a generalized term that encompasses a range of actions, such as removing anomalies, 
and applying filters and transformations that would be too time-consuming to run 
during the ingestion stage.

What is ELT and ETL :- 
ETL :- Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure\ETL.png
ETL stands for Extract, Transform, and Load.
Here the raw data is retrieved and transformed before being saved.
It is suitable for systems that only require simple models, with little dependency 
between items. For example, this type of process is often used for basic data cleaning tasks, 
deduplicating data, and reformatting the contents of individual fields.

ELT :- Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure\ELT.png
It is an abbreviation of Extract, Load, and Transform.Here data is stored before being transformmed.
ELT is more suitable for constructing complex models that depend on multiple items in the 
database, often using periodic batch processing.

ETL Vs ELT Comparision :- 
--------------------------------
i) Improved data privacy & compliance :- Yes/No
ii) Data Lake Support :- No/Yes
iii) Does not require specialist skills :- Yes/No
iv) Ideal for large volumes of data :- No/Yes


What is reporting :- Reporting is the process of organizing data into informational
summaries to monitor how different areas of an organization are performing.

What is business intelligence :- 
The term Business Intelligence (BI) refers to technologies, applications, and practices 
for the collection, integration, analysis, and presentation of business information. 
The purpose of business intelligence is to support better decision making.

benchmarking :- Information is often gathered about other companies in the same industry for comparison. 
This process of comparison with other companies in the same industry is known as benchmarking.

What is data visualization :- 
Data visualization is the graphical representation of information and data.
For Azure most popular data visualization tool is "Power BI".
Powe BI can connect to multiple source of data and can combine them into a data model.
Using this data model visuals are build and all these visuals can be shared as Reports.

Visualization options to represent data :- The most common forms of visualizations are :- 
i) Bar and column charts :- Ex :- Volume of sales by month

ii) Line charts :- Ex :- Share Price

iii) Matrix :- A matrix visual is a tabular structure that summarizes data.

iv) Key influencers :- A key influencer chart displays the major contributors to a 
selected result or value.Ex :- what influences customers to place a 
second order or why sales were so high last June.

v) Treemap :- Treemaps are charts of colored rectangles, with size representing the 
relative value of each item.
They can be hierarchical, with rectangles nested within the main rectangles.

vi) Scatter :- A scatter chart shows the relationship between two numerical values. 
A bubble chart is a scatter chart that replaces data points with bubbles, 
with the bubble size representing an additional third data dimension.

vii) Filled map :- If you have geographical data, you can use a filled map to 
display how a value differs in proportion across a geography or region

Data Analytics :- The term data analytics is a catch-all that covers a range of 
activities, each with its own focus and goals. You can categorize these 
activities as 
i) descriptive :- Help answering on what has happend, based on historical data.
ii) diagnostic  :- Help answering on why things happend.
iii) predictive :- Help answering on what will happen in future.
iv) prescriptive :- Help answering on what action needs to be taken to achieve a goal.
v) cognitive analytics :- Help answering on draw inference from existing data and patterns.




/* https://docs.microsoft.com/en-us/learn/modules/explore-roles-responsibilities-world-of-data/2-explore-job-roles */
/* Explore job roles in the world of data */

Roles in the world of data :-
------------------------------------
1) Database Administrators :- 
a) Manage databases
b) Assigning permissions to users
c) Storing backup copies of data and 
d) Restore data in case of any failures
e) Managing the security of the data in the database
f) Granting privileges over the data
g) Granting or denying access to users as appropriate

2) Data Engineers :- 
a) Working with data,ingestion pipelines, cleansing and transformation activities
b) Applying data cleaning routines
c) Identifying business rules and
d) Turning data into useful information
They are also responsible for ensuring that the privacy of data is maintained 
within the cloud and spanning from on-premises to the cloud data stores. 
They also own the management and monitoring of data stores and data pipelines to ensure 
that data loads perform as expected.

3) Data Analysts :- EXPLORE and analyze data to create visualizations and charts 
to enable organizations to make informed decisions.
They are responsible for designing and building scalable models, cleaning and transforming data, 
and enabling advanced analytics capabilities through reports and visualizations.

A data analyst processes raw data into relevant insights based on identified business 
requirements to deliver relevant insights.

/* Identify data services */
i) Azure SQL :- 
ii) Azure Database for open-source relational databases
	a) Azure Database for MySQL
	b) Azure Database for MariaDB 
	c) Azure Database for PostgreSQL
iii) Azure Cosmos DB :- 
iv) Azure Storage :- 
v) Azure Data Factory

vi) Azure Synapse Analytics

vii) Azure Databricks

viii) Azure HDInsight

ix) Azure Stream Analytics

x) Azure Data Explorer
xi) Azure Purview
xii) Microsoft Power BI

----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
2) https://docs.microsoft.com/en-us/learn/paths/azure-data-fundamentals-explore-relational-data/
/* Azure Data Fundamentals: Explore relational data in Azure */

entity :- Table
attribute  :- Columns
instance of an entity :- Rows

A table contains rows, and each row represents a single instance of an entity
SQL stands for Structured Query Language.
SQL was originally standardized by the American National Standards Institute (ANSI) in 1986.

Query Relational data in Azure :- 
-------------------------------------
DDL :- Data Definitation Language. Ex :- Create table, Alter table etc.
DML :- Data Manipulation Language. Ex :- Insert, Update, Delete,Select
DCL :- Data Control Language :- Ex :- Grant, Revoke, Deny


SQL Server on Azure Virtual Machine :- 
----------------------------------------------
Here first user will create a VM and there SQL server will be installed.
Here VM will be present in cloud.If SQL server is on premise then hardware requirement will be there
but here user does not have to maintain this.

Azure Database for PostgreSQL, MariaDB and MySQL :- 
-----------------------------------------------------------
i) Azure Database for PostgreSQL :- Automatically back up till 35 days.
There two way through which it can be deployed.
a) Single :- 
b) Hyper Scale (Citus Cluster) :- 

Azure Database for MariaDB :- Automatically back up till 35 days.
It works on Maria Db service Engine.It is well suited for Business critical workloads.
It can be used in IAAS Model :- (Infrastrucure as Service Model) & PAAS Model.

Azure Database for MySQL :- Automatically back up till 35 days.
It is the simplest relational database.

Provisioning and deploying relational data services on Azure :- 
--------------------------------------------------------------------
Provisioning is the act of running series of tasks that a service provider such as Azure SQL database
performs to create and configure a service.
Here user has to select database and its component.Acoordingly price will be calculated.

Method for Deployement :- 
--------------------------------
In Azure there are 4 methods available for deployement.
i) The Azure Portal :- portal.azure.com
ii) The Azure Command Line Interface (CLI) (Cloud Shell) :- It is embeded within portal.azure.com.
iii) Azure PowerShell :- Here "Azure Module" needs to be installed.then login to azure portal using credentials.
iv) Azure Resource Manager Templates (ARM) :- This is based on JSON patterns and 
contains key value pairs of the resources created.
Here created Sub Resource will also have JSON patterns and combining all these JSON patterns
makes "ARM" templates.

Data Security Components :- 
--------------------------------
i) Network Security :- a) Firewall b) Network Security Groups (NSG)
Firewall works on factors like Port,IP ranges
NSG works on factors like Port, Source, Destination & IP.

ii) Identity & Access Management (IAM) :- Azure AD & RBAC
It is used for authorizing and authentication of particular user.

iii) Encryption capabilities built into azure :- Azure Data Encryption (ADE).
It has ability to to encrypt/decrypt data in rest or in motion.
Here data can also be masked.

iv) Azure Threat Protection (ATP) :- It is a cloud based security solution.
It leverages on premises active directory signals to identify and detect an investigated advanced threats.
It also works on compromised identity and malicious insider action.
"OPS analyst manage ATP."

Query Tools :- 
---------------------
i) Azure Data Studio :- A light weight editor that can run on demand SQL queries, view & save result 
as text, JSON or excel.
OS :- Windows, macOS, Linux

ii) SQL Server management Studio (SSMS) :- Manage a SQL Server instance or database with full GUI support.
OS :- Windows

iii) SQL Server Data Tools (SSDT) :- A modern development tool for building SQL server relational database,
Azure SQL database, Analysis Service (AS) data models, Integration Services (IS) Packages, 
And Reporting Services (RS) reports.
OS :- Windows

iv) Visual Studio Code :- The MSSQL extension for Visual Studio Code is the official SQL Server extension
that supports connection to SQL Server and rich editing experience for T-SQL in visual Studio Code.
OS :- Windows, macOS, Linux


Index :- 
-------------
Syntax :- 
CREATE INDEX <Index_Name> ON <Table_name> (Col_Name)
DROP INDEX <Index_Name>.<Table_name>

Types of Indexes in SQL Server :- 
-------------------------------------
i) Clustered Index
ii) Non-Clustered Index
iii) Unique Index

i) A clustered index first sorts and then stores data row in the table or view. 
So, it decides about storage order of data row in the table or view. 
The order is decided based clustered index key.

Note: A table can have only one clustered index. Primary key constraint in the 
table creates clustered index automatically. 
So if you have primary key already present in the table then you cannot 
create another clustered index.

Create Clustered Index demo_clustered_index
ON tblIndexDemo(FirstName)

After creating the clustered index, run select query for the table. 
You will see the table has been arranged in the alphabetical order on the first name basis.

select * from tblIndexDemo
/* Data will sorted on the baisc of FirstName column */

ii) Non Clustered Index :- 
A non-clustered index maintains another table (can say lookup table) for the 
indexes that is stored at the separate location from the actual table. 
The index in the lookup table will point to the data row of the actual table.

Create NonClustered Index demo_non_clustered_index
ON tblIndexDemo(FirstName);

Difference Between Clustered and Non-Clustered Index :- 
i) Clustered index is stored physically in the table but non-clustered index is 
located at separate location.
ii) There can only one clustered index per table but multiple non-clustered index.
iii) Clustered index is fast to read data because they are present in table itself. 
	Non-clustered index is maintained in another table so it is comparatively slow.
iv) Non-clustered index is faster if you are inserting and updating data.
v) Non-clustered index consumes extra storage space because of the extra table.

iii) Unique Index :- 
Unique index maintains unique entries in the index, means no duplicate values are 
allowed in that column.
When you create a primary key then a unique clustered index is automatically created 
on that column.
You can define multiple unique index in a table.

Create UNIQUE INDEX demo_unique_index
ON tblIndexDemo(FirstName);

What is a columnstore index :- 
------------------------------------
A columnstore index is a technology for storing, retrieving, and managing data by 
using a columnar data format, 
called a columnstore.

In a column-based index, the data in the Employee table is stored in separate file 
for each of the columns.
So suppose in a query we need only a single column then
only that file will be scanned.So performance will be faster.
A row-based index is not as efficient because it may need to load one or more 
larger-sized data pages into 
memory and read the entire rows,

CREATE COLUMNSTORE INDEX idx_cs1
ON EmployeeTable (FirstName, LastName, HireDate, Gender);

You can also create columnstore indexes using SQL Server Management Studio. 
Simply navigate to the Indexes 
section of the table, and select New Index > Non-clustered Columnstore Index.

Relational data on Azure :- 
-------------------------------
Choose the right SQL option in Azure :- 
i) SQL server on a virtual machine (VM) :- IAAS :- Here we will have a server(Virtual Machine) and in this 
machine we will install SQL server.Now the application will connect to this DB via server.
Here we will have full control over machine.We will get 99.95% availability.
Suppose any one has a on premises SQL server and he wants to move this to VM then user will get
exact version of DB in VM.So there will not be any problem in migration since version is same.

ii) Azure SQL database (Managed Instance) :- PAAS :- Here user will go to Azure and configure a SQL server in the cloud.
Here availibility will be 99.99%.It will have build in advanced intelligence and security.
Here entire DB will be managed by Azure team.Backup, Patching and DR will be done by Azure itself.
Here user will get built in advanced intelligence and security.d

iii) Azure SQL database (Logical Server) :- It will be also present in azure.
but here it will be completely logical.At any moment of time user can do hardware,CPU configuration
changes through UI.Rest of the feature will be same as Azure SQL database (Managed Instance).

Services in Azure :- 
--------------------------------
i) Azure SQL database :- Azure SQL database is a fully managed platform as a service(PaaS) database engine.
This is also called DBAAs(Database As A Service).
Here we will get a Query platform in the portal and can use it to query data in the Azure SQL Database.

Deployement Options :- 
-------------------------------
i) Single Database :- It has two types.
a) IAAS Model :- (Infrastrucure as Service Model) 
b) PAAS Model :- (Platform as a service Model)
In IAAS model first user will spin a virtual machine and that virtual machine would have the
configuration like CPU, Memory and all other requirement based on requirement of database.
Now user will physically login into the server which will be empty and on that server database 
needs to be installed in it.Here as per our requirement we can install any version of SQL database.
Here user will be totally responsible to manage the VM.Here availitibility will be given by azure
on VM not to database.

In PAAS model user will got to azure portal and search for database which will be a pre installed
database.Here there will also be a server but it will be totally logical.
Here everyting will be managed by Azure.Since this will be managed by Azure so it will have
more availability given on database itself as compared to IAAS Model.

ii) Elastic Pool :- It is a pool of database.
Here reources are shared among databases within a pool.
Suppose there are three databases within elastic pool and each database is assigned an equal 
amount of database resources.
If load on one database increases and rest two are in good shape then resource from these two
can be utilised by 1st database to maintain sustainibility.(Sharing is Caring).

Suppose there is a Resource group inside that three databases exists And pricing of these databases
are calculated based on DTU(Database Transactional Unit).
So here instead of giving each DB as full resource combining 3 will get all reseource.
And when load will increase on anyone DB then other DB resources will be utilised.
Due to this model Prices will be less for USer.

Database administrator tools :- 
---------------------------------
i) SQL Server Database :- SQL Server Management Studio
ii) PostgreSQL :- pgAdmin 
iii) MySQL :- MySQL Workbench
iv)  cross-platform database administration tools :- Azure Data Studio

Azure Data Studio :- 
-----------------------
It is a graphical user interface (GUI) for managing many different database systems.
Currently it provides connections to 
i) On-Premises SQL Server databases ii) Azure SQL Database
iii) PostgreSQL iv) Azure SQL Data Warehouse & v) SQL Server Big Data Clusters
Here 3rd party software can be downloaded and installed that connect to other systems.

SQL Server Management Studio :- (SSMS)
------------------------------------------
It provides a graphical interface, enabling you to query data, perform general 
database administration tasks, and generate scripts for automating database maintenance 
and support operations.
SSMS has the ability to generate Transact-SQL scripts.
/* Transact-SQL is a set of programming extensions from Microsoft that adds several features 
to the Structured Query Language (SQL), including transaction control, 
exception and error handling, row processing, and declared variables.
*/

Use Of Azure portal to manage Azure SQL Database :- 
--------------------------------------------------------
In Azure portal there is a Service called "Azure SQL database".
This is similar to SQL Server except that it runs in the cloud.
Task that can be done using azure portal :- 
a) Increasing the database size b) creating a new database and c) deleting an existing database


On-Premises Vs Cloud :- 
----------------------------
i) Personal Control of Data security              a) On-Premises :- Yes  b) Cloud :- No
ii) Scalable                    a) On-Premises :- No  b) Cloud :- Yes
iii) Hardware Maintained        a) On-Premises :- No  b) Cloud :- Yes
iv) Software Maintained         a) On-Premises :- No  b) Cloud :- Yes
v) Low capital expenditure      a) On-Premises :- No  b) Cloud :- Yes
vi) Low Operation Expenditure   a) On-Premises :- Yes b) Cloud :- No

IaaS and PaaS :- 
-------------------------
i) IaaS :- IaaS is an acronym for "Infrastructure-as-a-Service".
Here we can create a virtual infrastructure in cloud.This is same as on-premises data center.
Here we can create set of virtual machines, connect them using a virtual network.
This approach is very similar to Running a system inside an organisation except hardware maintaining
part.Here day-to-day operations like installing and configuring the software, patching, 
taking backups, and restoring data will be done by user only.
IaaS as a half-way-house to fully managed operations in the cloud
Any licensed software can be run on virtually created machine.

Usage :- 
i) Migration of on-premises solution/data directly to a virtual machine in the cloud.
ii) Good for application where operating system level access is required.
/* Note :- Since here a virtual machine is getting created.Means user will get OS level access. */
/* Since OS got created.Now user needs to install a DB copy on that OS. */
iii) SQL virtual machines are lift-and-shift.

ii) PaaS :- PaaS stands for "Platform-as-a-service".
Here OS will not be created like IaaS.Directly Database will be created as per requirement.
Here user has to fill no of CPU, RAM etc and azure automatically creates the database/virtual machines.
Here Scaling will be done by Azure within few clicks.

PaaS solution for Relational Database available in Azure are :- 
a) Azure SQL Database           b) Azure Database for PostgreSQL
c) Azure Database for MySQL     d) Azure Database for MariaDB
/* Note :- Since here directly database is getting created.So OS and hardware will not be
exposed to application.If application is dependent on OS/hardware it needs to be removed.
*/

Comparision among SQL Server (On-Premises), Virtual machines in Azure (IaaS) & Azure SQL Database (PaaS)
Administrative Effort :- Low to High :- PaaS >>> IaaS >>> On-Premises
Capital Expenditure & day to day Control :- Low to High :- PaaS >>> IaaS >>> On-Premises

Question :- 
Port Number for :- 
Azure SQL Database :- 1433
Azure MySQL :- 3306
Azure PostgreSQL :- 5432

C:\Users\abhilaskumar\Desktop\Abhilash\Project\Work\2022\March\30th Mar 2022\1.PNG


----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
3) https://docs.microsoft.com/en-us/learn/paths/azure-data-fundamentals-explore-non-relational-data/
/* Microsoft Azure Data Fundamentals: Explore non-relational data in Azure */

/* Explore Azure Table storage */
Azure Table Storage implements the NoSQL key-value model.
Here the data for an item is stored as a set of fields, and the item is identified 
by a unique key.

Path :- F:\ABHILASH\Azure_Learning\Azure Table storage Key Value.png
Path :  C:\Users\abhilaskumar\Desktop\Abhilash\Script\Azure Table Storagee.png

/* https://docs.microsoft.com/en-us/learn/modules/explore-non-relational-data-offerings-azure/2-explore-azure-table-storage */
/* What is Azure Table Storage */
An Azure table enables you to store semi-structured data.
Here items are referred to as rows, and fields are known as columns.
All rows in a table must have a key but columns in each row can vary.
Azure Table Storage tables have no concept of relationships, stored procedures, secondary indexes, or foreign keys.
Here data will be present in denormalized form where each row will have entire data for a logical entity.
 
suppose we are storing customer information.Then in 1st row we may have 1st name, last name and 1 phone number
but 2nd row can have 1st name, last name and 2 phone numbers.So no of column can vary.
Accessing data from Azure Table Storage will be faster as all data is coming from a single row.

Path :- F:\ABHILASH\Azure_Learning\Table_Storage_Row_Column.png

/* Partitioning in Azure Table Storage */
For fast access Azure Table Storage splits a table into partitions.
Partitioning is a mechanism for grouping related rows, based on a common property or partition key. 

Rows that share the same partition key will be stored together. 
Partitioning helps to organize data and improve scalability and performance:

i) Partitions are independent from each other, and can grow or shrink as rows are added to, 
or removed from, a partition. A table can contain any number of partitions.

ii) While searching data, partition key can be included in the search criteria.
It reduces volume of data and amount of I/O (reads and writes) needed to locate the data.

Azure Table Storage table comprises two Key elements :- 
i) Partition Key :- It identifies the partition containing the row.
ii) Row key :-  It is unique to each row in the same partition.
Items in the same partition are stored in row key order
If an application adds a new row to a table, Azure ensures that the row is placed in 
the correct position in the table.

As data is stored in ordered manner, so application can quickly perform point queries that 
identify a single row, and range queries that fetch a contiguous block of rows in a partition.

/* https://docs.microsoft.com/en-us/learn/modules/explore-non-relational-data-offerings-azure/3-explore-azure-blob-storage */
/* Explore Azure Blob storage */
The term blob is an acronym for Binary Large OBject.
Azure Blob storage is a service that enables you to store massive amounts of unstructured 
data, or blobs (large, binary data objects, such as images and video streams) in the cloud.

Azure currently supports three different types of blob :- 
i) Block blobs :- The block is the smallest unit of data where data can be kept as an individual
unit.Maximum size of a block can be up to 100 MB.
A block blob can contain up to 50,000 blocks and maximum size can be 4.7 TB.
Block blobs are best used to store discrete, large, binary objects that change infrequently 
(not very frequently).

ii) Page blobs :- A page blob will have fixed size of 512 byte pages.Generaly it is used to support
random read and write operations.A page blob can hold up to 8 TB of data. 
In Azure Page blobs are used to implements virtual disk storage for virtual machines.

iii) Append blobs :- An append blob is a block blob optimized to support append operations. 
We can add blocks only at the end of Append blobs.Each Block size can vary up to 4MB.
The maximum size of an append blob is just over 195 GB.

Inside Azure account we need to create container.Here blob can be organized in a hierarchy 
of folders the way we keep files in file system.
At container level read/write access of blob can be managed.

Path :- F:\ABHILASH\Azure_Learning\Container.png
Blob storage provides three access tiers, which help to balance access latency and storage cost :-

i) Hot tier :- It is the default.This tier is used for the blobs that are accessed frequently.
The blob data is stored on high-performance media.

ii) Cool tier :- This tier has lower performance.Hense lower storage cost/charges compared to the Hot tier.
If data is accessed Infrequently then we can keep blob in Cool tier.
We can migrate data from cool to Hot and Vice Versa as per requirement.

iii) Archive tier :- This tier has lowest storage cost but with increased latency.
This tier is used to keep Historical data that must not be lost.
Here data is stored in offline state.In Hot and Cool tier data can be read in few milliseconds.
but reading data from Archive tier can take hours for data become available.
In order to retrive data from Archive tier, we need to change the access tier to Hot or Cool.
The blob will then be rehydrated.Once rehydration process is completed we can read the data.

/* Lifecycle Management Policies For BLOBS */
We can create a Lifecycle management policies for blobs in storage account.
This policy can automatically move a blob from Hot to Cool and then to the Archive Tier.
Policy is created based on the number of days since modification.
Here policy can also be configured in such a way that can arrange to delete outdated blobs.

/* Use cases and management benefits of using Azure Blob Storage :- */
i) Serving images or documents directly to a browser, in the form of a static website.
ii) Storing files for distributed access
iii) Streaming video and audio
iv) Storing data for backup and restore, disaster recovery, and archiving
v) Storing data for analysis by an on-premises or Azure-hosted service

Note :- Azure Blob storage is also used as the basis for Azure Data Lake storage. 
You can use Azure Data Lake storage for performing big data analytics. 

/* Features available with Azure Blob storage :- */
i) Availability :- To ensure availablity blob storage provides "Redundancy" in which
blobs are replicated three times in the region where azure account is created.
If we have selected "geo-redundancy" then data will be replicated into 2nd region with
additional cost.

ii) Versioning :- Earlier versions of a blob can be maintained and restored.

iii) Soft delete :- Due to this feature accidently deleted/updated blob can be recovered.

iv) Snapshots :- A snapshot is a read-only version of a blob at a particular point in time.

v) Change Feed :- Due to this feature we can get record of updates made to blob.
It can be used to monitor changes.

/* https://docs.microsoft.com/en-us/learn/modules/explore-provision-deploy-non-relational-data-services-azure/3-azure-data-lake-gen2 */
/* Explore Azure DataLake Storage Gen2 */
Azure Data Lake Store (Gen1) is a service for hierarchical data storage for analytical data lakes
which is used by big data analytical solutions that work with structured, semi-structured, 
and unstructured data stored in files.

Azure Data Lake Storage Gen2 is a newer version of this service that is integrated into Azure Storage.
Here we can take advantage of scalability of blob storage and the cost-control of storage tiers.
It also combines functionality of hierarchical file system capabilities and compatibility 
with major analytics systems of Azure Data Lake Store.

Since in ADLS Gen2 there will be high volume of data will be present which can be mounted into
Hadoop in Azure HDInsight, Azure Databricks, and Azure Synapse Analytics.

In order to create ADLS Gen2, we must enable the Hierarchical Namespace option of an Azure Storage account.
We can also upgrade an existing Azure Storage account to support Data Lake Gen2.
But it is a one way process.We can not revert it.

/* https://docs.microsoft.com/en-us/learn/modules/explore-non-relational-data-offerings-azure/4-explore-azure-file-storage */
/* Explore Azure File storage */
/* What is Azure File Storage? */
Once we create Azure Storage account, we will have four options on left side in the screen.
i) Container ii) File Shares iii) Queues iv) Tables
Here we will discuss /* File Shares */
Azure File Storage enables you to create files shares in the cloud, and access these 
file shares from anywhere with an internet connection.
It uses Server Message Block 3.0 (SMB) protocol.
Currently same protocol is getting used in many existing on-premises applications.
If we are moving/Migrating on-premises file shares to Cloud, These applications should continue 
to work unchanged.
We can access the shares in Azure File Storage using authentication and authorization 
services available through Azure Active Directory Domain Services.

In Azure File Storage(File Shares) account we can share up to 100 TB of data.
This data can be distributed across any number of file shares in the account.
The way we can create multiple container, same way we can also create any number of file shares.
The maximum size of a single file is 1 TB.But it can be controlled using quota option as per our choice.
Currently, Azure File Storage supports up to 2000 concurrent connections per shared file.

We can upload data to storage account using Azure portal or AzCopy utility.
Azure File Sync service can also be used to synchronize locally cached copies of 
shared files with the data in Azure File Storage.

Azure File Storage offers two performance tiers. 
i) Standard tier :- The Standard tier uses hard disk-based hardware in a datacenter, and 
ii) Premium tier :- The Premium tier uses solid-state disks. 
The Premium tier offers greater throughput, but is charged at a higher rate.

Azure Files supports two common network file sharing protocols:
i) Server Message Block (SMB) file sharing is commonly used across multiple operating 
systems (Windows, Linux, macOS).

ii) Network File System (NFS) shares are used by some Linux and macOS versions. 
To create an NFS share, you must use a premium tier storage account 
and create and configure a virtual network through which access to the share can be controlled.

/* Use cases & Benefit of Azure File Storage */
i) Migrate existing applications to the cloud :- 
ii) Share server data across on-premises and cloud :- 
iii) Integrate modern applications with Azure File Storage :- 
iv) Simplify hosting High Availability (HA) workload data :- 

Note :- Try to avoid use of Azure File Storage where same file is getting written by multiple
users.It can cause loss of data due to write lock and release lock.

Here also data is replicated locally within region but can also be geo-replicated 
to a second region.

All data is encrypted at rest, and you can enable encryption for data in-transit 
between Azure File Storage and your applications.

/* https://docs.microsoft.com/en-us/learn/modules/explore-provision-deploy-non-relational-data-services-azure/6-exercise-azure-storage */
/* Exercise: Explore Azure Storage */
/* Try to complete this */

/* Training */
ii) Unstructured Data :- Unstructured data is data that doesn’t naturally contain fields. 
Examples include video, audio, and other media streams. 
Each item is an amorphous blob of binary data. 
You can’t search for specific elements in this data.
In Azure, you would probably store video and audio data as block blobs in an 
Azure Storage account. (The term blob stands for Binary Large Object*). 
A block blob only supports basic read and write operations.

Non Relational Data on Azure :- 
-----------------------------------
Azure Data Services for Non-Relational Workloads :- 
-----------------------------------------------------------------
If user want to store data which is non structured like pdf files, Zipped files, Audio, video etc..
then in Azure it can be stored in "Storage Account" or "Data Lake Store".
Going through Azure portal user can directly create "Storage Account" and here all these
Non Structured data can be dumped.
Since in "Storage Account" user can not do Query directly.So through ETL/ELT data will be moved
to "Azure Synapse".Now here user can do Query on data.This is called "Data Storage Layer".

1) Storage Account :- 
--------------------------
i) Low Cost, high throughput data store.
ii) No-SQL data
iii) No Query on data directly.No ad hoc query support.
iv) Good for Storage of Archive or Static data.
v) Acts as a HDInsight Hadoop data store
vi) Here Flat files will be present.
vii) Old Approach

/* https://k21academy.com/microsoft-azure/az-303/azure-storage-account/#:~:text=Only%20data%20services%20from%20Azure,and%20files%20with%20disk%20images. */
/* Azure Storage Accounts Overview & Steps To Create */
/* Detailed Explanation */
/* Read it from here & Complete it.Video is also there.Watch It*/
The Azure storage account is a container that groups a set of Azure storage services together.
Only data services from Azure storage can be included in a storage account.

/* https://cloudacademy.com/blog/an-overview-of-azure-storage-part-1/ */
/* Can be good */

2) Data Lake Store :- 
------------------------
i) Low Cost, high throughput data store.
ii) Unlimited Storage for No-SQL Data
iii) Can Query on data directly.No ad hoc query support.
iv) Good for Storage of Archive or Static data.
v) Acts as a Databricks, HDInsight and IOT data store.
vi) Here in form of "Folder" data will be present.
vii) New Design
/* Note :- If we want to use more analytics on data then user should go ahead with "Data Lake Store".
*/
/* https://k21academy.com/microsoft-azure/data-engineer/azure-data-lake/ */
/* Azure Data Lake Overview For Beginners */
/* Try to complete all cources from k21academy.com.Each topic is covered */
/*  +19294760384 / +918047192727 contact@k21academy.com +917023687648 */

The world is exploding with new data and your business deal with new analytics solutions all 
the time such as web campaigns, device data from internet-connected products. 
This data comes in different formats and file types and it’s huge. 
So, we need to extract more insight from data. Azure Data Lake is a unique solution 
to start with big data in the cloud.


3) Azure Databricks :- Its an end to end data analytics(OLAP System).
Suppose we have an application.Its data is getting stored in Azure Data Lake store(ADLS).
Suppose user want to do analytics on this data then he will use "Databricks".This will connect to
ADLS and fetch the data.Now he can change formate of data, Filtering or any kind of activity
and once data got prepared, it can be dumped into "Azure Synapse"/"Azure Data Warehouse".
Data can also be dumped in Databricks itself and on top of that Reporting can also be done.
Here we can also create AI/ML Model.

i) Eases of deployement of a spark based cluster.
ii) Enables the fastes processing of Machine Learning Solutions.
iii) Enables collabration between data engineers and data scientist.
iv) Provides tight enterprise security integration with Azure AD.
v) Integration with other Azure Services and Power BI.

https://k21academy.com/microsoft-azure/data-engineer/azure-databricks/
/* Azure Databricks For Beginners */

4) Azure CosmosDB :- This is an OLTP System with No SQL env.It can be connected to multiple
API at a time.Data can be replicated within clicks.
i) Provides Global distribution for both Structured and UnStructured data stores.
ii) Millisecond query response time.
iii) 99.99% availability of data.
iv) Worldwide elastic scale of both the storage and throughput.
v) Multiple consistency levels to control data integrity with concurrency.

This DB is supported for multiple APIs.Suppose user wants Mongo DB for his application then
we can create "Cosmos DB having Mongo DB API".This will work same as Mongo DB.
Now again user is saying that he needs "Casendra", then we just need to install "Casendra API"
on "Cosmos DB".

In Mongo DB if we have stored data inside a JSON still we can query that record using SQL query.
Here data is stored as Key-Document.Here Key will be an int value and Document will be a JSON data.


5) Column-Family Databases :- 
------------------------------------------
Suppose we have Customer information table where columns are like Fname,Lname,Email,ContactNo,address, age etc.
but all these columns might not be filled for all customers.Most of the column value will be empty.
So in order to solve this problem Column-Family Database came into picture.
Here Similar kind of column will be clubbed together like identity columns, Address columns etc..
CustId  Column Family: Identity
1001    Fname:A Lname:B


CustId  Column Family: Contact Info
1001    Address:Abc PhNo:000

6) Graph Data Store :- It is used to store data in hierarchy.
C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Graph Data Store.png


7) Azure Table Storage :- 
---------------------------------
C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Azure Table Storage.png
Here in Azure there will be a storage account.Inside this storage Table will be created.
and next there will be entity(column) where actual data will be stored.

8) Azure Blob Storage :- 
----------------------------------
C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Azure Blob Storage.png
Here there will a storage account and there will some container.
suppose container names are "Pictures" & "movies".
Inside these Blobs can be stored.Ex :- Img001.jpg, Img001.jpg, Mov001.avi etc..  
Here in blob column pdf, zipped file, audio, video or any kind of data can be stored.


9) Azure File Storage :- Network File Storage (NFS)
------------------------------------------------------
C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Azure File Storage.png
Here if multiple application is there then Azure File Storage will be mounted on all these APP.
Data coming from all these app can be stored here and can be access also.
/* Note :- Azure Blob Storage can not be mounted. */
Feature :- 
i) Secure data at rest and in-transit using SMB 3.0 and https.
ii) Simplify cloud file management using familiar tools.





2) 
/* https://docs.microsoft.com/en-us/learn/modules/explore-non-relational-data-offerings-azure/5-explore-azure-cosmos-database */
/* Explore Azure Cosmos DB */

/* https://docs.microsoft.com/en-us/learn/modules/explore-non-relational-data-stores-azure/1-introduction */
/* Introduction */
Relational databases store data in relational tables, but sometimes the structure imposed 
by this model can be too rigid, and often leads to poor performance

There are some other models known as NoSQL databases where data is stored in other structures, 
such as documents, graphs, key-value stores, and column family stores. 

Azure Cosmos DB is a highly scalable cloud database service for NoSQL data.

Types of Non-Relational/NoSQL databases :- 
----------------------------------------------------
What is NoSQL :- NoSQL means Non-Relational.It is related to non-relational databases.
NoSQL (non-relational) databases generally fall into four categories :-
There are four types of NoSQL databases/Non-Relational database.
i) Key-Value Stores :- Table API
ii) Document Databases :- Core (SQL) API
iii) Column Family Databases/Column Store/Columnar Store :- Cassandra API 
iv) Graph Databases :- Gremlin API

/* Describe Azure Cosmos DB */
Internal data structure of Azure Cosmos DB is abstracted which enables developers 
to use Cosmos DB to store and query data using APIs.Which can be written in any language.

An API is an Application Programming Interface. 
Database management systems (and other software frameworks) provide a set of 
APIs that developers can use to write programs that need to access data. 
The APIs vary for different database management systems.

Cosmos DB uses indexes and partitioning to provide fast read and write performance.
It can also scale at high level to support massive volumes of data.
Here we can keep Cosmos DB in any azure regions and can enable multi-region writes.
Then globally distributed each users can work with data in their local replica.

/* When to use Cosmos DB */
Cosmos DB is a highly scalable database management system.
Cosmos DB automatically allocates space in a container for your partitions, 
and each partition can grow up to 10 GB in size
Indexes are created and maintained automatically. There''s virtually no administrative overhead.

Cosmos DB has been used by many of Microsoft''s products like Skype, Xbox, Microsoft 365, Azure, and many others. 

Cosmos DB is highly suitable for the following scenarios :-
i) IoT and telematics :- 
ii) Retail and marketing :- 
iii) Gaming :- 
iv) Web and mobile applications :- 

/* Identify Azure Cosmos DB APIs */
Azure Cosmos DB supports multiple APIs.
When we provision a new Cosmos DB instance, we have to select the API that we want to use.

Suppose we are migrating data from any existing NOSQL DB to Azure Cosmos DB, then 
we need to select same API which was used in existing NOSQL DB.
The choice of API depends on many factors including, the type of data to be stored, 
the need to support existing applications, and the API skills of the developers 
who will work with the data store.


/* All APIs :-  */
Gremlin API :- Graph Databases 
Cassandra API :- Column Family Databases/Column Store/Columnar Store
Table API :- Key-Value Stores 
MongoDB API :- NA
Core (SQL) API :- Document Databases


/* Core (SQL) API */
The native API in Cosmos DB manages data in JSON document format, and despite 
being a NoSQL data storage solution, uses SQL syntax to work with the data.

Syntax :- 
SELECT *
FROM customers c
WHERE c.id = "joe@litware.com"

The result of this query consists of one or more JSON documents, as shown here:

{
   "id": "joe@litware.com",
   "name": "Joe Jones",
   "address": {
        "street": "1 Main St.",
        "city": "Seattle"
    }
}
Document Databases :- In a document database, each document has a unique ID, but 
the fields in the documents are transparent to the database management system.
Document databases stores data in JSON format,but they could be encoded using other formats 
such as XML, YAML, JSON, BSON. 
Documents could even be stored as plain text. The fields in documents are exposed 
to the storage management system, enabling an application to query and filter
data by using the values in these fields.

A document store does not require that all documents have the same structure. 
This free-form approach provides a great deal of flexibility. Applications 
can store different data in documents as business requirements change.

Key         Document
-----------------------------
1001        {
            "CustomerID": 99,
            "Orderitems":[
            {"ProductID": 2010,
            "Quantity": 2,
            "Cost": 520
            },
            { "ProductID": 4365,
            "Quantity": 1,
            "Cost": 18
            }]
            "OrderDate": "04/01/2017"
            }
1002        {
            "CustomerID": 220,
            "Orderitems":
            { "ProductID": 1285,
            "Quantity": 1,
            "Cost": 120
            }],
            "OrderDate": "05/08/2017"
            }
Here application can retrieve documents by using the document key.
The application can also query documents based on the value of one or more fields. 
Here indexing can also be created on document databases for faster retrival from it.

In some document database management provide facility to modify values of specific
field without rewriting the entire document. 

Example of document database in Azure :- 
i) Azure Cosmos DB in its Core (SQL) API.

Non Azure NOSQL Document Database Examples :- MongoDB, CouchDB.

/* MongoDB API */
MongoDB is a popular open source database in which data is stored in Binary JSON (BSON) format. 
The Azure Cosmos DB MongoDB API enables developers to use MongoDB client libraries to code
and to work with data in Azure Cosmos DB.

MongoDB Query Language (MQL) uses a compact, object-oriented syntax in which developers 
use objects to call methods.
Ex :- This query uses "find" method query the products collection in the db object:
db.products.find({id: 123})
O/P :- 
{
   "id": 123,
   "name": "Hammer",
   "price": 2.99
}

/* Table API */
The Table API is used to work with data in key-value tables, similar to Azure Table Storage. 
The Azure Cosmos DB Table API offers greater scalability and performance than Azure Table Storage.

Suppose Data is present like this :- 
PartitionKey	RowKey	Name			Email
1					123	Joe Jones		joe@litware.com
1					124	Samir Nadoy		samir@northwind.com

Ex :- https://endpoint/Customers(PartitionKey='1',RowKey='124')

Key-Value Stores :- A key-value store is the simplest and often quickest type of 
NoSQL database for inserting and querying data.
Each data item has two elements a key and a value.The key uniquely identifies the item
and the value holds the data for the item.The value is OPAQUE to the DBMS.

OPAQUE :- OPAQUE means DB just see the value as an unstructured block.
Here only application will be able to understand how the data in the value is 
structured and what fields it contains
The opposite of OPAQUE is TRANSPARENT.If data is transparent DB can understand 
how the fields in the data are organized.A relational table is an example of a transparent structure.
Ex :- 
Key     Value
AAAA    1000010111010101010
BBBA    1001110111010101010
CFTR    1001110110010101010
ASJD    1001110111001010101

Here application will retrive the data on the basic of Key and after getting value
it will parse it.Here Query can not be done on "Value".
Here write operation are restricted to "Insert" and "Delete" only.
If any modification is required then at application end, it should be delete & Insert at "value".

The focus of a key-value store is the ability to read and write data very quickly. 
Search capabilities are secondary. A key-value store is an excellent choice for data 
ingestion, when a large volume of data arrives as a continual stream and must 
be stored immediately.

Example of key-value store in Azure :- 
i) Azure Table storage 
ii) Cosmos DB using Table API

Non Azure NOSQL Key-value Database Examples :- Cassandra, LevelDB, Riak

/* Cassandra API */
The Cassandra API is compatible with Apache Cassandra, which is a popular open source 
database that uses a column-family storage structure. Column families are tables, 
similar to those in a relational database, with the exception that it''s not mandatory 
for every row to have the same columns.

Suppose Data is present like this in Employees table :- 
ID	Name		Manager
1	Sue Smith	
2	Ben Chan	Sue Smith

Ex :- SELECT * FROM Employees WHERE ID = 2

iii) Column Family Databases/Column Store :- A column family database organizes data into rows and columns.
Example of Column Family database in Azure :- 
i) ORC Files
ii) Parquet Files
iii) Apache Cassandra
iv) Azure Cosmos DB through the Cassandra API

A column family database can appear very similar to a relational database, at least conceptually.

C:\Users\10662208\Desktop\ABHILASH\Script\Azure\column-family.png
C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Column-family-physical.png

Suppose we have two relational tables.
i) Customer Table ii) Address Table
Here in order to find customer details along with address needs a join.
If through application large no of request is coming then it will be time consuming process.
In order to handle this Column Family Databases came into picture.
Here similar kind of column is grouped together and it will be divided into groups
known as column-families.
Each column family holds a set of columns that are logically related together.

addressinfo
Row Key                         Column Families
--------                        --------------------
CustomerID          CustomerInfo                    Addressinfo
------------        -----------------------         --------------------
1                   Customerinfo:Title Mr           Addressinfo:StreetAddress 999 500th Ave
                    CustomerInfo:FirstName Mark     Addressinfo:City    Bellevue
                    CustomerInfo:LastName Hanson    AddressInfo:State   WA
                                                    AddressInfo:ZipCode 12345

2                   Customerinfo:Title Mr           Addressinfo:StreetAddress 999 500th Ave
                    CustomerInfo:FirstName Mark     Addressinfo:City    Bellevue
                    CustomerInfo:LastName Hanson    AddressInfo:State   WA
                                                    AddressInfo:ZipCode 12345

In most column family databases, the column-families are stored separately.
CustomerInfo column family might be held in one area of physical storage 
and the AddressInfo column family in another, in a simple form of vertical partitioning.
C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Column-family-physical.png

Non Azure NOSQL Column Family Examples :- HBase, BigTable, HyperTable.


/* Gremlin API */
The Gremlin API is used with data in a graph structure; in which entities are 
defined as vertices that form nodes in connected graph. 
Nodes are connected by edges that represent relationships, like this:
Path :- C:\Users\abhilaskumar\Desktop\Abhilash\Script\Gremlin API Graph.png

The example in the image shows two kinds of vertex (employee and department) 
and edges that connect them (employee "Ben" reports to employee "Sue", 
and both employees work in the "Hardware" department).

Gremlin syntax includes functions to operate on vertices and edges, enabling you 
to insert, update, delete, and query data in the graph. 
For example, you could use the following code to add a new employee named Alice that 
reports to the employee with ID 1 (Sue)


Ex :- 
g.addV('employee').property('id', '3').property('firstName', 'Alice')
g.V('3').addE('reports to').to(g.V('1'))

The following query returns all of the employee vertices, in order of ID.
Ex :- 
g.V().hasLabel('employee').order().by('id')

iv) Graph Databases :- A graph database stores two types of information.
i) Nodes :- ii) Edges :- 
Nodes and edges can both have properties that provide information about that node 
or edge (like columns in a table). 
Additionally, edges can have a direction indicating the nature of the relationship.

The purpose of a graph database is to enable an application to efficiently perform 
queries that traverse the network of nodes and edges, and to analyze the relationships
between entities. The image below shows an organization’s personnel database 
structured as a graph. The entities are the employees and the departments in the 
organization, and the edges indicate reporting lines and the department in which 
employees work. In this graph, the arrows on the edges show the direction of the relationships.
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Graph DataBase.png

Example of Graph Databases database in Azure :- 
i) Azure Cosmos DB supports graph databases using the Gremlin API.

Non Azure NOSQL Graph database Examples :- Polyglot, Neo4J.

/* Exercise: Explore Azure Cosmos DB */


----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
4) https://docs.microsoft.com/en-us/learn/paths/azure-data-fundamentals-explore-data-warehouse-analytics/
/* Microsoft Azure Data Fundamentals: Explore modern data warehouse analytics in Azure */

i) 
/* https://docs.microsoft.com/en-us/learn/modules/examine-components-of-modern-data-warehouse/ */
/* Examine components of a modern data warehouse */

The process of combining all of the local data sources is known as data warehousing. 
The process of analyzing streaming data and data from the Internet is known as Big 
Data analytics. Azure Synapse Analytics combines data warehousing with Big Data analytics.

/* Describe modern data warehousing */
A data warehouse gathers data from many different sources within an organization. 
This data is then used as the source for analysis, reporting, and online analytical processing (OLAP)

Data warehouses have to handle big data. Big data is the term used for large 
quantities of data collected.

/* What is modern data warehousing :- */
A modern data warehouse might contain a mixture of relational and non-relational data, 
including files, social media streams, and Internet of Things (IoT) sensor data. 
Azure provides a collection of services you can use to build a data warehouse solution, 
including Azure Data Factory, Azure Data Lake Storage, Azure Databricks, Azure Synapse Analytics, 
and Azure Analysis Services. You can use tools such as Power BI to analyze and visualize the data, 
generating reports, charts, and dashboards.

/* Combine batch and stream processing */
Now a days large scale business requires up-to-the-second(Real Time) ( streams of raw data)  
data and Historical data (cooked business information ).
up-to-the-second(Real Time) data is required to take instant decision.Ex :- Stock Market Data

Similarly historical is equally important.Which can be get through Batch Processing 
at regular intervals.

/* Explore Azure data services for modern data warehousing */
In order to now the elements required for organisation''s requirement Components 
required for Modern Data Warehuses is required.

/* What is Azure Data Factory? */
Azure Data Factory is described as a data integration service.
Here we can retrieve data from multiple sources and noise can be filtered out.
In ADF we can extract Interesting data and can disard non interesting data.
If Interesting data is not in the formate of processing then we can also transform 
it into a single uniform structure.Ex:- Date Time conversion
Azure Data Factory can then write the ingested data to a data store for subsequent processing.

Here work operation can be performed using pipeline.
And we can create pipeline using GUI or writing codes.

/* What is Azure Data Lake Storage */
A  data lake is a repository for large quantities of raw data.
Because the data is raw and unprocessed, it’s very fast to load and update.
This is not structured so can not be used for efficient analysis.
data lake as a staging point for your ingested data, before it’s massaged and
converted into a format suitable for performing analytics. 

Note :- A data warehouse stores large quantities of data, but the data in a warehouse 
is processed to convert it into a format for efficient analysis. 
A data lake holds raw data, but a data warehouse holds structured information.

Azure Data Lake Storage combines the hierarchical directory structure 
and file system semantics of a traditional file system with security and 
scalability provided by Azure. Azure Data Lake Storage is essentially an extension 
of Azure Blob storage, organized as a near-infinite file system

It has the following characteristics :- 
i) Data Lake Storage organizes your files into directories and subdirectories for 
improved file organization. Blob storage can only mimic a directory structure.

ii) Data Lake Storage supports the Portable Operating System Interface (POSIX) 
file and directory permissions which enables granular Role-Based Access Control (RBAC) on data.

iii) Azure Data Lake Storage is compatible with Hadoop Distributed File System (HDFS). 
All Apache Hadoop environments can access data in Azure Data Lake Storage Gen2.

Azure Data Factory is used to ingest and load the data from a variety of sources 
into Azure Data Lake Storage.

Path :- F:\ABHILASH\Azure_Learning\Data_Lake_Process.png

/* What is Azure Databricks */
Azure Databricks is an Apache Spark environment running on Azure to provide big data 
processing, streaming, and machine learning.
Apache Spark is a highly efficient data processing engine that can consume and process 
large amounts of data very quickly. 
Here we can use Spark libraries to perform  SQL processing, aggregations, 
and to build and train machine learning models using our data.

Azure Databricks provides a graphical user interface where we can define and test your
processing step by step, before submitting it as a set of batch tasks. 
We can create Databricks scripts and query data using   R, Python, and Scala languages. 
We can write our Spark code using notebooks. 
A notebook contains cells, each of which contains a separate block of code. 
When we run a notebook, the code in each cell is passed to Spark in turn for execution. 

Azure Databricks also supports structured stream processing. In this model, 
Databricks performs your computations incrementally, and continuously updates the 
result as streaming data arrives.

/* What is Azure Synapse Analytics */
Azure Synapse Analytics is an analytics engine. It’s designed to process large amounts 
of data very quickly.

Using Synapse Analytics, we can ingest data from external sources like flat files, 
Azure Data Lake, or other databases and then data can be transformed/aggregated 
to format for analytics processing.
Then we can write query on top of this data and generate reports, graphs, and charts.

Azure Synapse Analytics has massively parallel processing (MPP) architecture. 
This architecture includes a control node and a pool of compute nodes.

The Control node is the brain of the architecture. It’s the front end that interacts 
with all applications. The MPP engine runs on the Control node to optimize and 
coordinate parallel queries. When you submit a processing request, the Control 
node transforms it into smaller requests that run against distinct subsets of 
the data in parallel.

The Compute nodes provide the computational power. 
The data to be processed is distributed evenly across the nodes.
Users and applications send processing requests to the control node. 
The control node sends the queries to compute nodes, which run 
the queries over the portion of the data that they each hold. 
When each node has finished its processing, the results are sent back to the control 
node where they are combined into an overall result.

Azure Synapse Analytics supports two computational models :- 
i) SQL pools 
ii) Spark pools
In a SQL pool, each compute node uses an Azure SQL Database and Azure Storage to 
handle a portion of the data.

Path :- F:\ABHILASH\Azure_Learning\Synapse.png
Seems Image described is SQL pools . /* Check this */
Here in synapse we submit the request in the form of T-SQL.
Synapse fetches data from variety of sources.To do this It uses a technology called "PolyBase".
Polybase enables synapse to retrive data from relational and Non Relational Sources.
Like delimited text files, Azure Blob Storage, and Azure Data Lake Storage.
Here Polybase technology or T-SQL query directly connects with "Control Node".
Then control node connect to multiple "Compute Nodes".
Then these "Compute Nodes" will be connected to "Azure Stoage".
"Control Node" & "Compute Nodes" are nothing but azure SQL DB.
These combination (Nodes and azure Storage) are called "Azure Synapse Analytics".

/* SQL pools :- */
We can specify the number of nodes when we create a SQL pool. 
We can scale the SQL pool manually to add or remove compute nodes as necessary.
We can only scale a SQL pool when it’s not running a Transact-SQL query.

/* Spark pools :- */
In a Spark pool, the nodes are replaced with a Spark cluster. 
You run Spark jobs comprising code written in Notebooks, in the same way as Azure Databricks. 
You can write the code for notebook in C#, Python, Scala, or Spark SQL 
(a different dialect of SQL from Transact-SQL). As with a SQL pool, the Spark cluster splits 
the work out into a series of parallel tasks that can be performed concurrently. 
You can save data generated by your notebooks in Azure Storage or Data Lake Storage.

Note :- Spark is optimized for in-memory processing. 
A Spark job can load and cache data into memory and query it repeatedly. 
In-memory computing is much faster than disk-based applications, but requires additional memory resources.

You specify the number of nodes when you create the Spark cluster. 
Spark pools can have autoscaling enabled, so that pools scale by adding or removing nodes as needed. 
Autoscaling can occur while processing is active.

If resources are not getting utilised then it we can pouse the services then it will be
utilised by other users.Hense Cost will be redued.

/* What is Azure Analysis Services? */
It supports online analytical processing (OLAP) queries.
Here we need to create a model which will fetch data from  multiple sources, 
including Azure SQL Database, Azure Synapse Analytics, Azure Data Lake store, 
Azure Cosmos DB, and many others. 
So basically models is a set of queries and expressions that retrieve data from 
the various data sources and generate results. 
The results can be cached in-memory for later use, or can be calculated dynamically, 
directly from the underlying data sources.

In Analysis service there will be a graphical designer through which we can connect data sources together.
and define queries.This query can have filter and aggregate data.
This data can be explored within "Analysis Services" or using Power BI tool.

/* Seems here we are not storing data like synapse analytics.Direct query on multiple 
source and get the result. */ >>> Verify this

/* Compare Analysis Services with Synapse Analytics */
Use Azure Synapse Analytics for :- 
i) Very high volumes of data (multi-terabyte to petabyte sized datasets).
ii) Very complex queries and aggregations.
iii) Data mining, and data exploration.
iv) Complex ETL operations. ETL stands for Extract, Transform, and Load, and refers to 
the way in which you can retrieve raw data from multiple sources, convert this data 
into a standard format, and store it.
v) Low to mid concurrency (128 users or fewer).

Use Azure Analysis Services for :- 
i) Smaller volumes of data (a few terabytes).
ii) Multiple sources that can be correlated.
iii) High read concurrency (thousands of users).
iv) Detailed analysis, and drilling into data, using functions in Power BI.
v) Rapid dashboard development from tabular data.

/* What is Azure HDInsight */
Azure HDInsight is a big data processing service, that provides the platform for 
technologies such as Spark in an Azure environment.
HDInsight implements a clustered model which is similar to Synapse Analytics.
except that the nodes are running the Spark processing engine rather than Azure SQL Database.

Azure HDInsight can be used in conjuction with instead of Azure Synapse Analytics.
HDInsight also supports streaming technologies like Apache Kafka, and 
the Apache Hadoop processing model. 

We can use components of HDInsight in a data warehousing solution.
In below image it is described.
Path :- C:\Users\abhilaskumar\Desktop\Abhilash\Script\Azure_Learning\Hdinsight & Synapse.png

In above image HDInsight and Synapse has been combined.
Hadoop is an open source framework that breaks large data 
processing problems down into smaller chunks and distributes them across a 
cluster of servers, similar to Synapse Analytics operates.

"Hive" is a SQL-like query using this data can be analysed which is present in HDInsight cluster .
It can be used to  create, load, and query external tables.
In Azure Synapse "PolyBase" is used instead of "Hive".

/* Try to unserstand Image */

/* Explore analytical data stores */
There are two common types of analytical data store.
i) Data warehouses :- A data warehouse is a relational database in which the data is stored in a 
schema that is optimized for data analytics rather than transactional workloads.
Data will be stored in fact and dimension table.

ii) Data lakes :- A data lake is a file store, usually on a distributed file system for 
high performance data access. Technologies like Spark or Hadoop are often used 
to process queries on the stored files and return data for reporting and analytics.

iii) Hybrid approaches :- It combines features of data lakes and data warehouses in a lake 
database or data lakehouse.
The raw data is stored as files in a data lake, and a relational storage layer abstracts 
the underlying files and expose them as tables, which can be queried using SQL. 
SQL pools in Azure Synapse Analytics include PolyBase, which enables you to define 
external tables based on files in a datalake (and other sources) and query them using SQL. 

ii) 
/* https://docs.microsoft.com/en-us/learn/modules/explore-azure-synapse-analytics/ */
/* Explore large-scale data analytics */

/* https://docs.microsoft.com/en-us/learn/modules/explore-azure-synapse-analytics/1-introduction */
/* Introduction */
Two key elements :- Data Ingestion and Data Processing
Data ingestion is the process used to load data from various sources into a central data store
Data can be ingested using batch processing or streaming, depending on the nature of the data source
Data processing involves operations on the data to clean, filter, restructure, 
and prepare the data for analysis.

If data is present somewhere then it should be ingested in cloud.
Option 1 :- 
A common approach that you can use with Azure Synapse Analytics is to extract the data from where 
it is currently stored, load this data into an analytical data store, and then transform the 
data, shaping it for analysis. This approach is known as ELT, for extract, load, and transform.
Azure Synapse Analytics is particularly suitable for this approach.
Using Apache Spark and automated pipelines, Synapse Analytics can run parallel processing 
tasks across massive datasets, and perform big data analytics.

Option 2 :- Analyze operational data in its original location. 
This strategy is known as hybrid transactional analytical processing (HTAP).
We can perform this style of analysis over data held in repositories such 
as Azure Cosmos DB using Azure Synapse Link.

/* Describe common practices for data loading/Ingestion */
1) /* Ingest data using Azure Data Factory */
Data Factory provides an orchestration engine. 
Orchestration is the process of directing and controlling other services, 
and connecting them together, to allow data to flow between them. 
Data Factory uses orchestration to combine and automate sequences 
of tasks that use different services to perform complex operations.

Azure Data Factory uses a number of different resources :- 
linked services, datasets, and pipelines. 

/* Understand linked services */
as we know

/* Understand datasets */
as we know

/* Understand pipelines */
A pipeline is a logical grouping of activities that together perform a task.
as we know

/* Ingest data using PolyBase */
PolyBase is a feature of SQL Server and Azure Synapse Analytics.
Using this we can read data from external data sources or also read data managed by 
Hadoop, Spark, and Azure Blob Storage, as well as other database management 
systems such as Cosmos DB, Oracle, Teradata, and MongoDB.

PolyBase enables us to transfer data from an external data source into a table, 
as well as copy data from an external data source in Azure Synapse Analytics 
or SQL Server. 
You can also run queries that join tables in a SQL database with external data, 
enabling you to perform analytics that span multiple data stores.
/* Azure SQL Database does not support PolyBase. */

Azure Data Factory provides PolyBase support for loading data. For instance, 
Data Factory can directly invoke PolyBase on your behalf 
if your data is in a PolyBase-compatible data store.

/* Ingest data using SQL Server Integration Services (SSIS) */
SSIS is part of Microsoft SQL Server.
SSIS can extract and transform data from a wide variety of sources 
such as XML data files, flat files, and relational data sources, 
and then load the data into one or more destinations.

In SSIS Using graphical tools packages are made.
These packages are stored in Services Catalog database.
A package is an organized collection of connections, control flow elements, 
data flow elements, event handlers, variables, parameters, and configurations
Here without writing any code we can do everything.

SSIS is an on-premises utility.However using Azure Data factory existing SSIS package can be called.

/* Ingest data using Azure Databricks */
Databricks is based on Spark, and is integrated with Azure to streamline workflows. 
It provides an interactive workspace that enables collaboration between 
data scientists, data engineers, and business analysts.

Databricks can process data held in many different types of storage, including Azure Blob storage, 
Azure Data Lake Store, Hadoop storage, flat files, SQL databases, and data warehouses, 
and Azure services such as Cosmos DB. Databricks can also process streaming data. 
For example, you could capture data being streamed from sensors and other devices.
 
Spark code will be written in notebook and a Notebook contains series of steps (called cells).
Azure Databricks notebook can be called from ADF pipeline.

/* Describe data storage and processing */
The most common options for processing data in Azure include Azure Databricks, 
Azure Data Factory, Azure Synapse Analytics, and Azure Data Lake.

/* Process data using Azure Synapse Analytics */
There are two technology through which data can be processed in Azure Synapse Analytics.
Transact-SQL :- same as normal SQL used by Azure SQL Database,.

Spark :- Here code is written in notebooks in a programming language such as C#, Scala, Python, or SQL.
The Spark libraries provided with Azure Synapse Analytics enable you to read data from external sources
and also write data into variety of formats.

When you run Transact-SQL statements or start Spark jobs from a notebook, 
the request is sent to the control node. The control node runs a parallel 
processing engine that splits the operation into a set of tasks that can be 
run concurrently. Each task performs part of the workload over a subset of the source data. 
Each task is sent to a compute node to actually do the processing. 
The control node gathers the results from the compute nodes and combines them 
into an overall result.


/* Process data using Azure Databricks */
Databricks can process data held in many different types of storage, including Azure Blob storage, 
Azure Data Lake Store, Hadoop storage, flat files, databases, and data warehouses. 
Databricks can also process streaming data. Databricks uses an extensible 
architecture based on drivers.

A driver is a piece of code that connects to a specific data source and enables you 
to read and write that source. A driver is typically provided as part of a library 
that you can load into the Databricks environment. Drivers are available 
for many Azure services, including Azure SQL Database, Azure Cosmos DB, 
Azure Blob storage, and Azure Data Lake storage, as well as many services 
and databases produced by third-parties, such as MySQL and PostgreSQL.

/* Process data using Azure HDInsight */

/* Process data using Azure Data Factory */

/* Process data using Azure Data Lake */
Azure Data Lake comprises two main elements :- 
i) Data Lake Store
ii) Data Lake Analytics


iii) /* https://docs.microsoft.com/en-us/learn/modules/explore-fundamentals-data-visualization/ */
/* Explore fundamentals of data visualization */
Learn the fundamental principles of analytical data modeling and data visualization, 
using Microsoft Power BI as a platform to explore these principles in action.

/* Describe Power BI tools and workflow */
Path :- C:\Users\abhilaskumar\Desktop\Abhilash\Script\Azure_Learning\PowerBI.png
"Power BI Desktop" is a Microsoft Windows application which is used to create 
a data visualization solution.Here data can be imported from wide range of data sources.
After fetching the data, it will be combined and organised in an "analytics data model".
then report can be created that contain interactive visualizations of the data.

Once datamodel & reports are created, it can be published to the "Power BI service".
Here business user can interact with Report.
In "Power BI service" also basic data modeling and report editing can be done through web browser.
But functionality will be limited as compared to "Power BI Desktop tool".

In "Power BI Desktop" we can schedule a refreshes of data source from where data is coming for report.
Here we will get functionalty to share reports with other user.

Here(Power BI Desktop) we can also define dashboard and apps that combine similar kind of report 
in a single location.

Users can consume reports, dashboards, and apps in the Power BI service through a web browser, 
or on mobile devices by using the Power BI phone app.

/* Describe core concepts of data modeling */
Data Model contains tables.Through Data Model we can generate report.
Inside data model we will have "numeric values" also known as "measures" which is analsed in the report.
These "numeric values"/"measures" are aggregated on "entities"/"dimensions".

Ex :- measures :- revenue or quantity
dimensions :-  products, customers, and time

Identify total revenue by customer, OR 
total items sold by product per month

Since model forms a multidimensional structure.So it is also known as "Cubes".

/* Tables and schema */
Dimension Table :- It represnts the "entities" by which "numeric measures" can be aggregated.
Ex :- Product table / Customer Table
In dimension table each entity will have a row and it will be represented unique key value.like PK.

"Fact Table":- There will be a table which will contain numeric value called "Fact Table".
Ex :- Sales table

Path :- C:\Users\abhilaskumar\Desktop\Abhilash\Script\Azure_Learning\Star_Facts_Dimension.PNG

When a fact table is associtaed with multiple dimension table it is called "Star Schema".

When dimesnion table is splotted into multiple tables and fact table is there then it is called "snowflake schema".

/* Attribute hierarchies */
In analytical data model, Attribute hierarchies is one property which enables us to 
quickly drill up and drill down to find aggregated values at different levels in a hierarchical dimension.

Suppose we generated report where we can get revenue earned in 2021 fiscal year.
Now it can be aggregated like In 2021, in Jan month each day what was the revenue.
So here within a level we are able to see next level report data.

Path :- C:\Users\abhilaskumar\Desktop\Abhilash\Script\Azure_Learning\AttributeHierarchies.PNG

/* Analytical modeling in Microsoft Power BI */
In Power BI we can define an analytical model from tables present at various source.
In Power BI Desktop we will get a "Model" tab through which we can define analytical model
by creating relationships between fact and dimension tables.

Path :- C:\Users\abhilaskumar\Desktop\Abhilash\Script\Azure_Learning\PBI_AnalyticalModeling.PNG

/* Describe considerations for data visualization */
/* https://docs.microsoft.com/en-us/learn/modules/explore-fundamentals-data-visualization/4-data-visualizations */
Check above URL for Visulation :- 
Once data model is ready we can generate data visualizations  which can be added in report.
Types of Visulation :- 
i) Tables and text :- 
ii) Bar and column charts :- 
iii) Line charts :- 
iv) Pie charts :- 
v) Scatter plots :- 
vi) Maps :- 

/* Exercise – Visualize data with Power BI */
/* https://docs.microsoft.com/en-us/learn/modules/explore-fundamentals-data-visualization/5-exercise-power-bi */
1) Download Power BI :- https://powerbi.microsoft.com/desktop 
2) Open it and select "GET Data"(Starting page)
3) Select Web :- 
4) Customer Data :- https://github.com/MicrosoftLearning/DP-900T00A-Azure-Data-Fundamentals/raw/master/power-bi/customers.csv
5) Products Data :- https://github.com/MicrosoftLearning/DP-900T00A-Azure-Data-Fundamentals/raw/master/power-bi/products.csv
6) Orders Data :- https://github.com/MicrosoftLearning/DP-900T00A-Azure-Data-Fundamentals/raw/master/power-bi/orders.csv
7) Load :- One by one
/* Explore a data model */

/* Try to complete it in RDC 10.11.0.6 */




iv) /* https://docs.microsoft.com/en-us/learn/modules/explore-fundamentals-stream-processing/ */
/* Explore fundamentals of stream processing */

In this module we will learn about "Stream Processing" and the service we can use to implement it.
Data processing :- It is the conversion of raw data to meaningful information through a process.
There are two general ways to process data :- 
i) Batch processing :- Here multiple data records are stored and proessed together into a single operation.
ii) Stream processing :- Here source of data is constantly monitored and processed in real time 
as new data events occur.

/* i) Batch processing :-  */
Here newly arriving data elements are collected into a group.
The whole group is then processed at a future time as a batch. 
Batch processing job can be processed on a schedule time interval OR
when certain amount of data arrived OR
result of some other event.

Example :- 
i) Count of car in car parking.It can be counted at the time of entry which will be stream process
or count it when all cars are parked.

ii) Creadit Card Bill generation :- 

Advantages of batch processing :-
i) Large volumes of data can be processed at a convenient time.
ii) Job can be scheduled when load on server is idle such as overnight, or during off-peak hours.

Disadvantages of batch processing :- 
i) The time delay between ingesting the data and getting the results.
ii) Small error in source data can cause job failure.So data must be carefully checked before process.

/* ii) Stream processing :- */
Here each new piece of data is processed when it arrives.
Example :- 
i) A financial institution tracks changes in the stock market in real time
ii) An online gaming company collects real-time data about player-game interactions,


/* Differences between batch and streaming data :- */
i) Data scope :- Batch processing can process all the data in the dataset.
Streaming processing can process most recent data received (the last 30 seconds)
ii) Data size :- Batch processing is suitable for handling large datasets efficiently.
Stream processing is suitable for individual records or micro batches consisting of few records.
iii) Performance :- Latency for Batch processing is typically few hours.
Stream processing typically occurs immediately (seconds or milliseconds).
/* Latency is the time taken for the data to be received and processed. */
iv) Analysis :-  batch processing is used for performing complex analytics. 
Stream processing is used for simple response functions, aggregates, 
or calculations such as rolling averages.

/* Combine batch and stream processing */
Path :- C:\Users\abhilaskumar\Desktop\Abhilash\Script\Azure_Learning\Combine_Batch_Stream.png

i) Data events from a streaming data source are captured in real-time.
ii) Data from other sources is ingested into a data store (often a data lake) for batch processing.
iii) If real-time analytics is not required, the captured streaming data is written to the data store 
for subsequent batch processing.
iv) When real-time analytics is required, a stream processing technology is used to prepare the streaming 
data for real-time analysis or visualization; often by filtering or aggregating the data over temporal windows.
v) The non-streaming data is periodically batch processed to prepare it for analysis, and the results 
are persisted in an analytical data store (often referred to as a data warehouse) for historical analysis.
vi) The results of stream processing may also be persisted in the analytical data store to support 
historical analysis.
vii) Analytical and visualization tools are used to present and explore the real-time and historical data.

Note :- Commonly used solution architectures for combined batch and stream data processing 
include lambda and delta architectures. Details of these architectures are beyond the scope 
of this course, but they incorporate technologies for both large-scale batch data processing 
and real-time stream processing to create an end-to-end analytical solution.


/* Explore common elements of stream processing architecture */
/* Stream processing in Azure */
Services provided by microsoft for implementation of stream processing solutions :- 
i) Azure Stream Analytics :- It is a PaaS (platform-as-a-service).Here we can define streaming jobs
that will ingest data from a streaming source, apply a perpetual query, 
and write the results to an output.

ii) Spark Structured Streaming :- It is an open-source library.Using this complex streaming 
solutions on Apache Spark based services can be created.
Apache Spark based services are :- Azure Synapse Analytics, Azure Databricks, and Azure HDInsight.

/* Sources for stream processing in Azure */
i) Azure Event Hubs: A data ingestion service that you can use to manage queues of event data, 
ensuring that each event is processed in order, exactly once.

ii) Azure IoT Hub: A data ingestion service that is similar to Azure Event Hubs, but which is 
optimized for managing event data from Internet-of-things (IoT) devices.

iii) Azure Data Lake Store Gen 2: A highly scalable storage service that is often used in batch 
processing scenarios, but which can also be used as a source of streaming data.

iv) Apache Kafka: An open-source data ingestion solution that is commonly used together 
with Apache Spark. You can use Azure HDInsight to create a Kafka cluster.


/* Sinks for stream processing in Azure */
i) Azure Event Hubs: Used to queue the processed data for further downstream processing.

ii) Azure Data Lake Store Gen 2 or Azure blob storage: Used to persist the processed results as a file.

iii) Azure SQL Database or Azure Synapse Analytics, or Azure Databricks: 
Used to persist the processed results in a database table for querying and analysis.

iv) Microsoft Power BI: Used to generate real time data visualizations in reports and dashboards.


/* Explore Azure Stream Analytics */
Azure Stream Analytics is a service for complex event processing and analysis of streaming data. 
Stream Analytics is used to:
i) Ingest data from an input, such as an Azure event hub, Azure IoT Hub, or Azure Storage blob container.
ii) Process the data by using a query to select, project, and aggregate data values.
iii) Write the results to an output, such as Azure Data Lake Gen 2, Azure SQL Database, 
Azure Synapse Analytics, Azure Functions, Azure event hub, Microsoft Power BI, or others.

/* Azure Stream Analytics jobs and clusters */
The easiest way to use Azure Stream Analytics is to create a Stream Analytics job 
in an Azure subscription, configure its input(s) and output(s), 
and define the query that the job will use to process the data.
The Query will be "Structured Query Language" (SQL) syntax.

If stream process requirement is complex then we can create "Stream Analysis cluster".
which uses the same underlying processing engine as a Stream Analytics job, 
but in a dedicated tenant (so your processing is not affected by other customers) 
and with configurable scalability that enables you to define the right balance of 
throughput and cost for your specific scenario.

/* Exercise: Analyze streaming data */
Try to complete it using Azure portal.


/* Explore Apache Spark on Microsoft Azure */
Apache Spark is a distributed processing framework for large scale data analytics.
Apache Spark is getting used in Microsoft azure in following services :-
i) Azure Synapse Analytics :- 
ii) Azure Databricks :- 
iii) Azure HDInsight :- 
Spark can be used for both batch processing and stream processing.

/* Spark Structured Streaming */
In order to process streaming data through Spark, We can use "Spark Structured Streaming" library.
It provide an API for ingesting, processing, and outputting results from perpetual streams of data.

Spark Structured Streaming is built on a ubiquitous structure in Spark called a dataframe.
It encapsulates a table of data.
Spark Structured Streaming API can read data from a real-time data source, 
such as a Kafka hub, a file store, or a network port, into a "boundless" dataframe 
that is continually populated with new data from the stream. 
Again we can define a new query on dataframe which will selects, projects, or aggregates the data.
This result will generate a new dataframe which can be further processed.

/* Delta Lake */
Delta Lake is an open-source storage layer that adds support for transactional consistency, 
schema enforcement, and other common data warehousing features to data lake storage. 
It also unifies storage for streaming and batch data, and can be used in Spark to 
define relational tables for both batch and stream processing. 
When used for stream processing, a Delta Lake table can be used as a streaming source 
for queries against real-time data, or as a sink to which a stream of data is written.

The Spark runtimes in Azure Synapse Analytics and Azure Databricks include support for Delta Lake.

/* Exercise: Process streaming data using Spark */
/* Complete this exercise */

/* Explore Azure Data Explorer */
Azure Data Explorer is a standalone Azure service for efficiently analyzing data.
This service can be used as o/p when large volume of diverse data from websites, applications, IoT devices, and more
are analysed.
Suppose we have set up a  Azure Stream Analytics then we can redirect our logs to "Azure Data Explorer".

This service "Azure Data Explorer" is encapsulated as a runtime in Azure Synapse Analytics,
where it is referred to as Azure Synapse Data Explorer.
It enabling you to build and manage analytical solutions that combine SQL, Spark, and Data Explorer analytics 
in a single workspace.

Data is ingested into Data Explorer through one or more connectors or by writing a minimal 
amount of code. This enables you to quickly ingest data from a wide variety of data sources, 
including both static and streaming sources. Data Explorer supports batching and streaming in 
near real time to optimize data ingestion. The ingested data is stored in tables in a 
Data Explorer database, where automatic indexing enables high-performance queries.


Azure Data Explorer is a great choice of technology when you need to:
i) Capture and analyze real-time or batch data that includes a time-series element; 
such as log telemetry or values emitted by Internet-of-things (IoT) devices.

ii) Explore, filter, and aggregate data quickly by using the intuitive and powerful Kusto Query Language (KQL).

/* Kusto Query Language (KQL) */
To query Data Explorer tables, you can use Kusto Query Language (KQL), a language that is 
specifically optimized for fast read performance – particularly with telemetry data that 
includes a timestamp attribute.

Write down only table name it will display all content of that table name.

https://docs.microsoft.com/en-us/learn/modules/explore-fundamentals-stream-processing/9-exercise-data-explorer
/* Exercise: Explore Azure Synapse Data Explorer */

17
40
72




-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
Begineer Path :- 
1) Explained all topic in sequential manner.
https://www.youtube.com/watch?v=JXx6iN7MKw8&ab_channel=E-LearningBridge

-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
Dp-200 :- 
https://docs.microsoft.com/en-us/learn/certifications/exams/dp-200
/* Exam DP-200: Implementing an Azure Data Solution */

1) https://docs.microsoft.com/en-us/learn/paths/azure-for-the-data-engineer/
/* Azure for the Data Engineer */

2) https://docs.microsoft.com/en-us/learn/paths/store-data-in-azure/
/* Store data in Azure */

3) 

4) 

5) 

6) https://docs.microsoft.com/en-us/learn/paths/data-engineer-azure-databricks/
/* Data engineering with Azure Databricks */

------------------------------------------------------------------------------------------------------
1) https://docs.microsoft.com/en-us/learn/paths/azure-for-the-data-engineer/
/* Azure for the Data Engineer */
------------------------------------------------------------------------------------------------------
Storage for Structured Data :- Azure SQL Database & Azure SQL Data Warehouse.
Storage for UnStructured Data :- Azure Blob storage, NoSQL data in Azure Cosmos DB or Azure HDInsight
GDPR :- General Data Protection Regulation
PCI :- Payment Card Industry
DSS :- Data Security Standard

------------------------------------------------------------------------------------------------------
2) https://docs.microsoft.com/en-us/learn/paths/store-data-in-azure/
/* Store data in Azure */
------------------------------------------------------------------------------------------------------
Types Of Data :- Structured, Semi-Structured, and UnStructured



------------------------------------------------------------------------------------------------------
6) https://docs.microsoft.com/en-us/learn/paths/data-engineer-azure-databricks/
/* Data engineering with Azure Databricks */
------------------------------------------------------------------------------------------------------
Its an end to end data analytics(OLAP System).
Suppose we have an application.Its data is getting stored in Azure Data Lake store(ADLS).
Suppose user want to do analytics on this data then he will use "Databricks".This will connect to
ADLS and fetch the data.Now he can change formate of data, Filtering or any kind of activity
and once data got prepared, it can be dumped into "Azure Synapse".
Data can also be dumped in Databricks itself and on top of that Reporting can also be done.
Here we can also create AI/ML Model.

i) Eases of deployement of a spark based cluster.
ii) Enables the fastes processing of Machine Learning Solutions.
iii) Enables collabration between data engineers and data scientist.
iv) Provides tight enterprise security integration with Azure AD.
v) Integration with other Azure Services and Power BI.

Azure databricks is managed version of  "Apache Spark" which is a open source analytics and data
processing engine.
It is a cloud based big data and machine learning platform.

Apache Spark :- It is a unified processing engine which is used to analyze big data
using SQL, ML, Graph processing Or real time stream analysis.
It is a Spark Engine.

Azure Data Services for Data Engineer :- 
------------------------------------------------
i) Azure Data Factory
ii) Azure Synapse Analytics
iii) Power BI
iv) Azure Data Lake Storage

Account --> Subscription --> Resource Group --> Resource
First we should have an "account".Now we need to have a "Subscrition" where billing method
will be present.While accessing any Azure Service, "Resource Group" is required.
It can be created "Resource Groups" (Azure Service) >>> Create New "Resource Groups".
and after that a "Resource" we can create.
"Create a new Resource" means creating a new database/server or deploying and Azure Services.

Steps to create a Databricks Notebook :- 

==============================================================================================
==============================================================================================
https://event.on24.com/eventRegistration/console/EventConsoleApollo.jsp?simulive=y&eventid=2714514&sessionid=1&username=&partnerref=&format=fhvideo1&mobile=false&flashsupportedmobiledevice=false&helpcenter=false&key=8C15C0DB70D411F9F77D81F273FE5F43&text_language_id=en&playerwidth=1000&playerheight=650&overwritelobby=y&localeCountryCode=UK&newConsole=true&nxChe=true&newTabCon=true&eventuserid=427669420&contenttype=A&mediametricsessionid=370520970&mediametricid=3821811&usercd=427669420&mode=launch
Here's your custom link: come join us now!  '
Here’s your custom link: come join us now!  >>> From mail LTI

https://aka.ms/DataAISkilling >> Registration is done. Check for other activity after Video Sesison.

1) Core Data Concepts :- 
------------------------------
On premises versus Cloud Technilogies :- 
i) Computing Environment :- Very good in cloud
ii) Licensing Model :- Very easy to get license in cloud
iii) Maintainbility :- Everything maintained by cloud.
iv) Scalability :- Scale as per requirement at any time in cloud.
v) Availability :- Very less down.Always available in cloud.

Benefits of Cloud :- 
--------------------------
i) Always available 99.9999%
ii) Automatic upgrades, Patching & Backups
iii) Scaling at any point of time with pay
iv) Intelligence :- Advisor, tuning & monitoring
v) Active Geo Replication with readable secondry databases.
vi) Encrypt data at rest and in motion.

Features of Relational Database :- 
--------------------------------------
ACID :- Atomicity, Consistency, Isolation, Durability
Atomicity :- 
Consistency :- 
Isolation :- 
Durability :- 

Structure :- Relational Model :- 
-----------------------------------------
It represents the database as a collection of relation.A relation is nothing but a table of 
values.Every row in the table represents a collection of related data values.
These rows in the table denote a real world entity or relationship.

Attributes :- Columns
Tupple :- Rows

Features of Non Relational Database :- 
--------------------------------------
i) Highly variable structure
ii) Store the data in its original state and format.
iii) Doesn’t impose a schema on data.
iv) Store the information for entities in collections or containers.

CAP Theorem :- 60 to 69 Minutes (Check Again)
---------------------------------------------------
/* Read this */

Types of non-relational & NoSQL Database :- 
----------------------------------------------------
NoSQL Database is used to store Semi structured data.But it can also store structured data.
Structure Data :- Databases
Semi Structure Data :- XML/JSON Data, Email, Web Pages
Unstructured Data :- Audio, Video, Image Data, Natural Language, Documents.
Other format :- Avro, ORC, Parquet

Concept Of Data Analysics :- 
---------------------------------------------
1) Graphics representation of data :- 
i) Column Chart :- Simple Graph ex :- Age and Height Graph
ii) Bar Chart :- It is used to compare different values.Q1,Q2,Q3 & Q4 Revenue comparision
iii) Line Chart :- Share price
iv) Pi Chart :- 

ETL/ELT Porcess :- Extract, Transform & Load
---------------------------------------------------
We have source(OLTP)(Row level Database) which will good in data retrival at Row level.
But if we want to do aggregation on data then it will be very slow.
So we need to put that data into OLAP system which will be very fast in aggregation.
It will be in columnar format.Here Aggregation will be faster but row level retrival will be slower.

So We need to user ETL to move data from OLTP to OLAP.Here for transformation a server is required.
Now in modern time ELT is used.First it will load directly into OLAP system then transformation 
will start in the same sever.

Relational data on Azure :- 
-------------------------------
Choose the right SQL option in Azure :- 
i) SQL server on a virtual machine (VM) :- Here we will have a server(Virtual Machine) and in this 
machine we will install SQL server.Now the application will connect to this DB via server.
Here we will have full control over machine.We will get 99.95% availability.
Suppose any one has a on premises SQL server and he wants to move this to VM then user will get
exact version of DB in VM.So there will not be any problem in migration since version is same.

ii) Azure SQL database (Managed Instance) :- Here user will go to Azure and configure a SQL server in the cloud.
Here availibility will be 99.99%.It will have build in advanced intelligence and security.
Here entire DB will be managed by Azure team.Backup, Patching and DR will be done by Azure itself.
Here user will get built in advanced intelligence and security.d

iii) Azure SQL database (Logical Server) :- It will be also presnet in azure.
but here it will be completely logical.At any moment of time user can do hardware,CPU configuration
changes through UI.Rest of the feature will be same as Azure SQL database (Managed Instance).

Services in Azure :- 
--------------------------------
i) Azure SQL database :- Azure SQL database is a fully managed platform as a service(PaaS) database engine.
This is also called DBAAs(Database As A Service).
Here we will get a Query platform in the portal and can use it to query data in the Azure SQL Database.

Deployement Options :- 
-------------------------------
i) Single Database :- It has two types.
a) IAAS Model :- (Infrastrucure as Service Model) 
b) PAAS Model :- ()
In IAAS model first user will spin a virtual machine and that virtual machine would have the
configuration like CPU, Memory and all other requirement based on requirement of database.
Now user will physically login into the server whcih will be empty and on that server database 
needs to be installed in it.Here as per our requirement we can install any version of SQL database.
Here user will be totally responsible to manage the VM.Here availitibility will be given by azure
on VM not to database.

In PAAS model user will got to azure portal and search for database which will be a pre installed
database.Here there will also be a server but it will be totally logical.
Here everyting will be managed by Azure.Since this will be managed by Azure so it will have
more availability given on database itself as compared to IAAS Model.

ii) Elastic Pool :- It is a pool of database.
Here reources are shared among databases within a pool.
Suppose there are three databases within elastic pool and each database is assigned an equal 
amount of database resources.
If load on one database increases and rest two are in good shape then resource from these two
can be utilised by 1st database to maintain sustainibility.(Sharing is Caring).

Suppose there is a Resource group inside that three databases exists And pricing of these databases
are calculated based on DTU(Database Transactional Unit).
So here instead of giving each DB as full resource combining 3 will get all reseource.
And when load will increase on anyone DB then other DB resources will be utilised.
Due to this model Prices will be less for USer.

Why Azure SQL database is a good choice :- 
---------------------------------------------------
i) Convinence :- 
ii) Cost :- 
iii) Scale :- 
iv) Security :- Azure AD, EndPoint SQL Authntication, Firewall
Here Azure has numbers of predefined roles.User can also create their own role.

Azure Synapse Analytics :- Old Name :- (Azure Data Warehouse)
---------------------------------------------------
It is an Analytics service that brings enterprise data warehousing and Big data analytics together.
Import big data with simple PolyBase T-SQL Queries and then use the power of MPP to run high
performance analytics.It completely uses MPP system.

There are two types of Synapse available in Azure.
We will get these Synapse once user logged into Azure Portal.
i) Synapse SQL :-
    a) SQL Pool :- For SQL Pool user will be charged for per used data warehouse unit.
    b) SQL On Demand :- SQL On Demand is in preview mode.It is charged on per TB basic.
ii) Apache Spark :- 
iii) Hybrid Data Integration :- 
iv) Studio (Unified Interface) :- 

Basic Architecture of Synapse Analytics :- 
----------------------------------------------------
Here there will be a Central node called "Control Node".
There will be multiple "Compute node" will be connected to it.
All these Computer Node will be connected to a storage called "Data Lake Storage".

Here loads/traffic are distributed according to table Geometry.
Total 3 table geometry available in Azure.
i) Hash Based :- This will be responsible for distributing the load across "Compute node"
coming from "Control Node".This is placed between "Control Node" & "Compute node".
and hashing mechanism does distribution of load across "Compute node".

ii) Replicate :- If "Control Node" is smaller one then it can completely copied or cloned to compute Node.
So here it can process the thing all together.

iii) Round Robin :- Here data will be processed one by one.and this process is called Round Robin.

SQL Server on Azure Virtual Machine :- 
----------------------------------------------
Here first user will create a VM and there SQL server will be installed.
Here VM will be present in cloud.If SQL server is on premise then hardware requirement will be there
but here user does not have to maintain this.

Azure Database for PostgreSQL, MariaDB and MySQL :- 
-----------------------------------------------------------
i) Azure Database for PostgreSQL :- Automatically back up till 35 days.
There two way through which it can be deployed.
a) Single :- 
b) Hyper Scale (Citus Cluster) :- 

Azure Database for MariaDB :- Automatically back up till 35 days.
It works on Maria Db service Engine.It is well suited for Business critical workloads.
It can be used in IAAS Model :- (Infrastrucure as Service Model) & PAAS Model.

Azure Database for MySQL :- Automatically back up till 35 days.
It is the simplest relational database.

Provisioning and deploying relational data services on Azure :- 
--------------------------------------------------------------------
Provisioning is the act of running series of tasks that a service provider such as Azure SQL database
performs to create and configure a service.
Here user has to select database and its component.Acoordingly price will be calculated.

Method for Deployement :- 
--------------------------------
In Azure there are 4 methods available for deployement.
i) The Azure Portal :- portal.azure.com
ii) The Azure Command Line Interface (CLI) (Cloud Shell) :- It is embeded within portal.azure.com.
iii) Azure PowerShell :- Here "Azure Module" needs to be installed.then login to azure portal using credentials.
iv) Azure Resource Manager Templates (ARM) :- This is based on JSON patterns and contains key value pairs of the resources created.
Here created Sub Resource will also have JSON patterns and combining all these JSON patterns makes "ARM" templates.

Data Security Components :- 
--------------------------------
i) Network Security :- a) Firewall b) Network Security Groups (NSG)
Firewall works on factors like Port,IP ranges
NSG works on factors like Port, Source, Destination & IP.

ii) Identity & Access Management (IAM) :- Azure AD & RBAC
It is used for authorizing and authentication of particular user.

iii) Encryption capabilities built into azure :- Azure Data Encryption (ADE).
It has ability to to encrypt/decrypt data in rest or in motion.
Here data can also be masked.

iv) Azure Threat Protection (ATP) :- It is a cloud based security solution.
It leverages on premises active directory signals to identify and detect an investigated advanced threats.
It also works on compromised identity and malicious insider action.
"OPS analyst manage ATP."

Query Tools :- 
---------------------
i) Azure Data Studio :- A light weight editor that can run on demand SQL queries, view & save result 
as text JSON or excel.
OS :- Windows, macOS, Linux

ii) SQL Server management Studio (SSMS) :- Manage a SQL Server instance or database with full GUI support.
OS :- Windows

iii) SQL Server Data Tools (SSDT) :- A modern development tool for building SQL server relational database,
Azure SQL database, Analysis Service (AS) data models, Integration Services (IS) Packages, 
And Reporting Services (RS) reports.
OS :- Windows

iv) Visual Studio Code :- The MSSQL extension for Visual Studio Code is the official SQL Server exyension
that supports connection to SQL Server and rich editing experience for T-SQL in visual Studio Code.
OS :- Windows, macOS, Linux


-------------------------------------------------------------------------------------------------------
Query Relational data in Azure :- 
-------------------------------------
DDL :- Data Definitation Language. Ex :- Create table, Alter table etc.
DML :- Data Manipulation Language. Ex :- Insert, Update, Delete,Select
DCL :- Data Control Language :- Ex :- Grant, Revoke, Deny

-------------------------------------------------------------------------------------------------------
https://k21academy.com/microsoft-azure/data-engineer/azure-sql-database-azure-data-engineer-associate-dp-200-dp-201/
/* Azure SQL Database | All you need to know about Azure SQL Services */
-------------------------------------------------------------------------------------------------------
/* Demo */
/* Try to create a single database */

Linked Service Name :- LS_OSELocal_SQL_DB_txdb_S33
Server Name 	:- osedbserverlocal.database.windows.net
Authentication 	:- SQL Server Authentication
UseName			:- adminuser
Password 		:- usP>>2021
DB Name         :- oselocaltxdb_S33

oselocaltxdb_S33

i) Login to portal.azure.com
ii) Search for "SQL databses" and click on it.
iii) New :- /* Fill all details */
Subscription :- Give Active Subscription name.It should be already created.
Resource Group :- Under each Subscription we should have a resource group.Select it from drop down.
Database Name :- uspstagingtxdbdev (Any Name)
Server Name :- If already exist then inside that server a new DB will be created else
Create a new server./*osedbserverlocall.database.windows.net*/
    While Creating new server :- 
    Server name :- osedbserverlocall.database.windows.net
    Server admin login :- adminuser
    Password :- Pass@123
    Location :- Chose from dropdown. (US) East US
Want to Use Elastic Pool :- No /* Check usage of Yes */
Compute + storage :- It will show by default value.
General Purpose
Gen5, 2 vCores, 32 GB storage, zone redundant disabled
If we want to change "Compute + storage" then click on "Configure database".

Networking :- Here firewall will be present./* By default */
If after creating the DB any one wants to connect then user’s IP must be added into Firewall rule.
Then only it will connect.

Security :- Azure Defender for SQL
Protect your data using Azure Defender for SQL, a unified security package including 
vulnerability assessment and advanced threat protection for your server. /* By default */

Additional Setting :- /* By Default */
Tags :- /* By default */
Review + Create :- If it is fine then click on "Review + Create".
/* Database will be created */
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
Non Relational Data on Azure :- 
-----------------------------------
Azure Data Services for Non-Relational Workloads :- 
-----------------------------------------------------------------
If user want to store data which is non structured like pdf files, Zipped files, Audio, video etc..
then in Azure it can be stored in "Storage Account" or "Data Lake Store".
Going through Azure portal user can directly create "Storage Account" and here all these
Non Structured data can be dumped.
Since in "Storage Account" user can not do Query directly.So through ETL/ELT data will be moved
to "Azure Synapse".Now here user can do Query on data.This is called "Data Storage Layer".

1) Storage Account :- 
--------------------------
i) Low Cost, high throughput data store.
ii) No-SQL data
iii) No Query on data directly.No ad hoc query support.
iv) Good for Storage of Archive or Static data.
v) Acts as a HDInsight Hadoop data store
vi) Here Flat files will be present.
vii) Old Approach

/* https://k21academy.com/microsoft-azure/az-303/azure-storage-account/#:~:text=Only%20data%20services%20from%20Azure,and%20files%20with%20disk%20images. */
/* Azure Storage Accounts Overview & Steps To Create */
/* Detailed Explanation */
/* Read it from here & Complete it.Video is also there.Watch It*/
The Azure storage account is a container that groups a set of Azure storage services together.
Only data services from Azure storage can be included in a storage account.

/* https://cloudacademy.com/blog/an-overview-of-azure-storage-part-1/ */
/* Can be good */

2) Data Lake Store :- 
------------------------
i) Low Cost, high throughput data store.
ii) Unlimited Storage for No-SQL Data
iii) Can Query on data directly.No ad hoc query support.
iv) Good for Storage of Archive or Static data.
v) Acts as a Databricks, HDInsight and IOT data store.
vi) Here in form of "Folder" data will be present.
vii) New Design
/* Note :- If we want to use more analytics on data then user should go ahead with "Data Lake Store".
*/
/* https://k21academy.com/microsoft-azure/data-engineer/azure-data-lake/ */
/* Azure Data Lake Overview For Beginners */
/* Try to complete all cources from k21academy.com.Each topic is covered */
/*  +19294760384 / +918047192727 contact@k21academy.com +917023687648 */

The world is exploding with new data and your business deal with new analytics solutions all 
the time such as web campaigns, device data from internet-connected products. 
This data comes in different formats and file types and it’s huge. 
So, we need to extract more insight from data. Azure Data Lake is a unique solution 
to start with big data in the cloud.


3) Azure Databricks :- Its an end to end data analytics(OLAP System).
Suppose we have an application.Its data is getting stored in Azure Data Lake store(ADLS).
Suppose user want to do analytics on this data then he will use "Databricks".This will connect to
ADLS and fetch the data.Now he can change formate of data, Filtering or any kind of activity
and once data got prepared, it can be dumped into "Azure Synapse"/"Azure Data Warehouse".
Data can also be dumped in Databricks itself and on top of that Reporting can also be done.
Here we can also create AI/ML Model.

i) Eases of deployement of a spark based cluster.
ii) Enables the fastes processing of Machine Learning Solutions.
iii) Enables collabration between data engineers and data scientist.
iv) Provides tight enterprise security integration with Azure AD.
v) Integration with other Azure Services and Power BI.

https://k21academy.com/microsoft-azure/data-engineer/azure-databricks/
/* Azure Databricks For Beginners */

4) Azure CosmosDB :- This is an OLTP System with No SQL env.It can be connected to multiple
API at a time.Data can be replicated within clicks.
i) Provides Global distribution for both Structured and UnStructured data stores.
ii) Millisecond query response time.
iii) 99.99% availability of data.
iv) Worldwide elastic scale of both the storage and throughput.
v) Multiple consistency levels to control data integrity with concurrency.

This DB is supported for multiple APIs.Suppose user wants Mongo DB for his application then
we cab create "Cosmos DB having Mongo DB API".This will work same as Mongo DB.
Now again user is saying that he needs "Casendra", then we just need to install "Casendra API"
on "Cosmos DB".

In Mongo DB if we have stored data inside a JSON still we can query that record using SQL query.
Here data is stored as Key-Document.Here Key will be an int value and Document will be a JSON data.


5) Column-Family Databases :- 
------------------------------------------
Suppose we have Customer information table where columns are like Fname,Lname,Email,ContactNo,address, age etc.
but all these columns might not be filled for all customers.Most of the column value will be empty.
So in order to solve this problem Column-Family Database came into picture.
Here Similar kind of column will be clubbed together like identity columns, Address columns etc..
CustId  Column Family: Identity
1001    Fname:A Lname:B


CustId  Column Family: Contact Info
1001    Address:Abc PhNo:000

6) Graph Data Store :- It is used to store data in hierarchy.
C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Graph Data Store.png


7) Azure Table Storage :- 
---------------------------------
C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Azure Table Storage.png
Here in Azure there will be a storage account.Inside this storage Table will be created.
and next there will be entity(column) where actual data will be stored.


8) Azure Blob Storage :- 
----------------------------------
C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Azure Blob Storage.png
Here there will a storage account and there will some container.
suppose container names are "Pictures" & "movies".
Inside these Blobs can be stored.Ex :- Img001.jpg, Img001.jpg, Mov001.avi etc..  
Here in blob column pdf, zipped file, audio, video or any kind of data can be stored.


9) Azure File Storage :- Network File Storage (NFS)
------------------------------------------------------
C:\Users\10662208\Desktop\ABHILASH\Script\Azure\Azure File Storage.png
Here if multiple application is there then Azure File Storage will be mounted on all these APP.
Data coming from all these app can be stored here and can be access also.
/* Note :- Azure Blob Storage can not be mounted. */
Feature :- 
i) Secure data at rest and in-transit using SMB 3.0 and https.
ii) Simplify cloud file management using familiar tools.


Provisioning and Deploying Non-Relational Services on Azure :- 
--------------------------------------------------------------------------------------
Provisioning and Deployment :- 
Provisioning is the act of running series of tasks that a service provider such as Azure Cosmos DB
performs to create and configure a service.


Method for Deployement :- 
--------------------------------
In Azure there are 4 methods available for deployement.
i) The Azure Portal :- portal.azure.com
ii) The Azure Command -Line Interface (CLI) (Cloud shell) :- It is embeded within portal.azure.com.
iii) Azure PowerShell :- Here "Azure Module" needs to be installed.then login to azure portal using credentials.
iv) Azure Resource Manager Templates (ARM) :- This is based on JSON patterns and contains key value pairs of the resources created.
Here created Sub Resource will also have JSON patterns and combining all these JSON patterns makes "ARM" templates.

Data Security Components :- 
--------------------------------
i) Network Security :- a) Firewall b) Network Security Groups (NSG)
Firewall works on factors like Port,IP ranges
NSG works on factors like Port, Source, Destination & IP.

ii) Identity & Access Management (IAM) :- Azure AD & RBAC
It is used for authorizing and authentication of particular user.

iii) Encryption capabilities built into azure :- Azure Data Encryption (ADE).
It has ability to to encrypt/decrypt data in rest or in motion.
Here data can also be masked.

iv) Azure Threat Protection (ATP) :- It is a cloud based security solution.
It leverages on premises active directory signals to identify and detect an investigated advanced threats.
It also works on compromised identity and malicious insider action.
"OPS analyst manage ATP."

Managing Non-Relational Data Services on Azure :- 
--------------------------------------------------------
Management Tools :- 
i) Azure Storage Explorer :- In Preview Mode :- Can be used in the portal and can also be downloaded.
ii) VS Code :- VisulaCode, CLI
iii) Azure Cosmos Explorer :- Through this we can directly connect to Cosmos DB and then container.
All thes ething can be done through Portal itself.

-------------------------------------------------------------------------------------------------------
/* Demo */
/* Try to create a CosMos DB from azure portal */
/* 280 Start >> See one more time */
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
Modern Data Warehouse Analytics in Azure :- 
Modern Data Warehouse :- 
---------------------------
Data Warehousing WorkLoads :- Workload of datawarehouse depends on below factor.
i) Process of loading data into warehouse.
ii) Performing data warehouse analysis and reporting
iii) managing data in data warehouse
iv) Exporting data from data warehouse

Data Warehouse Units :- The performance capacity of a datawarehouse is determined by this.
Memory & Concurrency Limits :- To view resource allocated for all the performance profiles.
Scale Up or Down :- To Adjust Capacity

Data Warehousing Requirements :- 
------------------------------------------
i) Analytics :- 
ii) Integrations :- 
iii) Document Management :- 
iv) Decision Services :- 
v) Data Visulation :- 

Data Ingestion in Azure :- 
------------------------------------------
It is the process used to load data records from one or more sources to import data into 
Azure services.Important things in ingestion are :- 
a) Data Formats b) Properties c) Permissions

Types of Data Ingestion :- 
------------------------------------------
i) Batch Ingestion :- Bulk of data at different interval of time
ii) Streaming Ingestion :- Data keep on coming

Ingestion tools and methods in Azure :- 
------------------------------------------
i) Event Hub :- For Streaming Ingestion
ii) IoT Hub :- For Streaming Ingestion.Used for IoT enabled devices.
iii) Azure Blob Storage :- For Batch Ingestion (Explanation already present)
iv) Azure Data Factory (ADF) :- For Batch Ingestion (Explanation already present)

i) Event Hub :- It takes all coming streaming data and collect it then convert it into Batch mode.
Now there will a consumer associated with it which will consume these data.
This used for general purpose.

-------------------------------------------------------------------------------------------------------
/* Demo */
/* Try to do through azure portal */
/* 339 Start >> See one more time */
/* Create Azure Synpse SQL DW */
-------------------------------------------------------------------------------------------------------
Data Storage an Proocessing in Azure :- 
-------------------------------------------
Azure Storage Services :- 
--------------------------------
i) Azure Storage Blobs :- 
ii) Azure SQL database :- 
iii) ADF Datasets :- Move data from one DB to another.
iv) AML Datasets :- Azure Machine Learning Datasets.This is used for "Predective" use case.

Azure Data Processing Services :-
---------------------------------------
i) Azure Data Factory (ADF) :-  
ii) Azure Databricks :- 
iii) Synapse Analytics :- 
iv) HDInsight :- It is a HAdoop cluster inside Azure.

-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
Getting Started With Power BI :- 368
-------------------------------------
/* Continue from video */
_ADF
_DataFactory
---------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=Mc9JAra8WZU&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO */
/* Full PlayList  */

https://k21academy.com/microsoft-azure/azure-data-factory/
/* Azure Data Factory For Beginners */
/* Theory :- Very less informative */

1) Azure Data Factory (ADF) :- Data Integration Service
---------------------------------
Azure Data Factory is the "Cloud-based ETL" and data integration service.
Here we create data-driven pipelines for moveing data from one point to another.
Here we can also fo transformation.

ADF is used to fetch data from multiple sources and convert it into format that we can process.
Main purpose of ADF is to fetch data from multiple source and put it into Azure Data Lake Storage.

Azure Data Factory Components :- 
-----------------------------------------
i) Activity :- It is a processing step in a pipeline.
Ex :- A copy activity which will be used to copy data from one store to another store.
We can place multiple activity inside a pipeline.Here automatically a virtual machien will be 
created where all processing will happen.

ii) Pipeline :- When more than one activity is present it is called "Pipeline".
A pipeline is a logical grouping of activities that perform a unit of work.
We can have multiple Pipeline inside a "Data Factory".
Ex :- Activity  that ingests data from an Azure blob and then runs a hive query on 
HDInsight cluster to partition the data.

iii) Linked Service :- Linked Service is like a connection string that define
connection information needed for Data factory to connect to external resource.
Here connection will be established.It can be associated with "Data Lake Store", "Azure Databricks" etc..

iv) Dataset :- It represents data structure with data store.
It point to the data which is going to use in our Activity.It provide exact location
of data to Activity.

v) Triggers :- It is a scheduler.It executes the pipeline as per defined time.
When triggers run all data processing will start.

vi) Integration Runtime :- 
vii) Control Flow :- 

-------------------------------------------------------------------------------------------------------
https://www.youtube.com/watch?v=tXqjeMHT2ak&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=3&ab_channel=WafaStudies
/* 3. Create your First Azure Data Factory */
-------------------------------------------------------------------------------------------------------
Task :- Perform a copy activity on Azure Storage account.Copy a blob file and put it to another
location in the same Azure Storage account.
Task 1 :- Create a Azure Storage Account.
Task 2 :- Create a pipeline having copy activity.

/*
/* Demo */
/* Try to do through azure portal */
/* 359 Start >> See one more time */
/* ADf Pipeline */

1) Go to Azure Portal portal.azure.com
2) Create a new data factory.Data factory is a service available here.
3) Click on new :- and provide required details.
Subscription :- Give Active Subscription name.It should be already created.(ES-LOB-USP-DEV)
Resource Group :- Under each Subscription we should have a resource group.
                  Select it from drop down.(uspstagingdbgroupdev)
Region :- East US
Name :- As per wish.(Sample :- usp2adfv2stagingdev) :- (uspstorageadf)
Version :- V2 (V1 is old one.Select V2)
Git configuration :- Configure GIT later.
Click on "Review & Create".
Now this "usp2adfv2stagingdev" will display inside data factory service.
Now click on "Author & Monitor".Here we need to do development.


Search Storage Account.
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Storage Account Name :- "uspstorageaccountnew"
Review & Create :- Go to Resource :- It will be redirected to newly created Storage Account "uspstorageaccountnew".
Create a container inside Storage Account "uspstorageaccountnew".
New :- 
ContainerName :- "uspstagingcontainer"
Create then go inside that container.
Here we will create a folder and place a file inside it.
File will be a csv file which contains some name in comma seprated formate.

First upload the file inside newly created Container "uspstagingcontainer".
Inside advanced option select folder name.So file will be uploaded inside that folder.
Folder Name :- input
File Name :- data.txt
USP,usP,
Dev,dEV,
tEST,TEst
UAt,uat
PROD,pROd

Now we will create a Pipeline.Which will copy data.txt from input folder and paste into a new folder
"output" at same place.
Inside ADF if folder already exist then only data.txt file will be copied else
it will create "output" folder and paste the file data.txt.

Data Factory Name :- uspstorageadf (Already Created).
Resource Group :- uspstagingdbgroupdev
Inside this we will create a pipeline which will have a copy activity.
Go to "Author & Monitor".

1) Create a Linked Service :- LS_AzureStorage_uspstorageaccountnew
Choose Data Store as Azure Blob Storage.
2) Create Dataset :- 
Source DataSet :-    DS_uspstorageaccountnew_uspstagingcontainer_input_data
                     DS :- DataSets
                     uspstorageaccountnew :- Azure Storage Account Name
                     uspstagingcontainer :- Container Name
                     input :- Folder Name
                     data :- File Name
Select File Path :- Through Browse select the file then automatically it will be filled.
This will be used a Source.
Since we are copying data into another folder.So we need another DataSet.

Target DataSet :-    DS_uspstorageaccountnew_uspstagingcontainer_output_data
Folder Name :- output
File Name :- data.txt

3) Create Pipeline :- 
New PipeLine :- Copy_File_Pipeline
Copy Activity Name :- Copy_File_data
Run it through Debug.It will copy data to output folder in file data.txt.
If we want to chnage file name then new file name should be present in Target Dataset.

Publish it else all changes will be lost in next login.






-------------------------------------------------------------------------------------------------------

4.
-------------------------------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/azure/data-factory/ */
/* Azure Data Factory documentation */
Read it to know how to create ADF in different different ways.

Ways to create ADF :- 
i) Azure Portal :- 
ii) Azure Power Shell :- Install Azure Power Shell
iii) .Net :- 
iv) Python :- 
v)  REST :- API calling 
vi) Resource Manager Template (Azure PowerShell Az Module) :- JSON file

-------------------------------------------------------------------------------------------------------
https://www.youtube.com/watch?v=V_7bN4MqgcA&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=5&ab_channel=WafaStudies
/* 5. Pipelines and Activities in Azure Data Factory */
-------------------------------------------------------------------------------------------------------
Types Of Activities :- 
i) Data Movement Activities :- Copy activity etc..
ii) Data Transformation Activities :- U-SQL etc..
iii) Control Flow Activities :- Logical operation If-Else

/* https://docs.microsoft.com/en-us/azure/data-factory/concepts-pipelines-activities */
/* Pipelines and activities in Azure Data Factory */
/* Read from here for full knowledge on each activity type */
-------------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=LFdROd_jhaI&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=7&ab_channel=WafaStudies */
/* 7. Triggers in Azure Data Factory */
-------------------------------------------------------------------------------------------------------
Types of Triggers in ADF :- 
i) Schedule Trigger :- A trigger that invokes a pipeline on a wall clock schedule.
ii) Tumbling Window Trigger :- A trigger that operates on a periodic interval, while also retaining state.
iii) Event-based Trigger :- A trigger that respond to an event.

-------------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=YqpmDtG8WpI&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=8&ab_channel=WafaStudies */
/* 8. Schedule Trigger in Azure Data Factory */
-------------------------------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/azure/data-factory/how-to-create-schedule-trigger */
/* Create a trigger that runs a pipeline on a schedule */
Create a Trigger :- At the time of creating pipeline, we can associate a trigger with it.
But we can create a generic trigger and attach it anywhere in any pipeline.

Go to Trigger section and create a Schedule Trigger.
Trigger Name :- Schedule_Trigger
Time :- Every Day 10 AM.
END date :- No end date means will be running till life time everyday.
Suppose end date is 31st Dec 2021 theen till that date only this will run.
Activated :- Yes means after creation it will be activated.
No means manually we need to start this trigger first time.

Now go to pipiline and add it in trigger section inside pipeline.
After publish inside Trigger it will show '1' in related section means this trigger
is associated with 1 pipeline.1st time manually we need to trigger it.

Same Trigger can be added into multiple pipeline.
Since we can create Pipeline through multiple methods.Similarly we can also 
create Trigger in same way.

Property :- 
Start Time :- After this time trigger will check the recurrence.If conditions satisfies theen will be triggered.
Recurrence :- 
Every :- 1,2,3 etc..
Minute, Hour, Day, Week & Month

Advance Recurrence options :- 
--------------------------------
i) For Minute & Hour "Advance Recurrence options" will not show.
ii) It will come only for Day, Week & Month.

1) Every 1 day :- 
Advance Recurrence options :- 
a) Execute at these times
5:10, 15:15, 19:12 etc..
Here we need to write time at which trigger will run every day.
Hour :- 0-23
Minute :- 0-59

2) Every 1 Week :- 
Advance Recurrence options :- 
a) Run on these days
Sunday, Monday, .... Saturday :- Can Select any day even multiple day.

b) Execute at these times :- 
5:10, 15:15, 19:12 etc..
Here we need to write time at which trigger will run every day.
Hour :- 0-23
Minute :- 0-59

Example :- Run at 5:00 PM on Saturdays every week.
Run at 5:00 PM on Monday, Wednesday, and Friday every week.
Run at 5:15 PM and 5:45 PM on Monday, Wednesday, and Friday every week.
Run every 15 minutes on weekdays.


3) Every 1 Month :- 
Advance Recurrence options :- 
I) Month days :- 
a) Select day(s) of the month to execute :- 1, 2, 3, .. 31, Last :- Can Select any date even multiple date.
b) Execute at these times :- 
5:10, 15:15, 19:12 etc..
Here we need to write time at which trigger will run every day.
Hour :- 0-23
Minute :- 0-59

II) Week Days :- 
a) Execute at these times :- 
5:10, 15:15, 19:12 etc..
Here we need to write time at which trigger will run every day.
Hour :- 0-23
Minute :- 0-59

Note :- Depending upon any trigger requirement we can get triggering date using all these options.
/* Check example from MS documentation */

-------------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=vvuq-C_NXLI&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=9&ab_channel=WafaStudies */
/* 9. Tumbling Window Trigger in Azure Data Factory */
-------------------------------------------------------------------------------------------------------
Create a tumbling Trigger :- It is a type of trigger that fires at a periodic time interval
from a specified Start time, while retaning state.
It has one to one relationship with a pipeline means a tumbling window trigger can be 
attached with a single pipeline only.

Trigger Name :- TumblingTrigger
Start Time :- 14th May 2021 11:30 AM
END Time :- optional 15th May 11:30 AM
Recurrence/Frequency :- every 1 Hr. Other options are Minutes/Hours
/* Here we will get only Minutes & Hours */

So total hours is 24.Hense 24 times it will trigger on time will be
12:30 Pm, 1:30 PM, ...... 11:30 AM
If END date is not given theen it will keep on running evry hour.
Actual Trigger Time will be :- Start Time + Frequency(Hr/Minute/Months)

/* Note :- Minimum frequency is 5 minutes. */
/* above functionality we can also achieve through schedule trigger also */

/* System Variables :- */
i) trigger().outputs.windowStartTime
ii) trigger().outputs.windowEndTime
Using above mentioned variables 11:30 AM & 12:30 PM can be obtained and these value
can be used in pipeline Query for any condition.
Req :- Suppose we have a table and we would like to fetch data based on condition on Modified_Ts
column.Modified_Ts >= trigger().outputs.windowStartTime AND Modified_Ts <=trigger().outputs.windowEndTime
This requirement we can achieve through tumbling window trigger.

Difference between Schedule trigger & Tumbling Trigger :- 
/* More difference at bottom */
While creating schedule trigger we can not select past date time as Start point
but in Tumbling Trigger we can select past date time as start point.

Now these time can be fetched using system variable and can be used in SQL query to fetch data.
Now historical data can also be processed using Tumbling Trigger.

/* Advanced :- */
/* Advanced Properties inside tumbling window trigger while creating :- */
i) Add depedencies :- + >> Search for trigger with whom we want dependency with this trigger.
/* This option will not come in Schedule Trigger */

ii) Delay :- The delay defines how long the trigger waits past the due time before triggering a new run.
Suppose trigger is going to trigger at 12:00 AM.If we will add a delay of 1 min
then it will trigger at 12:01 AM.By default delay value will be 00:00:00.
Here we can also provider -ve value.
/* So Trigger Time = Actual Trigger Time + Delay */

iii) Max concurrency :- Using this we can achieve parallelism.
Since tumbling window trigger is used to process historical data.
So suppose start time is 1st Jan 2021 and would like to process till 30th June 2021.
Frequesny is 1 hr.So every day will run 24 times.
But we don’t want to wait for that much time.So we will give Max concurrency as 50.
Then every day it will run 50 times instead of 24 time.
and it will run in parallel.

The number of simultaneous trigger runs that are fired for windows that are ready. 
For example, to back fill hourly runs for yesterday results in 24 windows. 
If maxConcurrency = 10, trigger events are fired only for the first 10 windows 
(00:00-01:00 - 09:00-10:00). After the first 10 triggered pipeline runs are completed, 
trigger runs are fired for the next 10 windows (10:00-11:00 - 19:00-20:00). 
Continuing with this example of maxConcurrency = 10, if there are 10 windows ready, 
there are 10 total pipeline runs. If there's only 1 window ready, there's only 1 pipeline run.	
/* Try to understand */

iv) Retry policy :- Count :- If during execution it fails then will it re run or not.
By default value is 0 means it will not run.

v) Retry policy :- Interval in second :- Suppose we gave 2 as retry policy count.
Trigger fails and again it will try to run it.
So It will start after the give interval in this field.

-------------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=8X4CGsIuxGg&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=11&ab_channel=WafaStudies */
/* 10. Tumbling Window Trigger Dependency in Azure Data Factory */
-------------------------------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/azure/data-factory/how-to-create-tumbling-window-trigger */
/* Create a trigger that runs a pipeline on a tumbling window */
-----------------------------------------------------------------------------------------------------
While creating a tumbling window trigger we will get an option to add dependency.
Suppose we have 2 pipelines.
i) HourlyLogsPipeline :- Process logs every hour and store in SQL DB.
ii) HourlyDataProcessPipeline :- Takes logs data and customer data and do transformation and process it.
So here this pipiline HourlyDataProcessPipeline is dependent on HourlyLogsPipeline pipeline.
Means HourlyDataProcessPipeline should run only after HourlyLogsPipeline run successfully.

These kind of dependency we can create in Tumbling Window Trigger.
Dependent trigger must be also Tumbling Window Trigger.
Inside Advanced >>> Add Dependencies >>> New 
1) Trigger :- <Trigger Name> :- On which trigger we want a dependency
2) Offset :- -1, +1 etc..
If offset is -1.Suppose current trigger window time is 10 to 11.Then it will check 
9 to 10 window cycle of dependent trigger.
If it is +1 then it will check 11 to 12 window cycle of dependent trigger.
If offset is 0 then same window 10 to 11 will be checked.

3) Window Size/Time :- If offset is -1 hour.Suppose current trigger window time is 10 to 11.Then it will check 
9 to 10 window cycle of dependent trigger.
but if Window time is given as 2 hour then it will check 9 to 11 window cycle of dependent trigger.
(9 to 10 and 10 to 11 since Window Time=2)

Self Dependency Trigger :- This type of trigger is dependent on its own.
Here we have add same trigger name in dependency and need to provide offset in negative only and it is mandatory.
So suppose 9 to 10 window trigger executed.When next time it will run it needs to check
it’s previous window cycle is offset is -1.
It last execution is successful then only next run will be executed.
We can add max 2 two dependency in tumbling window trigger.

/* https://docs.microsoft.com/en-us/azure/data-factory/tumbling-window-trigger-dependency */
/* Create a tumbling window trigger dependency */
Must :- Read from here and see the image of dependency.It will give a better picture.
Usage scenarios and examples :- 
1) Dependency offset :- 
C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Dependency_1.png
Explanation :- Trigger A is dependent on Trigger B.
/* Green window will depend upon Yellow window */

C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Dependency_2.png
C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Dependency_3.png
C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Dependency_4.png
C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Dependency_5.png
/* Look into all these image for better understanding */

-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
Difference Between Schedule Trigger & Tumbling Window Trigger :- 
i) Schedule Trigger can be associated with any number on pipeline but Tumbling Window 
can be attach with only one trigger.

ii) While creating schedule trigger we can not select past date time as Start point
but in Tumbling Trigger we can select past date time as start point.

iii) In schedule trigger we can not put dependency on other triggers but in Tumbling Window Trigger 
we can put dependency on some other tumbling window trigger as well as on self trigger.
We can add max 2 two dependency in tumbling window trigger.

iv) After publish, Interval & frequency can not be changed in Tumbling Trigger but in schedule trigger
it can be changed.

v) System Variables in Tumbling window/Schedule trigger.:- 
a) @trigger().scheduledTime
b) @trigger().startTime

a) trigger().outputs.windowStartTime
b) trigger().outputs.windowEndTime

vi) In Schedule trigger recurrence options are Minute/Hour/Day/Week/Month
but in Tumbling window trigger recurrence options are only minute/Hour.

vii) In Tumbling window we have some extra properties like a) Dependency on Triggers
b) Delay c) Max concurrency d) Retry policy: count & e) Retry policy: interval in seconds


-------------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=RXEHrET9dUc&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=12&ab_channel=WafaStudies */
/* 11. Event based Triggers in Azure Data Factory */
-------------------------------------------------------------------------------------------------------
Storage Event & Custom Events :- 
This type of trigger is helpful when it needs to be triggered in case of any event.
Ex :- 
i) In the server(Azure Blob Storage) any file came or file deleted then event based triggers
pipeline will be useful.
Type of this trigger is "Storage Events".Means any event happening in storage account can
only be captured through this trigger.
Not applicable to database or any other services.

We have a pipeline created which copy file data from one folder to another in same container.
Linked Service :- LS_AzureStorage_uspstorageaccountnew
Source DataSets :- DS_uspstorageaccountnew_uspstagingcontainer_input_data
Sink(Target) Datasets :- DS_uspstorageaccountnew_uspstagingcontainer_output_data
Azure Storage Account(blob) :- uspstorageaccountnew
Container :- uspstagingcontainer
Source Folder Name :- input
Target Folder Name :- output

Pipeline Name :- Copy_File_Pipeline
Activity Name :- Copy_File_data

Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev 
Datafactory Name :- uspstorageadf

In this pipeline we will create a trigger of "Storage Event" type which will copy file 
to output folder when new file came at input folder.

Trigger Name :- EventTrigger
Type :- Storage Events
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer

Blob path begins with :- input/
/* ‘Blob path’ must begin with the path. 
For example: '2018/april/shoes.csv' or '2018/' */

Blob path ends with :- .txt
/* ‘Blob path’ must end in a file name or extension. 
For example, 'shoes.csv' or '.csv'. Container and folder name are optional but 
when specified they must be separated by a '/blobs/' segment. 
For example '/orders/blobs/2018/april/shoes.csv'. 
To specify a folder in any container omit the leading '/' character. 
For example, 'april/shoes.csv'. */

Event :- Blob created :- Check/Uncheck
         Blob deleted :- Check/Uncheck

Meaning :- 
Now whenever any file having extension .txt comes inside input folder then
automatically this trigger will run.Hense pipeline will be executed.

How it wokrs :- Azure data factory is integrated with "Azure Event Grid" which lets trigger 
pipeline on an event.

What is Azure Event Grid :- /* Will be explained */

Properties of Event based Trigger :- 
i) @triggerBody().filePath
ii) @triggerBody().fileName
During execution of pipeline using these variables we can know which file came from which folder.
We will define it in "Parameter" section using expression in pipeline.
Add two variable :- 
i) sourcepath :- 
ii) sourcefile :- 
Value to these variables will come from Trigger.So now we will go to trigger and assign
system variable to these variables created by us.

GO to trigger and continue.Automatically these variable will appear there.
sourcepath=@triggerBody().filePath
sourcefile=@triggerBody().fileName

Now we can use these variables as per our requirement./* Will be explained */

Own :- 
Pipeline Name :- EventBasedTriggerCopyFile
/* Copy file from test folder to Output folder if any .txt file exist */
Pipeline NAme :- CopyActivity
Source :- DS_Test
File Path Type :- Wildcard file path :- *.txt
Sink :- DS_Output

Trigger Name :- EventBasedTrigger
/* Copy any new .txt file from input folder to output folder */
Type :- Storage Events
Account selection method :- From Azure Subscription
Storage account name :- abksynapseadlsgen2
Container name :- abksynapsecontainer

Getting error in trigger while publishing as subscription is not coming as expected to trigger.
/* Look into this */
/* After plaing .csv file in Test folder pipeline didn't run */
/* Check this */

-------------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=8rJ0mvAswfc&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=13&ab_channel=WafaStudies */
/* 12. Integration runtime in Azure Data Factory */
-------------------------------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/azure/data-factory/concepts-integration-runtime */
/* Integration runtime in Azure Data Factory */
While creating Linked Service, we need to fill "Connect via integration runtime" option.
Here by default "AutoResolveIntegrationRuntime" will be present.But we can create a new IR
and select here.There are multiple scenario where we need to create a new IR and select it
while creating linked Service.

Integration runtime(IR) in ADF :- IR is the compute infrastrucure used by ADF to provide
below data integration capabilities across diferent network environments.
Data Integrations are :- 
i) Data Flow :- Section inside ADF (without code create flow diagram)
ii) Data Movement :- Copy Activity across data stores in public network and 
data stores in private network (on-premises or virtual private network)
iii) Activity Dispatch :- Transformation Activity running on a variety of compute services 
such as Azure Databricks, Azure HDInsight, Azure Machine Learning, 
Azure SQL Database, SQL Server, and more.
iv) SSIS Package Execution :- 

Integration run time provides compute environment where the activity either runs on or gets
dispatched from.
So Activity can be performed in the region closest to target data store or 
in compute service(IR).
When customer creates a data factory instance,they need to specify location of the data factory.
Here metadata of the data factory will be stored.
Meanwhile, a data factory can access data stores and compute services in other 
Azure regions to move data between data stores or process data using compute services.

The IR Location defines the location of its back-end compute means 
location where the data movement, activity dispatching, and SSIS package 
execution are performed. The IR location can be different from the location of 
the data factory it belongs to.

Example :- /* How Auto Resolve property of IR works */
Suppose you have your data factory created in "East US" & Integration runtime region is "Auto Resolve"
i) When copy data to Azure Blob in West US, if ADF successfully detected that the 
Blob is in West US, copy activity is executed on IR in West US; 

ii) If the region detection fails, copy activity is executed on IR in East US.
which is the data factory region.
When copy data to Salesforce of which the region is not detectable, 
copy activity is executed on IR in East US.

iii) If location of Integration runtime is not "Auto Resolve" then activity will be executed
in the IR env whichever has been selected during creation of Azure IR.

Above mentiomned all activity requires compute infrastrucure which will come from Integration
runtime(IR).

While creating linked services there is a field called "Connect via Integration Run Time".
Here by default values is "AutoResolveIntegrationRuntime" will be present.
So inside a pipeline we have linked services and Activity.
When activity runs, "Integration runtime(IR)" acts as a bridge between Linked Service and 
Activity and provide "Compute Infrastructure" information.

Manage >>> Integrations Runtime >>> Here by default "AutoResolveIntegrationRuntime"
is present.Here we can create new IRs of different types.

/* We need to choose above IR as per our requirement. */
Types of Integration runtime (IR) :- 
---------------------------------------
i) Azure :- It is the by default IR provided by Azure.
Name :- AutoResolveIntegrationRuntime
Type :- Azure
Sub Type :- Public
Region :- Auto Resolve

On public network(Cloud) :- If we want to perform below mentioned activities then we 
should choose Azure as IR.
Activity that can be performed using Azure IR in public network(Cloud).
a) Data Flow b) Data movement c) Activity Dispatch
On private network :- It does not work.So no activity can be performed using this.

If data movement is happening in public network(Azure Network) then "Azure" IR can be used.


ii) Self-hosted :- We need to create this.
On public (Cloud) Network :- Activity supported using Self Hosted are :- 
a) Data movement b) Activity Dispatch

On private (On Premises) Netwok :- Activity supported using Self Hosted are :- 
a) Data movement b) Activity Dispatch

If we want to move data from public (Azure) network to On private (Premises) network then 
"Self-hosted" IR can be used.

If we want to move data within "Azure virtual network" then "Self-hosted" IR can be used.

If we have existing SSIS Packages which is moving data from "Azure virtual network" 
to private (On Premises) Netwok then "Self-hosted" IR can be used.

iii) Azure-SSIS :- 
We need to create this.
On public (Cloud) Network :- Activity supported using Azure-SSIS are :- 
a) SSIS package execution

On private (On Premises) Netwok :- Activity supported using Azure-SSIS are :- 
a) SSIS package execution

If we have existing SSIS Packages which is moving data within public network(Azure Network)
then "Azure-SSIS" can be used.

/* Image Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Integration_Runtime_1.png */

Azure IR is  by default created by Azure itself.Rest two (Self-hosted & Azure-SSIS)
we need to create inside "manage >> Integration Runtimes".
Here new button will come and create different types of IRs.

Image Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Integration_Runtime.png

------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=MQ84n4Al_p4&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=14&ab_channel=WafaStudies */
/* 13. Azure Integration runtime in Azure Data Factory */
------------------------------------------------------------------------------------------
Azure provide by default Azure type integration run time.
Name :- AutoResolveIntegrationRuntime
Type :- Azure
Sub Type :- Public
Region :- Auto Resolve

Create Azure Integration Runtime :- 
----------------------------------------------
1) By default IR has location as "Auto Resolve" means how it works explained in above example.
When we want to keep Azure IR on certain location then we need to explicitly create a new IR.
2) If we would like to virtually group the activity executions on different IRs for management
purpose then we need to create new IR.

Steps to create Integration Runtime :- 
Manage >> Integration Runtimes >>> + New >>> Azure, Self-Hosted or Azure-SSIS
Location >> Auto Resolve (By Default) :- Can select as per choise.
Type :- Azure
Data Flow Run time >>> 
Compute Type :- Generat Purpose
Core Count :- 4 + (4 Driver Cores)
Time to live :- 10 minutes.

/* When to use Azure Integration Runtime :- */
-----------------------------------------------------
i) For Azure Server :- 
Activity :- a) Data Movement b) Compute Activity Dispatch
Source :- Azure
Destination :- Azure

------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=iIGeX7ZHABI&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=14&ab_channel=WafaStudies */
/* 14. Self Hosted Integration runtime in Azure Data Factory */
------------------------------------------------------------------------------------------
"Azure" type integration run time will not work in private network or On Premises Server.
Here we need to create "Self Hosted Integration runtime".

Azure Virtual Network (VNet) :- It is a representation of your own network in the cloud. 
It is a logical isolation of the Azure cloud dedicated to your subscription.

SSIS Package :- It is a collection of Control flow and data flow.Control flow includes 
the two things such as task and data flow task and Data flow includes source, 
transformation, and destination.

/* When to use Self Hosted Integration :- */
-----------------------------------------------------
i) For Azure Virtual Network (Private Network) :- 
Activity :- a) Data Movement b) Compute Activity Dispatch
Source :- Azure Virtual Network
Destination :- Azure Virtual Network 

ii) For On Premises Server :- 
Activity :- a) Data Movement b) Compute Activity Dispatch
Source :- Azure
Destination :- On Premises SQL Server


Self hosted integration runtime is capable of :- 
i) Performing data movement activity between cloud data store and in private network.
ii) Running transformation activity against compute resource in "on premises" or 
Azure Virtual Network.
iii) It can be installed on an "on premises machine" or a virtual machine inside
a private network.It can only be installed on windows OS.


------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=Rl1b-pRO4LE&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=15&ab_channel=WafaStudies */
/* 15. Setting up Self Hosted Integration runtime in Azure Data Factory */
------------------------------------------------------------------------------------------
Suppose we want data movement between "Azure cloud storage" and "On Premises Storage" OR
from "Azure Virtual Network" to "Azure Virtual Network".
So here we need to create a "Self Hosted Integration runtime".

1) 
Manage >> Integration Runtimes >>> + New >>>  Azure,Self-Hosted >>> Self-Hosted
Name :- 
Description :- 
Type :- Self-Hosted >>> Create
After create below screenshot will come.
/* Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Self_Hosted_Integration_Runtime.png */

2) Now install IR in On Premises OR Azure Virtual network.
There are two ways through which Self Hosted Integration runtime can be set up in windows machine.
/* Check where do we need to install.In the machine where Sql server is installed or any windows machine */
Option 1 :- Express Set up /* Not Explained.Check this */
Option 2 :- Manual Set UP. /* Explained */
Here we can see 2 Keys in screenshot.
/* https://www.microsoft.com/en-us/download/details.aspx?id=39717 */
>>> Download and Install Integration Runtime >>> It will redirect to Microsoft download centre.
>>> Download latest IR.
Install it on local windows computer.
>>> Copy Key from Portal and paste in Registration box in Local windows.
>>> Register

Now we can create Linked Service and there we can select this newly created SHIR.

/* Node :- */
From screenshot we can see a section "Nodes".
Once we register through key in local that machine will appear there.
and if we have created any linked service with this
IR and it is used in the ADF then execution will happen in this windows machine.
Here we can add maximum 4 machine in Node.This way we can get high availablity.
Again we need to take that downloaded Integration runtime and install on another machine.
Now new machine will also display in Node section.We can add maximum 4 nodes.

------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=9BvU_NpntSg&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=17&ab_channel=WafaStudies */
/* 16. Shared Self Hosted Integration runtime in Azure Data Factory */
------------------------------------------------------------------------------------------
While creating a new IR of Self Hosted type we will get 2 option.
i) Self-Hosted :- /* Self Hosted explained above. */
ii) Shared Self-Hosted :- /* Explained here */

In old release Self Hosted Integration runtime can be used in a single ADF (This is data factory not pipeline) only.
There were no option to use existing Self Hosted Integration runtime to other ADF (This is data factory not pipeline).
But now using "Shared/Linked" feature we can achieve this.

Suppose we created an ADF after creating a "Self Hosted Integration runtime".
Now we want to use this IR in another ADF.So here we need to add permission in IR.

Manage >>> Integration Runtime >>> Click on Self Hosted IR
below screenshot will come.
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Self_Hosted_Sharing.png
Inside Sharing option :- 
From the screenshot we can see ResourceId (Pre filled) & Grant Permission to another Data Factory.
i) Click on Grant and select newly created ADF
ii) Copy pre filled ResourceId :- 
iii) Create a new Self Hosted Integration runtime.
Steps :- 
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Self_Hosted_Sharing_1.png
Manage >> Integration Runtimes >>> + New >>>  
External Resource >>> Linked Self-Hosted
Name :- 
Description :- 
Type :- Self-Hosted (Linked) 
Resource Id :- Paste ResourceId here. >>> Create

/* Now this IR can be used in new ADF.Indirectly old IR will be used. */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=M22Mj0rcBcs&ab_channel=WafaStudies */
/* 17. Parameterize Linked Services in Azure Data Factory */
------------------------------------------------------------------------------------------
We can create a parametirized linked service where dynamic values can be passed at run time.
Suppose we have a SQL database which consist of 10 databases.
We need data from each database as per requirement.
So we need to create 10 linked service and inside that only change will be DB name
except that everything will be same.
We can minimize this effort by creating a Parameterized Linked Service.
and will create a single Linked Service.

Here I will create only Parameterized linked service but not implement how to pass
it at run time.First parameterized linked service will be created then Data set
and then Pipeline execution will happen.There we will see how parameter value will be passed.

I will made a linked service which will connect to local database and access all its DB.
Here database name will be a parameterzied value.
We can give parameter on any field like user name, Password, Servername etc..

Linked Service Name :- LS_OSELocal_SQL_DB
Account Selection method :- Enter manually else parameter will not work.
Server Name 	:- osedbserverlocal.database.windows.net
Authentication 	:- SQL Server Authentication
UseName			:- adminuser
Password 		:- usP>>2021
Fill all details except DB name.

/* At Linked Service level  */
Go to Parameter and create a parameter.
parameter Name :- DBName

Now go to Db name /* for linked service which we have kept blank  */
and click on ALT+P drop down.A new window will open and 
it will display the parameter name at bottom.Just select it and it will display like this.
@linkedService().DBName
This value will be populated in database name.
Save it.Publish it.
Parametrized linked Service is created.

We can create a parameterized linked service where at run time servername,database name,
user, password everything will be passed at run time.
Just create these many variables and select it for each field.
Note :- /* Each services does not support Parameterized Linked Services */

/* https://docs.microsoft.com/en-us/azure/data-factory/parameterize-linked-services */
/* Parameterize linked services in Azure Data Factory */
/* read it from here for more detailed information */

/* OWN */
Server Type 	:- Database Engine
Server Name 	:- osedbserverlocal.database.windows.net
Authentication 	:- SQL Server Authentication
Login			:- adminuser
Password 		:- usP>>2021
DataBase Name   :- oselocaltxdb_S34

LinkedService :- LocalAzureSQL
Database Name :- @linkedService().DBName

DataSet :- DSLocalDB
Table Name :- @dataset().TableName

Server :- 
DB1 :- T1,T2
DB2 :- T3,T4


-----------------------------------------------------------------------------------------
/*  https://www.youtube.com/watch?v=9XSJih4k-l8&ab_channel=WafaStudies */
/* 18. Parameterize Datasets in Azure Data Factory */
-----------------------------------------------------------------------------------------
While creating Datasets it requires table name.Other environment details it takes from 
linked services.
Since a DB can have so many tables.If we want to make generic Dataset which will get data
from any table then we need to create a Parameterized Data sets.
The way we have created Parameterized linked services same way we create it too.

Linked Service Name :- LS_OSELocal_SQL_DB
Datasets Name :- DS_OSELocal
Parameter Name Inside Parameter :- TableName
Create then check edit check box then type dbo as schema name and select parameter name
in table name. /* @dataset().TableName */

Here we also need to create a parameter for database name.Since we have used a 
parameterized linked service.And parameter used in linked servive will not work here.
So again we need to create a parameter at DataSet.

Parameter Name :- DBName :- /* @dataset().DBName */ /* Repeat same step */

/* At Pipeline level we will pass these variables */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=2u6Mo47A9JA&ab_channel=WafaStudies */
/* 19. Parameterize Pipelines in Azure Data Factory */
-----------------------------------------------------------------------------------------
Requirement :- We will copy a table data into another table of same structure in same database.
Source Table :- Table1
Target Table :- Table2

DB Name :- oselocaltxdb_S34
CREATE TABLE T1
(ID INT)
INSERT INTO T1 VALUES (1)
INSERT INTO T1 VALUES (1)


CREATE TABLE T2
(ID INT)

Linked Service Name :- LS_OSELocal_SQL_DB
Datasets Name :- DS_OSELocal
Pipeline Name :- Data_Copy_Pipeline
Activity Name :- Data_Copy_Activity

Here again we need to give all variable names.
i) Source DB name :- srcdbnamepipe
ii) Source Table Name :- srctablenamepipe
iii) Target DB name :- tgtdbnamepipe
iv) Target Table Name :- tgttablenamepipe

All these parameter we need to pass at run time means at Trigger level.
Create a schedule Trigger :- 
Trigger Name :- ScheduleTrigger
Here while running we need to provide these values.
If next time we want new set of value then we can change these from from trigger or
simply create a new trigger.

/* Publish All and trigger it */
srcdbnamepipe :- oselocaltxdb_S34
srctablenamepipe :- T1
tgtdbnamepipe :- oselocaltxdb_S34
tgttablenamepipe :- T2

SELECT * FROM T2
ID
1
1

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=-VtZtajW2Hc&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=21&ab_channel=WafaStudies */
/* 20. System Variables in Azure Data Factory */
-----------------------------------------------------------------------------------------
System Variables in ADF :- 
System variables are inbuilt variable provided by azure.
We can use these variables in expressions in ADF and scope is :- 
i) Pipeline Scope :- 
ii) Schedule Trigger Scope :- 
iii) Tumbling Window Trigger Scope :- 

/* https://docs.microsoft.com/en-us/azure/data-factory/control-flow-system-variables */
/* System variables supported by Azure Data Factory */
/* Here all predefined System variables name are present.Use these and try some examples */

All these varibale name will show in pipeline when we will create a parameter.
No Need to remember all these name.Automatically it will be displayed.

Pipeline scope :- 
-----------------------------
@pipeline().DataFactory
@pipeline().Pipeline	
@pipeline().RunId	   
@pipeline().TriggerType
@pipeline().TriggerId	
@pipeline().TriggerName
@pipeline().TriggerTime
@pipeline().GroupId	   
@pipeline()__?__.TriggeredByPipelineName
@pipeline()__?__.TriggeredByPipelineRunId

Schedule trigger scope :- 
----------------------------
@trigger().scheduledTime
@trigger().startTime

Tumbling window trigger scope :- 
-----------------------------------
@trigger().outputs.windowStartTime
@trigger().outputs.windowEndTime
@trigger().scheduledTime
@trigger().startTime

Requirement 1 :- 
-------------------------
Suppose we ran a pipeline and we want to store all pipeline level information to our DB.
Then we will pass all these variables as i/p to SP and this will insert data into our table.

New PipeLine :- Copy_File_Capture_Details_Pipeline
Copy Activity Name :- Copy_File_data
Source DataSet :-    DS_uspstorageaccountnew_uspstagingcontainer_input_data
Target DataSet :-    DS_uspstorageaccountnew_uspstagingcontainer_output_data
Stored Procedure Activity :- 
Stored Procedure Name :- Get_Pipeline_Details
Table Name :- Pipeline_Execution_Details
Linked Service Name :- LS_OSELocal_SQL_DB
Datasets Name :- DS_OSELocal
System Variable :- @pipeline().DataFactory, @pipeline().Pipeline, @pipeline().RunId	

/* Create table & procedure */
/* Add stored procedure as activity */
/* Pass system variable as i/p to SP */

CREATE PROCEDURE [dbo].[Get_Pipeline_Details] @ADFName nvarchar(500), @PipelineName nvarchar(500)
AS  
BEGIN 
    DECLARE @TransactionDatetime datetime=GETUTCDATE()
END;

Create two i/p parameter and assign system variable to it and run the pipeline.

/*
Source DataSet :-    DS_uspstorageaccountnew_uspstagingcontainer_input_data
                     DS :- DataSets
                     uspstorageaccountnew :- Azure Storage Account Name
                     uspstagingcontainer :- Container Name
                     input :- Folder Name
                     data :- File Name
Select File Path :- Through Browse select the file then automatically it will be filled.
This will be used a Source.
Since we are copying data into another folder.So we need another DataSet.

Target DataSet :-    DS_uspstorageaccountnew_uspstagingcontainer_output_data
Folder Name :- output
File Name :- data.txt

*/
/* Completed in next playlist where real time scenario is discussed */
/* Video no 6 */

Requirement 2 :- 
-------------------------
Suppose we have created a trigger and and this trigger is atteched to a pipeline
and pipeline contains a query which takes trigger start time in where clause.
So here first at pipeline level we will create parameter and after creating trigger
it will ask value for it.There we will provide below system variable.
@trigger().scheduledTime/@trigger().startTime as per our req.

/* Do exercise on this on portal */
/* Do it on Schedule and tumbling trigger type */
/* Done in tumbling window trigger */
-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=KMzQgkdKnBc&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=22&ab_channel=WafaStudies *
/* 21. Connectors Overview in Azure Data Factory */
-----------------------------------------------------------------------------------------
Supported data stores and its properties in ADF pipelines :- 

/* https://docs.microsoft.com/en-us/azure/data-factory/connector-overview */
/* Azure Data Factory connector overview */
Read from here for detailed information.

As per requirement this documentation can be checked what are the properties we can use
while creating pipeine.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=uE8IZMiRc5s&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=22 */
/* 22. Supported File Formats in Azure Data Factory */
-----------------------------------------------------------------------------------------
Suported Formates :- 
i) Avro Format :- 
ii) Binary Format :- These are text files (*.txt)
iii) Delimited text Format :- .csv files
iv) JSON Format :- .json files
v) ORC Format :- 
vi) Parquet Format :- 

Avro is a row-based format.It was created by Apache.
Each record contains a header that describes the structure of the data in the record. 
This header is stored as JSON The data is stored as binary information.
Avro is a very good format for compressing data and minimizing storage and network bandwidth requirements.

d) Parquet :- Parquet is another columnar data format. It was created by Cloudera and Twitter. 
A Parquet file contains row groups. Data for each column is stored together in the same 
row group. Each row group contains one or more chunks of data. A Parquet file includes 
metadata that describes the set of rows found in each chunk. An application can use 
this metadata to quickly locate the correct chunk for a given set of rows, and retrieve 
the data in the specified columns for these rows. Parquet specializes in storing 
and processing nested data types efficiently. It supports very efficient compression 
and encoding schemes.

Avro, ORC & Parquet Files :- 
----------------------------------
i) ORC, Avro & Parquet are the formats which are part of Apache hadoop echo system.
ii) These formats works on compression algorithm.Here data will be stored in compressed
format.Hence query result will be faster.
iii) If table data we are loading into all these file format then size will be less in
Avro, ORC & Parquet Files in compared to Binary, JSON & Delimited text file.

/* Read from documentation for more details */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=XOJeyRBXBos&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=23 */
/* 23. Copy Data Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
Properties of Copy Activity at Pipeline level :- 

General Section :- 
----------------------
i) Timeout :- By default value is 7 days (7:00:00:00).
Copy activity will run for 7 days.If during this time it didn’t get completed then it 
will be marked as "Timed Out".

ii) Retry :- If pipeline fails then how many times it will retry.
By default value is 0 means it will not try.

iii) Retry Interval :- If "Retry" value is > 0 then after failure, after how many minutes it
will try again.It is the interval between try attempt.

iv) Secure Output :- By default not checked :- When checked, output from the activity will not be captured in logging
v) Secure Input :- By default not checked :- When checked, output from the activity will not be captured in logging

Source Section :- 
---------------------
i) Source Dataset :-  Depending upon dataset selected, below setting may change 
    Suppose selected Dataset belong to Blob Storage.
ii) File Path Type :- Radio Button :- 
a) File Path in Dataset :- 
b) WildCard File Path :- *.csv or *.txt or any pattern can be set here
c) List Of Files :- 

iii) Filter by last modified :- If we want to filter files based on modified data time then can provide condition here.
Ex :- a) Start time (UTC) :- @adddays(utcnow(),-2)
      b) End time (UTC) :- @utcnow()

iv) Recursively :- By default not checked :- If checked and dataset pointing to any folder then all files inside that folder will be picked.

v) Enable partition discovery :- /* Check it */
vi) Partition root path :- /* Check it */
vii) Max concurrent connections :- /* Check it */
viii) Skip line count :-  /* Check it */
ix) Additional Columns :-  /* Check it */


/* /* https://docs.microsoft.com/en-us/azure/data-factory/connector-overview */
/* Azure Data Factory connector overview */

In order to know property of each selected datastore, click on above mentioned link & 
then click on datastore which we have selected.
Then go to "Copy Activity Properties" (Right Side).
Here all properties of that datastore for copy activity will be explained.


Sink Section :- 
-----------------------
/* Depending upon dataset selected, below setting may change */
/* Read from documentation */
i) Sink Dataset :- 
/* Check all these options */
ii) Copy behavior :- Drop Down :- i) Add Dynamic Content ii) Flatten hierarchy iii) Merge Files iv) Preserve Hierarchy v) None /* selected */
/* Copy behaviour is discussed in detail below. Must see */
iii) Max concurrent connections :- The upper limit of concurrent connections established to the data store during the activity run. Specify a value only when you want to limit concurrent connections.
iv) Block size (MB) :- 
v) Metadata
vi) Quote All Text :- 
viii) File Extension :- 
ix) Max rows per file :- 

Maping Section :- 
------------------------
When we are copying data between tables that time we can match columns of source & 
Target table.
Only in Delimited file mapping section is coming.For binary file mapping is not coming
Because in text file it considers single row means one column.

Suppose we have file and content is like this.
Abhilash,30,Male

When we will copy this file to target folder then and we want data like this.
30,Abhilash,Male

Here in mapping section we need to do a column mapping.
So we will select  column 2 which is 30 to go to target on 1st column.
and column 1 will map to column 2 in mapping section.


cat>employee.csv
Abhilash,30,Male

PipeLine Name :- Copy_File_Mapping_Pipeline
Copy Activity Name :- Copy_File_data
Linked Service :- LS_AzureStorage_uspstorageaccountnew
Source DataSet :-    DS_input_employee (File Type:- Delimited)
Target DataSet :-    DS_output_employee (File Type:- Delimited)
/* Only in Delimited file mapping section is coming.For binary file mapping is not coming */
/* Because in text file it considers single row means one column */
uspstorageaccountnew :- Azure Storage Account Name
uspstagingcontainer :- Container Name
input :- Source Folder Name
output :- Target Folder Name

Mapping :- Import Schema
Column 2 of source to Column 1 in target.
Column 1 of source to Column 2 in target.
/* If we don't want column 3 then in the mapping we can delete it */

Trigger Name :- Trigger_Copy_File_Mapping_Pipeline
Trigger it. Data copied and content is like this :- 
"30","Abhilash","Male"

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=pjGN_4BfORM&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=24 */
/* 24. Copy Data Activity in Azure data factory Continuation */
-----------------------------------------------------------------------------------------
Setting Section :- 
------------------------
i) Data Integration Unit (DIU) :- When pipeline runs it needs some DIU (Hardware Power).
By default it is "Auto".Means whatever required it will use.
We can manually configure this by dropdown.Values are 2,4,8,16,32

Cost :- You will be charged # of used DIUs * copy duration * $0.25/DIU-hour. 
Local currency and separate discounting may apply per subscription type. 

ii) Degree of copy parallelist :- Till what extent we want parallism while loading data 
into sink./* Check By default Value */

iii) Fault Tolerance :- If any incompatible rows are coming then by default it will terminate the
activity process.We can change this by choosing different options.
Sample values are :- 
a) Skip Incompatible rows
b) Skip Missing files
c) Skip Forbidden files
d) Skip files with invalid names

Suppose we choose "Skip Incompatible rows" then we need to give a linked service path
where these records will be stored.Currently these files can only be stored at "Azure Blob"
& "Azure Data Lake".So from here we can know how many records discarded.

iv) Enable Logging :- Yes :- This is used to capture all logs related to pipeline execution.
It includes all loaded files, skipped rows etc.. information into a file
whose linked service we need to provide.
/* Read more on it */

v) Enable Staging :- If while copying we want a staging env rather than copying data directly into 
target server.If selected as yes then need to provide linked service to staging env.
After successful transfer of data, staging server data will be deleted permanently.
Azure data lake or 

vi) Preserve :- /* Not discussed */

User Properties :- 
------------------------
When we run a pipeline, it’s log we can check in monitor window.
At pipeline level it will show execution status And again we will click on this pipeline 
then at activity level clicking on "chasma", we can see how many rows got copied from which server.

At activity level inside pipeline run,we have some columns like :- 
Activity name,
Activity type,
Run start,
Duration,
Status,
Integration runtime,
User properties :- Without configuring "User properties" it will be null.
Error,
Run ID

User properties :- Here as per our wish we can write "Name" & "Value".
Suppose we are transfering date from file1 to folder 2.
So these information we get assign to "Value" and give a "Name".
Similarly we can write upto 5 "Name" and assign value to it which will be useful at pipeline
level at monitor window.
After assigning "User properties", these value will be desplayed at Monitor section
once pipeline will run.So there only we can get some infomation.

Here we can create variable and assign value to it.And same will display in monitor.
Here we can use "Auto Generate" And it will set variable with value like Source, destination
and we can see these in monitor window and activity level inside a pipeline.
/* Max we can create 5 variables inside properties */

PipeLine Name :- Copy_File_Mapping_Pipeline
Re run this after adding "User properties" and can see source and destination file name & Location.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=bIITK_WUF0w&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=25 */
/* 25. Monitor Copy Data Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
/* Monitoring Activity of Pipeline */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=j7mblYz3b5w&ab_channel=Cloudpandith */
/* 11 Copy Behaviour in Azure Data Factory */
-----------------------------------------------------------------------------------------
Requirements :- 
i) Read from root folder and sub folder and copy files with same structure as source.
Source :- 
MainFolder
   file1
   file2
   SubFolder1 
        file3
        file4
Target :- 
MainFolder
   file1
   file2
   SubFolder1 
        file3
        file4
ii) Read files from root folder and copy files to root folder.Here sub folder can have same file name as root folder.
And if we will try to copy then either we can keep only one file.So here we need to rename each file to avoid
this error.
Source :- 
MainFolder
   file1
   file2
   SubFolder1
        file1 /* Also present in Main folder */
        file3
        file4
Target :- 
MainFolder
    file1_tgt
    file2_tgt
    file3_tgt
    file4_tgt
    
iii) Read files from root folder and subfolder and Merge two files data.
Source :- 
MainFolder
   file1
   SubFolder1 
        file2
        file3
Target :- 
MainFolder
    File1_File2_File3 /* Merged files */

1) Read files from root folder and copy files with same structure as source.
Here we need to copy only root folder files.
Source :- 
MainFolder
   file1
   file2
   SubFolder1 
        file3
        file4
Target :- 
MainFolder
   file1
   file2

2) Read files from root folder and copy files to sink.
Here just rename the files of root folder and copy it to sink.
Source :- 
MainFolder
   file1
   file2
   SubFolder1
        file3
        file4
Target :- 
MainFolder
    file1_tgt
    file2_tgt

3) Read files form root folder and merge two files data.
Here just merge data of root folder files.
Source :- 
MainFolder
   file1
   file2
   SubFolder1
        file3
        file4
Target :- 
MainFolder
    file1_file2_tgt

/* Copy Behaviour with Recurssive Yes/No :- */
In Copy activity, we have a sink where we need to select sink dataset where files will be copied.
Here we will also get one option "Copy Behaviour".From drop down we need to select.
i) Add Dynamic Content ii) Flatten hierarchy iii) Merge Files iv) Preserve Hierarchy v) None

Using these values we can achive our requirements.Check below screenshot.
Screenshot :- File Name :- Copy_Behaviour_Recurssive_Yes.png
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Copy_Behaviour_Recurssive_Yes.png

Screenshot :- File Name :- Copy_Behaviour_Recurssive_No.png
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Copy_Behaviour_Recurssive_No.png

Copy Behaviour :- 
1) Preserve Hierarchy /* Default one */ :- If we have selected Preserve Hierarchy in copy behaviour then it will wok as copy paste.
Here all the files and folder will be copied with same structure in target path.
Requirements that can be completed using it :- 

i) Read from root folder and sub folder and copy files with same structure as source.
Source :- 
MainFolder
   file1
   file2
   SubFolder1 
        file3
        file4
Target :- 
MainFolder
   file1
   file2
   SubFolder1 
        file3
        file4

2) Flatten hierarchy :- If we have selected Flatten Hierarchy in copy behaviour then it will take all the files
from root folder and subfolder and keep it at root folder.Here by default name will be given by pipeline.
Requirements that can be completed using it :- 

ii) Read files from root folder and copy files to root folder.Here sub folder can have same file name as root folder.
And if we will try to copy then either we can keep only one file.So here we need to rename each file to avoid
this error.
Source :- 
MainFolder
   file1
   file2
   SubFolder1
        file1 /* Also present in Main folder */
        file3
        file4
Target :- 
MainFolder
    file1_tgt
    file1_tgt_new
    file2_tgt
    file3_tgt
    file4_tgt

3) Merge Files :- f we have selected Merge Files in copy behaviour then it merge all files present in root folder
or subfolder and create a new merged file.If we have given a file name in dataset then that file name will be
picked for merged file name else auto genarated file name will be kept.
Requirements that can be completed using it :- 
iii) Read files from root folder and subfolder and Merge two files data.
Source :- 
MainFolder
   file1
   SubFolder1 
        file2
        file3
Target :- 
MainFolder
    File1_File2_File3 /* Merged files */

In above cases we need to keep Recursively = yes which is present in source section which is a check box.
then only files present inside subfolder will be picked.

If Recursively = no then files at root level will be picked only.All files at subfolder will be ignored.
Screenshot is present for bothe cases.

/* File Path type in source section :- */
If we want to put condition while fetching files from folder then we can use wildcard paths option.
i) * (Match zero or more character) :- *.csv :- Here all files having .csv extension will be picked.
ii) ? (Match zero or single character) :- ?uct.csv :- Here any type of file like cust,pust,dust.csv etc will be picked.
iii) * :- All files inside a directory & sub folder files also

/* Try to implement it in Azure Pipeline */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=7B5BJ1SV_Pw&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=26 */
/* 26. Delete Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
If we want to delete files and folders from On premises or from cloud storage and On premises storages
then we need to use "Delete Activity" in the pipeline.
Once delete activity ran and it deleted the files/folders it can not be restored.

/* https://docs.microsoft.com/en-us/azure/data-factory/delete-activity */
/* Delete Activity in Azure Data Factory */

Requirement :- Delete all .csv file from Output folder.

PipeLine Name :- Delete_File_Pipeline
delete Activity Name :- Delete_File_Activity
Linked Service :- LS_AzureStorage_uspstorageaccountnew
Source DataSet :-    DS_output_employee (File Type:- Delimited)
uspstorageaccountnew :- Azure Storage Account Name
uspstagingcontainer :- Container Name
output :- Target Folder Name

File Path Type :- 
---------------------
/* Example for each type :- */
/* https://docs.microsoft.com/en-us/azure/data-factory/connector-azure-blob-storage#folder-and-file-filter-examples */
i) File Path in Dataset :- If file name is provided in data set then only that file will
    be deleted.If folder name is provided then all files inside that folder will be deleted.
ii) WildCard File Path :- If selected the option will come "Wildcard file name".
    If we want to delete only *.txt or *.csv file then we can write here.
iii) Prefix :- 
iv) List Of files :- 

Recursively :- If yes then all subfolder/Sub files will be deleted.
By defgault value id false.

Logging Settings :- If we want metadata info of deleted files then here we need to configure it.
Need to select a linked service and a folder/file where these info will be stored.
Linked Service :- LS_AzureStorage_uspstorageaccountnew

Run Pipeline :- employee.csv will be deleted & log will be captured in output folder.
a new folder will be created for each run and inside that files will be present with log.

Log :- 
Name,Category,Status,Error
employee.csv,File,Deleted,

Supported Data store for Delete activity :- 
i) Azure Blob Storage :- 
ii) Azure Datalake Storage Gen1/2
iii) Azure File Storage :- 
/* Check from documentation */

/* Note :- It has no relation with Azure SQL Database.Only files related datastore are there */

PipeLine Name :- Delete_File_Pipeline
{
    "name": "Delete_File_Pipeline",
    "properties": {
        "activities": [
            {
                "name": "Delete_File_Activity",
                "type": "Delete",
                "dependsOn": [],
                "policy": {
                    "timeout": "7.00:00:00",
                    "retry": 0,
                    "retryIntervalInSeconds": 30,
                    "secureOutput": false,
                    "secureInput": false
                },
                "userProperties": [
                    {
                        "name": "FilesDeletes",
                        "value": "All .csv file in output folder"
                    }
                ],
                "typeProperties": {
                    "dataset": {
                        "referenceName": "DS_output_employee",
                        "type": "DatasetReference"
                    },
                    "logStorageSettings": {
                        "linkedServiceName": {
                            "referenceName": "LS_AzureStorage_uspstorageaccountnew",
                            "type": "LinkedServiceReference"
                        },
                        "path": "uspstagingcontainer/output"
                    },
                    "enableLogging": true,
                    "storeSettings": {
                        "type": "AzureBlobStorageReadSettings",
                        "recursive": false,
                        "wildcardFileName": "*.csv",
                        "enablePartitionDiscovery": false
                    }
                }
            }
        ],
        "annotations": [],
        "lastPublishTime": "2021-05-15T09:28:18Z"
    },
    "type": "Microsoft.DataFactory/factories/pipelines"
}

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=6cPv1TlVviA&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=27 */
/* 27. Variables in Azure Data Factory */
-----------------------------------------------------------------------------------------
Difference between Parameter & Variables :- 
------------------------------------------------
When we define any parameter then it’s value we are passing at run time through trigger.
and it is mandatory.

We can define a variable at pipeline level also set value of it using set variable activity 
or append variable activity.

i) Variables are internal to pipeline and value can be changed inside the pipeline.
ii) Variable supports 3 data types :- String, bool, Array
iii) Reference :- @variables('variableName')

Requirement :- 
Suppose in storage server two files are getting dumped.
HourlySales.csv and DailySales.csv
If HourlySales.csv dumped then load data into HourlySales table.
If DailySales.csv dumped then load data into DailySales table.

Approach :- 
Create an event trigger which will trigger whenever any .csv file will be uploaded into 
input folder.
If any pipeline has parameter then at run time at trigger level we need to provide value
and that value will be assign to parameter.
But this parameter we can not use for handling any logic.So we need to assign this parameter to 
variable or in other words value of variable will be parameter value which is coming from trigger
at the time of run.

i) Create a parameter :- FileName
ii) Create a variable :- FileType
iii) Assign value to Variable "FileType" = pipeline().parameters.FileName (Parameter Value)
iv) Use if else logic to decide which where do will be loaded.
v) From MS documentation on "Event based trigger", file name can obtained by "@triggerBody().fileName"
Pass this at the time of trigger.So basically this value will go to "Parameter" and then this
parameter will be assigned to "Variable".And then if else logic will be performed.


/* DB Linked Serives */
Linked Service Name :- LS_OSELocal_SQL_DB_txdb_S33
Server Name 	:- osedbserverlocal.database.windows.net
Authentication 	:- SQL Server Authentication
UseName			:- adminuser
Password 		:- usP>>2021
DB Name         :- oselocaltxdb_S33

/* DB DataSets Serives */
Datasets Name :- DS_OSELocal_HourlySales
Table Name :- HourlySales
CREATE TABLE [dbo].[HourlySales](
	[id] [int] NOT NULL,
	[Name] Nvarchar(Max) NULL,
	[Age] Nvarchar(Max) NULL
)

Datasets Name :- DS_OSELocal_DailySales
Table Name :- DailySales
CREATE TABLE [dbo].[DailySales](
	[id] [int] NOT NULL,
	[Name] Nvarchar(Max) NULL,
	[Age] Nvarchar(Max) NULL
)

/* Container Linked Serives */
Linked Service :- LS_AzureStorage_uspstorageaccountnew
                    uspstorageaccountnew :- Azure Storage Account Name
                    uspstagingcontainer :- Container Name
                    input :- Folder Name
DataSet :-    DS_input_HourlySales (File Type:- Delimited)
File Name :- HourlySales.csv

1,Abhilash,30


DataSet :-    DS_input_DailySales  (File Type:- Delimited)
File Name :- DailySales.csv

1,Ashish,34

/* Pipeline */
Pipeline Name :- LoadHourlyDailyPipeline
File Name :- LoadHourlyDailyPipeline.sql (Local)
Parameter :- FileName >>> Value will be dumped file name.

This value will come from event trigger./* @triggerBody().fileName */
While creating trigger will assign parameter FileName.
Value :- @triggerBody().fileName

First define variable at pipeline level.Then use SET variable activity to assign data to this variable.
Variable :- Name :- FileType :- 
Set Activity :- 
Name :- Drop down :- FileType
This value we will get from Parameter.
and it will be used for comparision in if/else block. 
Value :- /* pipeline().parameters.FileName */

/* IF/ELSE Activity :-  */
If Expression :- @equals(variables('FileType'),'HourlySales.csv')
/* Activity */
If Case :- Copy Activity Name :- LoadToHourlySalesTable
Else Case :- Copy Activity Name :- LoadToDailySalesTable

Trigger Name :- HourDailySalesEventTrigger
Variable Name for Event Trigger :- 
i) @triggerBody().fileName :- Name of the file whose creation or deletion caused the 
trigger to fire.

ii) @triggerBody().folderName :- Path to the folder that contains the file specified by 
@triggerBody().fileName. The first segment of the folder path is the name of 
the Azure Blob Storage container.

iii) @trigger().startTime	Time at which the trigger fired to invoke the pipeline run.
/* Since we need file name so will use @triggerBody().fileName */
Provide Variable Name :- @triggerBody().fileName
/* Try to run it.Getting error while publishing */

-------------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=rzDZdRifC40&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=29&ab_channel=WafaStudies */
/* 28. Set Variable Activity in Azure Data Factory */
-------------------------------------------------------------------------------------------------------
If we have defined a variable at pipelie level then we can assign a value to that variable
using "set Variable Activity".

We can assign system variable into a variable and can also use azure functions.
If we have selected variable name as array then we can pass values as comma seprated.

-------------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=aJuohp8a-fA&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=29&ab_channel=WafaStudiesWafaStudies */
/* 29. Append Variable Activity in Azure Data Factory */
-------------------------------------------------------------------------------------------------------
Append Variable Activity :- It is used to add a value to an existing array variable 
defined in a ADF pipeline.
/* Note :- It is limited to only array variable. */

Suppose we have created a pipeline and at pipeline level defined a variable
"FileName" as array type.Also we have created a parameter variable which takes file name
at run time.
For array variable we have assigned values which is a.txt,b.txt,c.txt.

Now suppose we do not want to use these file name values.
We want some other values for this variable.Then we can use "Append Variable Activity".

Inside General drag it and inside variable from drop down select "filename" variable
and give value as per our choice.Here we can select value of "parameter variable" also.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=nc4IFKkkfXM&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=31&ab_channel=WafaStudiesWafaStudies */
/* 31. Execute Pipeline Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
Execute Pipeline Activity :- This activity allows a data factory pipeline to invoke
another pipeline.

Requirement :- We have a pipeline which will copy data from one database to another database.
This pipeline requires 4 parameter to run.
i) Source DB name :- srcdbnamepipe
ii) Source Table Name :- srctablenamepipe
iii) Target DB name :- tgtdbnamepipe
iv) Target Table Name :- tgttablenamepipe

Create a master pipeline which will call this pipeline as child pipeline.

/* Child Pipeline Details */
Source Table :- Table1
Target Table :- Table2

Linked Service Name :- LS_OSELocal_SQL_DB
Datasets Name :- DS_OSELocal
Pipeline Name :- Data_Copy_Pipeline
Activity Name :- Data_Copy_Activity

Here again we need to give all variable names.
i) Source DB name :- srcdbnamepipe
ii) Source Table Name :- srctablenamepipe
iii) Target DB name :- tgtdbnamepipe
iv) Target Table Name :- tgttablenamepipe

/* Master Pipeline Details */
Pipeline Name :- MasterPipeline
Activity Name (Execute Pipeline) :- Invoke_Data_Copy_Pipeline
Since we need to pass 4 parameter to child pipeline.So here we will create 4 parameter.
Here we can hardcode these parameters.Then directlty child pipeline will be called with 
these values but next time again we need to change at pipeline level.
So we will create 4 parameter and trigger level we will pass as per our wish.


Properties :- Settings
Invoked Pipeline :- Data_Copy_Pipeline (select from drop down).
After selecting pipeline name automatically 4 paratemer(srcdbnamepipe,srctablenamepipe,tgtdbnamepipe,tgttablenamepipe)
will be displayed here which we need to pass.

Wait on completion :- By default "Yes".Means master pipeline will wait till execution
of child pipeline else after invoking it will proceed to run other activity if it has any.


Create 4 Parameter at pipeline level :- 
i) srcdb
ii) srctable
iii) tgtdb
iv) tgttable

Now at activity level for each parameter for child pipeline select these newly created
parameter.(Dynamically ALT+P)
srcdbnamepipe :- @pipeline().parameters.srcdb
srctablenamepipe :- @pipeline().parameters.srctable
tgtdbnamepipe :- @pipeline().parameters.tgtdb
tgttablenamepipe :- @pipeline().parameters.tgttable

/* Publish it and run it */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=y2KDonUDuPc&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=32 */
/* 32. Filter Activity in Azure Data Factory */
/* https://www.youtube.com/watch?v=KuWYuHlUwD0&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=34&ab_channel=WafaStudies */
/* 33. ForEach Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
Fileter Activity :- It is used in a pipeline to apply a filter expression 
to an input array.

Here we will create a parameter of array type and hardcode some value.
Then at pipeline level we will use filter activity to apply some condition on 
given i/p value and process it with "For each Activity".

Pipeline Name :- FilterPipeline
Activity Name :- Fileter_Activity
At Pipeline Level :- 
Parameter :- 
ArrayOfValues = [1,2,3,4,5,6]

Activity Name :- Fileter_Activity :- Setting :- 
/* At Filter activity level we will filter this array and will take only values greater
than 2 And same will pass in another activity "Foreach Activity". */

Settings :- 
items :- Select from Parameter :- @pipeline().parameters.ArrayOfValues
Condition :- @greater(item(),2) :- If value is greater than 2 then will return true.
Will use azure greater function to get value greater that 2.
item() :- Keyword to fetch array element.

/* ForEach Activity */ :- 
ForEach Activity :- It defines a repeating control flow in the pipeline.
It is used to iterate over a collection and executes specified activities in a loop.
Here we pass array of values and for each value it will iterate and perform the action.
The items properties is collection and each item inside collection is reffered by "@item()".

If passed array is [3,4,5,6]. Then for 1st iteration @item() will display 3 and so on.

Requirement :- We have input folder in our storage account and file present inside
that folder in data.txt.
We want to copy this file into 3 folder.
i) <Container>/Output1
ii) <Container>/Output2
iii) <Container>/Output3

Here we will not create 3 copy activity rather will use "for each activity" to call
a single copy activity 3 times and copy data to destination.

Linked Service :- LS_AzureStorage_uspstorageaccountnew
Source DataSet :- DS_uspstorageaccountnew_uspstagingcontainer_input_data
/* At source data.txt will be present */
Target DataSet Name :- DS_Output :- Here folder name we will pass dynamically.
Parameter :- Folder
For "Directory" inside connection add dynamic content :- @dataset().Folder

Pipeline Name :- For_Each_Copy_Output_Pipeline
Parameter :- OutputFolder = ["output1","output2","output3"] :- Values of folder where data
needs to be copied in the same container.
Note :- If we want to fetch 1st element then "@item()" can be used in foreach copy activity at dataset.

Here automaticall one by one value from array will be passed and using "@item()" we can get the value.
Activity Name :- ForEachActivity
Settings :- 
Sequential :- Check/Uncheck
If Sequentials is "No" then we need to provide Batch count.Now batch count number of 
element will be picked from the array list and go to Activity tab and will 
perform the action parallely.Same activity will be repeated till last element.

Items :- @pipeline().parameters.OutputFolder (Dynamic) :- 
This value will take from parameter "OutputFolder" dynamically.

Sequentials & Activities Batch Count :- 
If sequentials is "Yes" then first value it will take from the array and go to 
Activities tab and perform the action till last element.

Activity :- Define here Copy Activity which will be called sequentially.
Activity Name :- Copy_Activity
For Sink Data :- 
Folder parameter :- @item() :- from "foreach" output dynamically.

/* Publish it and trigger Now */
/* Running fine.Data is getting copied in 3 folders. */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=_VNOabanIV4&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=34&ab_channel=WafaStudies */
/* 34. Get Metadata Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
Get Metadata Activity :- It is used to retrive the metadata of any data in ADF.
Since while creating pipeline we are giving "Datasets" to know about data to pipeline.

But If we want to put some logic on metadata of data then first we should know
about metadata of that datasets.
Suppose DS_uspstorageaccountnew_uspstagingcontainer_input_Emp is pointing to 
container :- uspstagingcontainer
folder=input
and file=Emp.csv
So metadata of this file will be 
i) Add Dynamic Content,
ii) Column Count :- If dataset is pointing to a csv/XL then will give total column count in JSOn.
iii) Content MD5 :-     "contentMD5": "tFcoBRMuNbCj3jQvnbnaqA==" /* Check what is this */
iv) exists :-     "exists": true in JSON
v) item name :-     "itemName": "Emp.xlsx" :- file name dataset is pointing
v) Child Item :- If pointing to a folder then will give all file name inside this.
/* Will come only for folder. */
vi) item type :-     "itemType": "File"
vii) last modified date :-     "lastModified": "2021-08-24T08:47:59Z"
/* Last Modified of file or folder as per Dataset */
viii) Size :-     "size": 677
ix) Structure :- {"structure":[{"name":"empno","type":"String"},{"name":"ename","type":"String"},{"name":"job","type":"String"},{"name":"mgr","type":"String"},{"name":"hiredate","type":"String"},{"name":"sal","type":"String"},{"name":"comm","type":"String"},{"name":"deptno","type":"String"}],"effectiveIntegrationRuntime":"DefaultIntegrationRuntime(EastUS)","executionDuration":0,"durationInQueue":{"integrationRuntimeQueue":0},"billingReference":{"activityType":"PipelineActivity","billableDuration":[{"meterType":"AzureIR","duration":0.016666666666666666,"unit":"Hours"}]}}
/* Column Header structure */


If Datasets is points to a table then metadata will be 
i) Add Dynamic Content :- 
ii) ColumnCount :- 
iii) Exists  :- 
iv) Structure :- 

/* https://docs.microsoft.com/en-us/azure/data-factory/control-flow-get-metadata-activity */
/* Get Metadata activity in Azure Data Factory */
/* read all metadata related details means for which datasets what metadata we can get*/

After getting any metadata info we can apply if/else logic to decide which action 
we need to take.

In metadata activity :- 
Dataset :- main section beside General
Dataset :- Drop Down :- Select any dataset.
Field List :- + New :- Now we will get a dropdown.Here we can get metadata of selected dataset.
Suppose selected dataset belongs to DB then drop down will show :- 
i) Column Count ii) Exists iii) Structure iv) Add dynamic Content .


-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=pd-DJJUhnsw&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=35&ab_channel=WafaStudies */
/* 35. If Condition Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
If Condition Activity :- Here we will expression.If expressions resolves "True" then 
certain set of activities will run.If the expressions resolves to "Fail" then another
set of activity will run.

While checking condition we can use variable as well as Parameter.

Requirement :- There will be a parameter copytoOutput1.If it is "True" then copy data
to Output1 folder else output2 folder.
At run time this Output1/Output2 will be provided.

Parameter at pipeline level :- 
copytoOutput1 :- Default Value :- Yes
output1folder :- Default Value :- Output1
output2folder :- Default Value :- Output2

Since these parameter value we need to provide when pipeline will execute.If will not be provided
then by default value will be taken.

Create one dataset which will fetch data from input folder.
File Name :- data.txt

Now create 1 sink dataset but keep folder name dynamic.At run time folder name will be given.
So if copy needs to be done at Output1 folder then "parameter output1folder" will be used.
Similarly "parameter output2folder" for Output1 folder.


Source Dataset :- DS_uspstorageaccountnew_uspstagingcontainer_input_data
Sink Output1 Dataset :- DS_Output_If_Else /* Keep folder name dynamic */

Pipeline Name :- If_Else_Copy_Pipeline
Parameter :- 
copytoOutput1 :- Value :- True
output1folder :- VAlue :- Output1
output2folder :- VAlue :- Output2

Activity Name :- If_Else
Activities :- 
Expression :- /* Dynamic Content */ :- @bool(pipeline().parameters.copytoOutput1)
it is true then copy to Output1 folder And this folder name will come from parameter
output1folder/output2folder parameter value.

1st Copy Activity Name :- CopyToOutput1
2nd Copy Activity Name :- CopyToOutput2

Select folder name as "@pipeline().parameters.output1folder" dynamically.
Basically this value will come from parameter output1folder/output2folder as per activity.

/* Publish and run it */
/* Data.txt file got copied to Output1 folder as parameter copytoOutput1 is True */
Own Example :- Pipeline4 Using a variable x.If A then copy to output1 else do nothing.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=JVNt4unI06Y&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=36&ab_channel=WafaStudies */
/* 36. Wait Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
Wait Activity :- This activity allows a pipeline to to wait for certain period of time.
before executing next activity.
Here wait time we can define in seconds.
So if between two copy activity we have kept one "wait activity" then whatever 
wait time we have given,it will wait till that second then only next copy activity
will start.

Here at pipeline level we can define a parameter. and this parameter we can use as 
wait second inside "wait activity". 
This parameter value we need to pass during pipeline execution and same will
be assign to wait second.

Settings :- 
Wait time in second :- 5s

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=n8e_exWMH5k&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=37&ab_channel=WafaStudies */
/* 37. Until Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
Untill Activity :- This activity is similar to DO until or Do While activity
in programming languages.That means it is gurantee that at least one loop 
will definitely run as condition evaluation will happe at end of the loop.

This activity executes a set of activities in a looop untill the condition associated 
with the activity evalutes to "true".

Requirement :- Inside Storage at any moment of time a file data.txt can come.
We have to create a pipeline which will keep on checking the container.
Iff it is available then copy then copy data to output folder.
Else wait for 2 mins then again check whether file is availabel or not.

Activity Flow :- 
Untill Activity :- FIleexist variable :- False (By default)
Iff false then >>> Metadata Activity.
    Check existance of file.Iff present then make FIleexist variable = True.
    Else :- Wait Activity :- 2 mins
Iff FIleexist variable :- True >> Then copy file to output folder.


Pipeline Name :- UntillExistPipeline
Varibale :- IsFileExist :- False (By default)

Activity Name :- Until1
Properties :- Setting :- 
Expression :- @bool(variables('IsFileExist')) >> dynamic Expression
If it is true theen "Activity" tab will it will go.
Timeout :- 7 days (By default)
It will run till 7 days and still file didn’t come theen it will stop.
If file came theen also pipeline will stop.(Basic functionality of untill Activity)

Get Metadata Activity :- Get Metadata1
Source Dataset :- DS_uspstorageaccountnew_uspstagingcontainer_input_data
Filedlist >> Arguments >> Exist

If/Else Activity :- If Condition1
If File exist thhen set IsFileExist= true else wait for 2 ins.
Expression :- @bool(activity('Get Metadata1').output.exist) (Output of Get Metadata Activity)
/* Learn Azure Function */
If true :- 
Set Activity :- Set variable1 >> IsFileExist :- true
Else :- 
Wait Activity :- Wait1 >> 120 Sec

If file came the copy Activity (Existance of file will terminate until activity).
Copy Activity :- Copy data1
Source Dataset :- DS_uspstorageaccountnew_uspstagingcontainer_input_data
Sink Dataset :- DS_uspstorageaccountnew_uspstagingcontainer_output_data

/* Publish and Run it */
/* Getting error in if block.Solve it and complete it */
/* @bool(activity('Get Metadata1').output.exist) >> .exist was missing */
/* Now running fine. Data.txt got copied to output folder */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=rvIcklXCLVk&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=38&ab_channel=WafaStudies */
/* 38. Web Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
What is Rest API :- https://www.youtube.com/watch?v=madENMEfHLg

API is an URL which can do CRUD opration on database.And after each operation it will
send a response which will be in JSON format.
In UI if we need data from database theen through API it can be configured.
UI will call API and API will perform the operation on database and response/result will
be provided to UI.In technical term Client(UI) makes HTTP request to API.API will communicate to 
Database.Database provide required data to API.Theen API returns data to client(UI).

CRUD Operation :-
Operation       HTTP Method         Description
C :- Create     POST                Create/Insert Data
R :- Read       GET                 Reading/Retrieving Data
U :- Update     PUT/PATCH           Complete Update :- PUT, Partial Update :- PATCH
D :- Delete     DELETE              Deleting Data

Students API Resources :- 
http://geekyshows.com/api/students

GET Request :- 
i) GET:/api/students
Response :- It will be in JSON format.
[
{"id":1,"name":"abhi"},
{"id":2,"name":"kumar"}
]

ii) GET:/api/students/1
Response :- It will be in JSON format.
[
{"id":1,"name":"abhi"}
]

iii) Similar kind of request can also be made using POST/Patch/Delete request.


URL :- https://dummy.restapiexample.com/
Here some dummy rest API are present.Which we can use in our code for learning.

GET :- https://dummy.restapiexample.com/api/v1/employees
This API will give employee information in response which will be in JSON format.

Pipeline Name :- WebPipeline
Activity :- Web >>> WebActivity
General :- 
Settings :- 
URL :- :- https://dummy.restapiexample.com/api/v1/employee/1 :- REST API URL
Method :- GET
Datasets :- If dataset JSON is required as i/p to REST then select it. :- NA
Linked Services :- If Linked Services JSON is required as i/p to REST then select it. :- NA
Integration Runtime :- AutoResolve

/* Publish it and trigger it */
Go to monitor and see output for pipeline.
There response in the form of JSON is present.
https://dummy.restapiexample.com/api/v1/employees :- This API is failing while running pipeline.
https://dummy.restapiexample.com/api/v1/employee/1 :- This is running fine and o/p is
{
    "status": "success",
    "data": {
        "id": 1,
        "employee_name": "Tiger Nixon",
        "employee_salary": 320800,
        "employee_age": 61,
        "profile_image": ""
    },
    "message": "Successfully! Record has been fetched.",
    "ADFWebActivityResponseHeaders": {
        "Connection": "keep-alive",
        "Display": "staticcontent_sol, staticcontent_sol",
        "Host-Header": "c2hhcmVkLmJsdWVob3N0LmNvbQ==",
        "Referrer-Policy": "",
        "Response": "200",
        "Vary": "Accept-Encoding;Accept-Encoding;User-Agent;Origin",
        "X-Ezoic-Cdn": "Miss",
        "X-Middleton-Display": "staticcontent_sol, staticcontent_sol",
        "X-Middleton-Response": "200",
        "X-Ratelimit-Limit": "60",
        "X-Ratelimit-Remaining": "58",
        "X-Sol": "pub_site",
        "CF-Cache-Status": "DYNAMIC",
        "Expect-CT": "max-age=604800, report-uri=\"https://report-uri.cloudflare.com/cdn-cgi/beacon/expect-ct\"",
        "Report-To": "{\"endpoints\":[{\"url\":\"https:\\/\\/a.nel.cloudflare.com\\/report\\/v3?s=tYy3i%2B98gHvLOaGyxDtYzFfkJAM9BArhQ9M132TYoTanriSlGtbv88PUHacVn5ZuyJpYU5KnkKJckR7S6L%2FXBBIih734C8lNhravyYtvecr%2BNJc0REC8ciHLOk0PCOySYCB7MjHmgjQ0tGE%3D\"}],\"group\":\"cf-nel\",\"max_age\":604800}",
        "NEL": "{\"report_to\":\"cf-nel\",\"max_age\":604800}",
        "CF-RAY": "675bedc2ee695a33-IAD",
        "alt-svc": "h3-27=\":443\"; ma=86400, h3-28=\":443\"; ma=86400, h3-29=\":443\"; ma=86400, h3=\":443\"; ma=86400",
        "Cache-Control": "no-cache, max-age=31536000, private",
        "Date": "Wed, 28 Jul 2021 06:07:43 GMT",
        "Server": "cloudflare",
        "Content-Length": "179",
        "Content-Type": "application/json",
        "Expires": "Thu, 28 Jul 2022 06:07:42 GMT"
    },
    "effectiveIntegrationRuntime": "DefaultIntegrationRuntime (East US)",
    "executionDuration": 0,
    "durationInQueue": {
        "integrationRuntimeQueue": 10
    },
    "billingReference": {
        "activityType": "ExternalActivity",
        "billableDuration": [
            {
                "meterType": "AzureIR",
                "duration": 0.016666666666666666,
                "unit": "Hours"
            }
        ]
    }
}

Note :- 
We can also select POST method in make a request and data will be inserted into DB through API.

If API call requires linked service or Dataset theen we can also choose it.
So JSON of linked Services or Dataset will be passed.
/* Try to get some free API for share price and use it in web activity */
-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=XQExOQ3KLhg&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=39 */
/* 39. WebHook Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
/* This activity along with Azure Logic app can be used to send email in ADF */
/* Must complete it */

/* Related to web.Read it next time with requirement */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=-YwdbnEc_9Q&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=41&ab_channel=WafaStudies */
/* 40. Switch Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
Switch Activity :- It is similar to Switch statement which we use in programming language.
It evaluates a set of activities corresponding to a casee that matches a condition evalution.
/* Complete It */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=Jesb-nLXtQ4&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=42&ab_channel=WafaStudies */
/* 41. Validation Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
Validation Activity :- This activity is used to validate a pipeline to ensure the 
pipeline only continues execution once it has validated the attached dataset reference exists.

Since when we create any pipeline, we need to provide "datasets".
Datasets is linked to the actual files/tables etc.
While creating we provide these details.Suppose we have created datasets which is pointing
to a file data.txt.While creating data sets it was present but after that it got deleted.
Now when pipeline having this datasets will run then pipeline will fail because file is misisng.
To avoid this "Validation Activity" came into picture.
If we have kept this activity in the pipeline then first it will check the datasets and it’s
corresponding file/table then only pipeline will execute else it will not start.

In a single "Validation Activity" only one datasets can be verified.

Source Dataset :- DS_uspstorageaccountnew_uspstagingcontainer_input_data
Pipeline Name :- Validation_Activity_Pipeline
Activity Name :- Validation_Activity
Properties :- Settings :- 
Datasets :- DS_uspstorageaccountnew_uspstagingcontainer_input_data
/* This datsets is pointing to data.txt file inside input folder */
Timeout :- By default 7 days.It will be keep on checking the existance of file till this time.
Sleep :- by default 10 sec.If file is not present theen next attempt will be made after 10 sec.
Minimum Size :- By default value 0.Iff file exist and size is 0 still pass.
If we have defined minimum size as >0 and file is coming as blank theen it will consider
it as non existance of file.

If it is passed theen execute next activity.
If it fails theen from +arrow sign attach to web activity which will send email.(Depending upon requirement)

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=MWuWanhrNoU&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=42&ab_channel=WafaStudies */
/* 42. Lookup Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
Lookup Activity :- It is used to retrive a dataset/data from any of the ADF
supported data sources.
Lookup activity reads and retrun the content of a configuration file or table.
It also returns the result of executing a query or stored procedure.
The output from lookup activity can be used in a subsequent activity.

/* https://docs.microsoft.com/en-us/azure/data-factory/control-flow-lookup-activity */
/* Lookup activity in Azure Data Factory */

i) The Lookup activity can return up to 5000 rows; if the result set contains more records, 
the first 5000 rows will be returned.

ii) The Lookup activity output supports up to 4 MB in size, activity will fail 
if the size exceeds the limit.

iii) The longest duration for Lookup activity before timeout is 24 hours.

iv) When you use query or stored procedure to lookup data, make sure to return one 
and exact one result set(Only one column value). Otherwise, Lookup activity fails.

Property :- 
Settings :- 
Source Dataset :- Drop Down :- Select dataset. >>> Suppose DB dataset selected.
Use Query :- Radio Button :- i) Table ii) Query iii) Stored Procedure
If selected Radio button is i) Table >>> By default data will come from selected Dataset
If selected Radio button is ii) Query >>> Write down query as per req from dataset table.
If selected Radio button is iii) Stored Procedure >>> Drop Down >>> Choose Stored procedure

First Row Only :- Check/Uncheck

Isolation Level :- 
Partition Level :- 
/* Check usage of these property */



Output of Lookup activity will in the form of JSON.The lookup result is under a fixed firstRow key.
If we want to use the data then we need to extract the main value from JSON.

Example :- 
i) When firstRowOnly is set to true (default) :- 
JSON :- 
{
    "firstRow":
    {
        "Id": "1",
        "schema":"dbo",
        "table":"Table1"
    }
}

Extract Method :- @{activity('LookupActivity').output.firstRow.table}

ii) When firstRowOnly is set to false :- In this scenario there will be a "foreach" activity
associated just after lookup activity.
JSON :- 
{
    "count": "2",
    "value": [
        {
            "Id": "1",
            "schema":"dbo",
            "table":"Table1"
        },
        {
            "Id": "2",
            "schema":"dbo",
            "table":"Table2"
        }
    ]
}

count :- This fields indicates how many records are returned.
It will be present in the JSON at top.
Extract Method :- @{activity('lookupActivity').output.value[0].schema}
OR
@{activity('lookupActivity').output.value[1].table}

Entire Array :- @activity('lookupActivity').output.value >>> This can be passed to foreach activity.

Requirement :- We have a table T1 which is storing target folder name in one of it’s column.
We have a file in storage server.We need to copy that file to the destination folder
which is present in the databse.

Linked Service Name :- LS_OSELocal_SQL_DB_txdb_S33
Account Selection method :- Enter manually else parameter will not work.
Server Name 	:- osedbserverlocal.database.windows.net
Authentication 	:- SQL Server Authentication
UseName			:- adminuser
Password 		:- usP>>2021
DB Name         :- oselocaltxdb_S33

Table Name :- OutputFolderTable

CREATE TABLE [dbo].[OutputFolderTable](
	[id] [int] NOT NULL,
	[FolderName] Nvarchar(Max) NULL
)

INSERT INTO [dbo].[OutputFolderTable] values (1,'output1')
INSERT INTO [dbo].[OutputFolderTable] values (2,'output2')
INSERT INTO [dbo].[OutputFolderTable] values (3,'output3')

DB SQL Dataset :- DS_osedbserverlocal_txdb_S33_OutputFolderTable
Source file Storage Datasets :- DS_uspstorageaccountnew_uspstagingcontainer_input_data
/* It will point to data.txt file */

Target file storage Datasets :- DS_Output_Table 
/* It will point to uspstagingcontainer.Folder name will come from table :- @dataset().Folder */

Pipeline Name :- LookupPipeline
DB SQL Dataset :- DS_osedbserverlocal_txdb_S33_OutputFolderTable
Activity Name :- Lookup1
Properties :- Setting :- Select dataset from drop down.
Use Query :- 
i) Table :- All rows of the table mentioned in datsstes will be fetched.
ii) Query :- Explicitely we can write query to the table.So if table has 10 columns
but we need only 1 then query is useful.
iii) Stored Procedure :- Select procedure from dropdown.Whatever result will come 
from this will be stored in look up activity.

In this case we will use Query :- 
SELECT FolderName FROM [dbo].[OutputFolderTable]

fIRSTrowonly :- If yes then only one row will come.
                If No theen all row will come.
Select "No" :- Now all outputfolder name will come.
Will use "foreach activity" and iterate to folder name one by one and copy
data.txt file to destination folder.

Output of LookUp activity :- /* If First Row is selected */
{
    "firstRow": {
        "FolderName": "output1"
    },
    "effectiveIntegrationRuntime": "DefaultIntegrationRuntime (Southeast Asia)",
    "billingReference": {
        "activityType": "PipelineActivity",
        "billableDuration": [
            {
                "meterType": "AzureIR",
                "duration": 0.016666666666666666,
                "unit": "DIUHours"
            }
        ]
    },
    "durationInQueue": {
        "integrationRuntimeQueue": 0
    }
}

Since this output we need foreach activity.But foreach activity accepts Array as input.
So get the data and convert it to array using "arr" azure function.

/* Note :- Foreach always accepts input as Array */

ForEach Activity Name :- ForEach1
1) 
If onlyfirstrow is selected :- 
Settings :- 
items :- @array(activity('Lookup1').output.firstRow.FolderName)
/* Foreach accepts Array input  */


Copy Activity Name :- Copy data1
Sink Dataset :- For Folder Name :- @item() /* input to ForEach activity */

Each input inside foreach can be fetched using "@item()" keyword.

When onlyfirstrow is selected then able to read data from JSON and file data.txt got copied
into output1 folder.

2) If onlyfirstrow is not selected in lookup activity :- 
Here we will get multiple files in the JSON.So we need to read it in a different manner.
Output of Lookup activity :- 
{
    "count": 3,
    "value": [
        {
            "FolderName": "output1"
        },
        {
            "FolderName": "output2"
        },
        {
            "FolderName": "output3"
        }
    ],
    "effectiveIntegrationRuntime": "DefaultIntegrationRuntime (Southeast Asia)",
    "billingReference": {
        "activityType": "PipelineActivity",
        "billableDuration": [
            {
                "meterType": "AzureIR",
                "duration": 0.03333333333333333,
                "unit": "DIUHours"
            }
        ]
    },
    "durationInQueue": {
        "integrationRuntimeQueue": 0
    }
}

ForEach Activity :- 
Settings :- items :- @activity('Lookup1').output.value
/* This will give entire JSON as array */
/* Now we need to read its element FolderName */

Create a variable at pipeline level :- FileName
Inside foreach :- 
Activity Name :- Set Variable :- 
Variables :- 
Name :- FolderName
Value :- @item().FolderName /* This will give foldername as output1 then output2 then output3 */

Copy Activity :- Sink :- Folder Name :- @variables('FolderName')

/* Publish it and trigger it */
/* data.txt is getting copied at 3 places */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=wsQYuVT4Dpw&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=43 */
/* 43. Transform Data Activities Overview in Azure Data Factory */
-----------------------------------------------------------------------------------------
Transform Data Activity :- It is used to process and transform data in compute 
environments such as Azure data bricks or Azure HDInsight or azure datalake analytics.
Examples are :- Execute Data Flow Activity, Azure Function activity, Custom Activity,
Databricks Notebook Activity, Data Lake U-SQL Activity, Stored Procedure Activity etc..

Above discussed activity are called Control flow activity.
like filter activity, Getmetadata activity, if/else activity etc..

If we have any data flow activity or azure data bricks activity , we can execute it throgh pipeline.
Examples are :- 
i) Data Flow :- 
ii) Notebook :- 
iii) Python :- 
iv) U-SQL :- 
etc..
/* Try some examples */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=4Npu4F6dqMo&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=44&ab_channel=WafaStudiesWafaStudies */
/* 44. Stored Procedure Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
Stored Procedure Activity :- It is one of the transformation activity that ADF
supports.We run stored procedure as one of the step using this activity.

Requirement :- Write down a procedure which will take 5 i/p parameter.
Adf name, Pipeline name, pipeline status.
TAke one stored procedure activity inside a pipeline and run it to store all these details.

/* Complete it. Very Simple */

-----------------------------------------------------------------------------------------
/* Data Flow All Activity :-  */
-----------------------------------------------------------------------------------------
Data Flow Conclusion :- 
1) Multiple Inputs/Outputs :- 
i) New Branch :- 
ii) Join :- Inner, Left, Right
iii) Conditional Split :- This is similar to CASE statement.Give name for each condition.
It will make box for each condition in UI.Then add sink for each box (case condition).
iv) Exists :- Inside this EXISTS and NOt EXISTS both will be present.Same as SQL.
v) Union :- Same as SQL union.In a single union can select multiple sources for UNION operation.
vi) Lookup :- Similar to left outer join.select two sources and apply look up.

2) Schema Modifier :- 
i) Derived Column :- Derived Column Transformation is used to generate a new column or modify existing column data.
Lower name on ename column and comm+sal a new column.

ii) Select :- "Select" transformation is used to rename, drop or reorder columns.
It does not alter raw data but give us option to choose which we want to select.

iii) Aggregate :- MIN, MAX, SUM, COUNT, AVG etc.. of incoming rows.Only Group By and Aggreagte column will come in output.
	Select GROUP By column then select Aggregates Give alias of Aggregate columns and choose aggregate function over required column.

iv) Surrogate Key :- This transformation is used to add an incremental column in the data.
Suppose we are getting data like 3 column with value in each column.Now we want an additional
column "Id" which will be an incrementing column and can be considered as Primary Key.

v) Pivot :- 
vi) Unpivot :- 
vii) Window :- It is similar to OVER() PARTITION BY() Clause.These kind of value we can get from Window activity.

viii) Rank :- 
 
3) Formatters :- 
i) Flatten :- 
ii) Parse :- 
iii) 

4) ROW Modifier :- 
i) Filter :- Apply filter on incoming data like WHERE clause.
ii) Sort :- Same as ORDER By Clause.
iii) Alter Row :- Alter Row Transformation is used to set a policy when we want to insert, update, delete and upsert
record from a set of dataset to any database.
Here target sink must be a database in order to use Alter Row Transformation.
The way we are performing DML operation from one table to another table, same way here
we can also perform.

5) Destination :- 
i) Sink :- 

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=tdShbtu3shw&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=45&ab_channel=WafaStudiesWafaStudies */
/* 45. Data flow in Azure data factory */
-----------------------------------------------------------------------------------------
i) Data flow in ADF allows us to develope graphical data transformation logic that
can be executed as activities in ADF pipeline.

ii) Our data flow will execute on our own azure data bricks cluster for scaled out data
processing using spark.

iii) ADF internally handles all the code translation, spark optimization and 
execution of transformation.

Suppose we want to get data from 2 tables after joining.So we have to write SPArk or U-SQL
code.Then data from both the table will come.

Instead of it, using data flow we can create graphical representation of 2 tables as source 1 and source 2.
After that we can join using drag and drop.
This diagram we can save and later at pipeline level we can add "work flow activity"
and execute it.Here Azure will internally manage the code part.
Here data flow will be executed on our own Azure data bricks cluster using spark.
So converting graphical logic into Spark code will be done by Azure internally.

We can create a pipeline having "Data Flow" activity and add a new or existing data flow.
and run it.
/* Examples will be given in upcoming videos. */
There are two types of Data flow available in ADF :- 
i) Mapping Data flows :- 
ii) Wrangling Data flows :- 
/* Will be explained in upcoming videos */

/* Rest all videos in playlist is related to Data flows */
/* Can watch later on.But complete it */
/* Complete 45 to 73 video from playlist */
/* Started .... */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=HgcaPcBYXNI&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=46&ab_channel=WafaStudiesWafaStudies */
/* 46. Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
There are two types of Data flow available in ADF :- 
i) Mapping Data flows :- 
ii) Wrangling Data flows :- 

i) Mapping Data flows :- It is a visually designed data transformations in azure data factory.
Data flows allow data engineers to develope graphical data transformation logic without
writing code.
Here Azure will internally manage the code part.
Here data flow will be executed on our Azure data bricks cluster using spark.
So converting graphical logic into Spark code will be done by Azure internally.

Create 2 files :- 
i) Emp.csv
ii) dept.csv
Upload these file in the storage account.
Storage Account Name :- "uspstorageaccountnew"
ContainerName :- "uspstagingcontainer"
Using mapping data flow will join these two files on departmentid and get the result.
and store data into output folder inside result.csv file.

Linked Service :- LS_AzureStorage_uspstorageaccountnew
Source Dataset1 :- DS_uspstagingcontainer_Emp
Source Dataset2 :- DS_uspstagingcontainer_dept
Target Dataset :- DS_uspstagingcontainer_result

/* Create mapping data flow */
/* New Data Flow */
Name :- EmpDeptDataflow

Source1 :- 
Output Stream Name :- EmpData
Source Dataset :- DS_uspstagingcontainer_Emp

Source2 :- 
Output Stream Name :- deptData
Source Dataset :- DS_uspstagingcontainer_dept

Join :- 
Output Stream Name :- JoinEmpDept
Select right and left source and joining column

Output to file :- add + >> Sink
Output Stream Name :- OutputData
Target Dataset :- DS_uspstagingcontainer_result
Setting :- File Name option :- Output to single file.
File Name :- EmpDeptResult

Mapping :- Select all columns which we need in the file.
Uncheck auto mapping.

Data Preview :- Here using "data flow" radio button we can see for each activity what
will be the output.It will run on small set of input data.
Not doing as of now.

/* Publish all */ >> Run it using pipeline in next video.

/* Creating own table in SQL DB and trying to do same :-  */

DROP TABLE IF EXISTS DEPT;
CREATE TABLE DEPT(
DEPTNO INTEGER PRIMARY KEY,
DNAME VARCHAR(12),
LOC VARCHAR(10)
);

DROP TABLE if exists EMP;
CREATE TABLE EMP(
EMPNO INTEGER PRIMARY KEY,
ENAME VARCHAR(12) NOT NULL,
JOB VARCHAR(12),
MGR INTEGER ,
HIREDATE DATE,
SAL INTEGER ,
COMM INTEGER,
DEPTNO INTEGER
);

DROP TABLE if exists EMPDept;
CREATE TABLE EMPDept(
EMPNO INTEGER PRIMARY KEY,
ENAME VARCHAR(12) NOT NULL,
JOB VARCHAR(12),
MGR INTEGER ,
HIREDATE DATE,
SAL INTEGER ,
COMM INTEGER,
DEPTNO INTEGER,
DNAME VARCHAR(12),
LOC VARCHAR(10)
);


DELETE FROM dept;
insert into dept values(10, 'ACCOUNTING', 'NEW YORK');
insert into dept values(20, 'RESEARCH', 'DALLAS');
insert into dept values(30, 'SALES', 'CHICAGO');
insert into dept values(40, 'OPERATIONS', 'BOSTON');

DELETE FROM emp;
insert into emp values( 7839, 'KING', 'PRESIDENT', null, '17-NOV-1981', 5000, null, 10);
insert into emp values( 7698, 'BLAKE', 'MANAGER', 7839, '1-May-1981', 2850, null, 30);
insert into emp values( 7782, 'CLARK', 'MANAGER', 7839, '9-June-1981', 2450, null, 10);
insert into emp values( 7566, 'JONES', 'MANAGER', 7839, '2-Apr-1981', 2975, null, 20);
insert into emp values( 7788, 'SCOTT', 'ANALYST', 7566, '13-JUL-87', 3000, null, 20);
insert into emp values( 7902, 'FORD', 'ANALYST', 7566, '3-Dec-1981', 3000, null, 20);
insert into emp values( 7369, 'SMITH', 'CLERK', 7902, '17-Dec-1980', 800, null, 20);
insert into emp values( 7499, 'ALLEN', 'SALESMAN', 7698, '20-Feb-1981', 1600, 300, 30);
insert into emp values( 7521, 'WARD', 'SALESMAN', 7698, '22-Feb-1981', 1250, 500, 30);
insert into emp values( 7654, 'MARTIN', 'SALESMAN', 7698, '28-Sep-1981', 1250, 1400, 30);
insert into emp values( 7844, 'TURNER', 'SALESMAN', 7698, '8-Sep-1981', 1500, 0, 30);
insert into emp values( 7876, 'ADAMS', 'CLERK', 7788, '13-JUL-87', 1100, null, 20);
insert into emp values( 7900, 'JAMES', 'CLERK', 7698, '3-Dec-1981', 950, null, 30);
insert into emp values( 7934, 'MILLER', 'CLERK', 7782, '23-Jan-1982', 1300, null, 10);
 
SELECT * FROM EMP;
SELECT * FROM DEPT;

Create a new server./*osedbserverlocall.database.windows.net*/
While Creating new server :- 
Server name :- osedbserverlocall.database.windows.net
Server admin login :- adminuser
Password :- Pass@123

Data Factory Name :- MyTestFactoryashish
Linked Service Name :- LS_OSELocal_SQL_DB_txdb_S33
DataSet Name :- DS_EMP_S33
DataSet Name :- DS_DEPT_S33
DataSet Name :- DS_EMPDEPT_S33

Req :- Create a data flow of emp and dept table join and load data into a new table having additional 
deptname and location column.

/* Create mapping data flow */
/* New Data Flow */
Name :- EmpDeptDataflow
Source :- Emp and dept table
Join :- Inner join
Sink :- SQL database
Pipeline :- Call dataflow from pipeline
O/p :- Data got loaded into EMPDept table.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=FxkN1vctsB4&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=47&ab_channel=WafaStudiesWafaStudies */
/* 47. Data Flow Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
Pipiline Name :- RunDataFlow
Activity Name :- DataFlow
Data Flow Name :- EmpDeptDataflow

Setting :- 
Data flow :- EmpDeptDataflow
Run on (Azure IR) :- AutoResolveIntegrationRunTime
/* Select IR based on env.If everything is in Azure the AutoResolveIntegrationRunTime else create a new IR and select here */
Compute Type :- Select "General Purpose".Since this work flow is going to be executed on spark cluster.
So we need to select compute type./* Learn more on it on Azure Data bricks */

Core Count :- 4 + ( 4 Driver Core) /* by default */ :- Can  select 8 + ( 8 Driver Core) or 16 + ( 16 Driver Core)
Logging Level :- i) Verbose /* By Default selected */ ii) Basic iii) None
/* Check meaining of these properties */

Sink Properties :- 
Run in Parallel :- Check/Uncheck :- Uncheck
Continue After Sink Error :- Check/Uncheck :- Uncheck

Staging :- 
Staging Linked Service :- 
Staging Storage Folder :- 

Parameter :- If selected dataflow has any parameter then it will come here.

Publish All >> Trigger it
Ran succesfully and file got created.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=1MrnawEbO2U&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=48&ab_channel=WafaStudiesWafaStudies */
/* 48. Mapping Data Flow Debug Mode in Azure Data Factory */
-----------------------------------------------------------------------------------------
Azure data factory mapping provides a option to check how transformation is going to happen
in data flow without publishing it.While building only we can check it.

Turn on "Data Flow Debug" button which is present at the top of the design.
When it will be active it will ask for Integration Runtime.
A cluster having 4 + 4 cores with "General Computes" for 60 minutes
will become active.Inside this cluster logically data tranformation will happen.
This session will be closed once we turn off the "Data Flow Debug" button manually.

Data Flow Name :- EmpDeptDataflow
For each activity inside data flow diagram "Data Preview" tab is there.
then click on "Data Flow Debug".
If Green symbol is coming then we need to do refresh in "Data Preview" section.
/* Do it at sink last activity in Data Flow */
/* Data is coming fine in Debug Mode */

Beside Debug mode "Debug Setting" button is there.Here we can configure how many rows
we want from files else we can also provided a sample file path and run it using Debug mode.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=hpXePPFqJCs&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=49&ab_channel=WafaStudiesWafaStudies */
/* 49. Filter Transformation in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
The filter transformation allows row filtering based upon a condition.
It is similar to "WHERE" clause in SQL.

Requirement :- Create a data flow which will fetch only deptid=30 record from emp.csv and 
create a file and store in output folder having file name sales.csv.

Data Flow Name :- EmpSalesDataflow

Source1 :- 
Output Stream Name :- EmpData
Source Dataset :- DS_uspstagingcontainer_Emp

+ >> Row Modifier :- 
Output Stream Name :- GetSalesDeptdataFilter
Click on Filter On :- Open Expression builder
Expression :-  equals(deptno,'30') 


Output to file :- add + >> Sink
Output Stream Name :- OutputData
Target Dataset :- DS_uspstagingcontainer_result
Setting :- File Name option :- Output to single file.
File Name :- SalesEmp.csv

/* Publish All */
/* Create a pipeline to run EmpSalesDataflow data flow */
Pipiline Name :- RunEmpSalesDataflow
Activity Name :- DataFlow
Data Flow Name :- EmpSalesDataflow
/* Publish and trigger it */
/* File SalesEmp.csv generated successfully */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=-sxpg-6zgww&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=50&ab_channel=WafaStudiesWafaStudies */
/* 50. Aggregate Transformation in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=hq5BtHbATIc&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=51&ab_channel=WafaStudiesWafaStudies */
/* 51. JOIN Transformation in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
Aggregation of column values using :- MIN, MAX, SUM, COUNT, AVG etc..
Requirement :- Get count of employee under each department and store in a file.
Also also add deptname in the sink file.

Data Flow Name :- EmpCountDataflow

Source1 :- 
Output Stream Name :- EmpData
Source Dataset :- DS_uspstagingcontainer_Emp


+ >> Schema Modifier :- Aggregate
Output Stream Name :- Getempcount
Incoming Stream Name :- EmpData
Group By :- 
Columns :- deptno
Name As :- Deptno /* Will come in output */
/* Whatever will be in group by will be considered in SELECt clause query */

Aggregates :- 
Column :- TotalEmpCount /* Type by own */
Expression :- count(empno)

Source2 :- 
Output Stream Name :- deptData
Source Dataset :- DS_uspstagingcontainer_dept

+ >> join :- 
Output Stream Name :- Joindept
Left Stream :- Getempcount
Right Stream :- deptData
Joining column :- Deptno


Output to file :- add + >> Sink
Output Stream Name :- OutputData
Incoming Stream :- Getempcount
Target Dataset :- DS_uspstagingcontainer_result
Setting :- File Name option :- Output to single file.
File Name :- EmpCount.csv

/* Publish All */
/* Create a pipeline to run EmpCountDataflow data flow */
Pipiline Name :- RunEmpCountDataflow
Activity Name :- DataFlow
Data Flow Name :- EmpCountDataflow
/* Publish and trigger it */

/* File EmpCount.csv generated successfully */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=20iyvIrW7mg&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=52&ab_channel=WafaStudiesWafaStudies */
/* 52. Conditional Split Transformation in Mapping Data Flow in Azure data factory */
-----------------------------------------------------------------------------------------
The conditional split transformation routes data rows to different streams based on matching
condition.The conditional split transformation is similar to a "CASE" decision structure
in a programming language.

Requirement :- Since we have 3 deptno 10,20 and 30.
Get data from this file and split it into 3 separate files and if any new deptno
is coming then keep it as others.csv file.

Data Flow Name :- ConditionalSplitDataflow

Source1 :- 
Output Stream Name :- EmpData
Source Dataset :- DS_uspstagingcontainer_Emp

+ >> ConditionalSplit
Output Stream Name :- SplitOnDeptno
Incoming Stream :- EmpData

Split On :- i) First matching Condition (By default selected radio button) ii) All Matching Condition

Split Condition :- 
Stream Name :- SalesEmp
Condition :- Open expression builder >>> equals(deptno,'10')

Stream Name :- ResearchEmp
Condition :- Open expression builder >>> equals(deptno,'20')

Stream Name :- AccountingEmp
Condition :- Open expression builder >>> equals(deptno,'30')

If no condition Matches :- 
Stream Name :- OtherEmp

/* Now create sink for newly created 4 activities. */


Output to file :- add + >> Sink
Output Stream Name :- OutputData
Incoming Stream :- SalesEmp
Incoming Stream :- ResearchEmp
Incoming Stream :- AccountingEmp
Incoming Stream :- OtherEmp
Target Dataset :- DS_uspstagingcontainer_result
Setting :- File Name option :- Output to single file.
File Name :- SalesEmployee.csv,ResearchEmployee.csv,AccountingEmployee.csv,OtherEmployee.csv

/* Publish All */
/* Create a pipeline to run ConditionalSplitDataflow data flow */
Pipiline Name :- RunConditionalSplitDataflow
Activity Name :- DataFlow
Data Flow Name :- ConditionalSplitDataflow
/* Publish and trigger it */

SalesEmployee.csv,ResearchEmployee.csv,AccountingEmployee.csv,OtherEmployee.csv
Files generated successfully.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=a5KClu7LboQ&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=53&ab_channel=WafaStudiesWafaStudies */
/* 53. Derived Column Transformation in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
Derived Column Transformation is used to generate a new column or modify existing fields.

Req1 :- Since ename is in uppercase.Get data in lower case.So here we will modify
existing column.
Req2 :- comm IS NULL and create a new column having name NewComm and make it 0 if it is null..


Data Flow Name :- DerivedColumnDataflow

Source1 :- 
Output Stream Name :- EmpData
Source Dataset :- DS_uspstagingcontainer_Emp

+ >> SchemaModifier >>> DerivedColumn
Output Stream Name :- lowerename
Incoming Stream :- EmpData
Column  :- Ename
Expression :- lower(ENAME)

+ >> SchemaModifier >>> DerivedColumn
Output Stream Name :- NewComm
Incoming Stream :- lowerename
Column :- NewSal
Expression :- SAL + COMM /* If Comm is null then newSal will also be null.Handle this using function insisde expression */

Add a Sink data set and create a pipeline to run it.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=wWIiIxf4ME4&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=59 */
/* 59. Select Transformation in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
"Select" transformation is used to rename the column name, drop any column from output
or reorder columns.It does not alter raw data but give us option to choose which we want to select.

From + sign add "select" transformation.

Name :- EmpselectDataflow

Source1 :- 
Output Stream Name :- EmpData
Source Dataset :- DS_uspstagingcontainer_Emp

+  >>> Schema Modifier >>> select
Output Stream Name :- select
Incoming Stream :- EmpData
Options :- Skip duplicate input columns :- By default Check
    Skip duplicate output columns :- By default Check

Input Columns :- 
Keep Auto Mapping Off then all column mapping will display and from here we can rename the column name
or reorder the column sequence or delete any column from output.

Output to file :- add + >> Sink
Output Stream Name :- OutputData
Incoming Stream :- select
Target Dataset :- DS_uspstagingcontainer_result
Setting :- File Name option :- Output to single file.
File Name :- Empselect.csv

/* Create a pipeline to run EmpselectDataflow data flow */
Pipiline Name :- RunEmpselectDataflow
Activity Name :- DataFlow
Data Flow Name :- EmpselectDataflow
/* Publish and trigger it */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=eIcx2_Gnmkw&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=54&ab_channel=WafaStudiesWafaStudies */
/* 54. Exists Transformation in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
Req1 :- Print only those employee details whose deptno is present in dept.csv file.

/* Req 2 :- Print that dept info for which no employee is there i.e. no data in emp.csv file. */
/* Implement it later on */

Name :- EmpDeptExistDataflow

Source1 :- 
Output Stream Name :- EmpData
Source Dataset :- DS_uspstagingcontainer_Emp

Source2 :- 
Output Stream Name :- deptData
Source Dataset :- DS_uspstagingcontainer_dept

+ >>> Multiple Inputs/Outputs >>> Exist
Output Stream Name :- Exists
Left Stream :- EmpData
Right Stream :- deptData
Exist Type :- Exists
Custom Expression :- If checked then we can right our own query. /* Check on this */
Exists Condition :- 
Left: EMPDB’s column	:- Deptno
Right: DeptDb’s column :- Deptno

Optimize :- 
Broadcast :- i) Auto /* By default radio button selected */ ii) Fixed iii) Off

Output of exist will be columns from Left Stream :- EmpData only.
Simply it will work like Inner join.
/* Note :- select Exist Type as "Not Exists" and perform the operation */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=vFCNbHqWct8&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=55&ab_channel=WafaStudies */
/* 55. Union Transformation in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
It is same as SQL Union.
Req :- Get data from two table and store in a file in ADLS gen 2.

DROP TABLE if exists EMP2;
CREATE TABLE EMP2(
EMPNO INTEGER PRIMARY KEY,
ENAME VARCHAR(12) NOT NULL,
JOB VARCHAR(12),
MGR INTEGER ,
HIREDATE DATE,
SAL INTEGER ,
COMM INTEGER,
DEPTNO INTEGER
);

DELETE FROM emp2;
insert into emp2 values( 78391, 'KING', 'PRESIDENT', null, '17-NOV-1981', 5000, null, 10);
insert into emp2 values( 76982, 'BLAKE', 'MANAGER', 7839, '1-May-1981', 2850, null, 30);
insert into emp2 values( 77823, 'CLARK', 'MANAGER', 7839, '9-June-1981', 2450, null, 10);
insert into emp2 values( 75664, 'JONES', 'MANAGER', 7839, '2-Apr-1981', 2975, null, 20);
insert into emp2 values( 77885, 'SCOTT', 'ANALYST', 7566, '13-JUL-87', 3000, null, 20);
insert into emp2 values( 79026, 'FORD', 'ANALYST', 7566, '3-Dec-1981', 3000, null, 20);
insert into emp2 values( 73697, 'SMITH', 'CLERK', 7902, '17-Dec-1980', 800, null, 20);
insert into emp2 values( 74998, 'ALLEN', 'SALESMAN', 7698, '20-Feb-1981', 1600, 300, 30);
insert into emp2 values( 75219, 'WARD', 'SALESMAN', 7698, '22-Feb-1981', 1250, 500, 30);
insert into emp2 values( 76541, 'MARTIN', 'SALESMAN', 7698, '28-Sep-1981', 1250, 1400, 30);
insert into emp2 values( 78442, 'TURNER', 'SALESMAN', 7698, '8-Sep-1981', 1500, 0, 30);
insert into emp2 values( 78763, 'ADAMS', 'CLERK', 7788, '13-JUL-87', 1100, null, 20);
insert into emp2 values( 79004, 'JAMES', 'CLERK', 7698, '3-Dec-1981', 950, null, 30);
insert into emp2 values( 79345, 'MILLER', 'CLERK', 7782, '23-Jan-1982', 1300, null, 10);
 

SELECT All sources on which we want to perform UNION operation.
Select UNION activity and choose all sources for UNION operation.

/* Very Simple */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=Z4xfVDYbNNE&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=56&ab_channel=WafaStudiesWafaStudies */
/* 56. Lookup Transformation in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
Similar to left outer join.
select two sources.Then apply LookUp.

Source1 :- EMP Table
Source2 :- Dept Table
Lookup Setting :- 
Primary stream :- Dept Table
Lookup Stream :- EMP Table
Match Multiple Rows :- By default Not checked /* Check what is this */
Match On :- i) Any Row (By default selected Radio button) ii) First Row iii) Last Row
Lookup Condition :- Left(Deptno) & Right(Deptno)

add a sink :- 
Output will contain all data from dept table and wherver deptno is not matching Null will be present in output.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=XyLVCH-v1Ag&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=57&ab_channel=WafaStudiesWafaStudies */
/* 57. Sort Transformation in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
It is same as Order by clause.Select a source and add Sort activity.
Output Stream Name :- SortEmpData
Incoming Stream Name :- EmpData
Options :- i) Case insensitive ii) Sort only within partition :- Check box :- Selected as per requirement

Sort Conditions :- 
Exists Column :- EMPNO :- /* Select any column from drop down */
Order :- Ascending/Descending :- By default Ascending
Nulls First :- 

O/P :- Will give all columns and data will sorted on selected column.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=tU44UB7cqwk&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=58&ab_channel=WafaStudiesWafaStudies */
/* 58. New Branch in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
If we want to do multiple sets of operation and transformation against the same
data source then we need to use "New Branch".
It is useful when we want to use the same source for multiple sinks.

Req1 :- Get count of employee for each deptno in a file.
Req2 :- Get join of data between emp and dept and get dname from dept source for each row.

So here in both the requirement emp.csv file is required.So instead of creating
emp.csv file as source two times we can create a branch from 1st source emp.csv file
and can use it for other purpose.

Source 1 >>> + >>> New branch

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=ozQYffvt2aI&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=60 */
/* 60. Pivot Transformation in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
Pivot :- Converting column values into column.

Watch till 65 :-

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=UquN1EVaGaM&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=63&ab_channel=WafaStudies */
/* 62. Surrogate Key Transformation in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
This transformation is used to add an incremental column in the data.
Suppose we are getting data like 3 column with value in each column.Now we want an additional
column "Id" which will be an incrementing column and can be considered as Primary Key.

Req :- Add an incremental column in EMP table and store data into a CSV file in ADLSGEN 2.

Data Flow NAme :- SurrogateKeyDF
Output Stream Name :- EmpData
Source Dataset :- DS_uspstagingcontainer_Emp

+  >>> Schema Modifier >>> Surrogate Key
Output Stream Name :- SurrogateKey
Incoming Stream :- EmpData
Key Column :- EMPKey /* New column name */
Start Value :- 1

/* It will add an extra column "EMPKey" and value will start from 1 & will be incremented by 1. It will come
at last column.But we will use select transformation to get column "EMPKey" at first column */

+  >>> Schema Modifier >>> SELECT
Output Stream Name :- SELECT
Incoming Stream :- SurrogateKey

Output to file :- add + >> Sink
Output Stream Name :- OutputData
Incoming Stream :- SELECT
Target Dataset :- LS_ADLS_GEN2
Setting :- File Name option :- Output to single file.
File Name :- EMPSurrogateKey.csv

/* Create a pipeline and run this dataflow */

File data in ADLS Gen2 container :- 
EMPKey,EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO
1,7369,SMITH,CLERK,7902,1980-12-17,800,,20
2,7499,ALLEN,SALESMAN,7698,1981-02-20,1600,300,30
3,7521,WARD,SALESMAN,7698,1981-02-22,1250,500,30
4,7566,JONES,MANAGER,7839,1981-04-02,2975,,20
5,7654,MARTIN,SALESMAN,7698,1981-09-28,1250,1400,30
6,7698,BLAKE,MANAGER,7839,1981-05-01,2850,,30
7,7782,CLARK,MANAGER,7839,1981-06-09,2450,,10
8,7788,SCOTT,ANALYST,7566,1987-07-13,3000,,20
9,7839,KING,PRESIDENT,,1981-11-17,5000,,10
10,7844,TURNER,SALESMAN,7698,1981-09-08,1500,0,30
11,7876,ADAMS,CLERK,7788,1987-07-13,1100,,20
12,7900,JAMES,CLERK,7698,1981-12-03,950,,30
13,7902,FORD,ANALYST,7566,1981-12-03,3000,,20
14,7934,MILLER,CLERK,7782,1982-01-23,1300,,10


-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=EMWa8XsmKok&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=63&ab_channel=WafaStudies */
/* 63. Window Transformation in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
It is similar to OVER() PARTITION BY() Clause.

Req1 :- Get sum of salary for each department number along with other columns.
select *,Sum() over(partition by deptno)

Req2 :- Get rank of employee on each dept using dense rank.

Req1 & Req2:- 
Data Flow NAme :- WindowDF

Output Stream Name :- EmpData
Source Dataset :- DS_uspstagingcontainer_Emp


+  >>> Schema Modifier >>> Window
Output Stream Name :- SumSal
Incoming Stream :- EmpData
Windows Settings :- 
Over :- /* Same As SQL */
SurrogateKey1’s column :- DEPTNO
Name As :- DEPTNO

Sort :- /* For Req1 it is not required */
SurrogateKey1’s column :- DEPTNO
Order :- Ascending/Descending :- By default Ascending
Nulls First :- Checked /* By Default */

Range By :- 
Unbounded :- Checked /* By default */
Window Columns :-
Column :- SumSal    /* Type by own column name for window function output like rnk etc.. */
Expression :-   sum(SAL)


Create a NEW Branch from EMP table for Req2.
+  >>> Schema Modifier >>> Window
Output Stream Name :- DenseRAnk
Incoming Stream :- EmpData
Windows Settings :- 
Over :- Not required for Req2
Sort :- Sal Desc
Range By :- By defauly Unbounded (Checked)
Window Columns :- Column :- RAnk
                  Expression :-   

Output to file :- add + >> Sink
Output Stream Name :- DenseRankOutput
Incoming Stream :- DenseRAnk
Target Dataset :- LS_ADLS_GEN2
Setting :- File Name option :- Output to single file.
File Name :- DenseRankOutput.csv


Output to file :- add + >> Sink
Output Stream Name :- SumSalSink
Incoming Stream :- SumSal
Target Dataset :- LS_ADLS_GEN2
Setting :- File Name option :- Output to single file.
File Name :- SumSalOutput.csv

/* Create a pipeline and run this dataflow */
EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO,SumSal
7369,SMITH,CLERK,7902,1980-12-17,800,,20,10875
7566,JONES,MANAGER,7839,1981-04-02,2975,,20,10875
7788,SCOTT,ANALYST,7566,1987-07-13,3000,,20,10875
7876,ADAMS,CLERK,7788,1987-07-13,1100,,20,10875
7902,FORD,ANALYST,7566,1981-12-03,3000,,20,10875
7782,CLARK,MANAGER,7839,1981-06-09,2450,,10,8750
7839,KING,PRESIDENT,,1981-11-17,5000,,10,8750
7934,MILLER,CLERK,7782,1982-01-23,1300,,10,8750
7499,ALLEN,SALESMAN,7698,1981-02-20,1600,300,30,9400
7521,WARD,SALESMAN,7698,1981-02-22,1250,500,30,9400
7654,MARTIN,SALESMAN,7698,1981-09-28,1250,1400,30,9400
7698,BLAKE,MANAGER,7839,1981-05-01,2850,,30,9400
7844,TURNER,SALESMAN,7698,1981-09-08,1500,0,30,9400
7900,JAMES,CLERK,7698,1981-12-03,950,,30,9400


EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO,RAnk
7839,KING,PRESIDENT,,1981-11-17,5000,,10,1
7788,SCOTT,ANALYST,7566,1987-07-13,3000,,20,2
7902,FORD,ANALYST,7566,1981-12-03,3000,,20,2
7566,JONES,MANAGER,7839,1981-04-02,2975,,20,3
7698,BLAKE,MANAGER,7839,1981-05-01,2850,,30,4
7782,CLARK,MANAGER,7839,1981-06-09,2450,,10,5
7499,ALLEN,SALESMAN,7698,1981-02-20,1600,300,30,6
7844,TURNER,SALESMAN,7698,1981-09-08,1500,0,30,7
7934,MILLER,CLERK,7782,1982-01-23,1300,,10,8
7521,WARD,SALESMAN,7698,1981-02-22,1250,500,30,9
7654,MARTIN,SALESMAN,7698,1981-09-28,1250,1400,30,9
7876,ADAMS,CLERK,7788,1987-07-13,1100,,20,10
7900,JAMES,CLERK,7698,1981-12-03,950,,30,11
7369,SMITH,CLERK,7902,1980-12-17,800,,20,12

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=12Bt9N5lODA&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=64&ab_channel=WafaStudies */
/* 64. Alter Row Transformation in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
Alter Row Transformation is used to set a policy when we want to insert, update, delete and upsert
record from a set of dataset to any database.
Here target sink must be a database in order to use Alter Row Transformation.
The way we are performing DML operation from one table to another table, same way here
we can also perform.

Req :- We have data in EMP table.Perform DML operation on EMP2 table.
If new record are there insert it.If records are matching update it.


DROP TABLE if exists EMP2;
CREATE TABLE EMP2(
EMPNO INTEGER PRIMARY KEY,
ENAME VARCHAR(12) NOT NULL,
JOB VARCHAR(12),
MGR INTEGER ,
HIREDATE DATE,
SAL INTEGER ,
COMM INTEGER,
DEPTNO INTEGER
);

DELETE FROM emp2;
insert into emp2 values( 78391, 'ABC', 'PRESIDENT', null, '17-NOV-1981', 502300, 12, 10);
insert into emp2 values( 76982, 'BLAKE', 'MANAGER', 7839, '1-May-1981', 2850, null, 30);

DataFlow Name :- AlterRowTransformationDF
Output Stream Name :- EmpData
Source Dataset :- DS_uspstagingcontainer_Emp

+  >>> Schema Modifier >>> Alter Row
Alter Row Setting :- 
Output Stream Name :- AlterRow
Incoming Stream :- EmpData
Alter row conditions :- Drop Down :- Insert If/Update If/Delete If/Upsert If
Delete If :- Give a condition.If condition is satisfying then those record will not be inserted
into target table.From transformation result condition satisfying result will be deleted.

Update If :- If data is already inserted.Then if matching with specified column name then rest other 
column will be updated.

Insert If :- /* Check it */

Upsert If :- /* Check it */

/* Complete it */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=zrjYg2_2Y9I&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=65&ab_channel=WafaStudies */
/* 65. Flatten Transformation in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
This transformation is used to get rows from JSON array.If inside JSON value one field has
array values then we can split that value into two rows using Flatten Transformation.



 





-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=6rKZ7Om1gKo&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=66 */
/* 66. Parameterize Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
Req :- We need to get employee details for any particular departmentid.
So we need to create a dynamic workflow which will accept deptno as an input while executing
the dataflow.

Data Flow Sample :- 
Name :- EmpparametirizedDataflow

Source1 :- 
Output Stream Name :- EmpData
Source Dataset :- DS_uspstagingcontainer_Emp

+  >>> Row Modifier >>> Filter
Output Stream Name :- filter
Incoming Stream :- EmpData
Filter On :- Open expression builder >>> All >> Create New >> PArameters.
Name :- inputdeptno
Column :- deptno
Expression :- deptno == $inputdeptno


Output to file :- add + >> Sink
Output Stream Name :- OutputData
Incoming Stream :- filter
Target Dataset :- DS_uspstagingcontainer_result
Setting :- File Name option :- Output to single file.
File Name :- Empparameterfilter.csv


/* Create a pipeline to run EmpparametirizedDataflow data flow */
Pipiline Name :- RunEmpparametirizedDataflow
Activity Name :- DataFlow
Data Flow Name :- EmpparametirizedDataflow

Here create one more parameter at pipeline level and assign this value to the parameter
coming from dataflow./* Do revision on parameter */
Parameter >>> New >>> NAme = pipedept
At activity Level :- Parameters >> Value >> @pipeline().parameters.pipedept


/* Publish and trigger it.It will ask for deptno.Give any value among 10,20,30 and get 
output file  */


-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=dhbLDX02f10&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=67 */
/* 67. Validate Schema in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
Validate schema option in source will look for the schema in source.
If it finds any changes in the schema then it will make data flow to fail.

Req :- If we have created a data flow and it is running fine but at data source
if there is any change happen then entire data flow should change.


Data flow Name :- EmpDeptDataflow

Source1 :- 
Output Stream Name :- EmpData
Source Dataset :- DS_uspstagingcontainer_Emp

Source2 :- 
Output Stream Name :- deptData
Source Dataset :- DS_uspstagingcontainer_dept
Source Settings :- Options :- Uncheck :- All Schema Drift (Will see what is this)
Check :- Validate Schema

Join :- 
Output Stream Name :- JoinEmpDept
Select right and left source and joining column

Output to file :- add + >> Sink
Output Stream Name :- OutputData
Target Dataset :- DS_uspstagingcontainer_result
Setting :- File Name option :- Output to single file.
File Name :- EmpDeptResult

Pipiline Name :- RunDataFlow
Activity Name :- DataFlow
Data Flow Name :- EmpDeptDataflow

/* Run It */
Now make chnages in DS_uspstagingcontainer_Emp data set.
means remove a column from emp.csv file and run it again.Pipeline should fail.


-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=LS0u7DxhpDI&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=68 */
/* 68. Schema Drift in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
Schema drift is the case where fields, columns and types on the file can be chnaged on the
fly and our data flow should be smart enough to handle it.
If we have not handle it then data flow will become vulnerable to upstream data source
and we may get wrong data at sink.

Suppose we have a file where we have 4 columns c1, c2, c3 & c4.
When it will be fetched all these columns will go as it is .

/* Allow Drift Scheme */
Suppose column c3 got deleted.
If "Allow Drift Scheme" >>> Not Checked Then
Then at sink c4 column will shift to c2 column and c4 will become Null.

If "Allow Drift Scheme" >>> Checked Then
Theen at sink c3 will be null and c4 will have value which is correct.So
here schema drftingg is happenly properly.

/* Infer Drifted Column Types */
Suppose column c3 got deleted and a new column c5 has been added.
If "Allow Drift Scheme" >>> checked and "Infer Drifted Column Types" >>> not checked then
at sink c3 will come as null and c5 will also come.
and for c5 data type will be "String" as data is coming from a csv file.

Suppose column c3 got deleted and a new column c5 has been added.
If "Allow Drift Scheme" >>> checked and "Infer Drifted Column Types" >> checked theen
at sink c3 will come as null and c5 will also come.
and for c5 data type will be "Integer" if c5 contains only integer values.

/* Check will validation work if drift and validation both are checked */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=07Mq0rU9dtM&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=69&ab_channel=WafaStudiesWafaStudies */
/* 69. Wrangling Data Flow Overview in Azure Data Factory */
-----------------------------------------------------------------------------------------
Wrangling Data Flow :- It allow us to do code free data preparation at cloud scale.
It uses industry leading power query thechnology like excel.
Data preparation logic defined in wrangling data flows will get translated into spark
and run in Big data clusters.

We can use Wrangling data flows as one of the step inside ADF pipeline using Dataflow activity.

Power Query (Preview) :- New Power Query

/* Complete it.If requirement is coming */

70,71

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=4E98C4Pdip8&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=72&ab_channel=WafaStudiesWafaStudies */
/* 72. Different Author Modes in Azure Data Factory */
-----------------------------------------------------------------------------------------
Different Author Modes in ADF :- 
i) Data Factory (By Default)
ii) Set Up Code Repositiry (Need to connect with GIT)


-----------------------------------------------------------------------------------------
https://www.youtube.com/watch?v=5SEL-XIlzso&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=73&ab_channel=WafaStudiesWafaStudies
/* 73. Setup GitHub Code Repository for Azure Data Factory */
-----------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=9BawMq0CVbs&ab_channel=WafaStudies */
/* 75. Use Azure Key Vault Secrets in Azure Data Factory */
-----------------------------------------------------------------------------------------
/* Same Kind of link :-  */
/* https://www.youtube.com/watch?v=PgujSug1ZbI&ab_channel=AdamMarczak-AzureforEveryone */
/* Azure Key Vault Tutorial | Secure secrets, keys and certificates easily */

Req :- Create Keyvault and use it in Azure Data Factory.
Fetch emp.csv file from blob input data storage and copy to output folder.

Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Storage Account Name :- "uspstorageaccountnew"
ContainerName :- "uspstagingcontainer"


Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Key vault name :- uspdemokeyvault
Vault URI/DNS Name :- https://uspdemokeyvault.vault.azure.net/

Data Factory Directly can not connect to KeyVault.It requires access from KeyVault.
/* How to give access to Data Factory. */
Data Factory Name :- uspstorageadf.

uspdemokeyvault >>> Access Policy :- 
Key Permission :- Select All
Secret Permission :- Select All
Certificate Permission :- Select All
Select Principle :- /* Data Factory Name */ :- uspstorageadf
Select >>> Add >> Save


Create a Linked Service :- 
1) First create a Azure KeyVault Linked Service.
+ New :- Select Azure Key Vault :- Continue
Name :- LS_MyKv
Azure Subscription :- ES-LOB-USP-DEV
Azure KeyVault Name :- uspdemokeyvault

2) Get Connection string of Storage Account :- 
Storage Account :- uspstorageaccountnew
Access Keys :- (Security & Networking)
Key 1 >> Connection Strings :- 
DefaultEndpointsProtocol=https;AccountName=uspstorageaccountnew;AccountKey=gp0XnD19MdVHZdDUYBZdz5yjsxafV9HEFibsX+C1Ncqkc3JFrrEbO0HSJO+4InfRRZSpdN5leBH6EnO4MCg1Pw==;EndpointSuffix=core.windows.net
/* Copy This */

3) Generate a secret of this Connection string :- 
uspdemokeyvault :- Go to "secrets"(Below settings).
Generate/Import :- 
Upload Options :- Manual/Certificate >>> Manual
Name :- Storageuspstorageaccountnew /* Secret Name */
Value :- /* Connection Strings */ :- DefaultEndpointsProtocol=https;AccountName=uspstorageaccountnew;AccountKey=gp0XnD19MdVHZdDUYBZdz5yjsxafV9HEFibsX+C1Ncqkc3JFrrEbO0HSJO+4InfRRZSpdN5leBH6EnO4MCg1Pw==;EndpointSuffix=core.windows.net
Type :- (Optional)
Enabled :- Yes
>>> Create

4) Create a main Linked Service which will point to storage account using KeyVault.
+ New :- Select Azure table storage :- Continue
Name :- LS_MyKv_Storageuspstorageaccountnew
AKV Linked Service :- LS_MyKv
Secret Name :- /* Created in last step */ :- Storageuspstorageaccountnew
Secret Version :- By Default latest version

5) Create a dataset using linked service :- LS_MyKv_Storageuspstorageaccountnew
Dataset Name :- DS_input_emp
Linked Service Name :- LS_MyKv_Storageuspstorageaccountnew
File path :- uspstagingcontainer/input/Emp.csv

6) Create Copy ADF .

Conclusion :- 
1) Grant access to ADF from azure keyvault.(Must)
i) First create a keyvault linked service.
ii) Go to Keyvault and create the secret. (Get/Create Connection string for Source)
iii) Create a new linked Service and select newly created keyvault and secret.
iv) Create a dataset using newly created linkedservice.

integrated security=False;encrypt=True;connection timeout=30;data source=uspstagingdbserverdev.database.windows.net;initial catalog=uspstagingtxdbdev;user id=adminuser;Password=Pass@123;

Own :- 
----------------
Req :- Create a secret for Local DB connection string and then create a keyvalut linked 
service.
1) Generate a secret of Connection string for DB:- 
Server Type 	:- Database Engine
Server Name 	:- osedbserverlocal.database.windows.net
Authentication 	:- SQL Server Authentication
Login			:- adminuser
Password 		:- usP>>2021
DataBase Name   :- oselocaltxdb_S34

Connection String :- /* Manually formed.Always use this string for DB connection string. */
integrated security=False;encrypt=True;connection timeout=30;data source=osedbserverlocal.database.windows.net;initial catalog=oselocaltxdb_S34;user id=adminuser;Password=usP>>2021;

uspdemokeyvault :- Go to "secrets"(Below settings).
Generate/Import :- 
Upload Options :- Manual/Certificate >>> Manual
Name :- LocalDB1 /* Secret Name */
Value :- /* Connection Strings */ :- integrated security=False;encrypt=True;connection timeout=30;data source=osedbserverlocal.database.windows.net;initial catalog=oselocaltxdb_S34;user id=adminuser;Password=usP>>2021;
Type :- (Optional)
Enabled :- Yes
>>> Create

2) Create a Azure KeyVault Linked Service. /* Already Created */
+ New :- Select Azure Key Vault :- Continue
Name :- LS_MyKv
Azure Subscription :- ES-LOB-USP-DEV
Azure KeyVault Name :- uspdemokeyvault

3) Create a main Linked Service which will point to DB account using KeyVault.
Linked Service Name :- LS_MyKv_LocalDB
Secret Name :- LocalDB1
Authentication Type :- SQL Authentication or Managed Identity

Test Connection :- 
Cannot connect to SQL Database: 'osedbserverlocal.database.windows.net', Database: 'oselocaltxdb_S34', User: 'adminuser'. Check the linked service configuration is correct, and make sure the SQL Database firewall allows the integration runtime to access. Database 'oselocaltxdb_S34' on server 'osedbserverlocal.database.windows.net' is not currently available. Please retry the connection later. If the problem persists, contact customer support, and provide them the session tracing ID of '{8C028428-338B-4CAD-9661-674AE71C0755}'., SqlErrorNumber=40613,Class=20,State=1, Activity ID: de0244a1-ccf1-47f3-8024-ebd8d3db2bc4.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=2XfUKWwDi3g&ab_channel=WafaStudies */
/* 77. How to read JSON output of one Activity in to another Activity in Azure Data Factory */
-----------------------------------------------------------------------------------------
Completed in :- 
/* https://www.youtube.com/watch?v=MWuWanhrNoU&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=42&ab_channel=WafaStudies */
/* 42. Lookup Activity in Azure Data Factory */

Reading data from table and getting data as json and reading through foreach activity.


Lookup Activity :- It is used to retrive a dataset/data from any of the ADF
supported data sources.
Lookup activity reads and retrun the content of a configuration file or table.
It also returns the result of executing a query or stored procedure.
The output from lookup activity can be used in a subsequent activity.

/* https://docs.microsoft.com/en-us/azure/data-factory/control-flow-lookup-activity */
/* Lookup activity in Azure Data Factory */

Requirement :- We have a table T1 which is storing target folder name in one of it’s column.
We have a file in storage server.We need to copy that file to the destination folder
which is presnet in the databse.

Linked Service Name :- LS_OSELocal_SQL_DB_txdb_S33
Account Selection method :- Enter manually else parameter will not work.
Server Name 	:- osedbserverlocal.database.windows.net
Authentication 	:- SQL Server Authentication
UseName			:- adminuser
Password 		:- usP>>2021
DB Name         :- oselocaltxdb_S33

Table Name :- OutputFolderTable

CREATE TABLE [dbo].[OutputFolderTable](
	[id] [int] NOT NULL,
	[FolderName] Nvarchar(Max) NULL
)

INSERT INTO [dbo].[OutputFolderTable] values (1,'output1')
INSERT INTO [dbo].[OutputFolderTable] values (2,'output2')
INSERT INTO [dbo].[OutputFolderTable] values (3,'output3')

DB SQL Dataset :- DS_osedbserverlocal_txdb_S33_OutputFolderTable
Source file Storage Datasets :- DS_uspstorageaccountnew_uspstagingcontainer_input_data
/* It will point to data.txt file */

Target file storage Datasets :- DS_Output_Table 
/* It will point to uspstagingcontainer.Folder name will come from table :- @dataset().Folder */

Pipeline Name :- LookupPipeline
DB SQL Dataset :- DS_osedbserverlocal_txdb_S33_OutputFolderTable
Activity Name :- Lookup1
Properties :- Setting :- Select dataset from drop down.
Use Query :- 
i) Table :- All rows of the table mentioned in datsstes will be fetched.
ii) Query :- Explicitely we can write query to the table.So if table has 10 columns
but we need only 1 then query is useful.
iii) Stored Procedure :- Select procedure from dropdown.Whatever result will come 
from this will be stored in look up activity.

In this case we will use Query :- 
SELECT FolderName FROM [dbo].[OutputFolderTable]

fIRSTrowonly :- If yes then only one row will come.
                If No theen all row will come.
Select "No" :- Now all outputfolder name will come.
Will use "foreach activity" and iterate to folder name one by one and copy
data.txt file to destination folder.

Output of LookUp activity :- /* If First Row is selected */
{
    "firstRow": {
        "FolderName": "output1"
    },
    "effectiveIntegrationRuntime": "DefaultIntegrationRuntime (Southeast Asia)",
    "billingReference": {
        "activityType": "PipelineActivity",
        "billableDuration": [
            {
                "meterType": "AzureIR",
                "duration": 0.016666666666666666,
                "unit": "DIUHours"
            }
        ]
    },
    "durationInQueue": {
        "integrationRuntimeQueue": 0
    }
}

Since this output we need foreach activity.But foreach activity accepts Array as input.
So get the data and convert it to array using "arr" azure function.

/* Note :- Foreach always accepts input as Array */

ForEach Activity Name :- ForEach1
1) 
If onlyfirstrow is selected :- 
Settings :- 
items :- @array(activity('Lookup1').output.firstRow.FolderName)
/* Foreach accepts Array input  */


Copy Activity Name :- Copy data1
Sink Dataset :- For Folder Name :- @item() /* input to ForEach activity */

Each input inside foreach can be fetched using "@item()" keyword.



When onlyfirstrow is selected then able to read data from JSON and file data.txt got copied
into output1 folder.

2) If onlyfirstrow is not selected in lookup activity :- 
Here we will get multiple files in the JSON.So we need to read it in a different manner.
Output of Lookup activity :- 
{
    "count": 3,
    "value": [
        {
            "FolderName": "output1"
        },
        {
            "FolderName": "output2"
        },
        {
            "FolderName": "output3"
        }
    ],
    "effectiveIntegrationRuntime": "DefaultIntegrationRuntime (Southeast Asia)",
    "billingReference": {
        "activityType": "PipelineActivity",
        "billableDuration": [
            {
                "meterType": "AzureIR",
                "duration": 0.03333333333333333,
                "unit": "DIUHours"
            }
        ]
    },
    "durationInQueue": {
        "integrationRuntimeQueue": 0
    }
}

ForEach Activity :- 
Settings :- items :- @activity('Lookup1').output.value
/* This will give entire JSON as array */
/* Now we need to read its element FolderName */

Create a variable at pipeline level :- FileName
Inside foreach :- 
Activity Name :- Set Variable :- 
Variables :- 
Name :- FolderName
Value :- @item().FolderName /* This will give foldername as output1 then output2 then output3 */

Copy Activity :- Sink :- Folder Name :- @variables('FolderName')

/* Publish it and trigger it */
/* data.txt is getting copied at 3 places */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=9d39Bw2uFLw&list=PLMWaZteqtEaLTJffbbBzVOv9C0otal1FO&index=82&ab_channel=WafaStudies */ 
/* 82. Cache Sink and Cached lookup in Mapping Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------
/* Complete it */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=7eTK787svrw&ab_channel=MadanmohanSatna */
/* Common Data Model (CDM) with Azure Data Factory By Madan Mohan Satna */
-----------------------------------------------------------------------------------------
/* Another youtube video where Sink having inline Common Data Model (CDM) */






========================================================================================
========================================================================================
https://www.youtube.com/playlist?list=PLMWaZteqtEaJnFi7CFCdpUjYaBmN7H2-U
/* Azure Data Factory Tips & Tricks */
/* Full Playlist */
-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=umflqBYG9KU&list=PLMWaZteqtEaJnFi7CFCdpUjYaBmN7H2-U&index=2&ab_channel=WafaStudies */
/* 1. How to find related resources in Azure data factory */
-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=_lSB7jaDnG0&list=PLMWaZteqtEaJnFi7CFCdpUjYaBmN7H2-U&index=2&ab_channel=WafaStudies */
/* 2. How to dynamically access Activity Failure error message using expressions in Azure Data Factory */
-----------------------------------------------------------------------------------------
Req :- If any pipelines fails then how can we capture error message into a variable.

Pipeline Name :- CaptureErrorMsg
VAriable :- 
NAme :- ErrorMsg :- String
Activity Name :- StoredProcedure
Linked Service :- LS_OseLocal_xxx
Procedure Name :- xyz (Any dummy name.Since this procedure does not exist.SO it will fail)

/* Connect this variable upon failure of StoredProcedure activity */
Activity Name :- SetVariable
Value :- @string(activity('StoredProcedure'))
Actual Value :- @activity('StoredProcedure').Error.message

/* Since output is a jSON so converting it into string in the value */
O/P :- 

{
    "name": "ErrorMsg",
    "value": "{"PipelineName":"CaptureErrorMsg","PipelineRunId":
    "3854f589-b277-4e0b-b4b6-7f3440659383","JobId":"3854f589-b277-4e0b-b4b6-7f3440659383",
    "ActivityRunId":"90f4eb98-f176-4b74-86f8-fab4940217ff","ExecutionStartTime":
    "2021-09-28T07:58:10.0114364Z","ExecutionEndTime":"2021-09-28T07:58:21.7000727Z",
    "Status":"Failed","Error":{"errorCode":"2402","message":
    "Execution fail against sql server. Sql error number: 2812. 
    Error Message: Could not find stored procedure 'xyz'.",
    "failureType":"UserError","target":"StoredProcedure
    ","details":[]},"Output":{"effectiveIntegrationRuntime
    ":"DefaultIntegrationRuntime (East US)","executionDuration
    ":0,"durationInQueue":{"integrationRuntimeQueue":10},"billingReference":
    {"activityType":"ExternalActivity","billableDuration":[{"meterType":
    "AzureIR","duration":0.016666666666666666,"unit":"Hours"}]}},
    "ExecutionDetails":{"integrationRuntime":[{"name":"DefaultIntegrationRuntime","type":"Managed","location":"East US"}]},"StatusCode":400,"ExecutionStatus":"Fail","Duration":"00:00:11.6886363","RecoveryStatus":"None"}"
}

Actual O/P :- 
{
    "name": "ErrorMsg",
    "value": "Execution fail against sql server. Sql error number: 2812. Error Message: Could not find stored procedure 'xyz'."
}

/* Here directly failure message is coming into value/variable .*/

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=sCPtWwI1myM&list=PLMWaZteqtEaJnFi7CFCdpUjYaBmN7H2-U&index=3&ab_channel=WafaStudies */
/* 3. Force Cache refresh for Data Flow in Azure Data Factory */
-----------------------------------------------------------------------------------------

========================================================================================
========================================================================================
-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=WR6AbQ3grMU&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH */
/* Azure Data Factory Real Time Scenarios */
-----------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=WR6AbQ3grMU&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&ab_channel=WafaStudies */
/* 1. Handle Error Rows in Data Factory Mapping Data Flows */
-----------------------------------------------------------------------------------------
Req :- How to perform validation on rows and handle error rows in Mapping data flows.

drop table if exists A_Test
CREATE TABLE A_Test
(ID INT,
SaleDate date);

DELETE FROM A_Test
INSERT INTO A_Test VALUES (1,'2021-01-01')
INSERT INTO A_Test VALUES (1,'01-Jan-2021')
INSERT INTO A_Test VALUES (1,'01-01-2021')

SELECT * FROM A_Test;
ID	SaleDate
1	2021-11-30
1	2021-01-01
1	2021-01-01
1	2021-01-01


Files :- 
SalesIND_2020_May_01.csv
SalesAUS_2020_May_01.csv
/* SalesUK_2020_May_01.csv */
SalesUSA_2020_May_01.csv

cat>SalesIND_2020_May_01.csv
SaleDate,SalesItem,Country,Quantity
01-May-2020,Laptop,india,100
01-May-2020,Mobile,india,2
01--2020,Earphones,india,50
01-May-2020,Desktops,india,9
01-May-2020,Keyboards,india,10

cat>SalesAUS_2020_May_01.csv
SaleDate,SalesItem,Country,Quantity
01-May-2020,Laptop,Australia,100
01-May-2020,Mobile,Australia,2
01--2020,Earphones,Australia,50
01--2020,Desktops,Australia,9
01-May-2020,Keyboards,Australia,10

cat>SalesUSA_2020_May_01.csv
SaleDate,SalesItem,USA,Quantity
01-May-2020,Laptop,USA,100
01-May-2020,Mobile,USA,2
01--2020,Earphones,USA,50
01--2020,Desktops,USA,9
01-May-2020,Keyboards,USA,10

These files are present in BLOB staorage.Insert the record in DB.
If record is correct then insert it into "tbl_sales" table.
If record has any error then insert it into "tbl_sales_bad" table.

/* Table Structure */
drop table if exists tbl_sales
CREATE TABLE tbl_sales
(SaleDate date,
SalesItem nvarchar(100),
Country nvarchar(100),
Quantity int,
File_Name nvarchar(100)
);


drop table if exists tbl_sales_bad
CREATE TABLE tbl_sales_bad
(SaleDate nvarchar(100),
SalesItem nvarchar(100),
Country nvarchar(100),
Quantity int,
File_Name nvarchar(100)
);

/* Since we need to fetch data from file and need to handle some scenario so will
create a data flow. */

LinkedService :- LS_OseLocal_S34

Local :- 
-------------
Server Type 	:- Database Engine
Server Name 	:- osedbserverlocal.database.windows.net
Authentication 	:- SQL Server Authentication
Login			:- adminuser
Password 		:- usP>>2021
DataBase Name   :- oselocaltxdb_S34

DataSet Name for tbl_sales Table :- DS_DB_tbl_sales
DataSet Name for tbl_sales_bad Table :- DS_DB_tbl_sales_bad

/* Use Conditional Split transformation to achieve this */
It works as a CASE statement.So here we will put condition on data column.
If it is a proper data column then will create 1st block else
Another block will be created which will be bad rows.


Data flow Name :- HandleErrorRowDataFlow

Source1 :- 
Output Stream Name :- IndSalesData
Linked Service :- LS_AzureStorage_uspstorageaccountnew
Source Dataset :- DS_uspstagingcontainer_IndSalesData

Split Condition :- 
Output Stream Name :- ConditionalSplit1
Incoming Stream :- IndSalesData
Split Condition :- 
Stream Name :- BadRows
Condition :- Open expression builder >>> isNull(toDate(SaleDate,'dd-MMM-yyyy'))
/* Here Bad Rows will come */
ELSE
Stream Name :- GoodRows /*Here good rows will come */

/* We also need a file name column.So will use derived column transformation */
/* For Good as well as BAd Rows */
Adding a new column :- add + >> Derived Column
Output Stream Name :- DerivedFileName
Columns >> Column = FileName
        Expression = 'SalesIND_2020_May_01.csv'

Adding a new column :- add + >> Derived Column
Output Stream Name :- DerivedFileName1
Columns >> Column = FileName
        Expression = 'SalesIND_2020_May_01.csv'

/* Add Sink for Good and Bad Rows */
/* 
DataSet Name for tbl_sales Table :- DS_DB_tbl_sales
DataSet Name for tbl_sales_bad Table :- DS_DB_tbl_sales_bad
*/
Output to file :- add + >> Sink
Output Stream Name :- OutputDataBad
Target Dataset :- DS_DB_tbl_sales_bad


Output to file :- add + >> Sink
Output Stream Name :- OutputDataGood
Target Dataset :- DS_DB_tbl_sales

/* Here in Data Preview, SaleDate will be null because by default from file every column will
be String but in our DB it is Date and INT data type.
So we need to change datatype of columns before sink means at derived column */
So basically again we are deriving a new column so in the same derived column.

Output Stream Name :- DerivedFileName1
Columns >> Column = SaleDate
        Expression = toDate(SaleDate, 'dd-MMM-yyyy')

Columns >> Column = Quantity
        Expression = toInteger(Quantity)

/* Pipeline Creation */
Pipiline Name :- RunHandleErrorRowDataFlow
Activity Name :- DataFlow
Data Flow Name :- HandleErrorRowDataFlow

/* Run it and check data in tbl_sales & tbl_sales_bad table */
SELECT * FROM tbl_sales;
SaleDate	SalesItem	Country	Quantity	File_Name
2020-05-01	Laptop	    india	NULL	    SalesIND_2020_May_01.csv
2020-05-01	Mobile	    india	NULL	    SalesIND_2020_May_01.csv
2020-05-01	Desktops	india	NULL	    SalesIND_2020_May_01.csv
2020-05-01	Keyboards	india	NULL	    SalesIND_2020_May_01.csv

SELECT * FROM tbl_sales_bad;
SaleDate	SalesItem	Country	Quantity	File_Name
01--2020	Earphones	india	NULL	    SalesIND_2020_May_01.csv


Note :- Same thing can also be achieved through "Copy Activity" and Use property
 "Fault Tolarance". /* Try It */ >> /* Next Video */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=L165TgZZfHk&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=2&ab_channel=WafaStudiesWafaStudies */
/* 2. Get File Names from Source Folder Dynamically in Azure Data Factory */
-----------------------------------------------------------------------------------------
Req :- How to get file name dynamically and use it at run time in pipeline.
in input folder 3 files are present.Get the file name and then copy these files to output folder
with same name.

Solution :- 

File Name :- Inside "Sales" Folder.
SalesIND_2020_May_01.csv
SalesAUS_2020_May_01.csv
SalesUSA_2020_May_01.csv

Linked Service :- LS_AzureStorage_uspstorageaccountnew
Source Dataset :- DS_Sales
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
Folder Name :- Sales


Pipeline Name :- GetFileNameDynamically
Activity Name :- GetMetadataActivity
Source Dataset :- DS_Sales
Field List >>> +New >>> From Drop Down :- "Child Items"

Output of this activity will be a JSON inside this all files and folder name will be present
in JSON format.
O/P :- 
Output
{
    "childItems": [
        {
            "name": "SalesAUS_2020_May_01.csv",
            "type": "File"
        },
        {
            "name": "SalesIND_2020_May_01.csv",
            "type": "File"
        },
        {
            "name": "SalesUSA_2020_May_01.csv",
            "type": "File"
        }
    ],
    "effectiveIntegrationRuntime": "DefaultIntegrationRuntime (East US)",
    "executionDuration": 0,
    "durationInQueue": {
        "integrationRuntimeQueue": 0
    },
    "billingReference": {
        "activityType": "PipelineActivity",
        "billableDuration": [
            {
                "meterType": "AzureIR",
                "duration": 0.016666666666666666,
                "unit": "Hours"
            }
        ]
    }
}

/* loop through each file name copy that file into Target location */
Activity Name :- ForEachActivity
Settings >>> Items >>> @activity('GetMetadataActivity').output.childItems
/* This will get childItems array from JSON */
/* This will become Source for our for each Activity */
Click on >>> pencil icon (edit icon) in "ForEachActivity" activity.
A new window will be opened where we need to add a "Copy Activity".


Activity Name :- CopyActivity
Here we need to create a dynamic dataset as our file name will be changing.
/* -- Source Data Set
Linked Service :- LS_AzureStorage_uspstorageaccountnew
Dataset :- DS_input_Sales -- File Will be passed dynamically 
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
Folder Name :- Sales
File Name :- @dataset().FileName
*/

/* Sink Data Set */
Linked Service :- LS_AzureStorage_uspstorageaccountnew
Dataset :- DS_output_Sales  
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
Folder Name :- output

At Pipeline Level :- 
Source >>> Dataset  Properties :- 
Name :- FileName /* Automatically come from dataset */
Value :- /* Add Dynamic Content */ = @item().name
Sink :- DS_output_Sales

/* Publish All and Trigget it */
/* Files are present inside output folder. */

Source Code :- 
{
    "name": "GetFileNameDynamically",
    "properties": {
        "activities": [
            {
                "name": "GetMetadata",
                "type": "GetMetadata",
                "dependsOn": [],
                "policy": {
                    "timeout": "7.00:00:00",
                    "retry": 0,
                    "retryIntervalInSeconds": 30,
                    "secureOutput": false,
                    "secureInput": false
                },
                "userProperties": [],
                "typeProperties": {
                    "dataset": {
                        "referenceName": "DS_input",
                        "type": "DatasetReference"
                    },
                    "fieldList": [
                        "childItems"
                    ],
                    "storeSettings": {
                        "type": "AzureBlobFSReadSettings",
                        "enablePartitionDiscovery": false
                    },
                    "formatSettings": {
                        "type": "DelimitedTextReadSettings"
                    }
                }
            },
            {
                "name": "ForEach1",
                "type": "ForEach",
                "dependsOn": [
                    {
                        "activity": "GetMetadata",
                        "dependencyConditions": [
                            "Succeeded"
                        ]
                    }
                ],
                "userProperties": [],
                "typeProperties": {
                    "items": {
                        "value": "@activity('GetMetadata').output.childItems",
                        "type": "Expression"
                    },
                    "isSequential": true,
                    "activities": [
                        {
                            "name": "Copy data1",
                            "type": "Copy",
                            "dependsOn": [],
                            "policy": {
                                "timeout": "7.00:00:00",
                                "retry": 0,
                                "retryIntervalInSeconds": 30,
                                "secureOutput": false,
                                "secureInput": false
                            },
                            "userProperties": [],
                            "typeProperties": {
                                "source": {
                                    "type": "DelimitedTextSource",
                                    "storeSettings": {
                                        "type": "AzureBlobFSReadSettings",
                                        "recursive": true,
                                        "enablePartitionDiscovery": false
                                    },
                                    "formatSettings": {
                                        "type": "DelimitedTextReadSettings"
                                    }
                                },
                                "sink": {
                                    "type": "DelimitedTextSink",
                                    "storeSettings": {
                                        "type": "AzureBlobFSWriteSettings"
                                    },
                                    "formatSettings": {
                                        "type": "DelimitedTextWriteSettings",
                                        "quoteAllText": true,
                                        "fileExtension": ".txt"
                                    }
                                },
                                "enableStaging": false,
                                "dataIntegrationUnits": 2,
                                "translator": {
                                    "type": "TabularTranslator",
                                    "typeConversion": true,
                                    "typeConversionSettings": {
                                        "allowDataTruncation": true,
                                        "treatBooleanAsNumber": false
                                    }
                                }
                            },
                            "inputs": [
                                {
                                    "referenceName": "DS_input_P_FileName",
                                    "type": "DatasetReference",
                                    "parameters": {
                                        "FileName": {
                                            "value": "@item().name",
                                            "type": "Expression"
                                        }
                                    }
                                }
                            ],
                            "outputs": [
                                {
                                    "referenceName": "DS_output",
                                    "type": "DatasetReference"
                                }
                            ]
                        }
                    ]
                }
            }
        ],
        "annotations": []
    }
}
-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=q6eqH22SGBE&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=4&ab_channel=WafaStudiesWafaStudies */
/* 3. Incrementally copy new and changed files based on Last Modified Date in Azure Data Factory */
-----------------------------------------------------------------------------------------
Req :- From input folder fetch all the files whose modified date is lying in last 2 days.
So suppose todays date is 9th june 2021.So out ADF should pick files whose modified date is
9th and 8th June 2021.


Linked Service :- LS_AzureStorage_uspstorageaccountnew
Source Dataset :- DS_input_folder
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
Folder Name :- input

Linked Service :- LS_AzureStorage_uspstorageaccountnew
Source Dataset :- DS_output_folder
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
Folder Name :- output


Pipeline Name :- CopyFileIncrementally
Activity Name :- CopyActivity
Source >> Source DataSet :- DS_input_folder
File Type Path :- WildCard File PAth
Wildcard paths :- uspstagingcontainer / input / *.csv /* Fetch all files from input folder which is ending with .csv */
Filter by last modified :- Start time (UTC) :- @adddays(utcnow(),-2)
                            End time (UTC) :- @utcnow()
Sink :- Sink Dataset :- DS_output_folder

/* My Own Example :- */
Copy all .csv files older than 5 days to input folder from main container.
1) Create a Dataset which will point to container.Also create a dataset pointing to output folder.
2) Add copy activity.
3) At Source select :- Wildcard file path
4) Wildcard paths :- *.csv
5) Filter by last modified :- Start time (UTC) >> Blank & End time (UTC) :- @adddays(utcnow(),-5)
6) Add Sink :- select Output folder dataset.


-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=2yIznWN3wow&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=3&ab_channel=WafaStudiesWafaStudies */
/* 4. Delete old files from storage using Azure Data Factory */
-----------------------------------------------------------------------------------------
Req :- Delete all files from BLOB storage whose last modified date is greater than 20 days.

Linked Service :- LS_AzureStorage_uspstorageaccountnew
Source Dataset :- DS_input_folder
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
Folder Name :- input

File Name Data.txt,HourlySales.csv :- 
Last Modified Date :- 16th May 2021, 15th May 2021
Todays Date :- 9th June 2021
So this file should be deleted after running pipeline.



Pipeline Name :- GetFileNameDynamicallyfordelete
Activity Name :- GetMetadataActivity
Source Dataset :- DS_input_folder
Filter by last modified :- Start time (UTC) :- Blank
                            End time (UTC) :- @adddays(utcnow(),-21)
Field List >>> +New >>> From Drop Down :- "Child Items"
/* Other metadata are Exists,Item Name, Item Type, Last modified. Can select as per requirement */

Output of this activity will be a JSON inside this all files and folder name will be present
in JSON format.
O/P :- 
{
    "childItems": [
        {
            "name": "HourlySales.csv",
            "type": "File"
        },
        {
            "name": "data.txt",
            "type": "File"
        }
    ],
    "effectiveIntegrationRuntime": "DefaultIntegrationRuntime (East US)",
    "executionDuration": 0,
    "durationInQueue": {
        "integrationRuntimeQueue": 0
    },
    "billingReference": {
        "activityType": "PipelineActivity",
        "billableDuration": [
            {
                "meterType": "AzureIR",
                "duration": 0.016666666666666666,
                "unit": "Hours"
            }
        ]
/* Now will use "ForEach" to fetch file one by one and and delete it. */

/* loop through each file name copy that file into Target location */
Activity Name :- ForEachActivity
Settings >>> Items >>> @activity('GetMetadataActivity').output.childItems
/* This will get childItems array from JSON */
/* This will become Source for our for each Activity */
Click on >>> pencil icon (edit icon) in "ForEachActivity" activity.
A new window will be opened where we need to add a "Delete Activity".


Activity Name :- DeleteActivity
Here we need to create a dynamic dataset as our file name will be changing.
/* -- Source Data Set
Linked Service :- LS_AzureStorage_uspstorageaccountnew
Dataset :- DS_input_Folder_Dynamic_Files -- File Will be passed dynamically 
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
Folder Name :- input
File Name :- @dataset().FileName
*/

Source >> Data Set >>> File Name :- @item().name

Logging Setting :- This will capture all logs after pipeline execution.
So need to provide a linked service.
Linked Service :- LS_AzureStorage_uspstorageaccountnew
Folder Path :- uspstagingcontainer/output

/* Publish All and Trigger it */
/* Files Deleted successfully */
/* Even thogh only 2 files were there in JSON still 2 more file also got deleted. */
/* Can check log in out put folder.for each file a folder is created */


-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=S-VO5KwAD_4&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=5&ab_channel=WafaStudiesWafaStudies */
/* 5. Process fixed length text files by Azure Data Factory mapping data flows */
-----------------------------------------------------------------------------------------
What is Fixed Length text file :- 
Here each fileld will have a fixed length.Value can not exceed that length.
If it is less theen there will be space for remaining character.
Here no delimeter will be present.

cat>EmpFixedLength.txt
100ABHI     GRD7979919363
101ABHIKUMARAP 7979965463
102ABHILASH MUM7976565463

Req :- Convert this data into a csv file and store it.
Implement it using Data flow.

Linked Service :- LS_AzureStorage_uspstorageaccountnew
Source Dataset :- DS_input_EmpFixedLength
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
Folder Name :- input
File Name :- EmpFixedLength.txt


Data Flow Name :- FixedLengthDataFlow

Source1 :- 
Output Stream Name :- FixedLengthFileData
Linked Service :- LS_AzureStorage_uspstorageaccountnew
Source Dataset :- DS_uspstagingcontainer_EmpFixedLength

+ >> Schema Modifier >> Derived Column
Output Stream Name :- DerivedColumn
substring(string_to_subset, from_1-based_index, number_of_characters) :- 
LEngth  = 1 to 3 >> EmpId
          4 to 12 >> EmpName
          13 to 15 >> Loc
          16 to 26 >> PhNo
Sample Data :- 
100ABHI GRD7979919363	    100	ABHI	    GRD	7979919363
101ABHIKUMARAP 7979965463	101	ABHIKUMAR	AP	7979965463
102ABHILASH MUM7976565463	102	ABHILASH	MUM	7976565463

/* Now remove 1st column as it is not required using "select" activity */
 + >> Schema Modifier >> Select
Output Stream Name :- select
Delete column_1


/* Add Sink */
Output Stream Name :- SinkOutput
Sink Dataset :- DS_input_Empcsv
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
Folder Name :- input
File Name :- Empcsv.csv

Setting >> Output to a single file

/* Create a pipeline and run it */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=yoX0wTZzIcg&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=6&ab_channel=WafaStudiesWafaStudies */
/* 6. Log Pipeline Executions to SQL Table using Azure Data Factory */
-----------------------------------------------------------------------------------------
Requirement 1 :- 
-------------------------
Suppose we ran a pipeline and we want to store all pipiline level information to our DB.
Theen we will pass all these variables as i/p to SP and this will insert data into our table.

DROP TABLE IF EXISTS ADFPipelineDetails;
CREATE TABLE ADFPipelineDetails
(
ADFName NVARCHAR(500), 
PipelineName NVARCHAR(500),
TriggerName NVARCHAR(500), 
RunId NVARCHAR(500), 
TriggerTime DateTime
);

CREATE OR ALTER PROCEDURE [dbo].[Get_Pipeline_Details] @ADFName NVARCHAR(500), @PipelineName NVARCHAR(500),
@TriggerName NVARCHAR(500), @RunId NVARCHAR(500), @TriggerTime DateTime
AS  
BEGIN 
    INSERT INTO ADFPipelineDetails VALUES
    (@ADFName , @PipelineName , @TriggerName, @RunId, @TriggerTime)

END;


Pipeline scope :- 
-----------------------------
@pipeline().DataFactory
@pipeline().Pipeline	
@pipeline().RunId	   
@pipeline().TriggerType
@pipeline().TriggerId	
@pipeline().TriggerName
@pipeline().TriggerTime
@pipeline().GroupId	   
@pipeline()__?__.TriggeredByPipelineName
@pipeline()__?__.TriggeredByPipelineRunId

Schedule trigger scope :- 
----------------------------
@trigger().scheduledTime
@trigger().startTime

Tumbling window trigger scope :- 
-----------------------------------
@trigger().outputs.windowStartTime
@trigger().outputs.windowEndTime
@trigger().scheduledTime
@trigger().startTime

/*
Source DataSet :-    DS_uspstorageaccountnew_uspstagingcontainer_input_data
                     DS :- DataSets
                     uspstorageaccountnew :- Azure Storage Account Name
                     uspstagingcontainer :- Container Name
                     input :- Folder Name
                     data :- File Name
Select File Path :- Through Browse select the file then automatically it will be filled.
This will be used a Source.
Since we are copying data into another folder.So we need another DataSet.

Target DataSet :-    DS_uspstorageaccountnew_uspstagingcontainer_output_data
Folder Name :- output
File Name :- data.txt

*/

/* Sprint 34 Local db :- S_34 */
PipeLine Name :- Copy_File_Capture_Details_Pipeline
/* This will copy data.txt file from input folder to output folder */
Copy Activity Name :- Copy_File_data
Source DataSet :-    DS_uspstorageaccountnew_uspstagingcontainer_input_data
Target DataSet :-    DS_uspstorageaccountnew_uspstagingcontainer_output_data


Stored Procedure Activity :- Stored_Procedure
Table Name :- ADFPipelineDetails
Linked Service Name :- LS_OseLocal_S34
Datasets Name :- DS_ADFPipelineDetails
Stored Procedure Name :- Get_Pipeline_Details
Setting :- Stored Procedure Parameters >>> Import /* All input parameter will come and ask for input */
/* Select System level predefined variable */

System Variable :- @pipeline().DataFactory, @pipeline().Pipeline, @pipeline().RunId	
/* Pass system variable as i/p to SP */
@ADFName        :- @pipeline().DataFactory
@PipelineName   :- @pipeline().Pipeline
@TriggerName    :- @pipeline().TriggerName
@RunId          :- @pipeline().RunId
@TriggerTime    :- @pipeline().TriggerTime

Trigger Name :- Trigger_Copy_File_Capture_Details_Pipeline

/* Publish and Trigger it */

SELECT * FROM ADFPipelineDetails

ADFName	        PipelineName	                TriggerName	RunId	TriggerTime
uspstorageadf	Copy_File_Capture_Details_Pipeline	Manual	606912f7-2232-4d60-81ee-66a71e1742af	2021-06-10 14:11:34.840
/* Since I ran manually so Trigger name is coming as Manual.
If automatically as per schedule will run theb actual trigger name will come */


-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=YDRn_arRtjA&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=7&ab_channel=WafaStudiesWafaStudies */
/* 7. Remove Duplicate Rows using Mapping Data Flows in Azure Data Factory */
-----------------------------------------------------------------------------------------
Req :- Suppose we have two files.After doing UNION transformation we are getting
duplicate rows (Suppose for same key we are getting two different rows).
So will keet a single row from these file and process.

/* In Data flow UNION transformation is similar to "UNION ALL" in SQL. */
/* Complete it */


--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=SHomaQlxpno&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=8&ab_channel=WafaStudiesWafaStudies */
/* 8. Increment Keys from Existing Source Using Mapping Data Flow in Azure Data Factory */
--------------------------------------------------------------------------------------
Requirement :- Suppose we are copying data from one file to another file.
So we need to append the data in the target file and there will be a key column at
target file which should be sequential.
/* Use Data Flow */

Sink File :- TargetEmployee.csv /* Already Present at sink output folder */
id,name,Age,Gender
1,A,30,Male
2,B,31,Male
3,C,32,Male
4,D,33,Male

Source File :- SourceEmployee.csv /* Present at input folder */
name,Age,Gender
E,30,Male
F,31,Male
G,32,Male
H,33,Male

/* How to achieve this :- */
Since we have a source file which has 3 columns but at target we need 4 column.
Extra column is an identity column that we can add using "SurrogateKey" transformation.
Here we need to provide column name and start value.
Column name will be "Id" but start value we need to fetch from target file as 
which will be maximum of id value.And this value will become start value for source rows.

We can not directly append data into table.We have to take data from both the files
and do "Union" transformation and theen entire result will go to sink.


How to get Maximum of Id value from target file :- 
i) Add an extra column as dummy column using "Derived" transformation and here value
will also be 'dummy'
ii) Now Use aggregate transformation to get maximum of Id column.
iii) Use this value as start in "surrogate" key tranformation.




Data Flow Sample :- 
Name :- IncrementKeyDataflow

/* Fetch data from TargetEmployee.csv file */
Source1 :- 
Output Stream Name :- TargetEmployeeData
Sink Dataset :- DS_TargetEmployee
Linked Service :- LS_AzureStorage_uspstorageaccountnew
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
Folder Name :- output
File Name :- TargetEmployee.csv

/* Derived transformation to add a dummy column */
+ >> Derived 
Output Stream Name :- DerivedTranformation
Derived Column Settings :- Columns :- 
Column :- Dummy
Expression :- 'Dummy'

/* Aggragate transformation to get max of Id into dummy column */
+ >> Aggregate 
Output Stream Name :- AggregateTranformation
Group By :- 
Column :- Dummy
Name :- Dummy
Aggregates :- 
Column :- MaxId
Name :- MAX(id) /* Value 4 will come */
/* This produces 1 row >>> Dummy 4 */

/* Now Add SourceEmployeeData and do a cross join with AggregateTranformation.
So data will come like this */
name,Age,Gender,dummy,MaxId
D,30,Male,dummy,4
E,31,Male,dummy,4
F,32,Male,dummy,4
G,33,Male,dummy,4


/* Get SourceEmployee */
Output Stream Name :- SourceEmployeeData
Source Dataset :- DS_SourceEmployee
Linked Service :- LS_AzureStorage_uspstorageaccountnew
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
Folder Name :- input
File Name :- SourceEmployee.csv

/* Join this data with Aggragate transformation data (Cross Join) */
+ >> join
Output Stream Name :- CrossJoin
Left Stream :- AggregateTranformation
right Stream :- SourceEmployeeData
Join Type :- Custom (Cross)
Condition :- 1==1


/* We need to add an extra column which will be incremented automatically.
This can be done by "SurrogateKey" transformation */

+ >>> Schema Modifier >> SurrogateKey 
Output Stream Name :- SurrogateKey
Surrogate Key Settings :- 
Key Column :- Id
Start Value :- 1

/* Here Output will be :- */
name,Age,Gender,dummy,MaxId,Id
D,30,Male,dummy,4,1
E,31,Male,dummy,4,2
F,32,Male,dummy,4,3
G,33,Male,dummy,4,4

/* So now if we will add a new column which will be summation of MaxId and Id then
that value will become the actual Id that we want */

/* Add Derived transformation and change value of Id column to sum of MaxId and Id */
+ >> Derived 
Output Stream Name :- DerivedTranformation1
Derived Column Setting :- 
Columns :- 
Column :- id
Expression :- toString(toInteger(MaxId) + toInteger(Id))
/* Since Id is string in target File */

/* Add select transformation and remove dummy and maxId Column */
+ >> Select
Output Stream Name :- SelectTransformation
delete dummy and MaxId column.

Now we need to do a union with existing file data to get final set of result.
We have already taken target file so will create a branch from it and use in UNION transformation.

+ >> Branch from TargetEmployeeData
+ >> UNION
Incoming Stream :- SelectTransformation
Union With :- TargetEmployeeData

/* Now Create a sink and also create a data set which wil point to output folder */
/* Since file is already present So it will be overwritten */


/* Create a pipeline and run the data flow */
Pipeline Name :- RunIncrementKeyDataflow

--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=KUJSzF6vjnI&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=9&ab_channel=WafaStudiesWafaStudies */
/* 9. Running Total using Mapping Data Flow in Azure Data Factory */
--------------------------------------------------------------------------------------
/* Complete it */


--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=-xna7n33lmc&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=10&ab_channel=WafaStudiesWafaStudies */
/* 10. Log Pipeline Executions to file Using Mapping Data Flows in Azure Data Factory */
--------------------------------------------------------------------------------------



--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=MzHWZ5_KMYo&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=11&ab_channel=WafaStudies */
/* 11. Slowly Changing Dimension(SCD) Type 1 Using Mapping Data Flow in Azure Data Factory */
--------------------------------------------------------------------------------------
Requirement :- Get the file from blob storage and insert into database table.
If key column is matching then update rest of the column value else insert a new record into table.

/* File Data :- Keep this file in input folder */
cat>EMPDetails.csv
Empid,EmpName,Country,DeptId
1,A,India,10
2,B,UK,10
3,C,India,20
4,D,India,20
5,E,USA,30

DROP TABLE IF EXISTS EMPDetails;
CREATE TABLE EMPDetails
(
Empid INT, 
EmpName NVARCHAR(500),
Country NVARCHAR(500), 
DeptId NVARCHAR(500)
);

/* Already present data in table :- */
INSERT INTO EMPDetails VALUES (1,'A','India',10)
INSERT INTO EMPDetails VALUES (3,'C','India',20)
INSERT INTO EMPDetails VALUES (6,'F','India',30)

Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev 
Datafactory Name :- uspstorageadf

/* BLOB Storage */
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Storage Account Name :- "uspstorageaccountnew"
ContainerName :- "uspstagingcontainer"
Linked Service :- LS_AzureStorage_uspstorageaccountnew
Dataset Name :- DS_EMPDetails_uspstagingcontainer


/* Database */
Linked Service Name :- LS_OSELocal_SQL_DB_txdb_S33
Server Name 	:- osedbserverlocal.database.windows.net
Authentication 	:- SQL Server Authentication
UseName			:- adminuser
Password 		:- usP>>2021
DB Name         :- oselocaltxdb_S33

Linked Service Name :- LS_OSELocal_SQL_DB_txdb_S33
DataSet Name :- DS_EMPDetails_S33


alter row :- lOOK INTO IT
/* Complete it */

--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=mT2AOh6kJV8&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=14&ab_channel=WafaStudies */
/* 14. Convert Array to String in Azure Data Factory */
--------------------------------------------------------------------------------------
Same example as below without "join" function.



--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=dT6mKtv9Nlg&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=15&ab_channel=WafaStudies */
/* 15. Join() function to convert Array to String in Azure Data Factory */
--------------------------------------------------------------------------------------
Req :- If we have an array like ["a","b","c","d"] then we want output like a string a;b;c;d
This can be achieved using "join()" function.

Pipeline Name :- ConvertToString
Create Two VAriable :- 
i) EmailArray :- Array :- ["A","B","C","D"]
ii) EmailString :- String :- 

Activity Name :- Set Variable
Variable :- Name :- EmailString
VAlue :- @join(variables('EmailArray'),':')

O/P :-
{
    "name": "EmailString",
    "value": "A:B:C:D"
}
/* Pipeline is running fine and getting desired result */


Note :- If data is coing from a file then 1st create an array using "Append Variable".
Then use join function.















--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=U5pSm0G3Vic&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=18 */
/* 18. Copy multiple tables in bulk by using Azure Data Factory */
--------------------------------------------------------------------------------------
Requirement :- Get list of table from azure SLQ Db and copy data into a blob storage.

Approach :- Run a lookup query to get list of tables from DB then use ForEach to iterate over
each table and copy into ADLS Gen2.

/* Complete this.Seems simple */


--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=vU2ZOIPO_So&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=19&ab_channel=WafaStudies */
/* 19. Execute Stored Procedure with Output Parameter in Azure Data Factory */
--------------------------------------------------------------------------------------
Req :- Write a stored procedure having input and output parameter and execute it through ADF.

Note :- If we will run a SP having output parameter through "Stored Procedure" activity
then it will fail as it has no option for output parameter.
/* O/P :- Execution fail against sql server. Sql error number: 201. 
Error Message: Procedure or function 'GetEMPCountByDept' expects parameter '@EmpCount',
which was not supplied. */

So here we need to use "LookUp" Activity with query.
and inside query we need to pass procedure execute statement.and output of this
activity will be a json which will consist of output parameter value.

SP Name :- [dbo].[GetEMPCountByDept]

CREATE OR ALTER PROCEDURE [dbo].[GetEMPCountByDept] @Deptno INT, @EmpCount INT Output
AS  
BEGIN 
     SET @EmpCount = (SELECT COUNT(*) FROM emp where deptno=@Deptno)
END;

/* Execution :- */
DECLARE @Deptno INT, @EmpCount INT
SET @Deptno = 10
EXEC [dbo].[GetEMPCountByDept] @Deptno,@EmpCount OUTPUT
select @EmpCount


Pipeline NAme :- ExecuteSPOutParam
Activity Name :- LookupActivity
Dataset :- Any Dataset pointing to any table where SP is compiled.
Use Query :- Query
Query :- 
DECLARE @Deptno INT, @EmpCount INT
SET @Deptno = 10
EXEC [dbo].[GetEMPCountByDept] @Deptno,@EmpCount OUTPUT
select @EmpCount

O/P :- 
{
    "firstRow": {
        "": 3
},

/* Pipeline ran successfully and Output is coming in JSON. */

--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=QHeG36oqkPQ&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=20&ab_channel=WafaStudies */
/* 20. Get Latest File from Folder and Process it in Azure Data Factory */
--------------------------------------------------------------------------------------
Req :- Get max(modifieddate) file name from Input folder and copy it into output folder.

Input folder has 5 files.
i) Dept.csv	                    8/24/2021, 8:51:35 PM
ii) Emp.csv	                    8/26/2021, 2:28:37 PM
iii) SalesAUS_2020_May_01.csv	8/24/2021, 2:18:38 PM
iv) SalesIND_2020_May_01.csv	8/24/2021, 2:18:38 PM
v) SalesUSA_2020_May_01.csv	    8/24/2021, 2:18:38 PM

So here max modified date is 8/26/2021, 2:28:37 PM and file name is Emp.csv.SO this file
should be copied to Output folder.

/* Tried to get last modified & file name in a single getmetadata activity but not coming.LAst modifies
of folder name is cominh not for files */

Pipeline Name :- CopyMaxMadifiedDateFile
Vaariables :- 
i) MaxModifiedDate :- String :- 1990-08-24T15:21:35Z (By Default Value)
ii) MaxModifiedFileName :- String :- 

1) Activity Name :- GetMetadataActivity /* Get all file name inside input folder */
DataSet :- DS_Input
Field List :- Child Items

O/P :- 
{
    "lastModified": "2021-08-24T08:47:59Z",
    "childItems": [
        {
            "name": "Dept.csv",
            "type": "File"
        },
        {
            "name": "Emp.csv",
            "type": "File"
        },
        {
            "name": "SalesAUS_2020_May_01.csv",
            "type": "File"
        },
        {
            "name": "SalesIND_2020_May_01.csv",
            "type": "File"
        },
        {
            "name": "SalesUSA_2020_May_01.csv",
            "type": "File"
        }
    ],
 
2) Activity Name :- ForEachActivity
Sequentials :- Yes
Items :- @activity('GetMetadataActivity').output.childItems

3) Inside ForEachActivity :- 
Activity Name :- GetMetadataActivity1 /* Get last modified date of each file name */
DataSet :- DS_Input_P /* Need file name as input */ 
File Name :- @dataset().FileName :- @item().name

Field List :- Item Name & LastModified
O/P :- For each file this json will come in GetMetadata Activity
{
    "itemName": "SalesUSA_2020_May_01.csv",
    "lastModified": "2021-08-24T08:48:38Z",
    "effectiveIntegrationRuntime": "DefaultIntegrationRuntime (East US)",
    "executionDuration": 0,
    "durationInQueue": {
        "integrationRuntimeQueue": 0
}

{
    "itemName": "Dept.csv",
    "lastModified": "2021-08-24T15:21:35Z",
    "effectiveIntegrationRuntime": "DefaultIntegrationRuntime (East US)",
    "executionDuration": 0,
    "durationInQueue": {
        "integrationRuntimeQueue": 0
},


4) Inside ForEachActivity :- 
Activity Name :- IfCondition
Expression :- @greater(activity('Get Metadata1').output.lastModified,variables('MaxModifiedDate'))
If True then :- 
Activity Name :- Set Variable1
Variable :- MaxModifieddate :- @activity('Get Metadata1').output.lastModified

Activity Name :- Set Variable2
Variable :- MaxModifiedFileName :- @activity('Get Metadata1').output.itemName


5) Activity Name :- CopyActivity
Source Dataset :- DS_Input_P
File NAme :- @variables('MaxModifiedFileName')

Sink DataSet :- DS_Output

O/P :- Pipeline ran successfully and Emp.csv file got copied into output folder.

--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=b27gmOufge4&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=21&ab_channel=WafaStudies */
/* 21. Dynamic Column mapping in Copy Activity in Azure Data Factory */
--------------------------------------------------------------------------------------
Note :- If we want to copy data from source to destination and column name in destination
is same as source then even if we will not provide mapping it will run fine but
if any one of the column name is different then we need to provide mapping manually inside mapping section.
This process we can do dynamically.So here instead of manually importing schema in mapping
section we can keep mapping in a json file and then can use that file in mapping section.
Explained in below example.

Requirement :- We have two files Emp.xlsx & Dept.xlsx in data folder.
We need to load these files into Emp_XL & Dept_XL table.
number of column will match between table and file but name will be different.
So here we will have a new table Target_Info which will keep mapping info.

Approach :- Using Getmetadata activity get all file present inside data folder.
It will be a JSOn file.Use ForEach iterator to process each file.
Inside Foreach iterator use lookup activity to get mapping and target table name
for input file name from SQL table.Then use Copy activity to load data into SQl table.
Create Dynamic dataset set which will table file name and table name as parameter
in copy activity.

Storage account name :- abksynapseadlsgen2
Container name :- abksynapsecontainer
Folder Name :- Data
File Name :- Emp.xlsx
Empid	EmpName	Country	DeptId
1	A	India	10
2	B	UK	10
3	C	India	20
4	D	India	20
5	E	USA	30

Dataset :- DS_Emp_XL


File Name :- Dept.xlsx
DeptId 	DeptName
10	IT
20	HR
30	ADMIN

Dataset :- DS_Dept_XL
Main Dataset :- DS_Data_P /* It requires a file name as parameter */

/* DB Details */
Server name :- osedbserverlocall.database.windows.net
Server admin login :- adminuser
Password :- Pass@123
DB Name :- oselocaltxdb_S33 
Linked Service :- LS_OSELocal_SQL_DB_txdb_S33
Table Name :- Emp_XL


DROP TABLE if exists Emp_XL;
CREATE TABLE Emp_XL
(Emp_id INT,
Emp_Name NVARCHAR(50), 
Country NVARCHAR(50), 
Dept_Id INT );

DataSet :- DS_Emp_XL_DB

DROP TABLE if exists Dept_XL;
CREATE TABLE Dept_XL
(Dept_Id INT,
Dept_Name NVARCHAR(50))

DataSet :- DS_Dept_XL_DB
Main dataset :- DS_OSELocalDB_P /* It requires a Table name as parameter */

Note :- 
Here if we will try to load data from xl to table theen it will fail because
in source Empid is present but at destination Emp_id is present.So here we 
need to import schema in Mapping section theen it will run fine.
But here we will learn how to do dynamic mapping.
Here we store the mapping in a sql table and using lookup will fetch it and
content will be passed dynamically (Alt+P) inside mapping section.


DROP TABLE if exists Target_Info;
CREATE TABLE Target_Info
(FileName NVARCHAR(50),
TargeTatbleName NVARCHAR(max), 
Mapping NVARCHAR(max));

DataSet Name :- DS_Target_Info

delete from Target_Info
insert into Target_Info values ('Emp.xlsx','Emp_XL','{"type": "TabularTranslator","mappings": [{"source": {"name": "Empid","type": "String","physicalType": "String"},"sink": {"name": "Emp_id","type": "Int32","physicalType": "int"}},{"source": {"name": "EmpName","type": "String","physicalType": "String"},"sink": {"name": "Emp_Name","type": "String","physicalType": "nvarchar"}},{"source": {"name": "Country","type": "String","physicalType": "String"},"sink": {"name": "Country","type": "String","physicalType": "nvarchar"}},{"source": {"name": "DeptId","type": "String","physicalType": "String"},"sink": {"name": "Dept_Id","type": "Int32","physicalType": "int"}}]}')
insert into Target_Info values ('Dept.xlsx','Dept_XL','{"type": "TabularTranslator","mappings": [{"source": {"name": "DeptId ","type": "String","physicalType": "String"},"sink": {"name": "Dept_Id","type": "Int32","physicalType": "int"}},{"source": {"name": "DeptName","type": "String","physicalType": "String"},"sink": {"name": "Dept_Name","type": "String","physicalType": "nvarchar"}}]}')


select * from Target_Info
select * from [dbo].[Emp_XL]
select * from [dbo].[Dept_XL]


Pipeline Name :- CopyFileDynamicMapping
i) Activity Name :- GetMetadataActivity /* It will give all file name inside data folder */
DataSet :- DS_Data
Field List :- ChildItems

O/P :- {
    "childItems": [
        {
            "name": "Dept.xlsx",
            "type": "File"
        },
        {
            "name": "Emp.xlsx",
            "type": "File"
        }
    ],
    "effectiveIntegrationRuntime": "DefaultIntegrationRuntime (East US)",
    "executionDuration": 0,
    "durationInQueue": {
        "integrationRuntimeQueue": 0
    },
    "billingReference": {
        "activityType": "PipelineActivity",
        "billableDuration": [
            {
                "meterType": "AzureIR",
                "duration": 0.016666666666666666,
                "unit": "Hours"
            }
        ]
    }
}


ii) Activity Name :- ForEach /* One by one file name will be iterated */
Sequential :- Yes
Items :- @activity('GetMetadataActivity').output.childItems

iii) Inside For Each :- Activity Name :- LookUpActivity
/* This activity will be used to get target table name and mapping information */
Source Dataset :- DS_Target_Info
Use Query :- Query :- 
Query :- select * from Target_Info where FileName = '@{item().name}'

O/P :- 
{
    "firstRow": {
        "FileName": "Dept.xlsx",
        "TargeTatbleName": "Dept_XL",
        "Mapping": "{\"type\": \"TabularTranslator\",\"mappings\": [{\"source\": {\"name\": \"DeptId \",\"type\": \"String\",\"physicalType\": \"String\"},\"sink\": {\"name\": \"Dept_Id\",\"type\": \"Int32\",\"physicalType\": \"int\"}},{\"source\": {\"name\": \"DeptName\",\"type\": \"String\",\"physicalType\": \"String\"},\"sink\": {\"name\": \"Dept_Name\",\"type\": \"String\",\"physicalType\": \"nvarchar\"}}]}"
    },
    "effectiveIntegrationRuntime": "DefaultIntegrationRuntime (East US)",
    "billingReference": {
        "activityType": "PipelineActivity",
        "billableDuration": [
            {
                "meterType": "AzureIR",
                "duration": 0.016666666666666666,
                "unit": "DIUHours"
            }
        ]
    },
    "durationInQueue": {
        "integrationRuntimeQueue": 0
    }
}

/* AND */

{
    "firstRow": {
        "FileName": "Emp.xlsx",
        "TargeTatbleName": "Emp_XL",
        "Mapping": "{\"type\": \"TabularTranslator\",\"mappings\": [{\"source\": {\"name\": \"Empid\",\"type\": \"String\",\"physicalType\": \"String\"},\"sink\": {\"name\": \"Emp_id\",\"type\": \"Int32\",\"physicalType\": \"int\"}},{\"source\": {\"name\": \"EmpName\",\"type\": \"String\",\"physicalType\": \"String\"},\"sink\": {\"name\": \"Emp_Name\",\"type\": \"String\",\"physicalType\": \"nvarchar\"}},{\"source\": {\"name\": \"Country\",\"type\": \"String\",\"physicalType\": \"String\"},\"sink\": {\"name\": \"Country\",\"type\": \"String\",\"physicalType\": \"nvarchar\"}},{\"source\": {\"name\": \"DeptId\",\"type\": \"String\",\"physicalType\": \"String\"},\"sink\": {\"name\": \"Dept_Id\",\"type\": \"Int32\",\"physicalType\": \"int\"}}]}"
    },
    "effectiveIntegrationRuntime": "DefaultIntegrationRuntime (East US)",
    "billingReference": {
        "activityType": "PipelineActivity",
        "billableDuration": [
            {
                "meterType": "AzureIR",
                "duration": 0.016666666666666666,
                "unit": "DIUHours"
            }
        ]
    },
    "durationInQueue": {
        "integrationRuntimeQueue": 0
    }
}


iv) Inside For Each :- Activity Name :- CopyActivity
Source :- Source Datset :- DS_Data_P
File Name :- @item().name

Sink :- Sink Dataset :- DS_OSELocalDB_P
Table Name :- @activity('LookUpActivity').output.firstRow.TargeTatbleName

Mapping :- Add Dynamic Content :- @json(activity('LookUpActivity').output.firstRow.Mapping)


Run the pipeline :- 
O/P :- Pipeline ran successfully and data got loaded into [dbo].[Emp_XL] & [dbo].[Dept_XL] table.

/*
Tried to pass array inside for each and and used @item in lookup but not giving result.
Check this
*/

select * from Target_Info where FileName = string(@{pipeline().parameters.FileName})
https://docs.microsoft.com/en-us/azure/data-factory/control-flow-expression-language-functions

--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=4Hcvn9TQ5fM&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=23&ab_channel=WafaStudies */
/* 23. Send Email alert when Pipeline fails in Azure Data Factory */
--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=6p39ATHUiv8&ab_channel=DataTech */
/* How to send email notifications for activities in the Azure Synapse Analytics data pipeline? */

/* Follow the steps in above URL not Wafastudies and it will run fine */
Pipeline NAme :- StatusEmailPipeline
Activity Name :- Wait
Activity Name :- Web

/* Create a new Logic Apps */
Create a new Resource :- Search "Logic App" :- 
Subscription :- Visual Studio Enterprise
Resource Group :- myresource
Type :- Consumption
Logic App Name :- SendEmail
Publish :- Workflow
Create.

UI :- Workflows :- i) Workflows ii) Connections
Create a new Workflow :- Name :- NewWorkflow

{
    "Subject":"",
    "PipelineName":"",
    "Time":"",
    "Job_Status":""
}


--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=mQ9Pn8EC5cE&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=29 */
/* 29. Run an activity if any one of set of activities fail in Azure data factory */
--------------------------------------------------------------------------------------
When we connect two activity by default upon success only next activity will be invoked.
But we can define the connection as per our wish.
Click on + button (Add Output) in activity icon.It will have four options.
i) Success ii) Failure iii) Completion iv) Skipped

If we are taking arrow from Success and connecting to next activity then upon success only next
activity will run.
Similarly if connected through failure point then upon failure next activity will run.
If We have connected through success and first activity fails then next activity will be considered as skipped.

Suppose we want to send an email if activity fails. Then
i) If All Activities are connected in series (One after other)
Then at last add web activity(Which will send Email) and join it with last activity with Failure & Skipped.
So if any of the activity before last activity will fail then last one will be skipped.Hense
Web activity will be executed.Or All activity gets executed except last then it will be a fail
Activity.So again web activity will be called as we have taked two row from last activity(Failure & Skipped).


ii) If All Activities are connected in parallel (Activity has no dependency with each other).
Add a dummy activity (Wait Activity) upon success, Then this activity will only execute
if all previous activity executed successfully.If any one the activity fails then this dummy activity
will not execute.
Now add a web activity from Dummy Activity which will execute upon skipped on dummy activity.
If any of the activity fails then dummy activity will be skipped.Hense Web activity will be excuted.

--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=BhVa4CxRf7s&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=28&ab_channel=WafaStudies */
/* 28. TimeZone Conversion in Mapping Data Flows in Azure Data Factory */
--------------------------------------------------------------------------------------












--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=sA3n1xBGSsk&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=30 */
/* 30. Get Error message of Failed activities in Pipeline in Azure Data Factory */
--------------------------------------------------------------------------------------
Req :- Suppose some series/Parallel activities are connected and any one of these activity failed
then how will we capture error message of that activity and that error message we need to pass
to proc or Email.(Not Implemented this part).
Approach for series and parallel will be different.

i) For Parallel Activity :- 
Pipeline Name :- ParallelActivity
Create a variable :- 
Variable Name :- Var        :- String
Variable Name :- ErrorMsg   :- String

ii) Add three set variable activity in parallel and assign value to each variable inside set 
variable activity.
i) Activity Name :- Set variable1
Value :- @int('1')

ii) Activity Name :- Set variable2
Value :- Abhi

iii) Activity Name :- Set variable3
Value :- Kumar

iii) Add a dummy wait activity of 1 sec.

iv) Add another set variable activity which will capture error message.

Activity Name :- CaptureErrorDetails
@activity('Set Variable1').Error.message :- This will give error message if activity Set variable1 fails
@activity('Set Variable2').Error.message :- This will give error message if activity Set variable2 fails
@activity('Set Variable3').Error.message :- This will give error message if activity Set variable3 fails

Since any of the activity can fails.So we need to write expression like this.
@concat(activity('Set Variable1').Error.message,'|',activity('Set Variable2').Error.message,'|',activity('Set Variable3').Error.message)
/* Showing Error */

Since Activity "Set Variable1" is failing but other two are passing.So for those activity there will be
no error message.So add a question mark(?) after error for each activity.
Means if there is no error message then escape it.

Value :- @concat(activity('Set Variable1').Error?.message,'|',activity('Set Variable2').Error?.message,'|',activity('Set Variable3').Error?.message)

Output after Debug :- 
{
    "name": "ErrorMSg",
    "value": "The variable 'Var' of type 'String' cannot be initialized or updated with value of type 'Integer'. The variable 'Var' only supports values of types 'String'.||"
}

/* Running fine and getting error messge */

/* General Syntax to Get Error message in Parralel Activity :- */
@activity('<activity name>').Error?.message


/* General Syntax to Get Error message in Series Activity :- */
@activity('<activity name>')?.Error?.message
In series if one activity fails then other activity will not be executed.So <activity name>
will be null.Hense here for activity also we need to use question mark(?)


--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=-FRZXgSkvSY&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=33&ab_channel=WafaStudies */
/* 33. Load CSV file in to JSON with Nested Hierarchy using Azure data factory */
--------------------------------------------------------------------------------------
/* Data Flow */
/* Complete it */











--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=JOjxcsp5dwc&list=PLMWaZteqtEaLacN3eS3s8pw2jtwBVb1BH&index=37&ab_channel=WafaStudies */
/* 36. Execute SQL queries using Lookup activity in Azure data factory */
--------------------------------------------------------------------------------------
Using lookup activity we can run "SELECT" query inside a DB and get the results.
Lookup activity always expects output from query which we want to execute.

Suppose we have written a "CREATE TABLE" statement isnide query in lookup activity.
When we will run this this activity will fail and will give error.
/* Query is not valid.Query does not return any data */

If we will check DB then table will be present.Means Query gets executed but since it is not returning any
data so Lookup activity got failed.

/* How to resolve this */
Query :- 
CREATE TABLE TEST (ID INT)
SELECT 1 AS COL
This will work fine.Here table will be created and Lookup activity will also pass.

/* Note :- Create Schema will not work in Lookup even if we are using SELECT 1 AS COL. */

/* Best way to execute any query inside Lookup Activity */
Declare @sql nvarchar(max)
set @sql = 'CREATE SCHEMA DEMO'
EXEC SP_EXECUTESQL @sql
SELECT 1 AS abcd

This way we can write any SQL statement and execute it inside DB.














--------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=MhnmG-cHrKM&list=PL_XpoDibuob7MzdeYg8_aHJ8SQ4-XJ7b2&index=1 */
/* Azure Lab : Migrate On premise sql server to Azure sql database using backpac,dacpac,DMA tool */
--------------------------------------------------------------------------------------
/* Must complete it. Session on m]SQL server migration */

SSMS :- Can migrate schema or schema plus data through tier application option.
Data Migration Assistant :- Migrating VM SQL server to Azure SQL server
SQL Server Migration Assistant (SSMA) :- Migrating Oracle,TD database to Azure SQL Server
Azure Database Migration Service (ADM) :- If need to migrate large amount of VM data to Azure SQL Server














===============================================================================================
===============================================================================================
USP ADF Exaples :- 
---------------------
1) DataFactory Name :- usp2adfv2stagingdev
Pipeline Name :- PullDataMallTables_EDL 
/* Calling Data Bricks from ADF */
/* Must See it */
2) 


===================================================================================
===================================================================================
https://www.youtube.com/channel/UC_n9wCmDG064tZUKZF2g4Aw/playlists
https://www.youtube.com/playlist?list=PLMWaZteqtEaLRsSynAsaS_aLzDPBUU4CV
/* Azure Functions */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=eS5GJkI69Qg&list=PLMWaZteqtEaLRsSynAsaS_aLzDPBUU4CV&index=1&ab_channel=WafaStudiesWafaStudies */
/* 1. Introduction to Azure Functions */
-----------------------------------------------------------------------------------------
Azure Function :- It is a serverless compute service that lets you run event
triggered code without having to explicitely provision or manage infrastructure.

Azure function allows us to run small piece of code (Called Function) without
worrying about application infrastructure.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=M4m6gq6-nOk&list=PLMWaZteqtEaLRsSynAsaS_aLzDPBUU4CV&index=2&ab_channel=WafaStudiesWafaStudies */
/* 2. Create your First Azure Function Using Azure Portal */
-----------------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/azure/azure-functions/create-function-app-linux-app-service-plan */
/* Create a function app on Linux in an Azure App Service plan */
Create a resource for "Function App".
Create new :- 
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Function App name :- uspfunctionapp
Publish :- Code
Run Time Stack :- Python (Can choose language :- .Net, Node, Java, Powershell, Python)
Version :- Automaticall 3.9

Hosting :- 
Operating System :- linux (By Default for python) else windows and Python.
Application Insight :- Capture log in DB and can query.
Storage :- Automatically a new storage will be created where all functions will
be present and at the time of execution it be taken from here.
Review and Create :- 

/* Video is in .Net language.Search for python language for azure function */
/* try to find out a playlist for python language */
/* Continue on this.Get requirement and try to do it using python */

What are the benefits of azure functions?
 
Azure functions have the following benefits
Azure functions app is lightweight and requires very less resources to deploy and execute.
Azure functions app us serverless and does not require any Web server setup in cloud.
Azure functions app is compute-on-demand and doesn’t consume resources when not running.
Azure functions app charges are pay per use and you don’t pay anything if not using.
Azure functions app is event driven and executes only when event is fired.
Azure functions app is independent of other apps and does not affect or interfere with other apps.
Azure functions app is easy to write and deploy.
Azure functions app is easy to maintain and support.
Azure functions app is industry standard and developed and consumed using industry standard language and technologies.


-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=cb8BNZG803k&list=PLMWaZteqtEaLRsSynAsaS_aLzDPBUU4CV&index=3&ab_channel=WafaStudies */
/* 3. Create Azure Function using Visual Studio */
-----------------------------------------------------------------------------------------
Set up in Visual Studio 2019 :- 
/* Explained for 2019. I am trying to do in 2017 */
/* azure Function is not coming.So setting up in 2019 */

Create a new project >>> Search for Azure Function >> 
Project Name :- AzureFunctionTask
Location :- C:\Users\10662208\source\repos
Place solution and project in the same directory :- Yes
>>> Create
Azure Functions V3 .Net Core
Http trugger >>> by default
Storage Account :- Keep it as it is.
Authorization Level :- Anonymous

/*
Note :- Visual studio is not supporting Azure function through python.
It supports C#, Java etc..
It can only be done through "Visual Studio Code".
*/

Visual Studio Code Setup for Azure Functions Using Python :- 
1) Download it from below site
https://code.visualstudio.com/download

2) Path :- 
C:\Users\10662208\Downloads\VSCode-win32-x64-1.56.2.zip

3) Go to extension and add "Azure Functions" >>> Install
After installation a new icon below "extension" will come and name
of that icon will be "Azure"
Click on it.
Sign In to Azure.
Create new project.
Select folder in Loacal >>> Language as python >>> HTTP Trigger(MyHTTPTrigger)
>>> Anonymous >>> Open in the same window.

Note :- If we are installing any new package like numpy etc.. then we need to add this 
name in requirement.txt file.


File Name :- __init__.py
import logging

import azure.functions as func


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('name')

    if name:
        return func.HttpResponse(f"Hello, {name}. This HTTP triggered function executed successfully.")
    else:
        return func.HttpResponse(
             "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.",
             status_code=200
        )
Now >> deploy this file in azure function.
Go to azure tab and press upword arrow which will deploy to server. 

Now from Local projects >> Function >> Right click on function name and copy url.
https://uspfunctionapp.azurewebsites.net/api/myhttptrigger 
O/P :- This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.

Append :- ?name=Abhilash
https://uspfunctionapp.azurewebsites.net/api/myhttptrigger?name=Abhilash
O/P :- Hello, Abhilash. This HTTP triggered function executed successfully.

2) Create a new file :- SumNumbers.py

def sum_numbers(val1,val2):
    return val1+val2

/* Not completed */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=hYtp5lkoewE&list=PLMWaZteqtEaLRsSynAsaS_aLzDPBUU4CV&index=4&ab_channel=WafaStudiesWafaStudies */
/* 4. function.json file in Azure Function Code */
-----------------------------------------------------------------------------------------
Azure Function Code :- Azure function contains two impostant parts.
i) Our Code :- This is our code file which we will write in any language like C,C#, Python etc..

ii) Function.json File :- It contains configuration details.

Properties :- 
i) For compiled languages function.json file generates automatically from annotation
of our code.
For Scripting language we have to provide config file.
ii) It defines triggers, bindings and other configuration setting of Azure functions.
iii) Every function can have only one trigger.
iv) This file determines what events to monitor and how to pass data into and
return data from an Azure function.

Sample :- 
{
  "scriptFile": "__init__.py",
  "bindings": [
    {
      "authLevel": "anonymous",
      "type": "httpTrigger",
      "direction": "in",
      "name": "req",
      "methods": [
        "get",
        "post"
      ]
    },
    {
      "type": "http",
      "direction": "out",
      "name": "$return"
    }
  ]
}

/* Scenario type videos are not there in this playlist. */
/* Check and decide */
-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=UzTtastcBsk&ab_channel=AdamMarczak-AzureforEveryone */
/* Azure Storage Tutorial | Introduction to Blob, Queue, Table & File Share */
----------------------------------------------------------------------------------------------
/* Watch one more time for more information */
Azure Storage offers a massively scalable object store for data objects, a file system service for the
cloud, a messaging store for reliable messaging and a NOSQL Store.

Services which are part of Storage Account :- 
i) Blob :- 
ii) File :- 
iii) Queue :- 
iv) Table :- 

i) Blob Storage :- This can hold any kind of text and binary data.This is useful for below scenario.
a) Save image/document in it and it can be accessed by browser.
b) Storing files for distributed access.
c) Streaming video and audio.
d) Storing data for backup & Restore.
e) Storing data for analysis by an on premises or azure hosted service.

Architecture :- 
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Blob.png
Blob storage will have containers and each container will contains files.

ii) File Storage :- Managed file share for cloud or on premises deployements.
Architecture :- 
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\File.png
File Storage will have multiple Shares and each Share contains Files and folders.
/* Get exact meaning of Shares */

File Vs Blob Storage :- 
-------------------------
If file Shares via SMB "Lift & Shift" then choose "File Storage" else "Blob Storage".

iii) Queue Storage :- A messaging store for reliable messaging between application component.
Architecture :- 
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Queue.png
Queue Storage will have multiple Queue and each Queue contains Messages.
This is used as messaging service.

iv) Table Storage :- A NoSQL store for schemaless storage of structured data.
Architecture :- 
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Table.png
Table Storage will have multiple Tables and each Table contains Rows of Data.


/* Create Storage Account in Azure Portal */
https://ms.portal.azure.com/
Search "Storage Account" >>> Create >>> Enable hierarchical namespace >>> Check
Then only "ADLS V2" will be created.
While creating if Enable hierarchical namespace is not selected then normal data lake will be created.
We can see difference in container icon.
By default kind of storage account will be "StorageV2".
Inside this Blob, File, Queue & Table storage will be present. 
Inside storage account of USP, I can see "StorageV2", "Storage" & "Blob" kind of storage account
but now while creating i am able to create only "StorageV2" kind of storage account.
I can see in each kind of storage  Blob, File, Queue & Table storage is present.
In next video difference among "StorageV2", "Storage" & "Blob" kind of storage account is explained.

If we want to create ADLS Gen1 then directly seach "Data Lake Storage Gen1" and create it.
Again here also we can create container and store files.

Since in all these storage account we can store files and manage access to files but can not do 
transformation on the data present in these files.
So here we need to have "Azure Data Analytics" account.Here ADLS account will be present in the
data analytics and there we can write U-SQL script to transform the data.
/* See U-SQL section below */
--------------------------------------------------------------------------------------------------------------
https://www.youtube.com/watch?v=2uSkjBEwwq0&list=PLGjZwEtPN7j9hIHIQJ1Uh6IxEImhWZkPy&index=2&ab_channel=AdamMarczak-AzureforEveryone
/* Azure Data Lake Storage (Gen 2) Tutorial | Best storage solution for big data analytics in Azure */
--------------------------------------------------------------------------------------------------------------
Basic Architecture of data lake storage (By default Gen1) :- 
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\AzureDataLakeStorage.png

Here data lake storage will have container and inside each containers folders and files will be present.
This architecture is a combination of Blob & File storage called "ABFS"(Azure Blob File System).
This file system will be hadoop compatible means hadoop platform can connect on this.
Hadoop Platform :- Hortonworks, Databricks, HD Insight, Cloudera, Hadoop etc..
Now due to multi-protocol access windows platform can also connect.
Windows Platform :- Analytics Service, Power BI, App A, App B etc..

Why Gen2 :- 
Azure data lake storage Gen2(StorageV2/ADLS V2) is a data storage solution designed for big data analytics.
Azure data lake storage Gen2(StorageV2/ADLS V2) is a evolution of Azure data lake storage Gen1 built on top of 
Blob storage.
Here we will get 2 benefits :- 
i) Data Lake Property :- a) Hadoop compatible access b) POSIX permission c) Optimized Driver
ii) Blob Storage :- a) Low Cost b) Storage Tiers c) High Availablity and Disater Recovery

Blob Storage Vs ADLS Gen2 :- 
----------------------------------
                            Blob Storage        ADLS Gen2 
Access Tiers :-             Yes                 Yes
Top Level Organization :-   Container           Container 
Lower Level Organization :- Virtual Directory   Directory  
Data Container :-           Blob                File
Soft Delete :-              Yes                 No
Static Websites :-          Yes                 No
Snapshots :-                Yes                 No
Access Keys :-              Yes                 Yes
Shared Access Signatures :- Yes                 Yes
RBAC :-                     Yes                 Yes
Access Control Lists :-     No                  Yes

/* Create a new ADLS V2 */
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Storage Account Name :- "uspstorageaccountadlsv2"
Enable hierarchical namespace :- Check
Review & Create >>> Done

Container Name :- uspstagingcontainer
Here we can add directory and upload files.

/* https://www.youtube.com/playlist?list=PLGjZwEtPN7j9hIHIQJ1Uh6IxEImhWZkPy */
/* Azure Storage Account Tutorial for beginners - Blob, File, Queue & Table */
/* Complete this tutorials even watch all video from this channel"Azure For Everyone" */

===============================================================================================
_DataLake :- _Data Lake
/* Azure Data Lake Overview */
===============================================================================================
What is Azure Data Lake :- Azure Data Lake is a cloud platform designed to support big data analytics.
It provides unlimited storage for structured, semi-structured or unstructured data. 
It can be used to store any type of data of any size.

Azure Data Lake is built on Azure Blob storage, which is the Microsoft object storage 
solution for the cloud.It can integrate with ADF to run ETL process.

Azure Data Lake is based on Apache Hadoop YARN (Yet Another Resource Negotiator) cluster 
management platform.It can scale dynamically.

What are the Three Parts of Azure Data Lake :- 
--------------------------------------------------
It has three components :- 
i) Storage :- Azure Data Lake Storage 
ii) Analytics Service :- Azure Data Lake Analytics 
iii) Cluster Capabilities :- Azure HDInsight

/* i) Storage :- Azure Data Lake Storage  */
Azure Data Lake Storage provides a single storage platform that organizations can use 
to integrate their data.
It also provides role-based access controls and single sign-on capabilities through 
Azure Active Directory. 

Users can manage and access data within Azure Data Lake Storage using the Hadoop Distributed 
File System (HDFS).
Therefore any tool that we are already using that is based on HDFS will work with Azure Data Lake Storage.

/* ii) Analytics Service :- Azure Data Lake Analytics */
It is an on-demand analytics platform for big data.
Users can develop and run massively parallel data transformation and processing programs 
in U-SQL, R, Python, and .NET languages.

Note :- U-SQL is a big data query language created by Microsoft for the Azure Data Lake Analytics service.

With Azure Data Lake Analytics, users pay per job to process data on demand in an 
analytics as a service environment.

Azure Data Lake Analytics is a cost-effective analytics solution because you pay only 
for the processing power that you use.

/* iii) Cluster Capabilities :- Azure HDInsight */
It is a cluster management solution that makes it easy, fast, and cost-effective to 
process massive amounts of data.
It is a cloud deployment of Apache Hadoop that enables users to take advantage of optimized 
open source analytic clusters for Apache Spark, Hive, Map Reduce, HBase, Storm, Kafka, 
and R-Server. With these frameworks, you can support a broad range of functions, 
such as ETL, data warehousing, machine learning, and IoT. Azure HDInsight also integrates with 
Azure Active Directory for role-based access controls and single sign-on capabilities.

----------------------------------------------------------------------------------------------
/* https://www.bluegranite.com/blog/10-things-to-know-about-azure-data-lake-storage-gen2 */
----------------------------------------------------------------------------------------------
ADLS Gen1  :- Azure Data Lake Storage Gen1 (formerly known as Azure Data Lake Store).
important optimizations important for analytic workloads and more granular security.

Azure Storage :- Specifically blob storage
Geo-redundancy, hot/cold/archive tiers, additional metadata, and broader regional availability 

The new ADLS Gen2 service is built upon Azure Storage as its foundation.
When the hierarchical namespace (HNS) property is enabled, storage account becomes ADLS Gen2.

For any data lake storage account if HNS is enabled then that account is ADLS Gen2.

i) Object Storage :- Azure Blob Storage :- Data objects are stored in a flat namespace 
and represented as binary large objects(blobs).
Object storage is known for being highly scalable and very cost effective.
It’s a mature option for cloud storage with a vast number of implementations.

ii) File System Storage :- Azure Data Lake Storage Gen1 :- 
Data is distributed in blocks in a file system.Here directory will be there and inside that
file will be present.Here security can be implemented at directory and file level.
The file supports also supports atomic operations and metadata only operations
which can improve performance.

iii) Multi Modal Storage :- Azure Data Lake Storage Gen2 :- 
The concept behind ADLS Gen2 is to utilize file system capabilities for analytical
workloads at cost and scalability levels associated with object storage.
ADLS Gen2 is still evolving.


/* Complete structure of ADLS */
File Name :- C:\Users\10662208\Desktop\ABHILASH\Script\"Azure Learning"/Azure_Data_Lake.png

i) File System :- The concept of a container (from blob storage) is referred 
to as a file system in ADLS Gen2.

ii) Hierarchical Namespace (HNS) :- HNS is coupled with DFS end point which enables
the performance and security improvements.

iii) DFS Endpoint and File System Driver :- ADLS Gen2 utilizes the Azure Blob File System
(ABFS) driver, which is part of Apache Hadoop. For connectivity to ADLS Gen2, 
the ABFS driver utilizes the DFS (Distributed File System ) endpoint to invoke 
performance and security optimizations.

ABFS = Azure Blob File System
DFS = Distributed File System 

3. ADLS Gen2 has significant performance and security advantages for analytical workloads
Both the object store model (such as Azure blob storage) and the hierarchical file 
system model (ADLS Gen1 and Gen2) are compatible with HDFS (Hadoop Distributed 
File System). This is achieved with drivers that implement server-side HDFS 
semantics to translate into remote storage APIs, allowing ADLS Gen2 to behave 
very similarly to native HDFS. However, there are important distinctions between 
object storage and hierarchical file system storage in terms of performance and security.

i) Query Performance :- Here partitioning can be done and through query files can be
fetched.

ii) Data Load Performance :- Since files are stored and it’s metadata is maintained.
So metadata operation can be performed very quickly.Like renmae, move etc..

iii) Data Consistency via Atomic Operations :- 

iv) Granular Security at the Directory and File Level :- 

-------------------------------------------------------------------------------------------
5. ADLS Gen2 is the underlying storage for Power BI Dataflows
-------------------------------------------------------------------------------------------
Dataflows can be fully managed by Power BI, in which case the ADLS Gen2 account is present but only visible via the Power BI dataflows user interface. Alternatively, the ‘bring your own storage’ scenario (depicted below) is appropriate for organizations who wish to interact with the data in the data lake via additional tools and compute engines beyond Power BI:

-----------------------------------------------------------------------------------------------------------
/* Azure Data Lake Analytics */
-----------------------------------------------------------------------------------------------------------
============================================================================================================
============================================================================================================
-------------------------------------------------------------------------------------------
https://www.youtube.com/playlist?list=PLWPirh4EWFpGythJYVMF1Wtuts9fVmlyI
/* Azure Data Lake Analytics Playlist */
-------------------------------------------------------------------------------------------
Data Lake :- It is a storage account where any size of data can be stored.
Azure Data Lake :- It is a service provided by microsoft.
It has 2 parts.
i) Data Lake Analytics :- 
ii) Data Lake Store :- 

"Data Lake Analytics" is a service which is used to run big data job(Analytical Job) on the data present in 
"Data Lake Store".In Data Lake Store any sized data can be stored.

/* Architecture of Azure Data Lake :- */
-------------------------------------------------
Azure data lake store is build on top of a open source technology called "webHDFS".
It provodes an interface to connect with data present in Azure data lake store.

On top of Azure data lake store, "Analytics" exist which is also called "Azure Data lake Analytics".
Here we can run big data job in "Azure Data lake Analytics".
Here we can run "U-SQL" or "Spark Job" and also provision Hadoop cluster called "HDInsight".

Difference between Analytics Service and Cluster(HDInsight) :- 
Analytics Service means job as service.(JAAS)
Cluster(HDInsight) means cluster service.(CAAS)

In Cluster(HDInsight)(CAAS), user has to maintain the cluster along with writing code.
but in Analytics Service(JAAS),we need to take care of only submitting job and its content 
like aggregation, filter etc.. 
In this tutorial only Analytics Service(JAAS) has been covered.

/* Why Azure Data lake :- */
-------------------------------------------------
i) It is based on open source webHDFS and apache yarn.
ii) Can move any size on premices data into data lake.
iii) MPP :- Parallize the job .
iv) It can be scaled instatntly.
v) Role based security on objects.

/* Create an Azure Data Lake Analytics Account :- While creating by default Azure Data Lake Storage Gen1 :- uspdevadlaadls
will be created */
Creat an data lake analytics and associate a Azure data lake store :- 
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Name :- uspdevadla
Azure Data Lake Storage Gen1 :- uspdevadlaadls (By Default)
/* Review And Create */
/* Search "Data Lake Analytics" and get the created one */

Note :- While creating Data Lake Analytics account, we are getting option to add an storage account which is of 
ADLS Gen1 type only.Check can we add ADLS Gen2 account or not.

/* uspdevadla */ :- It is a Data Lake Analytics platform where we willl create JOB.
Inside Job we will write U-SQL Script which will get data from Data Lake account.

/* uspdevadlaadls */ :- This a ADLS Gen 1 Storage account where we will keep our data which will be used
by data Analytics.
Now we will create folder and store file in it using "explore Data".

/* Exploring Data Lake Analytics */
-------------------------------------------------
Since we have added a single Azure Data Lake Storage inside Data Lake Analytics.
But we can add more data lake account in it.

Now we will create folder and store file in it using "explore Data".
Data can be uploaded into data lake storage account via 2 ways.
i) Through Azure Portal :- Login to azure portal and upload.
ii) Azure Storage Explorer :- It is a desktop software that allows us to manage data
in azure from different platform.
It is the best way to upload data into data lake storage account.
This software we need to install at source end and provide the connection to storage account.
And from here we can upload files and it will be saved into data lake storage account.

How to install :- go to google and type "azure storage explorer download".
download the file and istall it.
Provide the connection and upload the file into it.
/* https://azure.microsoft.com/en-in/features/storage-explorer/ */
/* Can not install in remote.Try later */

Upload through Portal :- 
Path :- Data Explorer >>> Storage Account >>> uspdevadlaadls (Default) >> New Folder
Create a new folder.(Samplecsv)
Upload File :- 1000_Sales_Records.csv
Refresh after upload.

/* Creating simple Job in Azure data lake analytics */
While submiting any job we need to specify 3 things.
i) U-SQL Script :- Script to fetch and load data and do transformation.
ii) The data :-     What is source of data
iii) AU :- Analytical Unit :- It is the resources required for job to run.

Job Requirement :- Copy a file data from one folder to another folder in another file.
using U-SQL script.
Source Data :- /Samplecsv/1000_Sales_Records.csv
Target Data :- /target/result.csv

Create a new Job :- 
Name :- mysampleusqljob

@data = EXTRACT Region	  string,
        Country	  string,
        ItemType  string,
        SalesChannel  string,
        OrderPriority  string,
        OrderDate  string,
        OrderID  string,
        ShipDate  string,
        UnitsSold  string,
        UnitPrice  string,
        UnitCost  string,
        TotalRevenue  string,
        TotalCost  string,
        TotalProfit  string
FROM "/Samplecsv/1000_Sales_Records.csv"
USING Extractors.Csv(skipFirstNRows:1);

OUTPUT @data TO "/target/result.csv"
USING Outputters.Csv();

Here we also need to select AU.According to this value price will be calculated.
Select Au = 1
Submit >>> Automatically it will run.
/* Ran successfully and copied into "result.csv" file.

/* Explanation of U-SQL :- */
------------------------------------
U-SQL is a microsoft language for big data.
It is a combination of SQL and C#.
It uses ROWSET variables.It uses all data types from .Net.So can use all function from .Net

Sample Query :- 
@data = EXTRACT id int,
        Name string,
        City String
FROM "/Samplecsv/1000_Sales_Records.tsv"
USING Extractors.Tsv(skipFirstNRows:1);

OUTPUT @data TO "/target/result.csv"
USING Outputters.Csv();

i) Here we are useing a .tsv file.So we need to use Extractors.Tsv class.
similarly at target end we are using result.csv file.So need to use Outputters.Csv() class.

What are Extractors :- 
Commonaly used extractors :- 
i) Extractors.Text :- Normal text file
ii) Extractors.Csv :- Comma seprated file.
iii) Extractors.Tsv :- Tab seprated file.

What are Outputters :- 
Commonaly used Outputters :- 
i) Outputters.Text :- Normal text file
ii) Outputters.Csv :- Comma seprated file.
iii) Outputters.Tsv :- Tab seprated file.

We can write U-SQL script in Visual studio and run it.We need to install data Lake 
extension.But here i am going to execute directly on azure portal.

/* https://docs.microsoft.com/en-us/azure/data-lake-analytics/data-lake-analytics-data-lake-tools-get-started */
/* Learn from here how to connect to data lake from Visual Studio 8/

-------------------------------------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/azure/data-lake-analytics/data-lake-analytics-u-sql-get-started */
/* Sample U-SQL Script */
-------------------------------------------------------------------------------------------------------------
1) The following text is a simple U-SQL script. It defines a small dataset 
and writes that dataset to the default Data Lake Store as a file called /data.csv.

Job Name :- SampleUSQL-1
USE DATABASE master;
USE SCHEMA dbo;
@a  = 
    SELECT * FROM 
        (VALUES
            ("Contoso", 1500.0),
            ("Woodgrove", 2700.0)
        ) AS 
              D( customer, amount );
OUTPUT @a
    TO "/data.csv"
    USING Outputters.Csv();

2) This script doesn’t have any transformation steps. 
It reads from the source file called SearchLog.tsv, schematizes it, and writes 
the rowset back into a file called SearchLog-first-u-sql.csv.

Full File Path :- adl://mystore.azuredatalakestore.net/Samples/Data/SearchLog.tsv
Relative Path :- /output/SearchLog-first-u-sql.csv

@searchlog =
    EXTRACT UserId          int,
            Start           DateTime,
            Region          string,
            Query           string,
            Duration        int?,
            Urls            string,
            ClickedUrls     string
    FROM "/Samples/Data/SearchLog.tsv"
    USING Extractors.Tsv();

OUTPUT @searchlog
    TO "/output/SearchLog-first-u-sql.csv"
    USING Outputters.Csv();

3) Use scalar variables :- 

DECLARE @in  string = "/Samples/Data/SearchLog.tsv";
DECLARE @out string = "/output/SearchLog-scalar-variables.csv";
@searchlog =
    EXTRACT UserId          int,
            Start           DateTime,
            Region          string,
            Query           string,
            Duration        int?,
            Urls            string,
            ClickedUrls     string
    FROM @in
    USING Extractors.Tsv();
OUTPUT @searchlog
    TO @out
    USING Outputters.Csv();

4) Transform rowsets :- 
@searchlog =
    EXTRACT UserId          int,
            Start           DateTime,
            Region          string,
            Query           string,
            Duration        int?,
            Urls            string,
            ClickedUrls     string
    FROM "/Samples/Data/SearchLog.tsv"
    USING Extractors.Tsv();
@rs1 =
    SELECT Start, Region, Duration
    FROM @searchlog
WHERE Region == "en-gb";
OUTPUT @rs1
    TO "/output/SearchLog-transform-rowsets.csv"
    USING Outputters.Csv();

5) 
@searchlog =
    EXTRACT UserId          int,
            Start           DateTime,
            Region          string,
            Query           string,
            Duration        int,
            Urls            string,
            ClickedUrls     string
    FROM "/Samples/Data/SearchLog.tsv"
    USING Extractors.Tsv();
@rs1 =
    SELECT Start, Region, Duration
    FROM @searchlog
WHERE Region == "en-gb";
@rs1 =
    SELECT Start, Region, Duration
    FROM @rs1
    WHERE Start >= DateTime.Parse("2012/02/16") AND Start <= DateTime.Parse("2012/02/17");
OUTPUT @rs1
    TO "/output/SearchLog-transform-datetime.csv"
    USING Outputters.Csv();

6) Aggregate rowsets :- 
DECLARE @outpref string = "/output/Searchlog-aggregation";
DECLARE @out1    string = @outpref+"_agg.csv";
DECLARE @out2    string = @outpref+"_top5agg.csv";
@searchlog =
    EXTRACT UserId          int,
            Start           DateTime,
            Region          string,
            Query           string,
            Duration        int?,
            Urls            string,
            ClickedUrls     string
    FROM "/Samples/Data/SearchLog.tsv"
    USING Extractors.Tsv();
@rs1 =
    SELECT
        Region,
        SUM(Duration) AS TotalDuration
    FROM @searchlog
GROUP BY Region;
@res =
    SELECT *
    FROM @rs1
    ORDER BY TotalDuration DESC
    FETCH 5 ROWS;
OUTPUT @rs1
    TO @out1
    ORDER BY TotalDuration DESC
    USING Outputters.Csv();
OUTPUT @res
    TO @out2
    ORDER BY TotalDuration DESC
    USING Outputters.Csv();
/* https://docs.microsoft.com/en-us/u-sql/built-in-functions */
/* Advance level U-SQL.Learn it */

----------------------------------------------------------------------------------
----------------------------------------------------------------------------------
/* What is Analytical Unit :- (AU) :- */
It is a unit of compute resource.
USQLs jobs need AUs to execute their work.
1AU = 2 CPU Cores and 6 GB of RAM.
More AUs increase parallelism of a job.
In future microsoft can provide us the flexibility to control CPU and memory usage.

/* Stages of job */
-------------------------
i) Preparing :- Here script is loaded into azure and compiled and plans are getting prepared.
Here we can get compile error.

ii) Queuing :- Here jobs wait for resources(AU) to be allocated.
If all AUs are already in use then jobs needs to wait here.
Here we can get timeout error.

iii) Running :- In this phase actually data is copied.
Only for this activity prices are calculated.
Here we can get execution error.

iv) Finalzing :- Here Jobs finalizes the output file.

/* What Happens When you Submit a Job */
---------------------------------------------
When we submit any U-SQL script, the U-SQL compiler looks at the script & data and 
creates an input plan.
Now the plan is divided into individual tasks called a vertex.
Suppose we have submitted a job and it is divided into 4 vertex.
If we have allocated only 1 AU then initially 1st vertext will be completed.
Then AU will be released and it will be assigned to 2nd vertex.
and this way job will be completed.
If vertex has to work on same data then vertices will be grouped together and it is 
called "Stage" or "Super Vertex".
If we have more no of AUs then vertices can run parally.

/* Job Graph */
----------------------
When job runs and whether it fails or completed, it produce a job graph.
It has a input data set and output data set.
R :- How much amount of data read.
W :- How much amount of data written.

/* Job Heat Map */
-----------------------
IN graph page there is a drop down called display inside that by default progress will 
be displayed.Choose below option and see the result.
Using job heat map, we can visualize job graph using
i) Job Progress :- 
ii) Job Time :- 
iii) Data read :- 
iv) Data Written :- 


/* Schema on Read */
----------------------
Traditional RDBMS has strategy of "Schema on write".(SOW) means
here first we create schema(DB/Schema) and then we load data into it.
If incoming data is not fitiing into created schema then it will not be loaded.
Once data got loadedd we can use the data.

Azure Data lake Analytics is "Schema On Read" (SOR) means
here we do not worry about how data is coming.Any kind of data we can dump and when
we need to read the data we can define schema.
So here we have flexibility on data according to requirement.

/* Azure Data Lake Aggregating data */
--------------------------------------------
Three steps to perform aggregation :- 
i) Extracting the data
ii) Perform the aggregation using GROUP BY clause and an aggregate function.
iii) Output the data to a file.

<Job Name> = GetAggregateOnRegion

@data = EXTRACT Region	  string,
        Country	  string,
        ItemType  string,
        SalesChannel  string,
        OrderPriority  string,
        OrderDate  string,
        OrderID  string,
        ShipDate  string,
        UnitsSold  string,
        UnitPrice  string,
        UnitCost  string,
        TotalRevenue  string,
        TotalCost  string,
        TotalProfit  float
FROM "/Samplecsv/1000_Sales_Records.csv"
USING Extractors.Csv(skipFirstNRows:1);

@summirizeddata = SELECT Region,SUM(TotalProfit) AS RegionTotalProfit
                   FROM @data GROUP BY Region;

OUTPUT @summirizeddata TO "/target/summirizeddata.csv"
USING Outputters.Csv();

O/P :- Aggregate data is availble on "/target/summirizeddata.csv" file.

/* Azure Data Lake Filtering data */
--------------------------------------------
Three steps to perform aggregation :- 
i) Extracting the data
ii) Filter the data using WHERE CLAUSE or can use any C# function.
iii) Output the data to a file.

<Job Name> = GetFilterOnRegion

@data = EXTRACT Region	  string,
        Country	  string,
        ItemType  string,
        SalesChannel  string,
        OrderPriority  string,
        OrderDate  string,
        OrderID  string,
        ShipDate  string,
        UnitsSold  string,
        UnitPrice  string,
        UnitCost  string,
        TotalRevenue  string,
        TotalCost  string,
        TotalProfit  float
FROM "/Samplecsv/1000_Sales_Records.csv"
USING Extractors.Csv(skipFirstNRows:1);

@filterddata = SELECT Region,Country,TotalProfit
                FROM @data WHERE Region == "Asia";

OUTPUT @filterddata TO "/target/filterddata.csv"
USING Outputters.Csv();

O/P :- Filteres data is availble on "/target/filterddata.csv" file.
/* Note :- Learn how to use C# function in where clause. */


/* Pulling Data From Multiple Files */
--------------------------------------------
Steps to perform in order to pull data from multiple files :- 
i) Since we are fetching data from multiple sources, so we need to define schema.
ii) Upload data into azure data lake storage account using azure portal or Azure explorer.
iii) Extract the data using a standard Extractors.
iv) Perform aggregation using GROUP BY clause.
v) Output the data to a file.
vi) Output the data to the file.

We have two files 1000_Sales_Records.csv and 1000_Sales_Records_1.csv
inside samplecsv folder.Now will fetch all these files and merged into a single file
and store in result folder.

<Job Name> = GetAggregateOnRegionAllFiles

@data = EXTRACT Region	  string,
        Country	  string,
        ItemType  string,
        SalesChannel  string,
        OrderPriority  string,
        OrderDate  string,
        OrderID  string,
        ShipDate  string,
        UnitsSold  string,
        UnitPrice  string,
        UnitCost  string,
        TotalRevenue  string,
        TotalCost  string,
        TotalProfit  float
FROM "/Samplecsv/{*}.csv"
USING Extractors.Csv(skipFirstNRows:1);

@summirizeddata = SELECT Region,SUM(TotalProfit) AS RegionTotalProfit
                   FROM @data GROUP BY Region;

OUTPUT @summirizeddata TO "/target/allfilessummirizeddata.csv"
USING Outputters.Csv();

O/P :- all file data is availble on "/target/allfilessummirizeddata.csv" file.


/* U-SQL Catalog */
--------------------------
Whenever we create azure data lake analytics account, automatically we get azure
U-SQL catalog.
Data Explorer >>> Catalog

U-SQL catalog is the way U-SQL organises data and code for Re-use.
Every ADLA account has 1 USQL catalog.
Each USQL catalog has 1 database by default and name is master database.
But user can create multiple databases.
In U-SQL databases, data is stored in "Table".
Reusable codes are stored in the form of :- 
a) Views b) Table Valued Functions c) Stored Procedures


/* Creating a Database */
--------------------------
Create a Job :- CreateDB
CREATE DATABASE IF NOT EXISTS SALES;

/* Creating Schema and Tables */
----------------------------------
Schema is used to organize objects in a database.
Suppose we have a DB and inside this we want to store employees information.
but we do not want to mix IT and HR employees data.
So here we can create 2 schema.IT and HR schema and now we can create table inside it.
IT.Employee and HR.Employee.

Syntax to create Schema INSIDE SALES DB:- 
<Job Name> :- Createschematable
USE DATABASE SALES;
CREATE SCHEMA IF NOT EXISTS IT;

CREATE TABLE IT.Employees(
Empid string,
EmpName int
);

/* Inserting data into table */
Step 1 :- Extraction of files from data lake store.
Step 2 :- Insert into select statement.

File Name :- Emp.csv
Empid,EmpName
1,A
2,B
3,C
4,D
5,E

<Job Name> = InserttoEmployees

USE DATABASE SALES;

CREATE TABLE IT.Employeesnew(
Empid int,
EmpName string ,
INDEX clx_EmpID CLUSTERED(Empid ASC) DISTRIBUTED BY HASH(Empid)
);

@data = EXTRACT Empid	  int,
        EmpName	  string
FROM "/Samplecsv/Emp.csv"
USING Extractors.Csv(skipFirstNRows:1);

INSERT INTO IT.Employeesnew
SELECT * FROM @data;

/* Check whether data got inserted or not in the table */
In U-SQL we can not query data like SQL.We need to write another job to query data.
Data can not be shown as temporarily like in SQL.
Here we need to create a job and that job will get the data into a file.
Here azure directly provides us the job content to get the data from table.
Click on "Query table" and automatically it open a new job where content will be written.

<Job NAme> :- Query [SALES].[IT].[Employeesnew]

@table = SELECT * FROM [SALES].[IT].[Employeesnew];

OUTPUT @table
    TO "/Outputs/SALES.IT.Employeesnew.tsv"
    USING Outputters.Tsv();

/* Create View */
---------------------------------
Views are nothing but the saved SQL query. It can also be considered as a virtual table.
View in U-SQL is similar to views in relational database.
We can use views to encapsulates logic.


<Job NAme> :- CreateViewEmployeesnew

USE DATABASE SALES;
CREATE VIEW IT.V_Employeesnew
AS
SELECT * FROM IT.Employeesnew;

/* QUERY THE VIEW */
Here also we need to write a job to fetch data from view and that data will be stored
in the specified file.
Click On Query View :- 

<Job Name> = Query [SALES].[IT].[V_Employeesnew]

@view = SELECT * FROM [SALES].[IT].[V_Employeesnew];

OUTPUT @view
    TO "/Outputs/SALES.IT.V_Employeesnew.tsv"
    USING Outputters.Tsv();

/* Create a Table Valued Function (TVF) */
-----------------------------------------
In TVF, return type is a table.
Create a TVF which will return employee’s information according to passes empid.

<Job Name> = CreateTVF

USE DATABASE SALES;
CREATE FUNCTION IT.TVF_Emp_Record (@EmpId int)
RETURNS @EmpRecord TABLE
(
    EmpId int,
    EmpName string
)
AS 
BEGIN

@data = SELECT Empid,EmpName FROM SALES.IT.V_Employeesnew
        WHERE Empid == @Empid;
END;


/* Execute a Table Valued Function (TVF) */
-----------------------------------------------
Create a job to query the TVF.
While executing pass the required parameter.
Output the result to a file in data lake store.

U-SQL :- Catalog >>> Query TVF

<Job Name> = Query [SALES].[IT].[TVF_Emp_Record]

@tvf = [SALES].[IT].[TVF_Emp_Record](1);

OUTPUT @tvf
    TO "/Outputs/SALES.IT.TVF_Emp_Record.tsv"
    USING Outputters.Tsv();
/* Not running.Check */
/* https://www.youtube.com/watch?v=mqztjuaGdGw&list=PLWPirh4EWFpGythJYVMF1Wtuts9fVmlyI&index=30 */
/* Watch from here to complete */


====================================================================================
====================================================================================
_keyvault
/* https://www.youtube.com/playlist?list=PLMWaZteqtEaKUh7lI8qqiaf5KScGtHbFq */
/* Azure Key Vault */
-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=JDRixckApxM&list=PLMWaZteqtEaKUh7lI8qqiaf5KScGtHbFq&index=1&ab_channel=WafaStudiesWafaStudies */
/* 1. Introduction to Azure Key Vault */
-----------------------------------------------------------------------------------------
Inside Azure Key vault we store sensitive application related information
like password, SSL certificates etc..

Azure Key Vault :- 
i) Secrets Managements :- Here we can stores tokens, Passwords, certificates, API
keys and other secrets.Here we can also control who can access these secrets.

ii) Key managements :- Uisng encryption keys we can encrypt our data present in key vault.

iii) Certificates Management :- Here we can store TLS/SSL certificates.

iv) Store Secrets backed by Hardware Security Modules :- Here secrets and keys can 
be protected either by software or FIPS 140-2 level validated HSMs.


-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=Rb7qz_emvsg&list=PLMWaZteqtEaKUh7lI8qqiaf5KScGtHbFq&index=2&ab_channel=WafaStudiesWafaStudies */
/* 2. Store Secrets in Azure Key Vault using Azure Portal */
-----------------------------------------------------------------------------------------
Create a Key Voult :- 
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Key vault name :- uspdemokeyvault
Vault URI/DNS Name :- https://uspdemokeyvault.vault.azure.net/

How to store a secret in Key Vault :- 
Go to "secrets"(Below settings).
Generate/Import :- 
Upload Options :- Manual/Certificate >>> Manual
Name :- MySecret
Value :- 12345
Type :- pwd (Optional)
Enabled :- Yes
>>> Create
For each secret an URL will be generated.
/* https://uspdemokeyvault.vault.azure.net/secrets/MySecret/066d018f5fa94284bcf267b49e73843d */
We can use this URL while making any connection.

If we want to update our secrets/Password then :- create a new version.
Again a new URL will be generated and we can use it.

/* END */ /* Get more knowledge on azure Key Vault */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=PgujSug1ZbI&ab_channel=AdamMarczak-AzureforEveryone */
/* Azure Key Vault Tutorial | Secure secrets, keys and certificates easily */
-----------------------------------------------------------------------------------------
Req :- Create Keyvault and use it in Azure Data Factory.
Fetch emp.csv file from blob input data storage and copy to output folder.

Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Storage Account Name :- "uspstorageaccountnew"
ContainerName :- "uspstagingcontainer"


Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Key vault name :- uspdemokeyvault
Vault URI/DNS Name :- https://uspdemokeyvault.vault.azure.net/

Data Factory Directly can not connect to KeyVault.It requires access from KeyVault.
/* How to give access to Data Factory. */
Data Factory Name :- uspstorageadf.

uspdemokeyvault >>> Access Policy :- 
Key Permission :- Select All
Secret Permission :- Select All
Certificate Permission :- Select All
Select Principle :- /* Data Factory Name */ :- uspstorageadf
Select >>> Add >> Save


Create a Linked Service :- 
1) First create a Azure KeyVault Linked Service.
+ New :- Select Azure Key Vault :- Continue
Name :- LS_MyKv
Azure Subscription :- ES-LOB-USP-DEV
Azure KeyVault Name :- uspdemokeyvault

2) Get Connection string of Storage Account :- 
Storage Account :- uspstorageaccountnew
Access Keys :- (Security & Networking)
Key 1 >> Connection Strings :- 
DefaultEndpointsProtocol=https;AccountName=uspstorageaccountnew;AccountKey=gp0XnD19MdVHZdDUYBZdz5yjsxafV9HEFibsX+C1Ncqkc3JFrrEbO0HSJO+4InfRRZSpdN5leBH6EnO4MCg1Pw==;EndpointSuffix=core.windows.net
/* Copy This */

3) Generate a secret of this Connection string :- 
uspdemokeyvault :- Go to "secrets"(Below settings).
Generate/Import :- 
Upload Options :- Manual/Certificate >>> Manual
Name :- Storageuspstorageaccountnew /* Secret Name */
Value :- /* Connection Strings */ :- DefaultEndpointsProtocol=https;AccountName=uspstorageaccountnew;AccountKey=gp0XnD19MdVHZdDUYBZdz5yjsxafV9HEFibsX+C1Ncqkc3JFrrEbO0HSJO+4InfRRZSpdN5leBH6EnO4MCg1Pw==;EndpointSuffix=core.windows.net
Type :- (Optional)
Enabled :- Yes
>>> Create

4) Create a main Linked Service which will point to storage account using KeyVault.
+ New :- Select Azure table storage :- Continue
Name :- LS_MyKv_Storageuspstorageaccountnew
AKV Linked Service :- LS_MyKv
Secret Name :- /* Created in last step */ :- Storageuspstorageaccountnew
Secret Version :- By Default latest version

5) Create a dataset using linked service :- LS_MyKv_Storageuspstorageaccountnew
Dataset Name :- DS_input_emp
Linked Service Name :- LS_MyKv_Storageuspstorageaccountnew
File path :- uspstagingcontainer/input/Emp.csv

Conclusion :- 
1) Grant access to ADF from azure keyvault.(Must)
i) First create a keyvault linked service.
ii) Go to Keyvault and create the secret. (Get/Create Connection string for Source)
iii) Create a new linked Service and select newly created keyvault and secret.
iv) Create a dataset using newly created linkedservice.




-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------



-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------





-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------

=========================================================================================
=========================================================================================
_Databricks
https://www.youtube.com/watch?v=bO7Xad1gOFQ&list=PLMWaZteqtEaKi4WAePWtCSQCfQpvBT2U1
/* Azure Databricks Full Playlist */
-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=bO7Xad1gOFQ&list=PLMWaZteqtEaKi4WAePWtCSQCfQpvBT2U1&ab_channel=WafaStudiesWafaStudies */
/* 1. Introduction to Azure Databricks */
-----------------------------------------------------------------------------------------
Azure databricks is an apache Spark based Analytics platform optimized for the microsoft
azure cloud service platform.

Usage Of Databricks :- A business has multiple applications and these applications keep
their data at different differemt place.
These data will be big data like big csv file which may contain structured or non structured data.
First using ADF these data file will be dumped to non structured data storage like data lake,
blob data storage account, kafka etc..
From this point Databricks usage will start.

Now databricks will be used to move this data from Data lakestore to databse for analysis on data.
These target database can be Cosmos DB, SQL Database, SQL Dataware house, Analysis service etc..
So basically databricks is used to transform big data.

Non azure system were using "Apache Spark" framework to do this.
Now Microsoft and "Apache Spark" made this "Azure Databricks" framework.

Apache Spark EcoSystem :- 
------------------------------
i) Spark SQL DataFrames :- Can deal with relational data.
ii) Streaming :- Transformation of data
iii) MLlib MAchine Learning
iv) GraphX Graph Computation

Spark Core API :- Whatever processing or transformation logic we will apply we can write
it using below mentioned languages.
i) R ii) SQL iii) Python iv) Scala v) Java

Inside Azure Databricks a Databricks Workspace will be created which will be used for 
collabration among data scientist, data engineer & Business Analyst.

Inside "Databricks Workspace" we will have "Notebook" where we will write our transformation
logic using above mentioned language.

For Apache Spark system All these transformation language are going to execute 
on "Apache Spark Cluster".
Inside Azure we can create these server very easily in few clicks and it will create
cluster for us to execute our query.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=S3lI9cpaUy8&list=PLMWaZteqtEaKi4WAePWtCSQCfQpvBT2U1&index=3&ab_channel=WafaStudies */
/* 2. Create an Azure Databricks Workspace using Azure Portal */
-----------------------------------------------------------------------------------------
/* Azure Databricks doesn't work on Free trial.It needs to be upgraded */
Create Azure Databricks Service :- 
Search Azure Data bricks and click on "Create".

Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
WorkSpace Name :- uspLocalDatabricks
Region :- Code
Pricing Tier :- Standard (By Default)
Create >> This will create a "WorkSpace".
"Launch WorkSpace"

i)New Notebook :- This is the place where we will write our script(R,Python,Java etc..)
and here it will be stored.And this notebook will be executed in databricks env.
So inside databricks we will have a cluster/Compute Engine where this notebook(Script) will be executed.
So we have to create a "Spark Cluster"(Will work as Compute Engine) And then we will attach our notebook to this
"Spark Cluster".

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=laeuQnNuiqs&list=PLMWaZteqtEaKi4WAePWtCSQCfQpvBT2U1&index=3&ab_channel=WafaStudiesWafaStudies */
/* 3. Create Databricks Community Edition Account */
-----------------------------------------------------------------------------------------
Create account in cloud community databricks.Since free trial for databricks does not work in azure.
I will continue in azure microsoft.
Since not able to access MS account. SO creating trial account.

/* URL :- https://community.cloud.databricks.com/login.html */
User Name :- abhi.cvraman@gmail.com

After Login :- /* https://community.cloud.databricks.com/?o=895103653122863# */
Creating A new Cluster :- 
Cluster Name :- TestCluster
DataBrciks Run Time Version :- Run Time 8.3 (Scala 2.12, Spark 3.1.1)
/* Create CLuster */




-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=OUVUiVbI2UU&ab_channel=WafaStudiesWafaStudies */
/* 4. Workspace in Azure Databricks */
-----------------------------------------------------------------------------------------
Workspace :- An azure databricks workspace is an environment for accessing all our 
azure databricks assets.
The workspace organizes below objects into folders.
i) Notebook :- 
ii) Libraries :- 
iii) Experiments :- Machine Learning

Workspace can be managed using Workspace UI, databricks CLI and Databricks REST API.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=8oobJhnWp6k&ab_channel=WafaStudiesWafaStudies */
/* 5. Workspace assets in Azure Databricks */
-----------------------------------------------------------------------------------------
Workspace Assets :- 
i) Computes/Clusters :- It is a set of computation resources and configurations on we run our
data engineering, data science & data analytics workload such as production ETL pipeline,
streaming analytics, ad-hoc analytics & machine learning.
While creating a new Notebook, it will ask for a Cluster.Even without providing cluster
name we can proceed but at the time of Notebook execution cluster is mandatory amd we need to create it.
After creation we need to attach that cluster to Notebook.
Code written in that Notebook will be executed in that cluster only.

ii) + Create/Notebooks :- A notebook is a web based interface to documents containing a series of
runnable cells (commands) that operates on files and tables, visulation and narattive text.
Commands can run in sequence referring to the output of one or more previously run commands.

+ Create >> Notebook :- Here we can write our code.It can be written in below language.
i) R ii) SQL iii) Python iv) Scala v) Java

iii) Jobs :- It is a mechanism for running code in Azure Databricks.
The code written in Notebook can be run using Jobs at scheduled time.

iv) Libraries :- /* Not available in current version */ :- A library makes 3rd party or locally built 
code availble to notebooks and jobs running on our clusters.

v) Data :- Here we can import data into a databricks workspace and can work with it in 
azure databricks notebooks and cluster.We can use wide range of apache spark data sources
to access data.

vi) Experiments :- /* Not available in current version */ :- It allows us to run MLflow machine laerning model training.

vii) Workspace :- /* Explained in next video */
-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=lX0cLEAzMT4&ab_channel=WafaStudiesWafaStudies */
/* 6.Working with Workspace Objects in Azure Databricks */
-----------------------------------------------------------------------------------------
How to work with folders and other workspace objects in Azure Databricks :- 
Specials Folders in Azure Databricks :- It has three special folders.
Click On Workspace :- It will have 3 folders.
i) Workspace :- 
ii) Shared :- 
iii) Users :- 
These folders can not be moved or renamed.Workspace is the root folder.

i) Workspace :- 
Inside that Shared & Users will be present.
Workspace folder contains all organisation’s azure databricks static assets.
Every workspace has a workspace Id(Unique Id) which is the digit after "o=" from URL.
Data Bricks URL :- https://adb-7699593049064036.16.azuredatabricks.net/?o=7699593049064036
workspace Id = 7699593049064036
Ashish :- https://adb-3222624546457634.14.azuredatabricks.net/?o=3222624546457634#
workspace Id = 3222624546457634

ii) Shared :- Any objects placed inside this folder will be shared among all 
team members of that organisation.

iii) Users :- All objects placed inside this folder will be a private one.Except user no one can access it.
If we want to give access to other user then we need to add user’s emailId through "Admin Console".
Here folder willl be created for each user and Notebook present inside that folder will only be accessible
to that user only.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=9p4Evw7EzTw&ab_channel=WafaStudies */
/* 7. Create and Run Spark Job in Databricks */
-----------------------------------------------------------------------------------------
Requirement :- I have a csv file containing employee information.
upload this file in databricks server.
Then create a table for this data and get average salary of employee on certain category.

Also create a cluster forst where this query will run.

Cluster Name :- uspdevcluster
Cluster Mode :- Standard
Databricks Run time version :- 8.2 (Scala 2.12 Spark 3.1.1) (By default)

Employee.csv :- 
A	30	Male
B	31	Male
C	32	Male
D	33	Male

/* upload Employee.csv file */
Data >>> Default >>> Create Table
File uploaded to /FileStore/tables/employee.csv

Go to DBFS :- /* Databricks File System */
Then go to FileStore >>> tables >>> employee.csv

Create Notebook :- 
i) Notebook Name :- CreateTable
ii) Default language :- SQL
iii) cluster :- uspdevcluster
/* Notebook Created inside user >>> v-abku13@microsoft.com */

/* Now inside Notebook we will create table from uploaded CSV file. */
DROP TABLE IF EXISTS employee;
CREATE TABLE employee USING CSV OPTIONS (path "/FileStore/tables/employee-4.csv",header "true");
select * from employee;
select Name from employee;

O/P :- 
/* It is displaying data */
/* The way we are doing query on table can be done here */
/* Created table will be present inside Data >>> Default (Database) >>> employee */
/* Here we can also create our own DB and inside that can store table */

/* Wafastudies Playlist is not completed. Try to find out more videos on Databricks */
/* Video not available in youtube.Started reading from Microsoft documentation */

-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/azure/databricks/scenarios/quickstart-create-databricks-workspace-portal?tabs=azure-portal */
/* Quickstart: Run a Spark job on Azure Databricks Workspace using the Azure portal */
-----------------------------------------------------------------------------------------

Requirement :- Read a file present in blob storage account and create a TempView from the
data present in the file.Then using SQL display data into screen.

Connect to Storage Account from Databricks :- Go to "uspstorageaccountnew" >> Security + Networking >> Shared Access Signature
click the Generate SAS and connection string button
Copy text from SAS Token field.
Keep this token in a variable in Notebook and write syntax to connect to Storage Account


/* Create a new WorkSpace */
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
WorkSpace Name :- uspLocalDatabricks
Region :- Code
Pricing Tier :- Standard (By Default)
Create >> This will create a "WorkSpace".
"Launch WorkSpace"

/* Create a new cluster */
Cluster Name :- uspdevcluster
Cluster Mode :- Standard
Databricks Run time version :- 8.2 (Scala 2.12 Spark 3.1.1) (By default)

/* File Storage Detail */
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
Folder Name :- input
File Name :- Emp.csv

Create blob_sas_token for "uspstorageaccountnew" storage account.
Go to "uspstorageaccountnew" >> Security + Networking >> Shared Access Signature
click the Generate SAS and connection string button
/* Copy text from SAS Token field :-  */
?sv=2020-02-10&ss=bfqt&srt=sco&sp=rwdlacuptfx&se=2021-06-15T22:26:13Z&st=2021-06-15T14:26:13Z&spr=https&sig=Cnlgkje1I0X4%2B2Qe6WUxr1Te2x7lbzMABgY3aDaDQCQ%3D

Create Notebook :- 
i) Name :- MyNotebook
ii) Default language :- Python
iii) cluster :- uspdevcluster

/*
Note :- Read data from any kind of file documentation using sparksql
https://spark.apache.org/docs/2.0.1/api/python/pyspark.sql.html

Sample Code for .csv file :- 
spark.read.csv(path, schema=None, sep=None, encoding=None, quote=None, escape=None, comment=None, header=None, inferSchema=None, ignoreLeadingWhiteSpace=None, ignoreTrailingWhiteSpace=None, nullValue=None, nanValue=None, positiveInf=None, negativeInf=None, dateFormat=None, timestampFormat=None, maxColumns=None, maxCharsPerColumn=None, maxMalformedLogPerPartition=None, mode=None)
*/

/* Code */
from pyspark.sql import *
import pandas as pd

#/* Azure Storage Access Information */
blob_account_name = "uspstorageaccountnew"
blob_container_name = "uspstagingcontainer"
blob_relative_path = "input/Emp.csv"
blob_sas_token = r"?sv=2020-02-10&ss=bfqt&srt=sco&sp=rwdlacuptfx&se=2021-06-15T22:26:13Z&st=2021-06-15T14:26:13Z&spr=https&sig=Cnlgkje1I0X4%2B2Qe6WUxr1Te2x7lbzMABgY3aDaDQCQ%3D"

#/* Read file from blob storage */
wasbs_path = 'wasbs://%s@%s.blob.core.windows.net/%s' % (blob_container_name, blob_account_name, blob_relative_path)
spark.conf.set('fs.azure.sas.%s.%s.blob.core.windows.net' % (blob_container_name, blob_account_name), blob_sas_token)
print('Remote blob path: ' + wasbs_path)

#/* Create DataFrame */
#df = spark.read.parquet(wasbs_path)
df = spark.read.csv(wasbs_path,header=True)
print(df)
print('Register the DataFrame as a SQL temporary view: source')
df.createOrReplaceTempView('source')
print('Displaying top 10 rows: ')
display(spark.sql('SELECT * FROM source LIMIT 10'))

O/P :- 
/* Data is coming Fine */

Explanation :- 
createorReplaceTempView is used when we want to store the table for a particular spark session.
CreateOrReplaceTempView will create a temporary view of the table on memory it is 
not presistant at this moment but we can run sql query on top of that. 
If we want to save it we can either persist or use saveAsTable to save.
createOrReplaceTempView creates a lazily evaluated "view" that you can then use like a hive table in Spark SQL
First we read data in csv format and then convert to data frame and create a temp view (createOrReplaceTempView).

-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
/* Own 1 :- */
Requirement :- Create a temp view on the uploaded file in DBFS.

cat > Employee.csv
A	30	Male
B	31	Male
C	32	Male
D	33	Male

Create Notebook :- 
i) Name :- MyNotebook-1
ii) Default language :- Python
iii) cluster :- uspdevcluster

/* Code */
from pyspark.sql import *
#import pandas as pd

#/* Read file from DBFS storage */
wasbs_path = '/FileStore/tables/employee-4.csv'
print('Remote blob path: ' + wasbs_path)

#/* Create DataFrame */
df = spark.read.csv(wasbs_path,header=True)
print(df)
print('Register the DataFrame as a SQL temporary view: source')
df.createOrReplaceTempView('source')
print('Displaying top 10 rows: ')
display(spark.sql('SELECT * FROM source LIMIT 10'))


O/P :- 
Remote blob path: /FileStore/tables/employee-4.csv
DataFrame[Name: string, Age: string, Gender: string]
Register the DataFrame as a SQL temporary view: source
Displaying top 10 rows: 


/* Own 2 :- */
Req 2 :- Get EMP and Dept from ADLS storage and create two Global temp view and 
join these 2 data frame and try to get results.

Create Notebook :- 
i) Name :- GetEMPADFS
ii) Default language :- Python
iii) cluster :- uspdevcluster


#/* Code */
from pyspark.sql import *
import pandas as pd

#/* Azure Storage Access Information */
blob_account_name = "abksynapseadlsgen2"
blob_container_name = "abksynapsecontainer"
blob_relative_path = "input/Emp.csv"
blob_relative_path1 = "input/Dept.csv"

blob_sas_token = r"?sv=2020-08-04&ss=bfqt&srt=sco&sp=rwdlacupx&se=2021-08-24T23:12:15Z&st=2021-08-24T15:12:15Z&spr=https&sig=MO8nl9VXek27T1GatYbx%2BKw57KVRDuzC1XdYpK%2BPH5k%3D"

#/* Read file from blob storage */
wasbs_path = 'wasbs://%s@%s.blob.core.windows.net/%s' % (blob_container_name, blob_account_name, blob_relative_path)
wasbs_path1 = 'wasbs://%s@%s.blob.core.windows.net/%s' % (blob_container_name, blob_account_name, blob_relative_path1)
spark.conf.set('fs.azure.sas.%s.%s.blob.core.windows.net' % (blob_container_name, blob_account_name), blob_sas_token)
#print('Remote blob path: ' + wasbs_path)

df = spark.read.csv(wasbs_path,header=True)
#print(df)
df1 = spark.read.csv(wasbs_path1,header=True)
print('Register the DataFrame as a SQL temporary view: source')
df.createOrReplaceTempView('Emp')
df1.createOrReplaceTempView('Dept')
print('Displaying top 10 rows: ')
#display(spark.sql('SELECT * FROM Emp '))
#display(spark.sql('SELECT * FROM Dept '))

#display(spark.sql('SELECT e.empno,e.ename,e.deptno,d.dname FROM Emp e inner join Dept d on (e.deptno=d.deptno)'))
display(spark.sql('SELECT e.empno,e.ename,e.deptno,d.dname,e.hiredate FROM Emp e inner join Dept d on (e.deptno=d.deptno)'))
#/* Give hiredate output same as input file DD-MM-YYYY */

#display(spark.sql('SELECT e.empno,e.ename,e.deptno,d.dname,e.hiredate,date_format(hiredate, "MM") FROM Emp e inner join Dept d on (e.deptno=d.deptno)'))
#/* Error :- date_format(hiredate, "MM") giving null.Check how to do cast in Spark */

#display(spark.sql('SELECT e.empno,e.ename,e.deptno,d.dname,e.hiredate,date_format(e.hiredate,"yyyy MM dd").as("yyyy MM dd") FROM Emp e inner join Dept d on (e.deptno=d.deptno)'))
#/* Error */

/* Check date formate conversion in python Spark SQL */


-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/azure/databricks/getting-started/concepts */
/* Databricks Data Science & Engineering concepts */
-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/azure/databricks/getting-started/overview */
/* Azure Databricks architecture overview */
-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
/* Theory knowledge on azure databricks components */
/* Read this if any definition needs to be explained */

-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/azure/databricks/tutorials/run-jobs-with-service-principals */
/* Tutorial: Run a job with an Azure service principal */
-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=UoN8ch_sbGg&ab_channel=KnowledgeSharing */
/* Schedule azure databricks notebook */
-----------------------------------------------------------------------------------------
Req :- Create a job which will run above created notebook (Manually or Scheduled).
Notebook Name :- GetEMPADFS

Jobs :- Create Job :- 
Task Name :- RunGetEMPADFS
Type :- Notebook /* Select GetEMPADFS from user folder */
/* Create */
Then Schedule :- Edit Schedule
Scheduled Type :- /* Radio Button */ i) Manual (Paused) ii) Scheduled (Selected)
Schedule :- 
Every :- /* Drop Down */ :-i)Minute ii) Hour iii) day (selected) iv) Month v) Week
At :- Select time

/* Job got created.Now as per schedule it will run. */

-----------------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/azure/databricks/scenarios/store-secrets-azure-key-vault */
/* Tutorial: Access Azure Blob Storage from Azure Databricks using Azure Key Vault */
-----------------------------------------------------------------------------------------
Req :- Create secret in azure key vault and use it in DataBricks.
Create a storage account and blob container
Create an Azure Key Vault and add a secret for Access Key.
Create an Azure Databricks workspace and add a secret scope
Access your blob container from Azure Databricks


/* File Storage Detail */
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
Folder Name :- input
File Name :- Emp.csv
SAS Token field  /* Present under Shared Access Signature */ :- ?sv=2020-02-10&ss=bfqt&srt=sco&sp=rwdlacuptfx&se=2021-06-15T22:26:13Z&st=2021-06-15T14:26:13Z&spr=https&sig=Cnlgkje1I0X4%2B2Qe6WUxr1Te2x7lbzMABgY3aDaDQCQ%3D
Access key /* Present under Access Keys */ 
Key 1 :- gp0XnD19MdVHZdDUYBZdz5yjsxafV9HEFibsX+C1Ncqkc3JFrrEbO0HSJO+4InfRRZSpdN5leBH6EnO4MCg1Pw==
Key 2 :- TABQS0Xrt9yUYX6cIrrZppi9n/P/TlhISoQCc/0JxMZeG3bIOx2hpH6A7zQn62oD8C5ZfhxEitXE2oHgEqtB9g==


/* Key Vault Detail */
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Key vault name :- uspdemokeyvault

Secrets :- Create :- 
Name :- StorageKey
Value /* Key 1 */ :- gp0XnD19MdVHZdDUYBZdz5yjsxafV9HEFibsX+C1Ncqkc3JFrrEbO0HSJO+4InfRRZSpdN5leBH6EnO4MCg1Pw==
Content Type :- /* Optional */
/* Generate */

Settings :- 
Vault URI DNS :- https://uspdemokeyvault.vault.azure.net/
Resource ID :- /subscriptions/068b4f24-e652-4497-9b14-346db4e3c3fa/resourceGroups/uspstagingdbgroupdev/providers/Microsoft.KeyVault/vaults/uspdemokeyvault

/* Launch WorkSpace */
WorkSpace Name :- uspLocalDatabricks
URL :- https://adb-7699593049064036.16.azuredatabricks.net/?o=7699593049064036

Once your Azure Databricks workspace is open in a separate window, 
append #secrets/createScope to the URL. The URL should have the following format:

Sample :- 
https://<\location>.azuredatabricks.net/?o=<\orgID>#secrets/createScope.
New URL :- 
https://adb-7699593049064036.16.azuredatabricks.net/?o=7699593049064036#secrets/createScope
/* Create Secret Scope */
Scope Name :- DatabricksSecretScope
DNS Name /* Vault URI DNS */ :- https://uspdemokeyvault.vault.azure.net/
Resource Id :- /subscriptions/068b4f24-e652-4497-9b14-346db4e3c3fa/resourceGroups/uspstagingdbgroupdev/providers/Microsoft.KeyVault/vaults/uspdemokeyvault

/*
Note :- This error was coming while creating Secret Scope
/* Premium Tier is disabled in this workspace. Secret scopes can only be created with initial_manage_principal "users". 
Since while creating workgroup "Cluster Mode :- Standard" this was selected.
and secret scope is not supported in it.It is supported in "Premium Tier".
Re-Create the same workspace "uspLocalDatabricks" and select Cluster Mode= "Premium Tier".
After doing this "Secret Scope" got created.
*/
Next Step :- 
Access blob container from Azure Databricks :- 

/* Create a new cluster */
Cluster Name :- uspdevcluster
Cluster Mode :- Standard
Databricks Run time version :- 8.2 (Scala 2.12 Spark 3.1.1) (By default)


Create Notebook :- 
i) Name :- MyNotebookKeyVault
ii) Default language :- Python
iii) cluster :- uspdevcluster

mount-name :- It is a DBFS path representing where the Blob Storage container 
or a folder inside the container (specified in source) will be mounted. 
A directory is created using the mount-name you provide.

conf-key :- It can be either fs.azure.account.key.<\your-storage-account-name>.blob.core.windows.net 
or 
fs.azure.sas.<\your-container-name>.<\your-storage-account-name>.blob.core.windows.net

Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer

Scope-Name is the name of the secret scope you created in the previous section.
key-name is the name of they secret you created for the storage account key in your key vault.

/* Code */
dbutils.fs.mount( #source = "wasbs://<your-container-name>@<your-storage-account-name>.blob.core.windows.net", source = "wasbs://uspstagingcontainer@uspstorageaccountnew.blob.core.windows.net", #mount_point = "/mnt/<mount-name>", mount_point = "/mnt/input", #extra_configs = {"<conf-key>":dbutils.secrets.get(scope = "<scope-name>", key = "<key-name>")}) #conf-key = fs.azure.account.key.<\your-storage-account-name>.blob.core.windows.net #conf-key = fs.azure.sas.<\your-container-name>.<\your-storage-account-name>.blob.core.windows.net #conf-key = fs.azure.sas.uspstagingcontainer.uspstorageaccountnew.blob.core.windows.net  extra_configs = {"fs.azure.sas.uspstagingcontainer.uspstorageaccountnew.blob.core.windows.net":dbutils.secrets.get(scope = "DatabricksSecretScope", key = "StorageKey")})  #df = spark.read.text("/mnt/<mount-name>/<file-name>") df = spark.read.csv("/mnt/input/Emp.csv") df.show() 
O/P :- 
/* Showing Error.Fix it */

-----------------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/azure/databricks/scenarios/databricks-extract-load-sql-data-warehouse */
/* Tutorial: Extract, transform, and load data by using Azure Databricks */
-----------------------------------------------------------------------------------------
Requirement :- 
i) Create an Azure Databricks service.
ii) Create a Spark cluster in Azure Databricks.
iii) Create a file system in the Data Lake Storage Gen2 account.
iv) Upload sample data to the Azure Data Lake Storage Gen2 account.
v) Create a service principal.
vi) Extract data from the Azure Data Lake Storage Gen2 account.
vii) Transform data in Azure Databricks.
viii)Load data into Azure Synapse.

/* Launch WorkSpace */
WorkSpace Name :- uspLocalDatabricks
URL :- https://adb-7699593049064036.16.azuredatabricks.net/?o=7699593049064036

/* Create a new cluster */
Cluster Name :- uspdevcluster
Cluster Mode :- Standard
Databricks Run time version :- 8.2 (Scala 2.12 Spark 3.1.1) (By default)

/* Seems very lengthy.Leaving as of now */


-----------------------------------------------------------------------------------------
/* https://www.sqlshack.com/accessing-azure-blob-storage-from-azure-databricks/ */
/* Accessing Azure Blob Storage from Azure Databricks */
-----------------------------------------------------------------------------------------
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
WorkSpace Name :- uspLocalDatabricks
Cluster Name :- uspdevcluster
Cluster Mode :- Standard
Databricks Run time version :- 8.2 (Scala 2.12 Spark 3.1.1) (By default)

Storage :- 
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Storage Account Name :- "uspstorageaccountnew"
ContainerName :- "uspstagingcontainer"
Folder Name :- input

Generate SAS and connection string :- 
SAS :- Shared access signature
>>> Shared Acces signature >>> Create

Blob SAS Token :- 
sp=racwdl&st=2021-05-22T05:50:34Z&se=2022-07-07T13:50:34Z&spr=https&sv=2020-02-10&sr=c&sig=Eg%2FmO%2B2nlsQF%2FUew6oTAoYu4OhPvBFOTP2J1c5%2FdOzk%3D

Blob SAS URL :- 
https://uspstorageaccountnew.blob.core.windows.net/uspstagingcontainer?sp=racwdl&st=2021-05-22T05:50:34Z&se=2022-07-07T13:50:34Z&spr=https&sv=2020-02-10&sr=c&sig=Eg%2FmO%2B2nlsQF%2FUew6oTAoYu4OhPvBFOTP2J1c5%2FdOzk%3D

File Name :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure Learning\1000_Sales_Records.csv
Upload this file in "input" folder inside "uspstagingcontainer" container.


i) Read a CSV file from Blob Storage in the Databricks.
This is called  "Mount the Blob Storage in Azure Databricks".
ii) Do transformation to the data and move this processed data to a temporary 
    SQL view in Azure Databricks.
iii) Write the transformed data back to the Azure blob storage container.

Create a Notebook :- to access .csv file from Azure Blob Storage.
Name :- AccessingBlobStorage 
Language :- Python
Cluster :- uspdevcluster

2) /* Code For Notebook :- AccessingBlobStorage */

# command sets the Azure storage access information
blob_account_name = "uspstorageaccountnew"
blob_container_name = "uspstagingcontainer"
blob_relative_path = "1000_Sales_Records.csv"
blob_sas_token = r"?st=2019-02-26T02%3A34%3A32Z&se=2119-02-27T02%3A34%3A00Z&sp=rl&sv=2018-03-28&sr=c&sig=XlJVWA7fMXCSxCKqJm8psMOh0W4h7cSYO28coRqF2fs%3D"

# command allows Spark to read from Blob storage remotely
wasbs_path = 'wasbs://%s@%s.blob.core.windows.net/%s' % (blob_container_name, blob_account_name,blob_relative_path)
spark.conf.set('fs.azure.sas.%s.%s.blob.core.windows.net' % (blob_container_name, blob_account_name),blob_sas_token)
print('Remote blob path: ' + wasbs_path)

# command to creates a DataFrame
df = spark.read(wasbs_path)
print(df)

/* Not working. Check this */
print('Register the DataFrame as a SQL temporary view: source')
df.createOrReplaceTempView('source')

/* Same example working fine in above case */
/* Check this link in this page */
/* https://docs.microsoft.com/en-us/azure/databricks/scenarios/quickstart-create-databricks-workspace-portal?tabs=azure-portal */
/* Quickstart: Run a Spark job on Azure Databricks Workspace using the Azure portal */

-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
/* from another playlist */
/* TechLake */
-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=-TGBa1NoEbY&list=PL50mYnndduIGmqjzJ8SDsa9BZoY7cvoeD&index=6&ab_channel=TechLakeTechLake */
/* Databricks Tutorial 6: How To upload Data file into Databricks,Creating Table in #Databricks #azure */
------------------------------------------------------------------------------------------
Requirement :- Upload a file in Databricks and then create a table of that file using python.
/* Complete it */


-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
/* From Cloudpandith Channel */
-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=TIrFYOm1nI4&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=40&ab_channel=CloudpandithCloudpandith */
/* 8 Azure Databricks Databases and Tables */
-----------------------------------------------------------------------------------------
/* No need to watch video again */
Command to create/Drop Database/Table in Azure DataBricks :- 
Note :- If we are running query to create Db/table then it will be created  inside databricks only.
These can be seen in below path. 
Path :- Data >> Databases

/* Create Database */
/* SQL Code :- Inside Notebook */
%sql
Create Database Mydatabase

/* Python/Scala Code :- Inside Notebook  */
%scala
spark.sql("Create Database Mydatabase")

/* Drop Non Empty Databse */
/* SQL Code :- */
drop Database Mydatabase cascade

/* Python/Scala Code :- */
spark.sql("drop Database Mydatabase cascade")

/* Create Table */
/* Python/Scala Code :- */
/* If we have created a data frame and want to save that data into a table then this query will work fine.
Can use temp view also */
df.write.saveAsTable("dbname.tablename")

spark.sql("CREATE TABLE Mydatabase.student (id INT, name STRING, age INT);")
/* Table will be created inside Mydatabase in data section */

spark.sql("CREATE TABLE student (id INT, name STRING, age INT);")
/* Table will be created inside "Default" database in data section */

/* Create Partition Table */
/* Python/Scala Code :- */
/* Add Here Missing Code */

/* Describe table */
/* SQL/Python/Scala Code :- */
spark.sql("Describe table dbname.tablename")

/* Drop table */
/* SQL/Python/Scala Code :- */
spark.sql("Drop table dbname.tablename")

There are two types of tables in Databricks :- 
i) Global Tables :- These are available across all clusters. 
In Auzre Databricks, Global tables are registered to the Hive metastore.
Ex :- dataFrame.write.saveAsTable("<table-name>")

ii) Local Tables (Temp View) :- These are only available to the cluster to which it 
was created on and there are not registered to the Hive metastore. 
These are also known as temp tables or views.
Ex :- dataFrame.createOrReplaceTempView("<table-name>")

----------------------------------------------------------------------------------------------------------
Own Example :- 
Requirement :- Read a file from DBFS and create a table and insert data into it.
Do overwrite and append operation.

Create Notebook :- 
i) Name :- DatabricksDBNotebook
ii) Default language :- Python
iii) cluster :- uspdevcluster

/* Code */
df = spark.read.csv("dbfs:/FileStore/tables/csvfile/csvfile1.csv",header=True,inferSchema=True,sep=",")
# /* Table will be created inside default database */
df.write.mode("overwrite").saveAsTable("csvtable")  
csvtable = spark.sql("select * from csvtable")
csvtable.show()               #Dotted line tabular format data
display(csvtable)             #Display tabular format data
display(csvtable.select("*")) #Same as above.Display tabular format data

csvtable1 = spark.table("csvtable")
display(csvtable1.select("*")) #Same as above.Display tabular format data
# /* Append data into existing table */
df.write.mode("append").saveAsTable("csvtable") 
csvtable2 = spark.sql("select count(*) from csvtable")
csvtable2.show()            # 1st 5 record then again 5 record is inserted.So total 10 will come.

Note :- Whatever table we have created and data loaded,all these files can be seen in below path.
Data >> DBFS >> User >> hive >> Warehouse >> <TableName> >> File in the form of PArquet will be present

-----------------------------------------------
/* https://docs.databricks.com/spark/latest/spark-sql/language-manual/sql-ref-syntax-ddl-create-table-datasource.html */
/* https://spark.apache.org/docs/latest/sql-ref-syntax-ddl-create-table-hiveformat.html */
/* General Syntax to create Table :- */
-----------------------------------------------
/* Check usage of below syntax */
CREATE TABLE [ IF NOT EXISTS ] table_identifier
[ ( col_name1 col_type1 [ COMMENT col_comment1 ], ... ) ]
USING data_source
[ OPTIONS ( key1 [ = ] val1, key2 [ = ] val2, ... ) ]
[ PARTITIONED BY ( col_name1, col_name2, ... ) ]
[ CLUSTERED BY ( col_name3, col_name4, ... )
  [ SORTED BY ( col_name [ ASC | DESC ], ... ) ]
  INTO num_buckets BUCKETS ]
[ LOCATION path ]
[ COMMENT table_comment ]
[ TBLPROPERTIES ( key1 [ = ] val1, key2 [ = ] val2, ... ) ]
[ AS select_statement ]

-- Examples :- 
-- Use data source
CREATE TABLE student (id INT, name STRING, age INT) USING CSV;

--Use data from another table
CREATE TABLE student_copy USING CSV
    AS SELECT * FROM student;

--Omit the USING clause, which uses the default data source (parquet by default)
CREATE TABLE student (id INT, name STRING, age INT);

--Specify table comment and properties
CREATE TABLE student (id INT, name STRING, age INT) USING CSV
    COMMENT 'this is a comment'
    TBLPROPERTIES ('foo'='bar');

--Specify table comment and properties with different clauses order
CREATE TABLE student (id INT, name STRING, age INT) USING CSV
    TBLPROPERTIES ('foo'='bar')
    COMMENT 'this is a comment';

--Create partitioned and bucketed table
CREATE TABLE student (id INT, name STRING, age INT)
    USING CSV
    PARTITIONED BY (age)
    CLUSTERED BY (Id) INTO 4 buckets;

-----------------------------------------------------------------------------------------
https://www.youtube.com/watch?v=HBuvGasdlEM&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=36&ab_channel=Cloudpandith
/* 8 1 Azure Databricks Databases and Tables */
-----------------------------------------------------------------------------------------
/* Experiment on file and load to table.Already written by own in previous example. */


-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=fXHy-L4bVAw&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=15&ab_channel=CloudpandithCloudpandith */
/* 9.DBUTILS commands in Azure Databricks */
-----------------------------------------------------------------------------------------
The way we are creating files/Folders in Linux same we can also do in databricks using dbutils.
Created Folders and files can seen in below Path :- 
Data >>> Create Table >>> DBFS >>> tables >>> MyDir >>> File.txt
fs :- File System
Conclusion :- 
i) Create Directory :- mkdir
ii) Create File :- put
iii) Display File Content :- head
iv) List down files :- ls
v) Copy Files :- cp
vi) Move Files :- mv

/* Create Directory in DBFS :- */
dbutils.fs.mkdirs("/FileStore/tables/MyDir")

/* Create file and write data into it */
dbutils.fs.put("/path/filename.txt","content")
dbutils.fs.put("/FileStore/tables/MyDir/File.txt","Hello USP")

/* Displaying file content */
dbutils.fs.head("/path/filename.txt")
dbutils.fs.head("/FileStore/tables/MyDir/File.txt")

/* List down content in a directory */
dbutils.fs.ls("/path/")

/* Move file from one directory to another directory */
dbutils.fs.mv("path1","path2")

/* Copy file from one directory to another directory */
dbutils.fs.cp("path1","path2")

/* Remove file or directory */
dbutils.fs.rm("path1/file.txt")
dbutils.fs.rm("path1/",True)

/* Remove all files and directory inside a directory */
dbutils.fs.rm("path1/", recurse = True)

-----------------------------------------------------
/* Check its usage */
/* Mount and Unmount File System */
dbutils.fs.mount("mountpoint")
dbutils.fs.unmount("mountpoint")

/* List down mounts */
dbutils.fs.mounts()

/* Refresh Mount points */
dbutils.fs.refreshMounts()
-----------------------------------------------------
/* Install the packages */
dbutils.library.installPyPl("tensorflow")

/* Find current notebook path from UI */
/* Not working */
dbutils.notebook.getcontext.notebookPath

/* Run one notebook from another notebook */
/* Get Path of Notebook by right click on notebook */
%run path $name="ABC" $location="XYZ"
dbutils.notebook.run("Path",600,{"name":"rama","location":"bbsr")

/* Exit execution from notebook */
dbutils.notebook.exit("Testing")

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=Pl9PibjVTYA&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=39&ab_channel=CloudpandithCloudpandith */
/* 10 Databricks Variables, Widget Types, Databricks notebook parameters */
-----------------------------------------------------------------------------------------
Variables :- Normal variable in any programming language
Widget Types :- Pass input to any Notebook
notebook parameters :- Pass parameter to notebook and its setting

i) What is widget and types.
ii) How to create widget to pass dynamic values in python notebook.
iii) How to read dynamic parameter value in python Notebook.
iv) How to remove widget from python notebook.

Input widget allows us to add parameter to our notebook and bashboards.
The widget API consists of calls to create various types of input widgets, remove them
and get bound values.

Types of Widgets :- &
Syntax to Create widget to pass dynamic values to Python/Scala Notebook.
----------------------------------------------------------------------------
i) Text :- Input a value in a text box.
dbutils.widgets.text("sourcepath","") :- "" :- Default Path /* Check it */

ii) Dropdown :- Select a value from a list of provided values.
dbutils.widgets.dropdown("subject_dd","Payments",["Payments","Sales","Orders"])
subject_dd :- Parameter Value
Payments :- Default Value /* Must be part of Options */
["Payments","Sales","Orders"] :- Options

iii) Combobox :- Combination of text and dropdown.Select a value from a provided list or 
input one in the box.
dbutils.widgets.combobox("PaymentMode","any",["Online","Offline","3rd Party"])
PaymentMode :- Parameter Value
any :- Default Value /* May not be part of Options */
["Online","Offline","3rd Party"] :- Options

iv) Multiselect :- Select one or more values from a list of provided values.
dbutils.widgets.multiselect("Columns","trainname",["trainname","trainable","traindestination"])
Columns :- Parameter Value
trainname :- Default Value /* Must be part of Options */
["trainname","trainable","traindestination"] :- Options

Syntax to remove widgets from Python/Scala Notebook.
----------------------------------------------------------------------------
dbutils.widgets.remove("subject_dxx")
dbutils.widgets.removeall()


Syntax to Read dynamic parameter values in Python/Scala Notebook.
----------------------------------------------------------------------------
1) dbutils.widgets.multiselect("Columns","trainname",["trainname","trainable","traindestination"])
/* Select any one */
SourceLocation = dbutils.widgets.get("Columns")
print(SourceLocation)
O/P :- traindestination

2) dbutils.widgets.text("sourcepath","/Abk")
/* Write something on box */
SourceLocation = dbutils.widgets.get("sourcepath")
print(SourceLocation)
O/P :- written text will be displayed.

Requirement :- Create a widgets to pass dynamic values to python notebook.
/* Do this */

--------------------------------------------------------------------------------------------------
/* Own 1 :- */
--------------------------------------------------------------------------------------------------
Req :- Write a notebook which will create a table inside databricks.File will come from ADLS Gen2.
Call this notebook from Pipeline.

Notebook :- 
Name :- GetEMPADFS
Language :- Python
/* Code */
from pyspark.sql import *
import pandas as pd

#/* Azure Storage Access Information */
blob_account_name = "abksynapseadlsgen2"
blob_container_name = "abksynapsecontainer"
blob_relative_path = "input/Emp.csv"
blob_relative_path1 = "input/Dept.csv"

blob_sas_token = r"?sv=2020-08-04&ss=bfqt&srt=sco&sp=rwdlacupx&se=2026-04-01T12:41:00Z&st=2021-08-25T04:41:00Z&spr=https&sig=IjgKI3hdXn8W8eYjJVe1k3Kn8sTp6QxyJkKcw4i20TI%3D"

#/* Read file from blob storage */
wasbs_path = 'wasbs://%s@%s.blob.core.windows.net/%s' % (blob_container_name, blob_account_name, blob_relative_path)
wasbs_path1 = 'wasbs://%s@%s.blob.core.windows.net/%s' % (blob_container_name, blob_account_name, blob_relative_path1)
spark.conf.set('fs.azure.sas.%s.%s.blob.core.windows.net' % (blob_container_name, blob_account_name), blob_sas_token)
#print('Remote blob path: ' + wasbs_path)

df = spark.read.csv(wasbs_path,header=True)
df.write.mode("overwrite").saveAsTable("EMP")


/* Step 1 :- Generate SAS token which will be required while creating Linked Service */
Settings >>> User Settings
Access tokens >>> Generate New token
Comment :- ADF Integration
Duration :- 90 Days >>> /* Generate & Copy it */ 
Access Token :- dapib1be18c83ccb8d801cba055030af9a7f-3

/* Step 2 :- Create a linked service in ADF which will point to Azure Notebook */
Go to :- Manage >>> Linked Services >>> + New >>> Compute >>> Azure Databricks
Name :- AzureDatabricks1
Databricks workspace :- uspLocalDatabricks
Select Cluster :- Existing Interactive Cluster
Access Token :- dapib1be18c83ccb8d801cba055030af9a7f-3
Choose From Existing Clusters :- Dropdown :- uspdevcluster
>>> Create

/* Step 3 :- Create a pipeline which will call Azure Notebook */
Go to :- Author >>> + >>> Pipeline
Name :- NotebookCallGetEMPADFS
Add Activity :- Notebook
General :- 
Name :- GetEMPADFSCall
Azure Databricks :- 
Databricks Linked Service :- Dropdown :- AzureDatabricks1
Settings :- 
Notebook Path :- Browse >> Select Notebook Name :- GetEMPADFS
>>>> Run this pipeline >>> /* EMP table got created inside default DB in databricks */

--------------------------------------------------------------------------------------------------
/* Own 2 :- */
--------------------------------------------------------------------------------------------------
Req :- Write a Notebook which will fetch file from ADLS gen2 storage account.
Create a widget which will contain file name & path present in ADLS gen2 storage account.
Call this notebook from ADF and pass file path to Notebook.

Notebook :- 
Name :- EmpNotebook
Language :- Python

#/* Code */
from pyspark.sql import *
import pandas as pd

#/* Create Widget of text type */
dbutils.widgets.text("InputFileName","")
FileName = dbutils.widgets.get("InputFileName")

#/* Azure Storage Access Information */
blob_account_name = "abksynapseadlsgen2"
blob_container_name = "abksynapsecontainer"
blob_relative_path = "input/"+FileName

blob_sas_token = r"?sv=2020-08-04&ss=bfqt&srt=sco&sp=rwdlacupx&se=2026-04-01T12:41:00Z&st=2021-08-25T04:41:00Z&spr=https&sig=IjgKI3hdXn8W8eYjJVe1k3Kn8sTp6QxyJkKcw4i20TI%3D"

#/* Read file from blob storage */
wasbs_path = 'wasbs://%s@%s.blob.core.windows.net/%s' % (blob_container_name, blob_account_name, blob_relative_path)
spark.conf.set('fs.azure.sas.%s.%s.blob.core.windows.net' % (blob_container_name, blob_account_name), blob_sas_token)
#print('Remote blob path: ' + wasbs_path)

df = spark.read.csv(wasbs_path,header=True)
TableName = FileName.split('.')[0]
df.write.mode("overwrite").saveAsTable(TableName)

/* Steps of ADF Pipeline :- */
/* Step 1 :- Generate SAS token which will be required while creating Linked Service */
Open Notebook >>> Top Right Corner >>> Click on Workspace Name >>> User Settings
Access tokens >>> Generate New token
Comment :- ADF Integration
Duration :- 90 Days >>> Generate (Copy)
Access Token :- dapib1be18c83ccb8d801cba055030af9a7f-3

/* Step 2 :- Create a linked service in ADF which will point to Azure Notebook */
Go to :- Manage >>> Linked Services >>> + New >>> Compute >>> Azure Databricks
Name :- AzureDatabricks1
Databricks workspace :- uspLocalDatabricks
Select Cluster :- Existing Interactive Cluster
Access Token :- dapib1be18c83ccb8d801cba055030af9a7f-3
Choose From Existing Clusters :- Dropdown :- uspdevcluster
>>> Create

/* Step 3 :- Create a pipeline which will call Azure Notebook */
Go to :- Author >>> + >>> Pipeline
Name :- NotebookCallEmpNotebook
/* Since we have a widget inside Notebook.So here we will create a parameter at pipeline level
and will pass this inside notebook */
At Pipeline :- 
Parameter :- 
Name :- FileName
Type :- String
Default Value :- Dept.csv

Add Activity :- Notebook
General :- 
Name :- GetEMPADFSNotebook
Azure Databricks :- 
Databricks Linked Service :- Dropdown :- AzureDatabricks1
Settings :- 
Notebook Path :- Browse >> Select Notebook Name :- GetEMPADFS
Base PArameter :- + New >> NAme :- FileName, Value :- @pipeline().parameters.FileName
>>>> Run this pipeline >>> Will ask for File Name.If nothing provided then will take Dept.csv file as by default.
/* Keep widget blank in notebook */
O/P :- Ran successfully and Dept table got created.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=LpbthnBsrSM&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=23&ab_channel=Cloudpandith */
/* 11. Quick Installation of Azure Databricks CLI || Create Azure Databricks Cluster using CLI */

/* https://www.youtube.com/watch?v=f3492rjPLQs&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=42&ab_channel=Cloudpandith */
/* 12 Databricks CLI DBFS, Libraries and Jobs */
-----------------------------------------------------------------------------------------
Look into this if requirement comes.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=EV0m1ovMEbA&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=17&ab_channel=Cloudpandith */
/* 13. Read CSV Files efficiently in spark || Azure Databricks */
-----------------------------------------------------------------------------------------
/*
Note :- Read data from any kind of file documentation using sparksql
https://spark.apache.org/docs/2.0.1/api/python/pyspark.sql.html

Sample Code for .csv file :- 
spark.read.csv(path, schema=None, sep=None, encoding=None, quote=None, escape=None, comment=None, header=None, inferSchema=None, ignoreLeadingWhiteSpace=None, ignoreTrailingWhiteSpace=None, nullValue=None, nanValue=None, positiveInf=None, negativeInf=None, dateFormat=None, timestampFormat=None, maxColumns=None, maxCharsPerColumn=None, maxMalformedLogPerPartition=None, mode=None)
*/

1) Pyspark read csv file into dataframe.
Read single file.
Read all csv file in a directory.

2) Option while reading csv file.
Delimiter :- Comma(,),Pipe(|) etc..By default Comma(,).

Inferschema :- By default spark read all column as string.But if we want exact data type
of each column of file then we need to specify "Inferschema = true".
Then it will provide exact data type of each column present in the file.
By default Inferschema false.

Header :- Define Header while reading files.By Default false.

3) Read csv file with user specified schema :- Define each column data type by own and read.

Syntax to read csv file :- 
------------------------------
1) df = spark.read.csv("src/main/resource/file.csv",header=True,Inferschema=True,sep=",",schema=schema)

Inferschema = True means spark needs to read all data types.
schema=schema means from our side we are going to provide schema of data.
So we should not use both.Keep at a time only one.

2) df = spark.read.format("csv").option("header",True).option("Inferschema",True).
option("Delimiter",",").schema(schema).load("src/main/resource/file.csv")
/* Can use any syntax */

/* Write Dataframe as File :-  */
---------------------------------------------------------
3) format = csv,parquet etc..
df.write.mode("overwrite").format("csv").save("dbfs:/FileStore/tables/csvfile/")
df.write.mode("append").format("json").save("dbfs:/FileStore/tables/csvfile/")

i) overwrite – mode is used to overwrite the existing file, alternatively, 
you can use SaveMode.Overwrite.
ii) append – To add the data to the existing file, alternatively, you can use SaveMode.Append.
iii) ignore – Ignores write operation when the file already exists, alternatively 
you can use SaveMode.Ignore


Create Notebook :- 
i) Name :- ReadCSVNotebook
ii) Default language :- Python
iii) cluster :- uspdevcluster

1)
/* Code */
#/* Create 3 folder where will keep single file of each delimiter type */
dbutils.fs.mkdirs("/FileStore/tables/csvfile/")
dbutils.fs.mkdirs("/FileStore/tables/tsvfile/")
dbutils.fs.mkdirs("/FileStore/tables/pipefile/")

#/* Create 3 folder where will keep all files of each delimiter type */
dbutils.fs.mkdirs("/FileStore/tables/multicsvfile/")
dbutils.fs.mkdirs("/FileStore/tables/multitsvfile/")
dbutils.fs.mkdirs("/FileStore/tables/multipipefile/")

#/* Create a folder where we will copy file */
dbutils.fs.mkdirs("/FileStore/tables/copyfile/")

#/* Check directory created or not */
dbutils.fs.ls("/FileStore/tables/")


/* Since Folder got created.Now upload files inside it */
csvfile :- csvfile1.csv
tsvfile :- tsvfile1.csv
pipefile :- Pipelinefile1.csv

multicsvfile :- csvfile1.csv,csvfile2.csv
multitsvfile :- tsvfile1.csv,tsvfile2.csv
multipipefile :- Pipelinefile1.csv,Pipelinefile2.csv

/* Come back to notebook and read all these uploaded files */
2)
df = spark.read.csv("dbfs:/FileStore/tables/csvfile/csvfile1.csv",header=False,inferSchema=True,sep=",")
df.show()

O/P :- 
Header is false by default so header is also coming as data.
By default Inferschema is false.So all column are of string data types.

df:pyspark.sql.dataframe.DataFrame
_c0:string
_c1:string
_c2:string
_c3:string
+--------+----------+--------+-----------+
|     _c0|       _c1|     _c2|        _c3|
+--------+----------+--------+-----------+
|PlayerId|PlayerName|Palyerhs|NoOfMatches|
|       1|     Kohli|     186|         10|
|       2|       abd|     201|         30|
|       3|    Sehwag|     219|         50|
|       4|    Sachin|     200|         40|
|       5|    Yuvraj|     180|         50|
+--------+----------+--------+-----------+

3)
df = spark.read.csv("dbfs:/FileStore/tables/csvfile/csvfile1.csv",header=True)
df.show()

O/P :- 
df:pyspark.sql.dataframe.DataFrame
PlayerId:string
PlayerName:string
Palyerhs:string
NoOfMatches:string
+--------+----------+--------+-----------+
|PlayerId|PlayerName|Palyerhs|NoOfMatches|
+--------+----------+--------+-----------+
|       1|     Kohli|     186|         10|
|       2|       abd|     201|         30|
|       3|    Sehwag|     219|         50|
|       4|    Sachin|     200|         40|
|       5|    Yuvraj|     180|         50|
+--------+----------+--------+-----------+

4) 
df = spark.read.csv("dbfs:/FileStore/tables/csvfile/csvfile1.csv",header=True,inferSchema=True,sep=",")
df.show()

O/P :- 
/* Actual data type of column will be considered */
df:pyspark.sql.dataframe.DataFrame
PlayerId:integer
PlayerName:string
Palyerhs:integer
NoOfMatches:integer
+--------+----------+--------+-----------+
|PlayerId|PlayerName|Palyerhs|NoOfMatches|
+--------+----------+--------+-----------+
|       1|     Kohli|     186|         10|
|       2|       abd|     201|         30|
|       3|    Sehwag|     219|         50|
|       4|    Sachin|     200|         40|
|       5|    Yuvraj|     180|         50|
+--------+----------+--------+-----------+

5) Read multiple files from folder.
df = spark.read.csv("dbfs:/FileStore/tables/multicsvfile/",header=True,inferSchema=True,sep=",")
df.show()

O/P :- 
df:pyspark.sql.dataframe.DataFrame
PlayerId:integer
PlayerName:string
Palyerhs:integer
NoOfMatches:integer
+--------+----------+--------+-----------+
|PlayerId|PlayerName|Palyerhs|NoOfMatches|
+--------+----------+--------+-----------+
|       1|     Kohli|     186|         10|
|       2|       abd|     201|         30|
|       3|    Sehwag|     219|         50|
|       4|    Sachin|     200|         40|
|       5|    Yuvraj|     180|         50|
|       6|     Patel|     187|         10|
|       7|   Gambhir|     209|         20|
|       8|    Russel|     156|         30|
|       9|     Gayle|     300|         40|
|      10|      Lara|     400|         50|
+--------+----------+--------+-----------+

6) 
df = spark.read.csv("dbfs:/FileStore/tables/multicsvfile/",header=True,inferSchema=True,sep=",").orderBy("PlayerName")
df.show()

O/P :- 
+--------+----------+--------+-----------+
|PlayerId|PlayerName|Palyerhs|NoOfMatches|
+--------+----------+--------+-----------+
|       7|   Gambhir|     209|         20|
|       9|     Gayle|     300|         40|
|       1|     Kohli|     186|         10|
|      10|      Lara|     400|         50|
|       6|     Patel|     187|         10|
|       8|    Russel|     156|         30|
|       4|    Sachin|     200|         40|
|       3|    Sehwag|     219|         50|
|       5|    Yuvraj|     180|         50|
|       2|       abd|     201|         30|
+--------+----------+--------+-----------+

7) User defined schema :- 
from pyspark.sql.types import StructType,StructField,IntegerType,StringType
s=StructType([StructField("PlayerId",IntegerType()),
StructField("PlayerName",StringType()),
StructField("Palyerhs",IntegerType()),
StructField("NoOfMatches",IntegerType())])
df = spark.read.csv("dbfs:/FileStore/tables/multicsvfile/",header=True,schema=s)
df.show()
df.columns

O/P :- 
df:pyspark.sql.dataframe.DataFrame
PlayerId:integer
PlayerName:string
Palyerhs:integer
NoOfMatches:integer
+--------+----------+--------+-----------+
|PlayerId|PlayerName|Palyerhs|NoOfMatches|
+--------+----------+--------+-----------+
|       1|     Kohli|     186|         10|
|       2|       abd|     201|         30|
|       3|    Sehwag|     219|         50|
|       4|    Sachin|     200|         40|
|       5|    Yuvraj|     180|         50|
|       6|     Patel|     187|         10|
|       7|   Gambhir|     209|         20|
|       8|    Russel|     156|         30|
|       9|     Gayle|     300|         40|
|      10|      Lara|     400|         50|
+--------+----------+--------+-----------+
Out[16]: ['PlayerId', 'PlayerName', 'Palyerhs', 'NoOfMatches']

8) Write file data into a new file.
Output Folder :- /FileStore/tables/copyfile/
Output Folder File Name :- csvfile1.csv

df = spark.read.csv("dbfs:/FileStore/tables/csvfile/csvfile1.csv",header=True,inferSchema=True,sep=",")
df.show()
df.write.mode("overwrite").format("csv").save("dbfs:/FileStore/tables/copyfile/csvfile1.csv")

O/P :-  
This way csvfile1.csv folder is getting created and inside this folder 4 four files are getting generated.
_SUCCESS
_committed_3559981104939048573
_started_3559981104939048573
part-00000-tid-3559981104939048573-b3454d6f-e5f7-4056-a72e-1e000f37eb32-17-1-c000.csv

/* This part will have data */
/* We can get multiple part file for a single source file */

dbutils.fs.ls("dbfs:/FileStore/tables/copyfile/csvfile1.csv")
O/P :- 
Out[3]: [FileInfo(path='dbfs:/FileStore/tables/copyfile/csvfile1.csv/_SUCCESS', name='_SUCCESS', size=0),
FileInfo(path='dbfs:/FileStore/tables/copyfile/csvfile1.csv/_committed_3559981104939048573', name='_committed_3559981104939048573', size=112),
FileInfo(path='dbfs:/FileStore/tables/copyfile/csvfile1.csv/_started_3559981104939048573', name='_started_3559981104939048573', size=0),
FileInfo(path='dbfs:/FileStore/tables/copyfile/csvfile1.csv/part-00000-tid-3559981104939048573-b3454d6f-e5f7-4056-a72e-1e000f37eb32-17-1-c000.csv', name='part-00000-tid-3559981104939048573-b3454d6f-e5f7-4056-a72e-1e000f37eb32-17-1-c000.csv', size=76)]

/* Conclusion :- */
Spark uses Hadoop File Format, which requires data to be partitioned - that’s why we have part- files.
If data size of file will be large then we will get multiple part file.
But using "coalesce" we can restrict it into one part file. So here all data will be written
into a single cluster.So if file size is exceeding from the available size of cluster then cluster will crash.
So in that case "coalesce" should not be used.

So after write operation we need to rename the file.No other option available to pass file name while
writing data to file.

The key thing to always remember about Spark is that the data is always spread out across 
multiple computers. The data doesn’t reside in the memory of just one computer. 
It has been divided into multiple partitions, and those partitions are distributed 
across many computers.

When you tell Spark to write your data, it completes this operation in parallel. 
The driver tells all of the nodes to start writing their data at the same time. 
So each node in the cluster starts writing all of the partitions that it has at 
the same time all of the other nodes are writing all of their partitions. 
Therefore, Spark can’t write the data to just one file because all of the nodes would be 
tripping over each other. They would each try to write to the same file and end up 
overwriting the data that other nodes had written.
To solve this problem, Spark saves the data from each partition to its own file. 
Therefore, the number of files that get written is equal to the number of partitions 
that Spark created for your data.


9) Write file data into a new file.Only 1 part file using "coalesce" and rename file name.
and copy that file into another folder and deleting existing folder where all these files are present.
Output Folder :- /FileStore/tables/copyfile/
Output Folder File Name :- csvfile1.csv

df = spark.read.csv("dbfs:/FileStore/tables/csvfile/csvfile1.csv",header=True,inferSchema=True,sep=",")
df.show()
df.coalesce(1).write.mode("overwrite").format("csv").save("dbfs:/FileStore/tables/copyfile/")

data_location = "dbfs:/FileStore/tables/copyfile/"

files = dbutils.fs.ls(data_location)
csv_file = [x.path for x in files if x.path.endswith(".csv")][0]
dbutils.fs.mv(csv_file, "dbfs:/FileStore/tables/copyfilee/csvfile1.csv")
dbutils.fs.rm(data_location, recurse = True)

O/P :- 
So here part file has been renamed to file name as per our choice.
and placed inside another folder called "copyfilee".
Folder "copyfile" has been droped.
I am not getting a code where i can delete all files inside a directory without deleting directory.
dbutils.fs.rm("dbfs:/FileStore/tables/copyfile/", recurse = True)
This command is deleting copyfile directory.
So here creating a new folder after rename.
/* Try to get the code to delete all files inside a directory */

10) Generate only part file while writing and ignore all other file like _SUCCESS etc.

Output Folder :- /FileStore/tables/copyfile/
Output Folder File Name :- csvfile1.csv

/* Not getting any code through which we can disable/ignore _SUCCESS/_committed_3559981104939048573_started_3559981104939048573 files. */

11) While copying if multiple part file generated then combine it into a single file through below
pandas code.

import os
import glob
import pandas as pd

df = spark.read.csv("dbfs:/FileStore/tables/csvfile/csvfile1.csv",header=True,inferSchema=True,sep=",")
df.show()
df1 = spark.read.csv("dbfs:/FileStore/tables/multicsvfile/csvfile2.csv",header=True,inferSchema=True,sep=",")
df1.show()
df.write.mode("overwrite").format("csv").save("dbfs:/FileStore/tables/copyfile/")
df1.write.mode("overwrite").format("csv").save("dbfs:/FileStore/tables/copyfile/")
dbutils.fs.put("dbfs:/FileStore/tables/copyfile/part-00000-tid-3559981104939048573-b3454d6f-e5f7-4056-a72e-1e000f37eb32-17-1-c001.csv","1,Kohli,186,10")

/* Try to combine these file using below mentioned Pandas code */
os.chdir("/mydir")
extension = 'csv'
all_filenames = [i for i in glob.glob('*.{}'.format(extension))]
#combine all files in the list
combined_csv = pd.concat([pd.read_csv(f) for f in all_filenames ])
#export to csv
combined_csv.to_csv( "combined_csv.csv", index=False, encoding='utf-8-sig')



joined_files = os.path.join("/home", "mydata*.csv")
joined_list = glob.glob(joined_files)


dbutils.fs.head("dbfs:/FileStore/tables/copyfile/part-00000-tid-3559981104939048573-b3454d6f-e5f7-4056-a72e-1e000f37eb32-17-1-c001.csv")
/* Not sure will work or not */

12) Generic way to handle multiple part files using ADF pipelines Copy Activity.
Write a notebook which will generate multiple part files.
Then using ADF copy activity to merge all these files into a single file and keep in some other location.
Do all these in ADLS gen 2 storage account.

File Name :- BigCsvFile.csv /* Big file to generate multiple part file */
File Path :- 

/* Notebook :- */
Name :- CopyFileNotebook
Language :- Python

#/* Create folder to keep part file */
PartOutput

#/* create folder to keep merged part file and give name as per our choice */
MergedOutput

#/* Main Code to copy data */
#/* Azure Storage Access Information */
blob_account_name = "abksynapseadlsgen2"
blob_container_name = "abksynapsecontainer"
blob_relative_path = "input/BigCsvFile.csv"

blob_sas_token = r"?sv=2020-08-04&ss=bfqt&srt=sco&sp=rwdlacupx&se=2026-04-01T12:41:00Z&st=2021-08-25T04:41:00Z&spr=https&sig=IjgKI3hdXn8W8eYjJVe1k3Kn8sTp6QxyJkKcw4i20TI%3D"

#/* Read file from blob storage */
wasbs_path = 'wasbs://%s@%s.blob.core.windows.net/%s' % (blob_container_name, blob_account_name, blob_relative_path)
fileoutputpath="wasbs://abksynapsecontainer@abksynapseadlsgen2.blob.core.windows.net/PartOutput"
spark.conf.set('fs.azure.sas.%s.%s.blob.core.windows.net' % (blob_container_name, blob_account_name), blob_sas_token)

df = spark.read.csv(wasbs_path,header=True)
df.write.mode("append").format("csv").save(fileoutputpath)

O/P :- 
part-00000-tid-8998997353191964369-1b683569-6793-4fa1-8358-242e63b0cc71-10-1-c000.csv
part-00001-tid-8998997353191964369-1b683569-6793-4fa1-8358-242e63b0cc71-11-1-c000.csv
part-00002-tid-8998997353191964369-1b683569-6793-4fa1-8358-242e63b0cc71-12-1-c000.csv

/* ADF Pipeline */
Pipeline Name :- MergedPartFiles
Activity Name :- CopyActivity
Source :- 
Source dataset :- DS_PartOutput /* Will point to PartOutput folder where multiple part files are present */
File Path Type :- WildCard file Path
Wild Card Path :- *.csv

Sink :- 
Sink Dataset :- DS_MergedOutput /* This will point to Mergedfiles.csv file inside MergedOutput folder */  
Copy Behaviour :- Merge Files
File Extension :- .csv

/* Publish and run the pipeline */
O/P :- Merged file got generated in MergedOutput folder.
If sink dataset is pointing to only folder then by default file name will be gived.
File Name :- data_af5435cf-a211-45c7-ada9-fafd0baba534_82a8833a-063b-4416-87a0-37f29e85fe4b.csv


If sink dataset is pointing to file theen by as per our choice file name will come.
File Name :- MergesFile.csv


/* https://www.youtube.com/watch?v=j7mblYz3b5w&ab_channel=Cloudpandith */
/* 11 Copy Behaviour in Azure Data Factory */

Note :- Here copy activity is discussed in details.Must watch it.

-----------------------------------------------------------------------------------------
https://www.sqlshack.com/load-data-into-azure-sql-database-from-azure-databricks/
/* Load data into Azure SQL Database from Azure Databricks */
-----------------------------------------------------------------------------------------
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
WorkSpace Name :- uspLocalDatabricks
Cluster Name :- uspdevcluster
Cluster Mode :- Standard
Databricks Run time version :- 8.2 (Scala 2.12 Spark 3.1.1) (By default)

SQL Database :- 
Server Name 	:- osedbserverlocal.database.windows.net
Authentication 	:- SQL Server Authentication
Login			:- adminuser
Password 		:- usP>>2021
Database Name :- oselocaltxdb_S33

Uploading a CSV file on Azure Databricks Cluster :- 
File Name :- 1000_Sales_Records-1.csv
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure Learning\1000_Sales_Records-1.csv

DataBricks >>> Data >>> Create table >> Upload >>> C:\Users\10662208\Desktop\ABHILASH\Script\Azure Learning\1000_Sales_Records-1.csv
Uploaded Path :- /FileStore/tables/1000_Sales_Records_1.csv
/* This file will be uploaded into DBFS file system */
/* DBFS is a Databricks File System that allows you to store data for querying inside of Databricks. */
/* The way we were creating data frame in pandas same way we can create here and later
on this data frame can be used to visulize data and do analysis. */

Create a Notebook :- /* To load .csv file to SQL DB. */
Name :- LoadDataSQLTable
Language :- Python
Cluster :- uspdevcluster

sqlContext() :- To read the csv file and create a data frame.
DataFrameWriter :- It is the interface to describe how data 
(as the result of executing a structured query) should be saved to an external data source.

1) /* Code For Notebook :- LoadDataSQLTable */
/* Here target table "TotalProfit" will be created in this script only */
/* After insert check count of data into table */

import sys
import traceback
import re
from pyspark.sql import *
import pandas as pd

try:
    jdbcHostname = "osedbserverlocal.database.windows.net"
    jdbcPort = "1433"
    jdbcDatabase = "oselocaltxdb_S33"
    properties = {"user" : "adminuser","password" : "usP>>2021" }

    url = "jdbc:sqlserver://{0}:{1};database={2}".format(jdbcHostname,jdbcPort,jdbcDatabase)
    mydf = sqlContext.read.csv("/FileStore/tables/1000_Sales_Records_1.csv",header=True)
    print(mydf)

# /* If data already exist then it will be overwritten */
    myfinaldf = DataFrameWriter(mydf)
    myfinaldf.jdbc(url=url, table= "TotalProfit", mode ="overwrite", properties = properties)

# /* If data already exist in the table then it will be appended */
    mydf1 = spark.read.csv("/FileStore/tables/1000_Sales_Records_1.csv",header=True)
    mydf1.write.mode(saveMode="Append").jdbc(url=url,properties=properties,table="TotalProfit")

# /* Read data from database */
    pushdown_query = "(select top 10 * from TotalProfit) emp_alias"
    TotalProfit_df = spark.read.jdbc(url=url, table=pushdown_query, properties=properties)
    TotalProfit_df.show()   #Dotted Line Display
    display(TotalProfit_df) #Better Display

# /* Read count of data from database */
    pushdown_query1 = "(select count(*) as cnt from TotalProfit) emp_alias1"
    TotalProfit_df1 = spark.read.jdbc(url=url, table=pushdown_query1, properties=properties)
    display(TotalProfit_df1) #Better Display

except Exception as e:
    print(e)
    print(sys.exc_info())
    print(traceback.format_exc())
    print(sys.exc_info())

O/P :- 
SELECT * FROM TotalProfit;
/* 2000 rows present :- Next time again 1k record got appended */


2) /* Same example but get username & password from Keyvault */
i) Create a secret for username and password in Keyvault.
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Keyvault name :- usplocalkeyvault
Vault URI/DNS Name :- https://usplocalkeyvault.vault.azure.net/
Directory Id :- 72f988bf-86f1-41af-91ab-2d7cd011db47
Subscription Id :- 068b4f24-e652-4497-9b14-346db4e3c3fa
Resource Id :- /subscriptions/068b4f24-e652-4497-9b14-346db4e3c3fa/resourceGroups/uspstagingdbgroupdev/providers/Microsoft.KeyVault/vaults/usplocalkeyvault

user : adminuser
password : usP>>2021

Secret Name :- S33user :- adminuser
Secret Name :- S33password :- usP>>2021

ii) Create a secret Scope :- 
/* Launch WorkSpace,Every workspace has a URL */
WorkSpace Name :- uspLocalDatabricks
URL :- https://adb-7699593049064036.16.azuredatabricks.net/?o=7699593049064036

Once your Azure Databricks workspace is open in a separate window, 
append #secrets/createScope to the URL. The URL should have the following format:

Sample :- 
https://<\location>.azuredatabricks.net/?o=<\orgID>#secrets/createScope.
New URL :- 
https://adb-7699593049064036.16.azuredatabricks.net/?o=7699593049064036#secrets/createScope
/* Create Secret Scope */
Scope Name :- DatabricksSecretScope2
DNS Name  :- https://usplocalkeyvault.vault.azure.net/ :- /* Vault URI DNS from azure keyvault inside properties */
Resource Id :- /subscriptions/068b4f24-e652-4497-9b14-346db4e3c3fa/resourceGroups/uspstagingdbgroupdev/providers/Microsoft.KeyVault/vaults/usplocalkeyvault
/* from azure keyvault inside properties */ 

Create a Notebook :- /* To load .csv file to SQL DB. */
Name :- LoadDataSQLTable1
Language :- Python
Cluster :- uspdevcluster

/* Code */
import sys
import traceback
import re
from pyspark.sql import *
import pandas as pd

try:
    jdbcHostname = "osedbserverlocal.database.windows.net"
    jdbcPort = "1433"
    jdbcDatabase = "oselocaltxdb_S33"
    #properties = {"user" : "adminuser","password" : "usP>>2021" }
    
    user=dbutils.secrets.get(scope = "DatabricksSecretScope2",key="S33user"))
    password=dbutils.secrets.get(scope = "DatabricksSecretScope2",key="S33password"))
    properties = {"user" : user,"password" : password }

    url = "jdbc:sqlserver://{0}:{1};database={2}".format(jdbcHostname,jdbcPort,jdbcDatabase)
    mydf = sqlContext.read.csv("/FileStore/tables/1000_Sales_Records_1.csv",header=True)
    print(mydf)

# /* If data already exist then it will be overwritten */
    myfinaldf = DataFrameWriter(mydf)
    myfinaldf.jdbc(url=url, table= "TotalProfit", mode ="overwrite", properties = properties)

# /* If data already exist in the table then it will be appended */
    mydf1 = spark.read.csv("/FileStore/tables/1000_Sales_Records_1.csv",header=True)
    mydf1.write.mode(saveMode="Append").jdbc(url=url,properties=properties,table="TotalProfit")

# /* Read data from database */
    pushdown_query = "(select count(*) from TotalProfit) emp_alias"
    TotalProfit_df = spark.read.jdbc(url=url, table=pushdown_query, properties=properties)
    display(TotalProfit_df) #Better Display

except Exception as e:
    print(e)
    print(sys.exc_info())
    print(traceback.format_exc())
    print(sys.exc_info())

O/P :- 
SELECT count(*) FROM TotalProfit;
2000

-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
Own :- 
Requirement :- Create a temp view on the uploaded file in DBFS.

cat > Employee.csv
A	30	Male
B	31	Male
C	32	Male
D	33	Male

Create Notebook :- 
i) Name :- MyNotebook-1
ii) Default language :- Python
iii) cluster :- uspdevcluster

/* Code */
from pyspark.sql import *
#import pandas as pd

#/* Read file from DBFS storage */
wasbs_path = '/FileStore/tables/employee-4.csv'
print('Remote blob path: ' + wasbs_path)

#/* Create DataFrame */
df = spark.read.csv(wasbs_path,header=True)
print(df)
print('Register the DataFrame as a SQL temporary view: source')
df.createOrReplaceTempView('source')
print('Displaying top 10 rows: ')
display(spark.sql('SELECT * FROM source LIMIT 10'))


O/P :- 
Remote blob path: /FileStore/tables/employee-4.csv
DataFrame[Name: string, Age: string, Gender: string]
Register the DataFrame as a SQL temporary view: source
Displaying top 10 rows: 

Explanation :- 
createorReplaceTempView is used when we want to store the table for a particular spark session.
CreateOrReplaceTempView will create a temporary view of the table on memory it is 
not presistant at this moment but we can run sql query on top of that. 
If we want to save it we can either persist or use saveAsTable to save.
createOrReplaceTempView creates a lazily evaluated "view" that you can then use like a hive table in Spark SQL
First we read data in csv format and then convert to data frame and create a temp view (createOrReplaceTempView).


-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=yeNgrBxHmCc&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=4&ab_channel=Cloudpandith */
/* 31.Reading files from azure blob storage Directly in Azure Databricks, Writing files to blob storage */
-----------------------------------------------------------------------------------------
There are two ways through which blob data can be accessed.
i) Use access key of BLOB storage and directly access the files.
ii) Create Azure blob storage mount point on azure data bricks.
Means attaching blob data storage into data bricks.

About BLOB Storage :- 
--------------------------
i) It is a microsoft object storage solution for the cloud.
ii) It is optimized for storing massive amount of un-structured data.

About Azure Key Vault :- 
------------------------------
It is a cloud service that provides a secure store for secrets.We can securely
stores keys, passwords, certificates and other secrets.

Secret Scope :- 
-------------------------
It is a logical grouping mechanism for secrets.All secret belongs to a scope.
Scopes are idetifiable by name and it is unique per user’s workspace.
In order to connect to Key Vault from Azure databricks Secret scope is required in databricks.
Go to https://<databricks-instance.>#secrets/createScope.

Syntax to connect to BLOB storage directly using Access key :- 
-----------------------------------------------------------------
1) spark.conf.set("fs.azure.account.key.<StorageAccountName>.blob.core.windows.net",
                  dbutils.secrets.get(scope = "abkscope",key="blobkey"))
key :- Secret Name from KeyVault
2) BLOB URL Syntax :- wasbs://containername@storagename.blob.core.windows.net

Disadvabtage of above connection :- 
---------------------------------------------
If cluster got restarted then this connection again needs to be executed then only
file can be read from blob storage.

/* Code will be written based on Mount Point */
Importance of Mount Point :- 
----------------------------------------------
i) All users in the databricks workspace has access to the mounted Azure BLOB container.
Here we mount container name to databricks.
ii) Once a mount point is created through a cluster, users of that cluster can immediately
access the mount point.Even if cluster is down next time directly it can access mount point.
iii) In order to use mount point in another running cluster, we need to run below command
to make newly created mount point available for use.
dbutils.fs.refreshMounts()

Syntax to Create Mount Point for BLOB storage in Databricks :- 
---------------------------------------------------------------------
#source = "wasbs://<your-container-name>@<your-storage-account-name>.blob.core.windows.net",
#mount_point = "/mnt/<Container-Name>",
#extra_configs = {"<conf-key>":dbutils.secrets.get(scope = "<scope-name>", key = "<key-name>")})
#conf-key = fs.azure.account.key.<\storage-account-name>.blob.core.windows.net

dbutils.fs.mount(
source = "wasbs://uspstagingcontainer@uspstorageaccountnew.blob.core.windows.net",
mount_point = "/mnt/uspstagingcontainer",
extra_configs = {"fs.azure.account.key.uspstorageaccountnew.blob.core.windows.net":dbutils.secrets.get(scope = "DatabricksSecretScope", key = "blobkey")})


Syntax to Unmount blobstorage from Databricks :- 
---------------------------------------------------------------------
dbutils.fs.unmount("/mnt/uspstagingcontainer")


Read files into Dataframe :- 
------------------------------------------------------
1) format :- csv,parquet etc..
df = spark.read.format("format").load("mnt/uspstagingcontainer")
df.show()

2) format :- csv,parquet etc..
df = spark.read.format("format").load("mnt/uspstagingcontainer")
df.show()

3) format :- csv,parquet etc..
df = spark.read.format("format").schema(s).load("mnt/uspstagingcontainer")
df.show()


Write Dataframe as File :- 
---------------------------------------------------------
1) format = csv,parquet etc..
df.write.mode("overwrite").format("format").save("mnt/uspstagingcontainer")

2) format = csv,parquet etc..
df.write.mode("append").format("format").save("mnt/uspstagingcontainer")

1) /* Access blob container from Azure Databricks from input folder */
/* Without Mount. Reading file directly from blob storage */

i) /* File Storage Detail */
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
Folder Name :- csv
File Name :- Emp.csv
Folder Name :- json
File Name :- cpmultijson1.json,cpmultijson2.json,cpjson1.json,cpjson2.json

SAS Token field  /* Present under Shared Access Signature */ :- ?sv=2020-02-10&ss=bfqt&srt=sco&sp=rwdlacuptfx&se=2021-06-15T22:26:13Z&st=2021-06-15T14:26:13Z&spr=https&sig=Cnlgkje1I0X4%2B2Qe6WUxr1Te2x7lbzMABgY3aDaDQCQ%3D
Access key /* Present under Access Keys */ 
Key 1 :- gp0XnD19MdVHZdDUYBZdz5yjsxafV9HEFibsX+C1Ncqkc3JFrrEbO0HSJO+4InfRRZSpdN5leBH6EnO4MCg1Pw==
Key 2 :- TABQS0Xrt9yUYX6cIrrZppi9n/P/TlhISoQCc/0JxMZeG3bIOx2hpH6A7zQn62oD8C5ZfhxEitXE2oHgEqtB9g==

ii) /* Azure Key Vault details */
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Key vault name :- usplocalkeyvault
Vault URI/DNS Name :- https://usplocalkeyvault.vault.azure.net/
Directory Id :- 72f988bf-86f1-41af-91ab-2d7cd011db47
Subscription Id :- 068b4f24-e652-4497-9b14-346db4e3c3fa
Resource Id :- /subscriptions/068b4f24-e652-4497-9b14-346db4e3c3fa/resourceGroups/uspstagingdbgroupdev/providers/Microsoft.KeyVault/vaults/usplocalkeyvault

iii) /* Create secrets for blob storage Access key */
Secrets :- Create :- 
Name :- StorageKey
Value /* Key 1 */ :- gp0XnD19MdVHZdDUYBZdz5yjsxafV9HEFibsX+C1Ncqkc3JFrrEbO0HSJO+4InfRRZSpdN5leBH6EnO4MCg1Pw==
Content Type :- /* Optional */
/* Generate */

iv) /* Create Secrets at Databrciks. */
/* Launch WorkSpace,Every workspace has a URL */
WorkSpace Name :- uspLocalDatabricks
URL :- https://adb-7699593049064036.16.azuredatabricks.net/?o=7699593049064036

Once your Azure Databricks workspace is open in a separate window, 
append #secrets/createScope to the URL. The URL should have the following format:

Sample :- 
https://<\location>.azuredatabricks.net/?o=<\orgID>#secrets/createScope.
New URL :- 
https://adb-7699593049064036.16.azuredatabricks.net/?o=7699593049064036#secrets/createScope
/* Create Secret Scope */
Scope Name :- DatabricksSecretScope2
DNS Name /* Vault URI DNS from azure keyvault inside properties */ :- https://usplocalkeyvault.vault.azure.net/
Resource Id :- /* from azure keyvault inside properties */ 
/subscriptions/068b4f24-e652-4497-9b14-346db4e3c3fa/resourceGroups/uspstagingdbgroupdev/providers/Microsoft.KeyVault/vaults/usplocalkeyvault

/* Select Manage Principle as "All Users" to avoid below error */
Note :- This error was coming while creating Secret Scope
/* Premium Tier is disabled in this workspace. Secret scopes can only be created with initial_manage_principal "users". 
Since while creating workgroup "Cluster Mode :- Standard" this was selected.
and secret scope is not supported in it.It is supported in "Premium Tier".
Re-Create the same workspace "uspLocalDatabricks" and select Cluster Mode= "Premium Tier".
After doing this "Secret Scope" got created.
*/
v) /* Access blob container from Azure Databricks from input folder */

Create Notebook :- 
i) Name :- ReadBlobStorageNotebook
ii) Default language :- Python
iii) cluster :- uspdevcluster

/* Read blob storage directly using KEY no mount */

/* Code */
1) 
spark.conf.set("fs.azure.account.key.uspstorageaccountnew.blob.core.windows.net",
dbutils.secrets.get(scope = "DatabricksSecretScope2",key="StorageKey"))

# /* blobpath="wasbs://uspstagingcontainer@uspstorageaccountnew.blob.core.windows.net/" */
# /* At a time only one folder can be read */
filepath="wasbs://uspstagingcontainer@uspstorageaccountnew.blob.core.windows.net/csv"
csvdf = spark.read.format("csv").option("header",True).option("inferSchema",True).load(filepath)
csvdf.show()

O/P :- 
empno:integer
ename:string
job:string
mgr:integer
hiredate:string
sal:integer
comm:integer
deptno:integer
+-----+------+---------+----+----------+----+----+------+
|empno| ename|      job| mgr|  hiredate| sal|comm|deptno|
+-----+------+---------+----+----------+----+----+------+
| 7839|  KING|PRESIDENT|null|17-11-1981|5000|null|    10|
| 7698| BLAKE|  MANAGER|7839|  1-5-1981|2850|null|    30|
| 7782| CLARK|  MANAGER|7839|  9-6-1981|2450|null|    10|
| 7566| JONES|  MANAGER|7839|  2-4-1981|2975|null|    20|
| 7788| SCOTT|  ANALYST|7566|   13-7-87|3000|null|    20|
| 7902|  FORD|  ANALYST|7566| 3-12-1981|3000|null|    20|
| 7369| SMITH|    CLERK|7902|17-12-1980| 800|null|    20|
| 7499| ALLEN| SALESMAN|7698| 20-2-1981|1600| 300|    30|
| 7521|  WARD| SALESMAN|7698| 22-2-1981|1250| 500|    30|
| 7654|MARTIN| SALESMAN|7698| 28-9-1981|1250|1400|    30|
| 7844|TURNER| SALESMAN|7698|  8-9-1981|1500|   0|    30|
| 7876| ADAMS|    CLERK|7788|   13-7-87|1100|null|    20|
| 7900| JAMES|    CLERK|7698| 3-12-1981| 950|null|    30|
| 7934|MILLER|    CLERK|7782| 23-1-1982|1300|null|    10|
+-----+------+---------+----+----------+----+----+------+

2) 
#/* Copy file from csv folder to csvoutput folder. */
spark.conf.set("fs.azure.account.key.uspstorageaccountnew.blob.core.windows.net",
dbutils.secrets.get(scope = "DatabricksSecretScope2",key="StorageKey"))

filepath="wasbs://uspstagingcontainer@uspstorageaccountnew.blob.core.windows.net/csv/Emp.csv"
csvdf = spark.read.format("csv").option("header",True).option("inferSchema",True).load(filepath)
csvdf.show()
fileoutputpath="wasbs://uspstagingcontainer@uspstorageaccountnew.blob.core.windows.net/csvoutput"
csvdf.write.mode("overwrite").format("csv").save(fileoutputpath)

O/P :- Here also while copying part file will be created along with _SuCCESS & _COMMITTED folder.

3) 
#/* Rename copied file as per our choice after copy in thge same folder */
spark.conf.set("fs.azure.account.key.uspstorageaccountnew.blob.core.windows.net",
dbutils.secrets.get(scope = "DatabricksSecretScope2",key="StorageKey"))

filepath="wasbs://uspstagingcontainer@uspstorageaccountnew.blob.core.windows.net/csv/Emp.csv"
csvdf = spark.read.format("csv").option("header",True).option("inferSchema",True).load(filepath)
csvdf.show()

fileoutputpath="wasbs://uspstagingcontainer@uspstorageaccountnew.blob.core.windows.net/csvoutput"
csvdf.coalesce(1).write.mode("overwrite").format("csv").save(fileoutputpath)

files = dbutils.fs.ls(fileoutputpath)
print(files)
for x in files:
    if x.name.startswith("part-"):
        print(x.name)
        File_Name=x.name

oldfilename="wasbs://uspstagingcontainer@uspstorageaccountnew.blob.core.windows.net/csvoutput/"+File_Name
newfilename="wasbs://uspstagingcontainer@uspstorageaccountnew.blob.core.windows.net/csvoutput/Emp.csv"

dbutils.fs.mv(oldfilename,newfilename)

O/P :- File got renamed to Emp.csv in blob storage.

4) 
#/* Read Multiple multiline JOSN file using 2nd Multiline method */
filepath="wasbs://uspstagingcontainer@uspstorageaccountnew.blob.core.windows.net/json"
jsondf = spark.read.format("json").option("multiline","True").load(filepath)
jsondf.show()

O/P :- 
jsondf:pyspark.sql.dataframe.DataFrame
age:long
name:string
secretIdentity:string
userId:long
+---+---------------+--------------+------+
|age|           name|secretIdentity|userId|
+---+---------------+--------------+------+
| 29|   Molecule Man|     Dan Jukes|     1|
| 39|Madame Uppercut|   Jane Wilson|     2|
| 50|  Eternal Flame|       Unknown|     3|
| 29|   Molecule Man|     Dan Jukes|     4|
| 39|Madame Uppercut|   Jane Wilson|     5|
| 50|  Eternal Flame|       Unknown|     6|
+---+---------------+--------------+------+


4) 
#/* Write json data into another folder jsonoutput in json format*/
fileoutputpath="wasbs://uspstagingcontainer@uspstorageaccountnew.blob.core.windows.net/jsonoutput"
jsondf.write.mode("overwrite").format("json").save(fileoutputpath)

#/* Write json data into another folder jsonoutput1 in csv format*/
fileoutputpath1="wasbs://uspstagingcontainer@uspstorageaccountnew.blob.core.windows.net/jsonoutput1"
jsondf.write.mode("overwrite").format("csv").option("header",True).save(fileoutputpath)

/* See diffenece in writing as JSON and csv */

Conclusion :- 
-----------------
i) Azure Storage Properties :- i) SAS Token field ii) Access key
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
SAS Token field  /* Present under Shared Access Signature */ :- ?sv=2020-02-10&ss=bfqt&srt=sco&sp=rwdlacuptfx&se=2021-06-15T22:26:13Z&st=2021-06-15T14:26:13Z&spr=https&sig=Cnlgkje1I0X4%2B2Qe6WUxr1Te2x7lbzMABgY3aDaDQCQ%3D
Access key /* Present under Access Keys */ 
Key 1 :- gp0XnD19MdVHZdDUYBZdz5yjsxafV9HEFibsX+C1Ncqkc3JFrrEbO0HSJO+4InfRRZSpdN5leBH6EnO4MCg1Pw==
Key 2 :- TABQS0Xrt9yUYX6cIrrZppi9n/P/TlhISoQCc/0JxMZeG3bIOx2hpH6A7zQn62oD8C5ZfhxEitXE2oHgEqtB9g==

ii) KeyVault Properties :- 
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Key vault name :- usplocalkeyvault
Vault URI/DNS Name :- https://usplocalkeyvault.vault.azure.net/
Directory Id :- 72f988bf-86f1-41af-91ab-2d7cd011db47
Subscription Id :- 068b4f24-e652-4497-9b14-346db4e3c3fa
Resource Id :- /subscriptions/068b4f24-e652-4497-9b14-346db4e3c3fa/resourceGroups/uspstagingdbgroupdev/providers/Microsoft.KeyVault/vaults/usplocalkeyvault

iii) Create a secret in Keyvault for Azure Storage Access key.

iv) Get Azure databricks Workspace URL which we will create and write code.

v) Create a secret Scope.append #secrets/createScope to the URL. The URL should have the following format:
Sample :- 
https://<\location>.azuredatabricks.net/?o=<\orgID>#secrets/createScope.
New URL :- 
https://adb-7699593049064036.16.azuredatabricks.net/?o=7699593049064036#secrets/createScope

vi) Inside notebook where actual code will be written to access BLOB storage file.
Write below mentioned syntax to create connection.
spark.conf.set("fs.azure.account.key.uspstorageaccountnew.blob.core.windows.net",
dbutils.secrets.get(scope = "DatabricksSecretScope2",key="StorageKey"))
filepath="wasbs://uspstagingcontainer@uspstorageaccountnew.blob.core.windows.net/csv"

vii) Create a dataframe.
csvdf = spark.read.format("csv").option("header",True).option("inferSchema",True).load(filepath)
csvdf.show()

viii) At a time only one folder can be read from blob storage.

---------------------------------------------------------------------------------------------------
Own 1:- 
---------------------------------------------------------------------------------------------------
Req :- Read EMP and Dept data from ADLSGen2 input folder and create two temp view and then 
join these two temp views and select only 4 columns and then again create a new dataframe and
write data into output folder.


Create Notebook :- 
i) Name :- CopytoADLSGen2
ii) Default language :- Python
iii) cluster :- uspdevcluster

/* Code */
from pyspark.sql import *
import pandas as pd

#/* Azure Storage Access Information */
blob_account_name = "abksynapseadlsgen2"
blob_container_name = "abksynapsecontainer"
blob_relative_path = "input/Emp.csv"
blob_relative_path1 = "input/Dept.csv"

blob_sas_token = r"?sv=2020-08-04&ss=bfqt&srt=sco&sp=rwdlacupx&se=2026-04-01T12:41:00Z&st=2021-08-25T04:41:00Z&spr=https&sig=IjgKI3hdXn8W8eYjJVe1k3Kn8sTp6QxyJkKcw4i20TI%3D"

#/* Read file from blob storage */
wasbs_path = 'wasbs://%s@%s.blob.core.windows.net/%s' % (blob_container_name, blob_account_name, blob_relative_path)
wasbs_path1 = 'wasbs://%s@%s.blob.core.windows.net/%s' % (blob_container_name, blob_account_name, blob_relative_path1)
spark.conf.set('fs.azure.sas.%s.%s.blob.core.windows.net' % (blob_container_name, blob_account_name), blob_sas_token)
#print('Remote blob path: ' + wasbs_path)

df = spark.read.csv(wasbs_path,header=True)
df1 = spark.read.csv(wasbs_path1,header=True)
#print(df)
#print(df1)
print('Register the DataFrame as a SQL temporary view: source')
df.createOrReplaceTempView('Emp')
df1.createOrReplaceTempView('Dept')
print('Displaying top 10 rows: ')
#display(spark.sql('SELECT * FROM Emp '))
#display(spark.sql('SELECT * FROM Dept '))
df2 = spark.sql('SELECT e.empno,e.ename,e.deptno,d.dname FROM Emp e inner join Dept d on (e.deptno=d.deptno)')
fileoutputpath="wasbs://abksynapsecontainer@abksynapseadlsgen2.blob.core.windows.net/output"
df2.write.mode("overwrite").format("csv").save(fileoutputpath)

-----------------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/azure/databricks/scenarios/quickstart-create-databricks-workspace-portal?tabs=azure-portal */
/* Quickstart: Run a Spark job on Azure Databricks Workspace using the Azure portal */
-----------------------------------------------------------------------------------------
/* Without Mount Point */
Requirement :- Read a file present in blob storage account and create a TempView from the
data present in the file.Then using SQL display data into screen.

/* Create a new WorkSpace */
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
WorkSpace Name :- uspLocalDatabricks
Region :- Code
Pricing Tier :- Standard (By Default)
Create >> This will create a "WorkSpace".
"Launch WorkSpace"

/* Create a new cluster */
Cluster Name :- uspdevcluster
Cluster Mode :- Standard
Databricks Run time version :- 8.2 (Scala 2.12 Spark 3.1.1) (By default)

/* File Storage Detail */
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
Folder Name :- input
File Name :- Emp.csv

Create blob_sas_token for "uspstorageaccountnew" storage account.
Go to "uspstorageaccountnew" >> Security + Networking >> Shared Access Signature
click the Generate SAS and connection string button
/* Copy text from SAS Token field :-  */
?sv=2020-08-04&ss=bfqt&srt=sco&sp=rwdlacuptfx&se=2021-07-14T22:39:11Z&st=2021-07-14T14:39:11Z&spr=https&sig=HHCUFAEC3EJ%2B0TsZtXLolDiHvYSvaPhEwSjyJ%2FKXZmM%3D

Create Notebook :- 
i) Name :- MyNotebook
ii) Default language :- Python
iii) cluster :- uspdevcluster

/* Code */
from pyspark.sql import *
import pandas as pd

#/* Azure Storage Access Information */
blob_account_name = "uspstorageaccountnew"
blob_container_name = "uspstagingcontainer"
blob_relative_path = "input/Emp.csv"
blob_sas_token = r"?sv=2020-08-04&ss=bfqt&srt=sco&sp=rwdlacuptfx&se=2021-07-14T22:39:11Z&st=2021-07-14T14:39:11Z&spr=https&sig=HHCUFAEC3EJ%2B0TsZtXLolDiHvYSvaPhEwSjyJ%2FKXZmM%3D"

#/* Read file from blob storage */
wasbs_path = 'wasbs://%s@%s.blob.core.windows.net/%s' % (blob_container_name, blob_account_name, blob_relative_path)
spark.conf.set('fs.azure.sas.%s.%s.blob.core.windows.net' % (blob_container_name, blob_account_name), blob_sas_token)
print('Remote blob path: ' + wasbs_path)

#/* Create DataFrame */
df = spark.read.csv(wasbs_path,header=True)
print(df)
print('Register the DataFrame as a SQL temporary view: source')
df.createOrReplaceTempView('source')
print('Displaying top 10 rows: ')
display(spark.sql('SELECT * FROM source LIMIT 10'))

O/P :- 
/* Data is coming Fine */

Explanation :- 
createorReplaceTempView is used when we want to store the table for a particular spark session.
CreateOrReplaceTempView will create a temporary view of the table on memory it is 
not presistant at this moment but we can run sql query on top of that. 
If we want to save it we can either persist or use saveAsTable to save.
createOrReplaceTempView creates a lazily evaluated "view" that you can then use like a hive table in Spark SQL
First we read data in csv format and then convert to data frame and create a temp view (createOrReplaceTempView).


-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=rpRaQTnLhvQ&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=9&ab_channel=Cloudpandith */
/* 37. Azure Databricks || Reading and Writing Data From ADLS Gen1, ADLS Gen2 and Blob Storage Directly */
-----------------------------------------------------------------------------------------
Reading/Writing Data from Blob/ADLS Gen2 Storage :- 
-------------------------------------------------------
These 2 storage account will have an access key.Using this key only we can access these storage
account.Instead of hardcoding key inside databricks code , we will keep that key inside
Keyvault and will create a secret.Now First databricks will connect to Keyvault and get the key
through secret scope then it will go to Storage account for read/write purpose through use of access key.


Reading/Writing Data from ADLS Gen1 Storage :- 
-------------------------------------------------------
/* Code for Blob & ADLS Gen2 */
Reading data from Blob & ADLS Gen2 through keyvault without mount is written in above example.
Refer that.

/* Code for ADLS Gen1 */
See next code :- 

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=GQ9lIZdDGDM&ab_channel=Cloudpandith */
/* Hands-On : Python : Mount Azure Data Lake Gen1 on Azure Databricks - Part 1 */
-----------------------------------------------------------------------------------------
There are two ways through which Databricks can connect to ADLS Gen1.
i) Mount ADLS Gen1 file system to DBFS using a service principle and Oauth 2.0
ii) Using a Service Principle directly.


Azure Data Lake Storage Gen1 :- 
----------------------------------------
Search "Data Lake Storage Gen1" and create.
Name :- uspdevadlaadls
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev

App Registration :- 
--------------------------
In order to connect to ADLS Gen1 file system from databricks, it requires permission for which
"App Registration" is required.

App Registration :- 
------------------------
i) Application-id :- It uniquely identifies the client application.
ii) Directory-id :- It uniquely identifies the Azure AD instance.
iii) Service-Credential :- This will be used by application to its identity.

Search "App Registrations" :- 
+ New Registration :- 
Name :- ADLGen1_MountUser
Supported account types :- (By Default) :- 
Who can use this application or access this API?
Accounts in this organizational directory only (Microsoft only - Single tenant)
>>> Register

/* Overview :- */
Application (client) ID :- 6ffd02c8-e5ad-47e9-a689-16c85ca9d229
Object ID :- c106c601-02cf-48fb-975f-2b4cc386ac7d
Directory (tenant) ID :- 72f988bf-86f1-41af-91ab-2d7cd011db47

/* Certificates & Secrets :- */
+ New Client Secret :- 
Name :- AdlsGen1
Value :- oSD~4_vYRqtNu3R0cKxhm~0s_27b8L7u~P /* Will wok as Password */
Secret ID :- 637fd889-2498-4fca-895a-6ede0e9074a8
So basically here we have created a user(ADLGen1_MountUser) whose password is Value.
Now this user needs access to connect to ADLS Gen1.

Go to ADLS Gen1 "uspdevadlaadls" :- 
Data Explorer >>> Access >>> +Add
Select user Or Group :- ADLGen1_MountUser
Read,Write & execute for 6 Months.

/* Now use ADLGen1_MountUser can access ADLS Gen1 storage */
Folder Name :- 
Name :- uspdevadlaadls
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Folder Name :- Samplecsv
File Name :- 1000_Sales_Records.csv

Now we will mount "Samplecsv" folder.So all files & folders present inside this folder will become
accessble to Databricks.

Create Notebook :- 
i) Name :- ADLSGen1Notebook
ii) Default language :- Python
iii) cluster :- uspdevcluster

/* Code */
# /* One time Activity.Once mounted can start reading/Writing Activity. */
username='6ffd02c8-e5ad-47e9-a689-16c85ca9d229' #Application (client) ID
password='oSD~4_vYRqtNu3R0cKxhm~0s_27b8L7u~P'   #Value
directoryid='72f988bf-86f1-41af-91ab-2d7cd011db47'  #Directory (tenant) ID
storagename='uspdevadlaadls'    #ADLS Gen1 Storage Name
mountpoint='Samplecsv'      #Folder Name

#Mount the Data Lake Gen1 to DBFS
configs = {"dfs.adls.oauth2.access.token.provider.type" : "ClientCredential",
        "dfs.adls.oauth2.client.id" : username,
        "dfs.adls.oauth2.credential" : password,
        "dfs.adls.oauth2.refresh.url" : "https://login.microsoftonline.com/"+directoryid+"/oauth2/token"}

dbutils.fs.mount(source = "adl://"+storagename+".azuredatalakestore.net/"+mountpoint,mount_point = "/mnt/"+mountpoint,extra_configs = configs)

# /* Do not run mount code again and again.Once mount is ready we can perform read/write operation */
# /* Reading activity */
root_path = "/mnt/"+mountpoint+"/1000_Sales_Records.csv"
#sourcepath = '' Since till Samplecsv folder it is mounted.So files present inside it can be accessed.
sourcefiletype = 'csv'
df = spark.read.csv(root_path,header=True)
display(df)

# /* Copy Activity */
targetpath = "/mnt/"+mountpoint+"target"
targetfiletype = 'csv'
df.write.mode("overwrite").option('header',True).save(targetpath)
df1 = spark.read.csv(targetpath,header=True)
display(df1)

O/P :- 
Data is coming fine in df dataframe from file.
/* Check copy activity.It is showing error */

mountpoint='Samplecsv'      #Folder Name
dbutils.fs.ls("/mnt/"+mountpoint)           #Files/Folders present under mounted folder.
dbutils.fs.unmount("/mnt/"+mountpoint)      #Unmount mounted storage

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=ZDly4kK82aw&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=17&ab_channel=Cloudpandith */
/* 69. Azure Data Factory Integration -Accessing a Databricks Notebook with Input and Output Parameters */
-----------------------------------------------------------------------------------------
i) /* File Storage Detail */
Azure Storage Account Name :- uspstorageaccountnew
Container Name :- uspstagingcontainer
Folder Name :- csvinput
File Name :- Emp.csv
Folder Name :- jsoninput
File Name :- cpjson1.json

SAS Token field  /* Present under Shared Access Signature */ :- ?sv=2020-02-10&ss=bfqt&srt=sco&sp=rwdlacuptfx&se=2021-06-15T22:26:13Z&st=2021-06-15T14:26:13Z&spr=https&sig=Cnlgkje1I0X4%2B2Qe6WUxr1Te2x7lbzMABgY3aDaDQCQ%3D
Access key /* Present under Access Keys */ 
Key 1 :- gp0XnD19MdVHZdDUYBZdz5yjsxafV9HEFibsX+C1Ncqkc3JFrrEbO0HSJO+4InfRRZSpdN5leBH6EnO4MCg1Pw==
Key 2 :- TABQS0Xrt9yUYX6cIrrZppi9n/P/TlhISoQCc/0JxMZeG3bIOx2hpH6A7zQn62oD8C5ZfhxEitXE2oHgEqtB9g==

ii) /* Azure Key Vault details */
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Key vault name :- usplocalkeyvault
Vault URI/DNS Name :- https://usplocalkeyvault.vault.azure.net/
Directory Id :- 72f988bf-86f1-41af-91ab-2d7cd011db47
Subscription Id :- 068b4f24-e652-4497-9b14-346db4e3c3fa
Resource Id :- /subscriptions/068b4f24-e652-4497-9b14-346db4e3c3fa/resourceGroups/uspstagingdbgroupdev/providers/Microsoft.KeyVault/vaults/usplocalkeyvault

iii) /* Create secrets for blob storage Access key */
Secrets :- Create :- 
Name :- StorageKey
Value /* Key 1 */ :- gp0XnD19MdVHZdDUYBZdz5yjsxafV9HEFibsX+C1Ncqkc3JFrrEbO0HSJO+4InfRRZSpdN5leBH6EnO4MCg1Pw==
Content Type :- /* Optional */
/* Generate */

iv) /* Create Secrets at Databrciks. */
/* Launch WorkSpace,Every workspace has a URL */
WorkSpace Name :- uspLocalDatabricks
URL :- https://adb-7699593049064036.16.azuredatabricks.net/?o=7699593049064036

Once your Azure Databricks workspace is open in a separate window, 
append #secrets/createScope to the URL. The URL should have the following format:

Sample :- 
https://<\location>.azuredatabricks.net/?o=<\orgID>#secrets/createScope.
New URL :- 
https://adb-7699593049064036.16.azuredatabricks.net/?o=7699593049064036#secrets/createScope
/* Create Secret Scope */
Scope Name :- DatabricksSecretScope2
DNS Name /* Vault URI DNS from azure keyvault inside properties */ :- https://usplocalkeyvault.vault.azure.net/
Resource Id :- /* from azure keyvault inside properties */ 
/subscriptions/068b4f24-e652-4497-9b14-346db4e3c3fa/resourceGroups/uspstagingdbgroupdev/providers/Microsoft.KeyVault/vaults/usplocalkeyvault

/* Select Manage Principle as "All Users" to avoid below error */
Note :- This error was coming while creating Secret Scope
/* Premium Tier is disabled in this workspace. Secret scopes can only be created with initial_manage_principal "users". 
Since while creating workgroup "Cluster Mode :- Standard" this was selected.
and secret scope is not supported in it.It is supported in "Premium Tier".
Re-Create the same workspace "uspLocalDatabricks" and select Cluster Mode= "Premium Tier".
After doing this "Secret Scope" got created.
*/
v) /* Access blob container from Azure Databricks from input folder */

v) /* Azure Data Factory Details :- */
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev 
Datafactory Name :- uspstorageadf


Requirement :- Create a notebook which copy file from input folder to output folder.
Notebook will be called through an ADF pipeline and input and output folder name will 
passed as input.Get output of databricks which will be the input folder file name and 
store it into SQL Server.


1) /* Create Notebook :- */
i) Name :- ADFDatabricksIntegration
ii) Default language :- Python
iii) cluster :- uspdevcluster

/* Code */
#/* Create widgets to hold input and output folder name */
dbutils.widgets.text("inputfolder","")
dbutils.widgets.text("outputfolder","")

inputfoldername = dbutils.widgets.get("inputfolder")
outputfoldername = dbutils.widgets.get("outputfolder")

#/* Read blob storage directly using KEY no mount */
spark.conf.set("fs.azure.account.key.uspstorageaccountnew.blob.core.windows.net",
dbutils.secrets.get(scope = "DatabricksSecretScope2",key="StorageKey"))

sourcepath="wasbs://uspstagingcontainer@uspstorageaccountnew.blob.core.windows.net/"+inputfoldername
targetpath="wasbs://uspstagingcontainer@uspstorageaccountnew.blob.core.windows.net/"+outputfoldername

df = spark.read.format("csv").option("header",True).option("inferSchema",True).load(sourcepath)
df.show()

df.write.mode("overwrite").format("csv").option("header",True).save(targetpath)

2) /* Create a linked service to connect to Notebook from ADF pipeline */
i) Open the notebook ADFDatabricksIntegration
ii) Top right corner :- workspacename(user man icon) :- uspLocalDatabricks(Man Symbol) :- click
User Settings >>> Generate New Token >>> Comment >>> (fill name here) >>> adb_token >>> Generate
Copy Generated Token :- dapi6aff2ef6c182c62a43956a421ca912b3-3
Done

iii) Create a secret for Generated Token in azure keyvault.
Name :- adbsecret
Value :- dapi6aff2ef6c182c62a43956a421ca912b3-3
/* Generate */

iv) Create a linkedin service in ADF.
v) Manage >>> Linked Service >>> New  >>> Compute >>> Azure Databricks
Name :- LS_ADFDatabricksIntegration
/* Error :- Cluster is not getting loaded. */
/* Check this & Complete this */

3) Create Pipeline and execute Notebook
/* Must Complete it */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=nNr3XcpzcZg&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=30&ab_channel=Cloudpandith */
/* 14. Read TSV files efficiently in spark || Azure Databricks */
-----------------------------------------------------------------------------------------
Same as previous video.Only difference is delimiter.

Syntax to read csv file :- 
------------------------------
1) df = spark.read.csv("src/main/resource/file.csv",header=True,Inferschema=True,sep="\t",schema=schema)
df = spark.read.csv("src/main/resource/file.csv",header=True,Inferschema=True,sep="|",schema=schema)

Inferschema=True means spark needs to read all data types.
schema=schema means from our side we are going to provide schema of data.
So we should not use both.Keep at a time only one.

2) df = spark.read.format("csv").option("header",True).option("Inferschema",True).
option("Delimiter","|").schema(schema).load("src/main/resource/file.csv")
/* Can use any syntax */

Create Notebook :- 
i) Name :- ReadTPSVNotebook
ii) Default language :- Python
iii) cluster :- uspdevcluster


1)
df = spark.read.csv("dbfs:/FileStore/tables/tsvfile/tsvfile1.csv",)
df.show(truncate=False)

O/P :- 
Delimiter is not defined.So all column is considered as one row.
Header is false by default so header is also coming as data.
By default Inferschema is false.So all column are of string data types.

df:pyspark.sql.dataframe.DataFrame
_c0:string
+----------------------------------------+
|_c0                                     |
+----------------------------------------+
|PlayerId	PlayerName	Palyerhs	NoOfMatches|
|21	Kohli	186	10                         |
|22	abd	201	30                           |
|23	Sehwag	219	50                        |
|24	Sachin	200	40                        |
|25	Yuvraj	180	50                        |
+----------------------------------------+


2)
df = spark.read.csv("dbfs:/FileStore/tables/tsvfile/tsvfile1.csv",header=True,sep="\t")
df.show(truncate=False)

O/P :- 
df:pyspark.sql.dataframe.DataFrame = [PlayerId: string, PlayerName: string ... 2 more fields]
+--------+----------+--------+-----------+
|PlayerId|PlayerName|Palyerhs|NoOfMatches|
+--------+----------+--------+-----------+
|21      |Kohli     |186     |10         |
|22      |abd       |201     |30         |
|23      |Sehwag    |219     |50         |
|24      |Sachin    |200     |40         |
|25      |Yuvraj    |180     |50         |
+--------+----------+--------+-----------+

4) 
df = spark.read.csv("dbfs:/FileStore/tables/tsvfile/tsvfile1.csv",header=True,inferSchema=True,sep="\t")
df.show()

O/P :- 
/* Actual data type of column will be considered */
df:pyspark.sql.dataframe.DataFrame
PlayerId:integer
PlayerName:string
Palyerhs:integer
NoOfMatches:integer
+--------+----------+--------+-----------+
|PlayerId|PlayerName|Palyerhs|NoOfMatches|
+--------+----------+--------+-----------+
|      21|     Kohli|     186|         10|
|      22|       abd|     201|         30|
|      23|    Sehwag|     219|         50|
|      24|    Sachin|     200|         40|
|      25|    Yuvraj|     180|         50|
+--------+----------+--------+-----------+

5) Read multiple files from folder.
df = spark.read.csv("dbfs:/FileStore/tables/multitsvfile/",header=True,inferSchema=True,sep="\t")
df.show()

O/P :- 
df:pyspark.sql.dataframe.DataFrame
PlayerId:integer
PlayerName:string
Palyerhs:integer
NoOfMatches:integer
+--------+----------+--------+-----------+
|PlayerId|PlayerName|Palyerhs|NoOfMatches|
+--------+----------+--------+-----------+
|      21|     Kohli|     186|         10|
|      22|       abd|     201|         30|
|      23|    Sehwag|     219|         50|
|      24|    Sachin|     200|         40|
|      25|    Yuvraj|     180|         50|
|      26|     Patel|     187|         10|
|      27|   Gambhir|     209|         20|
|      28|    Russel|     156|         30|
|      29|     Gayle|     300|         40|
|      30|      Lara|     400|         50|
+--------+----------+--------+-----------+

6) 
df = spark.read.csv("dbfs:/FileStore/tables/multitsvfile/",header=True,inferSchema=True,sep="\t").orderBy("PlayerName")
df.show()

O/P :- 
df:pyspark.sql.dataframe.DataFrame
PlayerId:integer
PlayerName:string
Palyerhs:integer
NoOfMatches:integer
+--------+----------+--------+-----------+
|PlayerId|PlayerName|Palyerhs|NoOfMatches|
+--------+----------+--------+-----------+
|      27|   Gambhir|     209|         20|
|      29|     Gayle|     300|         40|
|      21|     Kohli|     186|         10|
|      30|      Lara|     400|         50|
|      26|     Patel|     187|         10|
|      28|    Russel|     156|         30|
|      24|    Sachin|     200|         40|
|      23|    Sehwag|     219|         50|
|      25|    Yuvraj|     180|         50|
|      22|       abd|     201|         30|
+--------+----------+--------+-----------+
7) User defined schema :- 
from pyspark.sql.types import StructType,StructField,IntegerType,StringType
s=StructType([StructField("PlayerId",IntegerType()),
StructField("PlayerName",StringType()),
StructField("Palyerhs",IntegerType()),
StructField("NoOfMatches",IntegerType())])
df = spark.read.csv("dbfs:/FileStore/tables/multitsvfile/",header=True,schema=s,sep="\t")
df.show()
df.columns

O/P :- 
df:pyspark.sql.dataframe.DataFrame
PlayerId:integer
PlayerName:string
Palyerhs:integer
NoOfMatches:integer
+--------+----------+--------+-----------+
|PlayerId|PlayerName|Palyerhs|NoOfMatches|
+--------+----------+--------+-----------+
|      21|     Kohli|     186|         10|
|      22|       abd|     201|         30|
|      23|    Sehwag|     219|         50|
|      24|    Sachin|     200|         40|
|      25|    Yuvraj|     180|         50|
|      26|     Patel|     187|         10|
|      27|   Gambhir|     209|         20|
|      28|    Russel|     156|         30|
|      29|     Gayle|     300|         40|
|      30|      Lara|     400|         50|
+--------+----------+--------+-----------+

Out[13]: ['PlayerId', 'PlayerName', 'Palyerhs', 'NoOfMatches']

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=v817AFI8bJw&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=28&ab_channel=Cloudpandith */
/* 15. Read PIPE Delimiter CSV files efficiently in spark || Azure Databricks */
-----------------------------------------------------------------------------------------
/* Repeat same step just change delimiter */

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=cmuiTjupTpg&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=22&ab_channel=Cloudpandith */
/* 16. Read CSV files with multiple delimiters in spark 3 || Azure Databricks */
-----------------------------------------------------------------------------------------
/* Repeat same step just change delimiter to || or $| */
/* No Difference at all */
/* In Spark 3 */

/* Create a new cluster */
Cluster Name :- uspdevcluster
Cluster Mode :- Standard
Databricks Run time version :- 8.2 (Scala 2.12 Spark 3.1.1) (By default)

This cluster is Spark 3.So here all these code will work.
But if Cluster version is spark 2.x then code will not work.
Check code in next video.

-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=wWgdw0Wqzz8&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=32&ab_channel=Cloudpandith */
/* 17. Read CSV files with multiple delimiters in spark 2 || Azure Databricks */
-----------------------------------------------------------------------------------------
/* See later */


-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=eQt-LfpoTkw&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=34&ab_channel=Cloudpandith */
/* 18. Read CSV file with multiple delimiters at different positions in Azure Databricks */
-----------------------------------------------------------------------------------------
cat>MultiDelmFile.csv
A|B|C-D-E|F
J-K-C-D|A|K

Here | & - both are delimiter and we need to read it on the basic of it.

Path :- /FileStore/tables/MultiDelmFile.csv

Create Notebook :- 
i) Name :- ReadMultidelNotebook
ii) Default language :- Python
iii) cluster :- uspdevcluster

1)
/* Code */
import re
filepath = "/FileStore/tables/MultiDelmFile.csv"
r1=sc.textFile(filepath)
r1.collect()

r2 = r1.map(lambda x:re.split("[|]|[-]",x))
r2.collect()

df = r2.toDF()
df.show()

O/P :- 
['A|B|C-D-E|F', 'J-K-C-D|A|K']  >>> r1.collect()
[['A', 'B', 'C', 'D', 'E', 'F'], ['J', 'K', 'C', 'D', 'A', 'K']] >>> r2.collect()

_1:string
_2:string
_3:string
_4:string
_5:string
_6:string
+---+---+---+---+---+---+
| _1| _2| _3| _4| _5| _6|
+---+---+---+---+---+---+
|  A|  B|  C|  D|  E|  F|
|  J|  K|  C|  D|  A|  K|
+---+---+---+---+---+---+

2) Same thing can also be done using pandas.
/* Complete it */



-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=fnDC161KSzk&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=27&ab_channel=Cloudpandith */
/* 19. Write dataframe as CSV file with different delimiters in Azure Databricks */
-----------------------------------------------------------------------------------------
/* Complete it */


-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=kRitGkJ3LJk&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=6&ab_channel=Cloudpandith */
/* 20. Read and Write Parquet File in Azure Databricks */
-----------------------------------------------------------------------------------------
Apache Parquet :- It is a columnar file format that provides optimizations to 
speed up queries and it is more efficient file format than CSV or JSON.
It is supported by many data processing systems like Spark, Hive etc..
It is compatible with most of the pocessing frameworks in the hadoop echo systems.
It provides efficient data compression techniques.It reduces data storage by 75% on average.

Spark SQL provides support of both reading and writing Parquet files that automatically
capture the schema of the original data.

What is columnar Storage :- 
cat>File.txt
cid cname       CStartDate
1   Azure       01-01-2021
2   DataBricks  02-01-2021
3   ADF         03-01-2021

Row Oriented Storage :- 
1   Azure       01-01-2021 2   DataBricks  02-01-2021 3   ADF         03-01-2021

columnar Storage :- 
1   2   3   Azure   DataBricks  ADF 01-01-2021  02-01-2021  03-01-2021

Advantage of APACHE Parquet :- 
i) Reduce Storage 
ii) Good Query performance
iii) Can fetch specific column that we need to access
iv) Automatically the schema of original data.
v) Apache Parquet is a good option if we have to provide partial search features
i.e. not querying all the columns.

Difference between CSV and Parquet file :- 
-------------------------------------------------
Properties      CSV     Parquet
Columnar        No      Yes
Compressable    No      Yes
Splittable      Yes     Yes        
Human Readable  Yes     No     
Default Schema  Manual  Automatic   
Data Size       10 GB   2 Gb (Snappy :- Compression Technique)          
Use Case        Write   Read            

Read Parquet file into DataFrame :- 
------------------------------------------
1) parqDF = spark.read.parquet("Date/cloud/xyz.parquet")
2) parqDF1 = spark.read.format("parquet").load("Date/cloud/xyz.parquet")

Write DataFrame as Parquet file :- 
------------------------------------------
1) df.write.mode("append").parquet("Date/cloud/outputt")
2) df.write.mode("overwrite").format("parquet").save("Date/cloud/outputt")

/* How to convert csv file to parquet file */
CSV File :- C:\Users\10662208\Desktop\ABHILASH\Script\"Azure Learning"\Emp.csv
Parquet File :- C:\Users\10662208\Desktop\ABHILASH\Script\"Azure Learning"\Emp.parquet

/* Python code to convert :-  */
cat>b.py
import pandas as pd
def write_parquet_file():
    df = pd.read_csv('Emp.csv')
    df.to_parquet('Emp.parquet')
write_parquet_file()


Create Notebook :- 
i) Name :- ParquetReadWriteNotebook
ii) Default language :- Python
iii) cluster :- uspdevcluster


/* Code */
#/* Create folder to keep parquet file */
dbutils.fs.mkdirs("ls")
dbutils.fs.mkdirs("/FileStore/tables/input/")
dbutils.fs.mkdirs("/FileStore/tables/output/")

input_path = "/FileStore/tables/input/Emp.parquet"
output_path = "/FileStore/tables/output/"

#/* Read parquet file from input folder */
parqDF = spark.read.parquet(input_path)
#parqDF.show /* Result will not be readble.Also for big data use display. */
display(parqDF)
parqDF.count()  #/* Total No of records in file */
parqDF.printSchema()  #/* Schema of file */

O/P :- 
empno:long
ename:string
job:string
mgr:double
hiredate:string
sal:long
comm:double
deptno:long
/* All Data of Emp file in readble formate */
Out[4]: 14
/* Schema */
root
 |-- empno: long (nullable = true)
 |-- ename: string (nullable = true)
 |-- job: string (nullable = true)
 |-- mgr: double (nullable = true)
 |-- hiredate: string (nullable = true)
 |-- sal: long (nullable = true)
 |-- comm: double (nullable = true)
 |-- deptno: long (nullable = true)

/* 2nd Syntax */
parqDF1 = spark.read.format("parquet").load(input_path)
display(parqDF1)
parqDF1.count()  #/* Total No of records in file */
parqDF1.printSchema()  #/* Schema of file */

O/P :- Same as above one.

#/* Create a PArquet file in output folder */
parqDF1.write.mode('overwrite').parquet(output_path)
dbutils.fs.ls("FileStore/tables/output/")

O/P :- 
Out[9]: [FileInfo(path='dbfs:/FileStore/tables/output/_SUCCESS', name='_SUCCESS', size=0),
 FileInfo(path='dbfs:/FileStore/tables/output/_committed_5386412880426991782', name='_committed_5386412880426991782', size=232),
 FileInfo(path='dbfs:/FileStore/tables/output/_started_5386412880426991782', name='_started_5386412880426991782', size=0),
 FileInfo(path='dbfs:/FileStore/tables/output/part-00000-tid-5386412880426991782-e41bafd1-711a-4c11-9bad-ca4309becaf6-17-1-c000.snappy.parquet', name='part-00000-tid-5386412880426991782-e41bafd1-711a-4c11-9bad-ca4309becaf6-17-1-c000.snappy.parquet', size=2770)]

File Name :- part-00000-tid-5386412880426991782-e41bafd1-711a-4c11-9bad-ca4309becaf6-17-1-c000.snappy.parquet
can add data to this this file .
Automatically this file will be created.We can not control file name.

#/* 2nd way to Create a PArquet file in outputlatest folder */
dbutils.fs.mkdirs("FileStore/tables/outputlatest")
parqDF1.write.mode("overwrite").format("parquet").save("FileStore/tables/outputlatest")
dbutils.fs.ls("FileStore/tables/outputlatest")

O/P :- 
Out[10]: [FileInfo(path='dbfs:/FileStore/tables/outputlatest/_SUCCESS', name='_SUCCESS', size=0),
 FileInfo(path='dbfs:/FileStore/tables/outputlatest/_committed_8475713557036041326', name='_committed_8475713557036041326', size=123),
 FileInfo(path='dbfs:/FileStore/tables/outputlatest/_started_8475713557036041326', name='_started_8475713557036041326', size=0),
 FileInfo(path='dbfs:/FileStore/tables/outputlatest/part-00000-tid-8475713557036041326-bfb1fb12-400d-46ac-ae02-478b2b573cb8-18-1-c000.snappy.parquet', name='part-00000-tid-8475713557036041326-bfb1fb12-400d-46ac-ae02-478b2b573cb8-18-1-c000.snappy.parquet', size=2770)]


File Name :- part-00000-tid-8475713557036041326-bfb1fb12-400d-46ac-ae02-478b2b573cb8-18-1-c000.snappy.parquet
can add data to this this file .
Automatically this file will be created.We can not control file name.


parqDF = spark.read.parquet("FileStore/tables/outputlatest")
display(parqDF)
/* Not working */
/* Check this */

-------------------------------------------------------------------------------------
https://www.youtube.com/watch?v=yM6Nr92kAew&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=24
21. Create Partitioned Parquet File in Azure Databricks
-------------------------------------------------------------------------------------
/* DO it later on */


-------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=xUZreg5VQeU&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=10 */
/* 22.  Reading and writing excel files in Azure Databricks */
-------------------------------------------------------------------------------------
1) How to install Spark Excel Library
2) Options while reading Excel Files :- 
i) InferScahema :- same as previous one.
ii) Header :- This option is used to read the first line of the excel file as column name.
By default the value of this option is false. and all column types are assumed to be a string.
iii) dataaddress :- It is used to specify the sheet of the excel file.
By default it is 1st sheet but can be set to any sheet.

3) Read excel :- 
i) Read excel file into Dataframe.
ii) Read sheet in Excel file into Dataframe
iii) Read particular cells of Sheet in Excel file into Dataframe.
iv) Read Excel file with a user specified schema.
4) Write Excel :- 
i) Write Dataframe as Excel file.
ii) Write Dataframe as Excel files with sheet name.

Syntax to read Excel file in dataframe :- 
----------------------------------------------
1) df = spark.read.format("com.crealytics.spark.excel")
.option("header",True)
.option("inferSchema",True)
.load("FileStore/tables/xldata/MyExcel.xlsx")
df.show()

/* By default 1st sheet of MyExcel.xlsx will be read */

2)  df = spark.read.format("com.crealytics.spark.excel")
.option("header",True)
.option("inferSchema",True)
.option("dataAddress","'SheetName'!")
.load("FileStore/tables/xldata/MyExcel.xlsx")
df.show()

/* Sheet Name SheetName will be read from MyExcel.xlsx file */

3) /* USer defined Schema */
df = spark.read.format("com.crealytics.spark.excel")
.option("header",True)
.schema(s)
.option("dataAddress","'SheetName'!")
.load("FileStore/tables/xldata/MyExcel.xlsx")
df.show()

Syntax to Write Excel file in dataframe :- 
----------------------------------------------
1) df.write.mode("append")
format("com.crealytics.spark.excel")
.option("header",True)
.option("inferSchema",True)
.option("dataAddress","'SheetName'!")
.save("FileStore/tables/xldata/MyExcel.xlsx")


2) df.write.mode("overwrite")
format("com.crealytics.spark.excel")
.option("header",True)
.option("inferSchema",True)
.save("FileStore/tables/xldata/MyExcel.xlsx")


Note :- In order to do Excel read write operation on any cluster associated with
Notebook, excel library installation is required on cluster.(uspdevcluster)
Databricks Run time version :- 8.2 (Scala 2.12 Spark 3.1.1) (By default)
As per version we need to add excel library.

1st menthod to install Excel library on Cluster :- 
----------------------------------------------------------
Compute >>> uspdevcluster >>> Libraries >>> Install New >>> Maven >>> Maven Central
Search >> Spark-excel >> Since our cluser Spark version is 2.12 so choose that package only.
>>> Install

2nd Method to install any library on cluster :- 
----------------------------------------------------------
Download jar from maven site and directly upload that file.

Sample XL file :- 
File Name :- EmpData.xlsx
Sheet Name :- Sheet1,Sheet2
cat>Sheet1
Empid	EmpName
1	A
2	B
3	C
cat>Sheet2
EmpName	Loc
A	BBSR
B	MUM
C	DELHI

Create Notebook :- 
i) Name :- ReadWriteXLSNotebook
ii) Default language :- Python
iii) cluster :- uspdevcluster


/* Code */
#/* Create new folder inputxls and outputxls */
dbutils.fs.mkdirs("FileStore/tables/inputxls")
dbutils.fs.mkdirs("FileStore/tables/outputxls")
dbutils.fs.ls("FileStore/tables/inputxls")

#/* Read xl file */
input_path="/FileStore/tables/inputxls/EmpData.xlsx"
xldf = spark.read.format("com.crealytics.spark.excel").option("header",True).option("inferSchema",True).option("dataAddress","'Sheet1'!").load(input_path)
xldf.show()

O/P :- 
df:pyspark.sql.dataframe.DataFrame
Empid:double
EmpName:string
+-----+-------+
|Empid|EmpName|
+-----+-------+
|  1.0|      A|
|  2.0|      B|
|  3.0|      C|
+-----+-------+

#/* User defined schema */
from pyspark.sql.types import StructType,StructField,IntegerType,StringType
s=StructType([StructField("Empid",IntegerType()),
StructField("EmpName",StringType())])
xldf1 = spark.read.format("com.crealytics.spark.excel").option("header",True).schema(s).option("dataAddress","'Sheet1'!").load(input_path)
xldf1.show()

O/P :- 
df:pyspark.sql.dataframe.DataFrame
Empid:integer
EmpName:string
+-----+-------+
|Empid|EmpName|
+-----+-------+
|    1|      A|
|    2|      B|
|    3|      C|
+-----+-------+

#/* Create a new xl file and save data of EmpData.xlsx >> Sheet1 */
output_path="/FileStore/tables/outputxls/MyEmpData.xlsx"
xldf1.write.mode("overwrite").format("com.crealytics.spark.excel").option("header",True).save(output_path)
dbutils.fs.ls("/FileStore/tables/outputxls")

#/* Read Data from newly created xls */
xldf2 = spark.read.format("com.crealytics.spark.excel").option("header",True).option("inferSchema",True).option("dataAddress","'Sheet1'!").load(input_path)
xldf2.show()

O/P :- 
Empid:double
EmpName:string
+-----+-------+
|Empid|EmpName|
+-----+-------+
|  1.0|      A|
|  2.0|      B|
|  3.0|      C|
+-----+-------+

#/* Specify sheet name and overwrite the data */
output_path="/FileStore/tables/outputxls/MyEmpData.xlsx"
xldf1.write.mode("overwrite").format("com.crealytics.spark.excel").option("header",True).option("dataAddress","'Sheet1'!").save(output_path)
dbutils.fs.ls("/FileStore/tables/outputxls")

O/P :- After providing option("dataAddress","'Sheet1'!") >> error is coming.
Invalid row number (-1) outside allowable range (0..1048575)
Solution :- Add Range of file data then it will not come.

#/* Specify sheet name and overwrite the data */
output_path="/FileStore/tables/outputxls/MyEmpData.xlsx"
xldf1.write.mode("overwrite").format("com.crealytics.spark.excel").option("header",True).option("dataAddress","'Sheet1'!A1:B3").save(output_path)
dbutils.fs.ls("/FileStore/tables/outputxls")

#/* Read Data from newly created xls */
xldf2 = spark.read.format("com.crealytics.spark.excel").option("header",True).option("inferSchema",True).option("dataAddress","'Sheet1'!").load(output_path)
xldf2.show()

O/p :- 
xldf2:pyspark.sql.dataframe.DataFrame
Empid:double
EmpName:string
+-----+-------+
|Empid|EmpName|
+-----+-------+
|  1.0|      A|
|  2.0|      B|
|  3.0|      C|
+-----+-------+

#/* Specify sheet name and Append the data */
#If we will provide A1:B3 then append & Overwrite is same.It will same as overwrite.
#So Give another index there data will be appended.
#If we want to append data on xl then we need atlease start cell no.
#Using python we can get the last cell and can use in append operation

output_path="/FileStore/tables/outputxls/MyEmpData.xlsx"
xldf1.write.mode("append").format("com.crealytics.spark.excel").option("header",False).option("dataAddress","'Sheet1'!A5:B7").save(output_path)
dbutils.fs.ls("/FileStore/tables/outputxls")

#/* Read Data from newly created xls */
xldf2 = spark.read.format("com.crealytics.spark.excel").option("header",True).option("inferSchema",True).option("dataAddress","'Sheet1'!").load(output_path)
xldf2.show()

O/P :- 
xldf2:pyspark.sql.dataframe.DataFrame
Empid:double
EmpName:string
+-----+-------+
|Empid|EmpName|
+-----+-------+
|  1.0|      A|
|  2.0|      B|
|  3.0|      C|
|  1.0|      A|
|  2.0|      B|
|  3.0|      C|
+-----+-------+

-------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=Rd36_8KVEuc&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=18 */
/* 23. Reading and writing XML files in Azure Databricks */
-------------------------------------------------------------------------------------
/* Look it later on */


-------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=PGXQ9Z-O-pw&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=12 */
/* 24.How to Read Json Files in Pyspark,How to Write Json files in Pyspark,json file as Spark DataFrame */
-------------------------------------------------------------------------------------
1) Options while reading JSON file
i) Multiline :- 
2) Read JSON
i) Read JSON file into DataFrame
ii) Read multiple JSON file/Files into DataFrame
iii) Read multiple JSON file into DataFrame with user defined schema.
iv) Read multiple multiline JSON files into DataFrame
v) Read multiple multiline JSON files into DataFrame with user defined schema.

3) Write JSON :- 
i) Write Dataframe as JSON file with append mode.
ii) Write Dataframe as JSON file with overwrite mode.

1) i) Multiline :- This option is used to read records from multiple lines.
By Default, Spark considers every record in a JOSN file as a fully Qualified record in 
a single line.Hence we need to use the multiline option to process JSOn from multiple lines.

What is multiline JSON File :- If JSON is present in a single line then it is simple JOSN
but if using JSON viewer we have expanded it then all data will be present in multiple lines.
and this file is called MULTILINE JSON file.

Syntax to read JOSN file into Dataframe (Single Line JSON ) :- 
----------------------------------------------------------------------
1) df = spark.read.json("/FileStore/tables/JSONInput/file.json")
2) df = spark.read.format("json").load("/FileStore/tables/JSONInput/")
3) df = spark.read.format("json").schema(s).load("/FileStore/tables/JSONInput/")

Syntax to read JOSN file into Dataframe (MultiLine JSON ) :- 
----------------------------------------------------------------------
1) df = spark.read.json(filepath,multiline=True).
2) df = spark.read.format("json").option("multiline","True").load("/FileStore/tables/JSONInput/")
3) df = spark.read.format("json").option("multiline","True").schema(s).load("/FileStore/tables/JSONInput/")


Syntax to write DataFrame as JSON file :- 
--------------------------------------------------
1) df.write.mode("overwrite").format("json").save("FileStore/tables/JSONOutput/")
2) df.write.mode("append").format("json").save("FileStore/tables/JSONOutput/")


File Name :- cpjson1.json,cpjson2.json
Multiline File Name :- cpmultijson2.json,cpmultijson2.json


Create Notebook :- 
i) Name :- ReadWriteJSONNotebook
ii) Default language :- Python
iii) cluster :- uspdevcluster

1)
/* Code */
#/* Create JSON1(File :- cpjson1.json) & JSON2(Files :- cpjson1.json,cpjson2.json) folder */
dbutils.fs.mkdirs("FileStore/tables/JSON1/")
dbutils.fs.mkdirs("FileStore/tables/JSON2/")
dbutils.fs.mkdirs("FileStore/tables/OutputJSON/")

#/* Upload files */
#File uploaded to /FileStore/tables/JSON1/cpjson1.json
#File uploaded to /FileStore/tables/JSON2/cpjson1.json
#File uploaded to /FileStore/tables/JSON2/cpjson2.json

#/* Read JSON File JSON1(File :- cpjson1.json) */
filePath="/FileStore/tables/JSON1/cpjson1.json"
df = spark.read.format("json").load(filePath)
df.show()

O/P :- 
df:pyspark.sql.dataframe.DataFrame
age:long
dateOfBirth:string
firstName:string
id:long
lastName:string
+---+-----------+---------+---+--------+
|age|dateOfBirth|firstName| id|lastName|
+---+-----------+---------+---+--------+
| 25|       2007|     John|  1|   Smith|
| 35|       2005|     John|  2|   Smith|
| 15|       1983|     John|  3|   Smith|
| 12|       1995|     John|  4|   Smith|
| 37|       2015|     John|  5|   Smith|
+---+-----------+---------+---+--------+

#/* Read JSOn files form JSON2(Files :- cpjson1.json,cpjson2.json) */
filePath1="/FileStore/tables/JSON2/"
df1 = spark.read.format("json").load(filePath1)
df1.show()

O/P :- 
age:long
dateOfBirth:string
firstName:string
id:long
lastName:string
+---+-----------+---------+---+--------+
|age|dateOfBirth|firstName| id|lastName|
+---+-----------+---------+---+--------+
| 25|       2007|     John|  1|   Smith|
| 35|       2005|     John|  2|   Smith|
| 15|       1983|     John|  3|   Smith|
| 12|       1995|     John|  4|   Smith|
| 37|       2015|     John|  5|   Smith|
| 25|       2007|     John|  6|   Smith|
| 35|       2005|     John|  7|   Smith|
| 15|       1983|     John|  8|   Smith|
| 12|       1995|     John|  9|   Smith|
| 37|       2015|     John| 10|   Smith|
+---+-----------+---------+---+--------+
/* Combine Data from both the files are coming */

#/* Write this data into OutputJSON folder */
filepath2 = "FileStore/tables/OutputJSON/"
df1.write.mode("append").format("json").save(filepath2)

#/* Display data from newly created file */
filepath2 = "/FileStore/tables/OutputJSON/"
df2 = spark.read.format("json").load(filepath2)
df2.show()

O/P :- 
df2:pyspark.sql.dataframe.DataFrame
age:long
dateOfBirth:string
firstName:string
id:long
lastName:string
+---+-----------+---------+---+--------+
|age|dateOfBirth|firstName| id|lastName|
+---+-----------+---------+---+--------+
| 25|       2007|     John|  6|   Smith|
| 35|       2005|     John|  7|   Smith|
| 15|       1983|     John|  8|   Smith|
| 12|       1995|     John|  9|   Smith|
| 37|       2015|     John| 10|   Smith|
| 25|       2007|     John|  1|   Smith|
| 35|       2005|     John|  2|   Smith|
| 15|       1983|     John|  3|   Smith|
| 12|       1995|     John|  4|   Smith|
| 37|       2015|     John|  5|   Smith|
+---+-----------+---------+---+--------+

/* Same way overwrite will also work but it will remove existing data and only newly added data will be there */

2) 
Create Notebook :- 
i) Name :- ReadWriteMultiLineJSONNotebook
ii) Default language :- Python
iii) cluster :- uspdevcluster

/* Code */
#/* Create MultiJSON1(File :- cpmultijson2.json) & MultiJSON2(Files :- cpmultijson2.json,cpmultijson2.json) folder */
dbutils.fs.mkdirs("FileStore/tables/MultiJSON1/")
dbutils.fs.mkdirs("FileStore/tables/MultiJSON2/")
dbutils.fs.mkdirs("FileStore/tables/MultiJSONOutput/")

#Upload Files
#File uploaded to /FileStore/tables/MultiJSON1/cpmultijson1.json
#File uploaded to /FileStore/tables/MultiJSON2/cpmultijson1.json
#File uploaded to /FileStore/tables/MultiJSON2/cpmultijson2.json

#/* Read multiline JOSN file using single line method */
filepath = "/FileStore/tables/MultiJSON1/cpmultijson1.json"
df = spark.read.json(filepath)
df.show()

O/P :- /* Error */
AnalysisException: Since Spark 2.3, the queries from raw JSON/CSV files are disallowed when the

#/* Read multiline JOSN file using Multiline method */
filepath = "/FileStore/tables/MultiJSON1/cpmultijson1.json"
df = spark.read.json(filepath,multiLine=True)
df.show()

O/P :- 
df:pyspark.sql.dataframe.DataFrame
age:long
name:string
secretIdentity:string
userId:long
+---+---------------+--------------+------+
|age|           name|secretIdentity|userId|
+---+---------------+--------------+------+
| 29|   Molecule Man|     Dan Jukes|     1|
| 39|Madame Uppercut|   Jane Wilson|     2|
| 50|  Eternal Flame|       Unknown|     3|
+---+---------------+--------------+------+

#/* Read multiline JOSN file using 2nd Multiline method */
filepath = "/FileStore/tables/MultiJSON1/cpmultijson1.json"
df = spark.read.format("json").option("multiline","True").load(filepath)
df.show()

O/P :- 
df:pyspark.sql.dataframe.DataFrame
age:long
name:string
secretIdentity:string
userId:long
+---+---------------+--------------+------+
|age|           name|secretIdentity|userId|
+---+---------------+--------------+------+
| 29|   Molecule Man|     Dan Jukes|     1|
| 39|Madame Uppercut|   Jane Wilson|     2|
| 50|  Eternal Flame|       Unknown|     3|
+---+---------------+--------------+------+


#/* Read Multiple multiline JOSN file using 2nd Multiline method */
filepath = "/FileStore/tables/MultiJSON2/"
df1 = spark.read.format("json").option("multiline","True").load(filepath)
df1.show()

O/P :- 
df1:pyspark.sql.dataframe.DataFrame
age:long
name:string
secretIdentity:string
userId:long
+---+---------------+--------------+------+
|age|           name|secretIdentity|userId|
+---+---------------+--------------+------+
| 29|   Molecule Man|     Dan Jukes|     1|
| 39|Madame Uppercut|   Jane Wilson|     2|
| 50|  Eternal Flame|       Unknown|     3|
| 29|   Molecule Man|     Dan Jukes|     4|
| 39|Madame Uppercut|   Jane Wilson|     5|
| 50|  Eternal Flame|       Unknown|     6|
+---+---------------+--------------+------+

#/* Write data into another JOSN */
filepath = "/FileStore/tables/MultiJSONOutput/"
df1.write.mode("overwrite").format("json").save(filepath)

#/* Read newly created JOSN */
filepath = "/FileStore/tables/MultiJSONOutput/"
df2 = spark.read.format("json").option("multiline","True").load(filepath)
df2.show()

O/P :- 
+---+------------+--------------+------+
|age|        name|secretIdentity|userId|
+---+------------+--------------+------+
| 29|Molecule Man|     Dan Jukes|     1|
| 29|Molecule Man|     Dan Jukes|     4|
+---+------------+--------------+------+

/* Check why only 2 records are coming.Where are other data */

-----------------------------------------------------------------------------------------
/* 25,26 is not present in playlist */
-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=eIiInIx3tMg&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=31 */
/* 27. Parquet vs Avro vs ORC | AVRO File Optimizing Your Big Data | File Formats */
-----------------------------------------------------------------------------------------
/* look into this */


-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=Dp1Nv4o0lrA&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=10&ab_channel=Cloudpandith */
/* 48. Custom Logging in Databricks pyspark || Logging Strategies in Azure Databricks || Notebook calls */
-----------------------------------------------------------------------------------------
/* Must Watch & implement it */





-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=2MX4oQi_9y8&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=2&ab_channel=Cloudpandith */
/* 59. Delta Lake #Databricks, #DatabricksTutorial, #AzureDatabricks,#Cloudpandith, #DeltaLakeACID */
-----------------------------------------------------------------------------------------












-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=cvsF-ld2Ehk&list=PL_XpoDibuob6_rELsVWANzI9uEqbUr2Ax&index=3&ab_channel=Cloudpandith */
/* 75 . Azure Data Factory Interview Question and Answers - Provided By Cloudpandith BI Master Program */
-----------------------------------------------------------------------------------------
/* Must watch */


============================================================================================
/* Databricks from Another Channel "CloudFitness" */
/* https://www.youtube.com/playlist?list=PLtlmylp_ZK5wr1lyq76h1V4ZuWZYThgy0 */
/* Databricks hands on tutorial(Pyspark) */
/* Full Playlist */
============================================================================================
-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=404QLpVzvKE&list=PLtlmylp_ZK5wr1lyq76h1V4ZuWZYThgy0&index=2&ab_channel=CloudFitness */
/* DATAFRAMES USING DATABRICKS PART-1 */
-----------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=oNjI8M8cB_A&list=PLtlmylp_ZK5wr1lyq76h1V4ZuWZYThgy0&index=3&ab_channel=CloudFitness */
/* DATAFRAMES USING DATABRICKS PART-2 */
-----------------------------------------------------------------------------------------
/* Create a new WorkSpace */
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
WorkSpace Name :- uspLocalDatabricks
Region :- Code
Pricing Tier :- Standard (By Default)
Create >> This will create a "WorkSpace".
"Launch WorkSpace"

/* Create a new cluster */
Cluster Name :- uspdevcluster
Cluster Mode :- Standard
Databricks Run time version :- 8.2 (Scala 2.12 Spark 3.1.1) (By default)

File Name :- /FileStore/tables/Emp.csv
/FileStore/tables/Dept.csv


Notebook Name :- 
i) Name :- DataFrameEx
ii) Default language :- Python
iii) cluster :- uspdevcluster

#/* Code */
df1 = spark.read.csv(path='/FileStore/tables/Emp.csv',sep=',',header=True)
df2 = sqlContext.read.csv(path='/FileStore/tables/Dept.csv',sep=',',header=True)
print(df1)              # /* Print Structure of dataframe.Column name & Data Type */
df1.show()              # /* Display All rows in tabular format */
df1.show(n=5)           # /* Display Top 5 rows in tabular format */

df1.head()              # /* Gives rows in the form of tupple */    
O/P :- [Row(empno='7839', ename='KING', job='PRESIDENT', mgr=None, hiredate='17-11-1981', sal='5000', comm=None, deptno='10'),

df1.head(5)      
O/P :- [Row(empno='7839', ename='KING', job='PRESIDENT', mgr=None, hiredate='17-11-1981', sal='5000', comm=None, deptno='10'),
 Row(empno='7698', ename='BLAKE', job='MANAGER', mgr='7839', hiredate='1-5-1981', sal='2850', comm=None, deptno='30'),
 Row(empno='7782', ename='CLARK', job='MANAGER', mgr='7839', hiredate='9-6-1981', sal='2450', comm=None, deptno='10'),
 Row(empno='7566', ename='JONES', job='MANAGER', mgr='7839', hiredate='2-4-1981', sal='2975', comm=None, deptno='20'),
 Row(empno='7788', ename='SCOTT', job='ANALYST', mgr='7566', hiredate='13-7-87', sal='3000', comm=None, deptno='20')]

df1.select('empno','ename','deptno').show()     # /* Display only selected columns */
O/P :- 
+-----+------+------+
|empno| ename|deptno|
+-----+------+------+
| 7839|  KING|    10|
| 7698| BLAKE|    30|
| 7782| CLARK|    10|
| 7566| JONES|    20|
| 7788| SCOTT|    20|


df1.columns     # /* All column name of the file */
O/P :- Out[6]: ['empno', 'ename', 'job', 'mgr', 'hiredate', 'sal', 'comm', 'deptno']

df1.schema      # /* All column name & Data Type of the file */
O/P :- Out[7]: StructType(List(StructField(empno,StringType,true),StructField(ename,StringType,true),StructField(job,StringType,true),StructField(mgr,StringType,true),StructField(hiredate,StringType,true),StructField(sal,StringType,true),StructField(comm,StringType,true),StructField(deptno,StringType,true)))

df1.dtypes      # /* Column name & Data Types */
O/P :- [('empno', 'string'),
 ('ename', 'string'),
 ('job', 'string'),
 ('mgr', 'string'),
 ('hiredate', 'string'),
 ('sal', 'string'),
 ('comm', 'string'),
 ('deptno', 'string')]

df1.drop("comm").show()     # /* All columns except comm column will be displayed along with data */
# /* If again will do df1.show() will display all columns. */
# /* If we want to exclude any or some columsn then we can use drop command */
O/P :- 
+-----+------+---------+----+----------+----+------+
|empno| ename|      job| mgr|  hiredate| sal|deptno|
+-----+------+---------+----+----------+----+------+
| 7839|  KING|PRESIDENT|null|17-11-1981|5000|    10|
| 7698| BLAKE|  MANAGER|7839|  1-5-1981|2850|    30|
| 7782| CLARK|  MANAGER|7839|  9-6-1981|2450|    10|
| 7566| JONES|  MANAGER|7839|  2-4-1981|2975|    20|

df3 = df1.select(df1.empno.cast("int"),df1.deptno.cast("int"))
# /* Change data types of column */
df3.dtypes      # /* Data Types chnaged from String to integer */
df3.show()
O/P :- empno:integer
deptno:integer
+-----+------+
|empno|deptno|
+-----+------+
| 7839|    10|
| 7698|    30|
| 7782|    10|

/* Define own schema using StructType */
from pyspark.sql.types import *
MySchema = StructType([StructField("empno",IntegerType()),
StructField("ename",StringType()),
StructField("job",StringType()),
StructField("mgr",IntegerType()),
StructField("hiredate",StringType()),
StructField("sal",IntegerType()),
StructField("comm",IntegerType()),
StructField("deptno",IntegerType())
])

df4 = spark.read.csv(path='/FileStore/tables/Emp.csv',sep=',',header=True,schema=MySchema)
df4.dtypes          # /* Data Types of all columns */
O/P :- empno:integer
ename:string
job:string
mgr:integer
hiredate:string
sal:integer
comm:integer
deptno:integer

df4.sort("empno",ascending=True).show()   # /* Sort rows on the basic of empno */
O/P :- 
+-----+------+---------+----+----------+----+----+------+
|empno| ename|      job| mgr|  hiredate| sal|comm|deptno|
+-----+------+---------+----+----------+----+----+------+
| 7369| SMITH|    CLERK|7902|17-12-1980| 800|null|    20|
| 7499| ALLEN| SALESMAN|7698| 20-2-1981|1600| 300|    30|
| 7521|  WARD| SALESMAN|7698| 22-2-1981|1250| 500|    30|
| 7566| JONES|  MANAGER|7839|  2-4-1981|2975|null|    20|
| 7654|MARTIN| SALESMAN|7698| 28-9-1981|1250|1400|    30|


df4.filter("deptno==10").show()  # /* Where clause using filter operator */
O/P :- 
+-----+------+---------+----+----------+----+----+------+
|empno| ename|      job| mgr|  hiredate| sal|comm|deptno|
+-----+------+---------+----+----------+----+----+------+
| 7839|  KING|PRESIDENT|null|17-11-1981|5000|null|    10|
| 7782| CLARK|  MANAGER|7839|  9-6-1981|2450|null|    10|
| 7934|MILLER|    CLERK|7782| 23-1-1982|1300|null|    10|
+-----+------+---------+----+----------+----+----+------+

# /* IN clause and new dataframe */
df5 = df4[df4.deptno.isin(10,20)]   
df5.show()
O/P :- 
+-----+------+---------+----+----------+----+----+------+
|empno| ename|      job| mgr|  hiredate| sal|comm|deptno|
+-----+------+---------+----+----------+----+----+------+
| 7839|  KING|PRESIDENT|null|17-11-1981|5000|null|    10|
| 7782| CLARK|  MANAGER|7839|  9-6-1981|2450|null|    10|
| 7566| JONES|  MANAGER|7839|  2-4-1981|2975|null|    20|
| 7788| SCOTT|  ANALYST|7566|   13-7-87|3000|null|    20|
| 7902|  FORD|  ANALYST|7566| 3-12-1981|3000|null|    20|
| 7369| SMITH|    CLERK|7902|17-12-1980| 800|null|    20|
| 7876| ADAMS|    CLERK|7788|   13-7-87|1100|null|    20|
| 7934|MILLER|    CLERK|7782| 23-1-1982|1300|null|    10|
+-----+------+---------+----+----------+----+----+------+

# /* Distict value for any column in dataframe */
df4.select("deptno").distinct().show()
O/P :- 
+------+
|deptno|
+------+
|    20|
|    10|
|    30|
+------+

df4.select("deptno").distinct().count()
O/P :- 3

df1 = spark.read.csv(path='/FileStore/tables/Emp.csv',sep=',',header=True)
df2 = spark.read.csv(path='/FileStore/tables/Dept.csv',sep=',',header=True)

/* Join Two DataFrames */
df1.join(other=df2,on="deptno",how='inner').show()
O/P :- 
+------+-----+------+---------+----+----------+----+----+----------+-------+
|deptno|empno| ename|      job| mgr|  hiredate| sal|comm|     dname|    loc|
+------+-----+------+---------+----+----------+----+----+----------+-------+
|    10| 7839|  KING|PRESIDENT|null|17-11-1981|5000|null|ACCOUNTING|NEWYORK|
|    30| 7698| BLAKE|  MANAGER|7839|  1-5-1981|2850|null|     SALES|CHICAGO|
|    10| 7782| CLARK|  MANAGER|7839|  9-6-1981|2450|null|ACCOUNTING|NEWYORK|
|    20| 7566| JONES|  MANAGER|7839|  2-4-1981|2975|null|  RESEARCH| DALLAS|
+-----+------+---------+----+----------+----+----+------+----+----+--------+

/* Use any kind of other join and see the result */
df1.join(other=df2,on="deptno",how='inner').select(df1.empno,df1.ename,df1.deptno,df2.dname).show()
O/P :- 
+-----+------+------+----------+
|empno| ename|deptno|     dname|
+-----+------+------+----------+
| 7839|  KING|    10|ACCOUNTING|
| 7698| BLAKE|    30|     SALES|
| 7782| CLARK|    10|ACCOUNTING|
| 7566| JONES|    20|  RESEARCH|
| 7788| SCOTT|    20|  RESEARCH|
| 7902|  FORD|    20|  RESEARCH|
| 7369| SMITH|    20|  RESEARCH|
| 7499| ALLEN|    30|     SALES|

Join String	                            Equivalent SQL Join
----------------------------------      ----------------------
inner	                                INNER JOIN
outer, full, fullouter, full_outer	    FULL OUTER JOIN
left, leftouter, left_outer	            LEFT JOIN
right, rightouter, right_outer	        RIGHT JOIN


/* How to do UNION on two dataframes */
df1.union(df2).show()   # /* As no of columns are not matching So it won't work but can be used in other cases */

/* How to do Aggregation(Sum,Max,Min,avg) */
df1.agg({"sal" : "average"}).show()
O/P :- 
+-----------------+
|         avg(sal)|
+-----------------+
|2073.214285714286|
+-----------------+

df1.agg({"sal" : "sum"}).show()
O/P :- 
+--------+
|sum(sal)|
+--------+
| 29025.0|
+--------+

/* Group By & aggregaion */
df1.groupby("deptno").agg({'sal':'sum'}).show()
O/P :- 
+------+--------+
|deptno|sum(sal)|
+------+--------+
|    30|  9400.0|
|    20| 10875.0|
|    10|  8750.0|
+------+--------+

df1.groupby("deptno").agg({'sal':'count'}).show()
O/P :- 
+------+----------+
|deptno|count(sal)|
+------+----------+
|    30|         6|
|    20|         5|
|    10|         3|
+------+----------+

#/* Create Temp table from Dataframe */
df1.createOrReplaceTempView('Emp_Tmp_Table')
sqlContext.registerDataFrameAsTable(df1,'Emp_Tmp_Table_1')

display(spark.sql('SELECT * FROM Emp_Tmp_Table'))
display(spark.sql('SELECT * FROM Emp_Tmp_Table_1'))

#/* Create Dataframe from Table */
New_df = spark.table('Emp_Tmp_Table')
New_df.show(n=3)
O/P :- 
+-----+-----+---------+----+----------+----+----+------+
|empno|ename|      job| mgr|  hiredate| sal|comm|deptno|
+-----+-----+---------+----+----------+----+----+------+
| 7839| KING|PRESIDENT|null|17-11-1981|5000|null|    10|
| 7698|BLAKE|  MANAGER|7839|  1-5-1981|2850|null|    30|
| 7782|CLARK|  MANAGER|7839|  9-6-1981|2450|null|    10|
+-----+-----+---------+----+----------+----+----+------+

-----------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=D5_AKDew3oU&list=PLtlmylp_ZK5wr1lyq76h1V4ZuWZYThgy0&index=3 */
/* Handles errors in data bricks notebooks */
-----------------------------------------------------------------------------------------------------
/* https://docs.microsoft.com/en-us/azure/databricks/spark/latest/spark-sql/handling-bad-records */
/* Read from here and get some examples */

If while reading any file we are getting any error then it can be handled through moving
that record into a bad file.


from pyspark.sql.types import *
MySchema = StructType([StructField("empno",IntegerType()),
StructField("ename",StringType()),
StructField("job",StringType()),
StructField("mgr",IntegerType()),
StructField("hiredate",StringType()),
StructField("sal",IntegerType()),
StructField("comm",IntegerType()),
StructField("deptno",IntegerType()),
StructField("Newdeptno",IntegerType())
])

df = spark.read.option("badRecordPath","/FileStore/tables/").csv('/FileStore/tables/Emp.csv',sep=',',header=True,schema=MySchema)
df.show()

/* Not working.Must lokk into this and other method of error handling */

-----------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=I6_XGS-jHwM&list=PLtlmylp_ZK5wr1lyq76h1V4ZuWZYThgy0&index=5&ab_channel=CloudFitness */
/* Strategies to create Surrogate keys in Spark-Databricks */
-----------------------------------------------------------------------------------------------------
/* https://kb.databricks.com/sql/gen-unique-increasing-values.html */
/* Generate unique increasing numeric values */

i) zipWithIndex() :- The zipWithIndex() function is only available within RDDs. 
We cannot use it directly on a DataFrame.
Convert your DataFrame to a RDD, apply zipWithIndex() to your data, 
and then convert the RDD back to a DataFrame.



from pyspark.sql.types import *
MySchema = StructType([StructField("empno",IntegerType()),
StructField("ename",StringType()),
StructField("job",StringType()),
StructField("mgr",IntegerType()),
StructField("hiredate",StringType()),
StructField("sal",IntegerType()),
StructField("comm",IntegerType()),
StructField("deptno",IntegerType())
])

df = spark.read.csv('/FileStore/tables/Emp.csv',sep=',',header=True,schema=MySchema)
df.show()
rdd_df = df.rdd.zipWithIndex()
df_final = rdd_df.toDF()
df_final.show()

O/P :- 
+--------------------+---+
|                  _1| _2|
+--------------------+---+
|{7839, KING, PRES...|  0|
|{7698, BLAKE, MAN...|  1|
|{7782, CLARK, MAN...|  2|
|{7566, JONES, MAN...|  3|
|{7788, SCOTT, ANA...|  4|
|+-------------------+---+

df_final = df_final.withColumn('empno', df_final['_1'].getItem("empno"))
df_final = df_final.withColumn('ename', df_final['_1'].getItem("ename"))

# finally select the columns we need:
df_final.select('index', 'empno', 'ename').show()

/* Look into all other method.Must Complete */

-----------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=sIlayzDrP48&list=PLtlmylp_ZK5wr1lyq76h1V4ZuWZYThgy0&index=6&ab_channel=CloudFitness */
/* Managed and External Tables(Un-Managed) tables in Spark Databricks */
-----------------------------------------------------------------------------------------------------
/* Try to understand all videos and complete it */



==============================================================================================
==============================================================================================
Power BI :- 
-----------------
/* https://www.youtube.com/playlist?list=PLMWaZteqtEaJdMD_68w61GN4Of7WtHdnF */
/* Full Playlist */

----------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=5-CSubEgyus&list=PLMWaZteqtEaJdMD_68w61GN4Of7WtHdnF&index=1&ab_channel=WafaStudies */
/* 1. Power BI Overview */
----------------------------------------------------------------------------------------------
What is Power BI :- 
It is a tool or technology to generate reports.
Power BI is a collection of software services, apps and connectors that work together to turn
your unrelated sources of data into coherent, visual immersive and interactive insights.

Through Power BI we can connect to data sources, visualize and discover what is important and 
share that with anyone we want.

Parts of Power BI :- 
--------------------------
Power BI consists of several elements that all wok together.
i) A window desktop application called power BI desktop.
ii) An online SaaS(Software As A Service) called Power BI Service.
iii) Power BI mobile apps for Windows,iOS & Android device.
iv) Power Bi report builder :- It is used for creating paginated reports to share in the 
Power BI service.
v) Power BI Report Server :- It is an on premises report server, where we can publish our 
power BI report after creating them in Power BI desktop.

Work Flow in Power BI :- 
-----------------------------------
First Power BI will connects to data source through Power BI desktop and will build the report.
Then it will be published to Power BI service.
Then it will be shared to business users in Power BI services.
Through mobile device these can also be accessed.

----------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=rXpy147BRjw&list=PLMWaZteqtEaJdMD_68w61GN4Of7WtHdnF&index=2&ab_channel=WafaStudies */
/* 2. Download and Install Power BI Desktop */
----------------------------------------------------------------------------------------------
What is Power BI (PBI) desktop :- 
--------------------------------
It is free application which we need to install on local computer, that allows us to connect
transform and visualize our data.

In Power BI desktop, we can connect to multiple data sources and can combine then (called modeling)
into a data model.Using this we can create visuals and collection of visuals can be shared as reports.

Download and Install Power BI desktop :- 
---------------------------------------------
https://www.google.com/search?q=download+power+BI+desktop&rlz=1C1GCEU_enIN948IN948&oq=download+power+BI+desktop&aqs=chrome..69i57j69i61l2.5866j0j7&sourceid=chrome&ie=UTF-8
/* Installed in local */

----------------------------------------------------------------------------------------------
https://www.youtube.com/watch?v=XjxYTQAfYfU&list=PLMWaZteqtEaJdMD_68w61GN4Of7WtHdnF&index=3&ab_channel=WafaStudies
/* 3. Get started with Power BI Desktop */
----------------------------------------------------------------------------------------------
There are majorly 3 views available which we can select on the top left side of the canvas :- 
i) Reports :- Here actual reports will be prepared after connecting to data source.
ii) Data :- Whatever table or data we have imported will be available under data section.
iii) Model :- If we have imported multiple tables then we can define joining among tables.

Req :- Fetch data from XL file and do some basic transformation.

Download sample financial XL from below mentioned site.
/* https://docs.microsoft.com/en-us/power-bi/create-reports/sample-financial-download */

File Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Financial_Sample_XL\Financial Sample.xlsx
Table Design >>> financials >> /* This is the table name of the file */

Power BI desktop >>> Reports >>> Import Data from Excel
File Name :- Financial Sample.xlsx

After Import :- 2 names are getting displayed.
i) Financials :- Table name of the file
ii) Sheet1 :- 1st sheet name of the xl

Select Financials >>> Transform Data >> A new window "Power Query Editor" will be opened.
/* Here we can do transformation */
i) Make "Segment" column in Upper case :- Right Click >>> Transform >>> UPPERCASE
ii) Make "Unit sold" as whole number (Integer) :- Right Click >>> Chnage Type >>> Whole Number
iii) Rename "Month Name" to "Month" only :- 
>>> Close & Apply
/* Now transformed data will be present in "Data" option */
Σ :- It represents Integer Number.
Calender Sign :- Date & DateTime
No Sign :- Varchar


Insert >>> Text Box >>> Sample Report
Drag Sales :- 
Drag Date  :- 
Remove Date hierarchy and select only date.

Add "Slicer" in the report & Add "date".
Now it will work as a filter and whatever will select date range in that way Graph will be prepared.
/* Not working as expected :- Look */
Save >> SampleReport.pbix
Can also publis >> Will look into next video.


----------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=A1AeXLtD5X0&list=PLMWaZteqtEaJdMD_68w61GN4Of7WtHdnF&index=4&ab_channel=WafaStudies */
/* 4. Sign up for the Power BI Service */
----------------------------------------------------------------------------------------------
Go to >>> powerbi.com
Create an acocunt.I will use "abhilash.kumar@lntinfotech.com".
Not able to publish report from local to "v-abku13".
This site requires a work email address.gmail,outlook,hotmail,yahoo etc will not work.
So we can get temporary work email address from "https://10minutemail.com/"
Workspace :- Create WorkSpace :- 
Name :- CogsWorkSpace

Activity ID: 327684b1-7f85-4c57-9a7e-134d50a1d02b
Request ID: 7ade19a7-2ebc-fb50-50e8-486e7882f97c
Correlation ID: 61c66ef5-f1b2-4aa2-4140-804953ff3f8d
Time: Mon Jun 28 2021 22:10:09 GMT+0530 (India Standard Time)
Service version: 13.0.16239.61
Client version: 2106.1.06698-train
Cluster URI: https://wabi-south-east-asia-redirect.analysis.windows.net/


----------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=mvvODDh1hqg&list=PLMWaZteqtEaJdMD_68w61GN4Of7WtHdnF&index=5&ab_channel=WafaStudies */
/* 5. Publish report to Power BI Service */
----------------------------------------------------------------------------------------------
In order to share a report among people of organization we need to publish the report on
Power BI Services.

Power BI Desktop >>> Publish
Provide Email ID and WOrkSpace.
Reports will be uploaded to Power BI Services.

Inside Power BI services :- 
----------------------------------
Inside My Workspace two files will be uploaded.
Name :- SampleReport
Type :- File/DataSet

We can also select files from our local computer from Power BI service directly.
Get data >>>> Files >>> Get >>> Select .pbix file from Local computer.

Share :- Here we can send email or generate sharepoint link of the file.


----------------------------------------------------------------------------------------------
https://www.youtube.com/watch?v=33LbDD2dN7g&list=PLMWaZteqtEaJdMD_68w61GN4Of7WtHdnF&index=6&ab_channel=WafaStudies
6. Get Started with Power BI Service
----------------------------------------------------------------------------------------------
If we do not want to do any transformation on data then we can generate report in PBI services
directly.

Here we can generate report and share with clients.


----------------------------------------------------------------------------------------------
https://www.youtube.com/watch?v=6kzQPNl2Q-U&list=PLMWaZteqtEaJdMD_68w61GN4Of7WtHdnF&index=7&ab_channel=WafaStudies
7. Basic Concepts in Power BI Service
----------------------------------------------------------------------------------------------
i) Workspace :- 
ii) Reports :- 
iii) Dashboards :- 
iv) Datasets :- 
v) Workbook :- 

==============================================================================================
==============================================================================================
Azure Logic Apps :- 
/* Full Playlist */
/* https://www.youtube.com/playlist?list=PLMWaZteqtEaIWwpz64BwOBytNDPka700J */
/* Azure Logic Apps */

----------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=KxkiE2JC0RU&list=PLMWaZteqtEaIWwpz64BwOBytNDPka700J&ab_channel=WafaStudies */
/* 1. Introduction to Azure Logic Apps */
----------------------------------------------------------------------------------------------
What is Azure Logic Apps :- It is a cloud service that helps us to schedule, automate and 
orchestrate tasks, business processes and workflow when we need to integrate apps, data, systems
and services across enterprise or organizations.

Examples :- 
i) Send email notification when events happens in various systems, apps & services.
ii) Move uploaded files from SFTP or FTP server to azure storage.
iii) Monitor tweets for a specific subjects, analyze the sentiment & create alert or task for
item that need review.


/* How Logic Apps Work :- */
i) Every logic apps workflows starts with a trigger which fires when a specific event happens.
ii) Whenever trigger fires, the logic apps engine create a logic app instance that runs
the action in the workflow.
iii) We can build our logic apps visually with the help of Logic App Designer
which is available in the Azure portal through browser and in visual studio.
iv) Logic Apps deploys and run in the cloud on Azure.

/* https://www.youtube.com/watch?v=ZvsOzji_8ow&ab_channel=AdamMarczak-AzureforEveryone */
/* Azure Logic Apps Tutorial */


----------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=tUOTecMFHQw&list=PLMWaZteqtEaIWwpz64BwOBytNDPka700J&index=2&ab_channel=WafaStudies */
/* 2. Create your first Logic Apps workflow using Azure Portal */
----------------------------------------------------------------------------------------------
Requirement :- we have an storage account inside which we have a container.Whenever any
new file is getting dumped inside this container then a logic app should run which will
insert a record in SQL database having column blobname, bobpath & LastModifiedDate.

/* Create a new Logic Apps */
Create a new Resource :- Search "Logic App" :- 
Subscription :- Visual Studio Enterprise
Resource Group :- myresource
Type :- Consumption /* Don't select standard.UI will become different.Must */
Logic App Name :- SendEmail
Publish :- Workflow
Create.

UI :- Workflows :- i) Workflows ii) Connections
Create a new Workflow :- Name :- NewWorkflow
/* A new window will appear.Here we need to define our operation,Action and Trigger. */
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Workflow.png
Here screenshot is present while creating a new workflow.

Choose an Operation :- By default some options will be displayed there.Ex :- 
Azure blob, Azure function, Control, Datetime, DB2 etc..
From these value we need to choose any value.Since we need to check new entry of file in 
Azure blob storage.So will select "Azure blob".
After selecting a new window will apper.Screenshot is presnet here.
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Workflow_2.png

Everything is predefined.We just need to search that and select.Automatically every option
associated operation will appear.
No we need to choose from "Triggers".
By default "When a blob is added or modofies in blob storage" option is showing.
Select this option.A new window will appear where we need to define  the connection.
Means from Logic app it will connect to blob storage account.Then only it will know the action.
Path :- C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\Workflow_3.png

Create Connection :- 
*Connection name :- BlobConnection
*Azure Blob Storage Connection String :- uspstorageaccountnew
Parameters :- *Blob Path :-  /uspstagingcontainer/input
Settings :- Trigger Conditions :- + Add :- 


SQLDB_S33
when a blob is added or modified in azure storage


/* Blob Storage Account :- */
Subscription :- ES-LOB-USP-DEV
Resource Group :- uspstagingdbgroupdev
Storage Account Name :- "uspstorageaccountnew"
ContainerName :- "uspstagingcontainer"
Folder Name :- input

https://uspstorageaccountnew

https://uspstorageaccountnew.blob.core.windows.net/uspstagingcontainer/input

/* SQL Database :- */
Server Name 	:- osedbserverlocal.database.windows.net
Authentication 	:- SQL Server Authentication
Login			:- adminuser
Password 		:- usP>>2021
Database Name   :- oselocaltxdb_S33

drop table if exists blobdetails;
create table blobdetails
(
    BlobName nvarchar(100),
    BlobPath nvarchar(400),
    BlobLastModifiedDate nvarchar(100)
)

select * from blobdetails;
when blob is added or modified


/* Learn more on Logic App.Email is working is fine.See some other usage of logic app */


==========================================================================================
==========================================================================================
_synapse
/* Azure Synapse Analytics */
---------------------------------
---------------------------------------------------------------------------------------------------
/* https://www.youtube.com/playlist?list=PLMWaZteqtEaIZxPCw_0AO1GsqESq3hZc6 */
/* Azure Synapse Analytics Playlist */
/* Azure SQL Data Warehouse */

/* https://docs.microsoft.com/en-in/azure/synapse-analytics/ */
/* Azure Synapse Analytics */
/* Full Azure Synapse MS Documentation */
---------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=Qoatg-SPpe4&list=PLMWaZteqtEaIZxPCw_0AO1GsqESq3hZc6&index=2&ab_channel=WafaStudies */
/* 1. Introduction to Azure Synapse Analytics */
---------------------------------------------------------------------------------------------------
Azure synapse is a limitless analytics service that brings enterprise datawarehousing
and Big data analytics together.It gives us the freedom to query data on our terms 
using either serverless or dedicated resources at scale.

Azure Synapse analytics bring best of below components together as single service.
i) SQL technology used in data Warehousing (Synapse SQL)
ii) Spark technology used in big data (Apache Spark)
iii) Pipeline for data integration and ETL/ELT (ADF Activity)
iv) Azure Data Lake Storage Gen2

/* So basically ADF,SQL and big Analytics (Data Bricks) all these we can perform in Azure Synapse. */

It has deep integration with Azure service such as Power BI, Cosmos DB, Azure ML etc..

/* Azure Synapse Diagram :- */
C:\Users\10662208\Desktop\ABHILASH\Script\Azure Learning\Azure_Synapse_Diagram.PNG

---------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=7CaPNyT8qPQ&list=PLMWaZteqtEaIZxPCw_0AO1GsqESq3hZc6&index=3&ab_channel=WafaStudies */
/* 2. Create Azure Synapse Analytics Workspace */
---------------------------------------------------------------------------------------------------
i) Go to https://ms.portal.azure.com/#home
ii) Search /* Azure Synapse Analytics */
iii) + Create :- 
Subscription :- Visual Studio Enterprise
Resource Group :- myresource
Managed Resource Group :- Keep Blank
Workspace Name :- abksynapseworkspace
Region :- East US
Select Data Lake Storage Gen 2 :- // 
Account Name :- If already have then select from drop down else create a new one.
    Create New :- Name :- abksynapseadlsgen2
File System Name :- It is container name.Id already created then select from drop down else create a new one.
    Create New :- Name :- abksynapsecontainer

/* Note :- Synapse account must be associated with an ADLS Gen2 storage account. */

Go to Resource Group :- click on "abksynapseworkspace".
Open :- Synapse Studio :- A new window will open.
/* https://web.azuresynapse.net/en-us/?workspace=%2fsubscriptions%2fa076fb24-5057-42ad-bd6a-1735a7907331%2fresourceGroups%2fmyresource%2fproviders%2fMicrosoft.Synapse%2fworkspaces%2fabksynapseworkspace */
In order to work on azure synapse analytics account we need "Synapse Studio".
Everything we need to do here.

Another way to launch "Synapse Studio" :- 
https://web.azuresynapse.net
Select workspace name :- "abksynapseworkspace"
/* https://web.azuresynapse.net/en-us/home?workspace=%2Fsubscriptions%2Fa076fb24-5057-42ad-bd6a-1735a7907331%2FresourceGroups%2Fmyresource%2Fproviders%2FMicrosoft.Synapse%2Fworkspaces%2Fabksynapseworkspace */

Here options are :- 
i) Home
ii) Data :- a) Workspace :- Database :- No DB as of now
            b) Linked :- Here ADLS Gen2 account and its container will be present.
iii) Develope :- 
iv) Integrate :- 
v) Monitor :- 
vi) Manage :- 

---------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=DZneFEqH-H4&list=PLMWaZteqtEaIZxPCw_0AO1GsqESq3hZc6&index=3&ab_channel=WafaStudies */
/* 3. Basic Concepts in Azure Synapse Analytics */
---------------------------------------------------------------------------------------------------
 ) Synapse Workspace :- It is a collabration place for doing cloud based enterprise analytics in azure.
Synapse Workspace will be associated with ADLS Gen 2 and file system.
A workspace allow us to perform analytics with SQL and Apache spark.
Resources available for SQL and spark analytics are organised into SQL & spark pools.

ii) Linked Services :- It is a connection strings that defines the connection information
needed for workspace to connect to external resources.
Go to :- Monitor >>> Linked Service >>> Create New

iii) Synapse SQL :- It has ability to do T-SQL based analytics in Synapse workspace.
It has two consumption models :- i) Dedicated ii) Serverless
Synapse SQL pools help us to run SQL scripts.
Go to :- Manage >>> SQL Pools >>> 
Here By default "build-in" will be present which will have "Serverless" consumption model.

If SQL pool is of "Serverless" consumption model then it will be reserved only till query
execution happens.After that it will be automatically released.
So we have to pay only for that duration of time.

If SQL pool is of "dedicated" consumption model then every time it will be available.
So here we need to pay more.

We can create our own new SQL Pool. Go to :- Manage >>> SQL Pools >>> Create New

iv) Apache Spark for Synapse :- This gives ability to do Spark based analytics in synapse workspace.
We can create apache spark pool in workspace. When we start using that spark pool, the workspace 
creates spark session to handle the resources associated with that session.
There are two ways to use spark in synapse.
a) Spark Notebook :- For doing data science and data engineering using scala, pyspark, C# and spark SQL.
b) Spark job definitions :- For running batch Spark jobs using jar files.

Go to :- Manage >>> Apache Spark Pools >>> Create New

v) Pipelines :- Same as ADF pipelines.
Go to :- Integrate >>> + >>> Pipeline
DataSet :- Go to :- Data >>> linked >>> + >>> Integration Dataset

---------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=r3IAu6FG-vQ&list=PLMWaZteqtEaIZxPCw_0AO1GsqESq3hZc6&index=4&ab_channel=WafaStudies */
/* 4. Analyze data with a server less SQL pool */
---------------------------------------------------------------------------------------------------
Built in Serverless SQL Pool :- 
i) In serverless SQL pools, without reserving the capacity we can run SQL queries.
Billing for a serverless SQL pool is based on the amount of data processed to run the query.

ii) Every workspace comes with a pre configured serverless SQL pool called "Built-in".


Requirement :- Upload a .csv file in ADLS gen2 and query the data from that file.
The query will use "Built-in" SQL pool.

Function used to read data from File :- OPENROWSET() :- It is used to access files in Azure 
storage account and return set of rows.


CSV File :- C:\Users\10662208\Desktop\ABHILASH\Script\"Azure Learning"\Emp.csv
Go to :- Data >>> Linked >>> abksynapseadlsgen2 >>> abksynapsecontainer
Upload >>> Emp.csv
File URL :- More >>> Properties >>> URL (Copy)
/* https://abksynapseadlsgen2.dfs.core.windows.net/abksynapsecontainer/Emp.csv */

Develope >>> + >>> SQL Script
Name :- SQL_Script_1
Results Settings Per Query :- ALL Rows (By default First 5000 rows)
/* By default this script will be connected to "Built-in" SQL pool.If we have other SQL pool then 
we can also select from drop down. */

Query :- Run :- Data from file will be displayed in tabular format.

SELECT *
FROM
    OPENROWSET(
    BULK 'https://abksynapseadlsgen2.dfs.core.windows.net/abksynapsecontainer/Emp.csv',
    FORMAT = 'CSV',
    HEADER_ROW = TRUE,
    PARSER_VERSION='2.0'
    ) AS [result]
    
SELECT dept, SUM(sal) AS TotSalary
FROM
    OPENROWSET(
    BULK 'https://abksynapseadlsgen2.dfs.core.windows.net/abksynapsecontainer/Emp.csv',
    FORMAT = 'CSV',
    HEADER_ROW = TRUE,
    PARSER_VERSION='2.0'
    ) AS [result]
GROUP BY dept

O/P :- Giving error as salary column is a varchar.Check how to do cast and re run it.


---------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=xipW6s7hg2E&list=PLMWaZteqtEaIZxPCw_0AO1GsqESq3hZc6&index=5&ab_channel=WafaStudies */
/* 5. Analyze data with dedicated SQL Pool in Azure Synapse Analytics */
---------------------------------------------------------------------------------------------------
Dedicated SQL pool :- It consumes billable resources if it is active.We can pause the 
pool to reduce cost.
Dedicated SQL pool will be associated with dedicated SQL database.


Requirement :- Create a dedicated SQL pool and use this SQL pool while executing
any SQL script.So here we will create a table from downloaded parquet file.
and then will query on the table created.


Create a dedicated SQL pool :- 
Go to :- Manage >>> SQL pools >>> +New >> 
Dedicated SQL pool name :- Dedicate-SQL-Pool-1
Create :- /* Failed to deploy Dedicate-SQL-Pool-1 (dedicated SQL pool). */
/* Try to solve this */

Whenever we create a new dedicated SQL pool a new database will be created with same name.
Go to :- Data >>> Workspace >>> Databases >>> Dedicate-SQL-Pool-1

File URL :- 
/* https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbDJCOVhSUmNEMmU0MnhMSVJmcWF4WE1SWlNQUXxBQ3Jtc0trZTZ3cVlDeGZHMkJzRmd2VnRvSnQ4RXRsNGZ2aFI3Rno0aUFiUlVDQ3BkdzVZVENoY21PekwzcFQ4cWNZM0FoQ0g4MTdmT3JVMk9Mb2Yyak1UX2luVElQRnRxYlhOSEg2Y1pLYXU5SF81ZXQ5MDQ0UQ&q=https%3A%2F%2Fazuresynapsestorage.blob.core.windows.net%2Fsampledata%2FNYCTaxiSmall%2FNYCTripSmall.parquet */
File Path :- 
/* C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\NYCTripSmall.parquet */

CSV File Path :- C:\Users\10662208\Desktop\ABHILASH\Script\"Azure Learning"\NYCTripSmall.parquet
Go to :- Data >>> Linked >>> abksynapseadlsgen2 >>> abksynapsecontainer
Upload >>> NYCTripSmall.parquet
File URL :- More >>> Properties >>> URL (Copy)
/* https://abksynapseadlsgen2.dfs.core.windows.net/abksynapsecontainer/NYCTripSmall.parquet */

Develope >>> + >>> SQL Script
Name :- SQL_Script_2
Results Settings Per Query :- ALL Rows (By default First 5000 rows)
/* By default this script will be connected to "Built-in" SQL pool.
Since we have created a dedicated SQL pool, So will select from "Connect to" drop down. */

Query 1:- 
IF NOT EXISTS (SELECT * FROM sys.objects O JOIN sys.schemas S ON O.schema_id = S.schema_id WHERE O.NAME = 'NYCTaxiTripSmall' AND O.TYPE = 'U' AND S.NAME = 'dbo')
CREATE TABLE dbo.NYCTaxiTripSmall
(
 [DateID] int,
 [MedallionID] int,
 [HackneyLicenseID] int,
 [PickupTimeID] int,
 [DropoffTimeID] int,
 [PickupGeographyID] int,
 [DropoffGeographyID] int,
 [PickupLatitude] float,
 [PickupLongitude] float,
 [PickupLatLong] nvarchar(4000),
 [DropoffLatitude] float,
 [DropoffLongitude] float,
 [DropoffLatLong] nvarchar(4000),
 [PassengerCount] int,
 [TripDurationSeconds] int,
 [TripDistanceMiles] float,
 [PaymentType] nvarchar(4000),
 [FareAmount] numeric(19,4),
 [SurchargeAmount] numeric(19,4),
 [TaxAmount] numeric(19,4),
 [TipAmount] numeric(19,4),
 [TollsAmount] numeric(19,4),
 [TotalAmount] numeric(19,4)
)
WITH
(
DISTRIBUTION = ROUND_ROBIN,
 CLUSTERED COLUMNSTORE INDEX
 -- HEAP
)
GO

COPY INTO dbo.NYCTaxiTripSmall
(DateID 1, MedallionID 2, HackneyLicenseID 3, PickupTimeID 4, DropoffTimeID 5,
PickupGeographyID 6, DropoffGeographyID 7, PickupLatitude 8, PickupLongitude 9, 
PickupLatLong 10, DropoffLatitude 11, DropoffLongitude 12, DropoffLatLong 13, 
PassengerCount 14, TripDurationSeconds 15, TripDistanceMiles 16, PaymentType 17, 
FareAmount 18, SurchargeAmount 19, TaxAmount 20, TipAmount 21, TollsAmount 22, 
TotalAmount 23)
FROM 'https://abksynapseadlsgen2.dfs.core.windows.net/abksynapsecontainer/NYCTripSmall.parquet'
WITH
(
FILE_TYPE = 'PARQUET'
,MAXERRORS = 0
,IDENTITY_INSERT = 'OFF'
)

O/P :- Here a new table "dbo.NYCTaxiTripSmall" will be created inside "Dedicate-SQL-Pool-1" DB.
and data from parquet file will be loaded.

Query 2 :- Go to :- Data >>> Workspace >>> Databases >>> Dedicate-SQL-Pool-1
>>> Table >>> Right Click >>> New SQL Script >>> Select TOP 100 rows
and copy below query.

SELECT PassengerCount,
      SUM(TripDistanceMiles) as SumTripDistance,
      AVG(TripDistanceMiles) as AvgTripDistance
FROM  dbo.NYCTaxiTripSmall
WHERE TripDistanceMiles > 0 AND PassengerCount > 0
GROUP BY PassengerCount
ORDER BY PassengerCount;


---------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=F25pgHJYMsM&list=PLMWaZteqtEaIZxPCw_0AO1GsqESq3hZc6&index=6&ab_channel=WafaStudies */
/* 6. Analyze data with Server less Spark Pool in Azure Synapse Analytics */
---------------------------------------------------------------------------------------------------

File URL :- 
/* https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbDJCOVhSUmNEMmU0MnhMSVJmcWF4WE1SWlNQUXxBQ3Jtc0trZTZ3cVlDeGZHMkJzRmd2VnRvSnQ4RXRsNGZ2aFI3Rno0aUFiUlVDQ3BkdzVZVENoY21PekwzcFQ4cWNZM0FoQ0g4MTdmT3JVMk9Mb2Yyak1UX2luVElQRnRxYlhOSEg2Y1pLYXU5SF81ZXQ5MDQ0UQ&q=https%3A%2F%2Fazuresynapsestorage.blob.core.windows.net%2Fsampledata%2FNYCTaxiSmall%2FNYCTripSmall.parquet */
File Path :- 
/* C:\Users\10662208\Desktop\ABHILASH\Script\Azure_Learning\NYCTripSmall.parquet */

CSV File Path :- C:\Users\10662208\Desktop\ABHILASH\Script\"Azure Learning"\NYCTripSmall.parquet
Go to :- Data >>> Linked >>> abksynapseadlsgen2 >>> abksynapsecontainer
Upload >>> NYCTripSmall.parquet
File URL :- More >>> Properties >>> URL (Copy)
/* https://abksynapseadlsgen2.dfs.core.windows.net/abksynapsecontainer/NYCTripSmall.parquet */

ABFSS Path :- Used in notebook.
/* abfss://abksynapsecontainer@abksynapseadlsgen2.dfs.core.windows.net/NYCTripSmall.parquet */


Spark :- Spark is a technology/framework which is used for big data processing.
Inside spark we will have clusters which is a combination of VMs (Node).
Here we need to write spark code in scala/Python/C# etc and this code will be executed in
cluster.

In Azure databricks we create a cluster and attaching it to Notebook but 
in Azure Synapse we need to create a "Spark Pool" (Define Node and Size) and this
spark will be used in executing Notebook.


/* Create Apache Spark Pool */
Go to :- Manage >>> Apache Spark pools >>> +New >> 
Apache Spark pool name :- SparkPool1
Review + Create >>> /* Error */
Encountered internal server error. Diagnostic information: 
timestamp '20210819T093449Z', 
subscription id 'a076fb24-5057-42ad-bd6a-1735a7907331', 
tracking id '64a329fc-86ef-4729-955c-a41d19fda1b5', 
request correlation id '6023e336-965b-4b17-baf0-847eeafe59ad'.

Next Attempt :- /* Done */

Apache Spark pools is similar to SQL pool.Whenever we will use that time only we need to pay.
Spark pools controls how many spark resources will be used by that session and how long
the session will last before it automatically pause.

Requirement :- We will create a data frame of NYCTripSmall.parquet file inside notebook.
and display data.Then create a new database and load data from Dataframe to a table inside newly created DB.

Develope >>> + >>> Notebook
Name :- FetchNYCTripSmalldata

1) 
%%pyspark
df = spark.read.load('abfss://abksynapsecontainer@abksynapseadlsgen2.dfs.core.windows.net/NYCTripSmall.parquet', format='parquet')
display(df.limit(10))
df.printSchema()        # /* Display data types of each column */

O/P :- Data will be displayed.

2) 
%%pyspark
spark.sql("CREATE DATABASE IF NOT EXISTS nyctaxi")
df.write.mode("overwrite").saveAsTable("nyctaxi.trip")

O/P :- DB and table will be created inside database present in Data >>> Workspace.

3) %%pyspark
df = spark.sql("SELECT * FROM nyctaxi.trip") 
display(df)


4) %%pyspark
df = spark.sql("""
   SELECT PassengerCount,
       SUM(TripDistanceMiles) as SumTripDistance,
       AVG(TripDistanceMiles) as AvgTripDistance
   FROM nyctaxi.trip
   WHERE TripDistanceMiles > 0 AND PassengerCount > 0
   GROUP BY PassengerCount
   ORDER BY PassengerCount
""") 
display(df)
df.write.saveAsTable("nyctaxi.passengercountstats")

O/P :- Output is getting stored inside "nyctaxi.passengercountstats" table.


---------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=dNntMxyHbNg&list=PLMWaZteqtEaIZxPCw_0AO1GsqESq3hZc6&index=7&ab_channel=WafaStudies */
/* 7. Analyze data in Storage Account in Azure Synapse Analytics */
---------------------------------------------------------------------------------------------------
Requirement :- In previous step we have created a table "passengercountstats".
We will load data of this file into ADLS Gen2 container as csv and parquet file.


Develope >>> + >>> Notebook
Name :- CopyNYCTripSmalldataToADLS

1) 
%%pyspark
df = spark.sql("SELECT * FROM nyctaxi.passengercountstats")
df = df.repartition(1)  # /* This ensures we will get a single file during write(). */
df.write.mode("overwrite").csv("/NYCTaxi/PassengerCountStats_csvformat")
df.write.mode("overwrite").parquet("/NYCTaxi/PassengerCountStats_parquetformat")

O/P :- Files generated succesfully in csv and parquet format.
Since we have used partition(1) so only one file will be generated.
Also a _Success will will be generated in each folder.
We can see data of each file using SQL script or notebook to DF option.

---------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=UdUw2c-w1NA&list=PLMWaZteqtEaIZxPCw_0AO1GsqESq3hZc6&index=8&ab_channel=WafaStudies */
/* 8. Integrate Pipelines in Azure Synapse Analytics */
---------------------------------------------------------------------------------------------------
Requirement :- Create a pipeline and run notebook created in last step.
So basically we will call a Notebook from Azure Pipeline.

Notebook Name :- CopyNYCTripSmalldataToADLS

/* Delete NYCTaxi folder from ADLS.Since already it is created */
Go to :- Integrate >>> +  >>> Pipeline
Pipeline Name :- Notebook(Synapse) :- RunNBCopyNYCTripSmalldataToADLS
Activity Name :- Notebook1
Setting :- Notebook :- CopyNYCTripSmalldata (Drop Down)

publish All >>> Run >>> Files got created.
The way we are creating pipelines in ADF same way everything we can do here.

---------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=XccZMJncQD8&list=PLMWaZteqtEaIZxPCw_0AO1GsqESq3hZc6&index=9&ab_channel=WafaStudies */
/* 9. Monitor your Azure Synapse Analytics Workspace */
---------------------------------------------------------------------------------------------------
Monitor section is used to see status of pipeline run, Trigger Run, Notebook run, SQL Script run etc.
If we are running any SQL script then also we can check its status.

SQL Script :- SQL Requests
Notebook :- Apache Spark Application
Pipeline :- Pipeline Runs
Triggered Pipeline :- Trigger Runs

---------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=zABMh5Ia8UA&list=PLMWaZteqtEaIZxPCw_0AO1GsqESq3hZc6&index=10&ab_channel=WafaStudies */
/* 10. Add an Administrator to your Azure Synapse Workspace */
---------------------------------------------------------------------------------------------------
i) Add Owner role to a new user(Teammate)
ii) Add Synapse administrator role for the workspace to new user.
iii) create a new user in DB
iv) Grant access to DB user.
/* Watch when requirement comes */

---------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=n6jCi9HOyTw&list=PLMWaZteqtEaIZxPCw_0AO1GsqESq3hZc6&index=11&ab_channel=WafaStudies */
/* 11. Azure Synapse SQL Architecture */
---------------------------------------------------------------------------------------------------
Synapse SQL has two component :- 

---------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=KTr50OtHTN8&list=PLMWaZteqtEaIZxPCw_0AO1GsqESq3hZc6&index=12 */
/* 12. Distributions(Hash, Round Robbin & Replicate) in Azure Synapse Analytics */
---------------------------------------------------------------------------------------------------

/* Must :- Watch one more time both video and also read from documentation for better understanding */

---------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=_0T1cn2_faE&list=PLMWaZteqtEaIZxPCw_0AO1GsqESq3hZc6&index=13&ab_channel=WafaStudies */
/* 13. Server less SQL Pool Overview in Azure Synapse Analytics */
---------------------------------------------------------------------------------------------------
Serverless SQL Pool :- Every synapse analytics workspace comes with serverless SQL pool endpoint
that we can use to query data in the azure data lake (Parquet, Data Lake, Delimeted text formats), 
Cosmos DB or Dataverse.

It allows ut to get query data with T-SQL syntax directly without need to copy or load data 
into a specialized store.

We only need to pay for query execution.

/* Serverless SQL Pool Benefits :- */
i) Using "Built-In" SQL pool we can create a new DB.This DB will not have its storage account.
It is called "Logical DatawareHouse"(LDW).
Go to :- Develope >>> + >>> SQL Script
Name :- CreateDB_SQL_Script
CREATE DATABASE demoDB :- Run this using built-In SQL pool.

O/P :- A new DB will be created inside Data >>> Workspace >>> Database >>> demoDB
This DB will not have any storage account so table, procedure, function will not be part of this DB.
Component inside demoDB :- 
i) External Resources :- a) External Data Sources b) External File Formats
ii) External Table :- Here it will store metadata of files.So whenever we will query this table
it will get the data from storage file.
iii) Schemas :- 
iv) Security :- 
v) Views :- 

/* What are the objects we can do using built-In SQL pool :-  */
i) Database :- Can create multiple databses
ii) Schema :- Within databse can create multiple schemas.
iii) Views, Stored Procedure, Inline table value function :- /* Check for stored procedure */
iv) External Resources :- Data Source, File Formats and tables.

/* Not supported objects in Logical Database :-  */
i) Table :- 
ii) Trigger :- 
iii) Materialized Views :- 
iv) DDL statement except views and security :- 
v) DML Statements :- 

---------------------------------------------------------------------------------------------------
/* https://www.youtube.com/watch?v=WMSF_ScBKDY&list=PLMWaZteqtEaIZxPCw_0AO1GsqESq3hZc6&index=14&ab_channel=WafaStudies */
/* 14. Create External Data source in Azure Synapse Analytics */
---------------------------------------------------------------------------------------------------
External Table :- Here we will write a command to create External table which will point
to storage account.Whenever we will write select command on external table it will fetch data from
storage account and will return.

External Data Source :- It is used to established connectivity with external resources like
Azure Storages.It is primarily used for Data virtualization and data load using Polybase.

/* Syntax :- */
CREATE EXTERNAL DATA SOURCE <data_source_name>
WITH
(    LOCATION         = '<prefix>://<path>'
     [, CREDENTIAL = <database scoped credential> ]
     , TYPE = HADOOP
)
[;]

/* Create an External Data Source */ 

/* Watch one more time */

---------------------------------------------------------------------------------------------------
LTI Account Azure Services :- 
Resource Group :- LTI_Resource_Grp

Storage Account Name :- ltista
Container Name :- lticontainer

Azure SQL :- 
Server Name :- lti.database.windows.net
User :- adminuser
Password :- Pass@123

Data Factory :- 
Name :- LTI-DF


