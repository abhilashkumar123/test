from django.db.models import Q
from django_filters.rest_framework import FilterSet, filters

from .models import (
    AuditLog,
    Country,
    Entity,
    EntityRole,
    Language,
    LinkType,
    Product,
    ProductUrl,
    ProductUrlChangeRequests,
    ProductUrlRequest,
    User,
)


class AuditLogFilter(FilterSet):
    class Meta:
        model = AuditLog
        fields = {
            "user": ["exact", "in"],
            "action": ["exact", "in", "icontains"],
            "created": ["exact", "in", "gt", "gte", "lt", "lte"],
        }


class LanguageFilter(FilterSet):
    class Meta:
        model = Language
        fields = {
            "id": ["exact", "in"],
            "name": ["exact", "in", "icontains"],
            "iso_639_1_code": ["exact", "in"],
            "iso_639_2_code": ["exact", "in"],
        }


class LinkTypeFilter(FilterSet):
    class Meta:
        model = LinkType
        fields = {
            "id": ["exact", "in"],
            "name": ["exact", "in", "icontains"],
            "tag": ["exact", "in"],
        }


class CountryFilter(FilterSet):
    class Meta:
        model = Country
        fields = {"id": ["exact", "in"], "name": ["exact", "in", "icontains"]}


class UserFilter(FilterSet):
    class Meta:
        model = User
        fields = {
            "id": ["exact", "in"],
            "username": ["exact", "in", "icontains"],
            "first_name": ["exact", "in", "icontains"],
            "last_name": ["exact", "in", "icontains"],
        }


class EntityFilter(FilterSet):
    class Meta:
        model = Entity
        fields = {"id": ["exact", "in"], "country__name": ["exact", "in"]}


class ProductFilter(FilterSet):
    entity = filters.CharFilter(method="entity_filter", field_name="entity")

    class Meta:
        model = Product
        fields = {"id": ["exact", "in"], "gtin": ["exact", "in", "icontains"]}

    def entity_filter(self, queryset, name, value):
        if value:
            return queryset.filter(products__in=[value])
        return queryset


class EntityRoleFilter(FilterSet):
    class Meta:
        model = EntityRole
        fields = {
            "id": ["exact", "in"],
            "user": ["exact", "in"],
            "entity": ["exact", "in"],
            "group": ["exact", "in"],
            "user__email": ["exact", "in"],
            "group__name": ["exact", "in"],
        }


class ProductUrlFilter(FilterSet):
    # todo: remove this post deployment. very bad code.
    batch_number = filters.CharFilter(
        method="batch_number_filter", field_name="batch_number"
    )
    serial_number = filters.CharFilter(
        method="serial_number_filter", field_name="serial_number"
    )
    exclude_special_link_types = filters.BooleanFilter(
        method="exclude_special_link_types_filter",
        field_name="exclude_special_link_types",
    )

    class Meta:
        model = ProductUrl
        fields = {
            "id": ["exact", "in"],
            "product": ["exact", "in"],
            "link_type": ["exact", "in"],
            "language": ["exact", "in"],
            "product__gtin": ["exact"],
        }

    def batch_number_filter(self, queryset, name, value):
        if value:
            batch_number_filter = (
                Q(allowed_batch_numbers__iexact="")
                | Q(allowed_batch_numbers__isnull=True)
                | Q(allowed_batch_numbers__icontains=value)
            )
            return queryset.filter(batch_number_filter)
        return queryset

    def serial_number_filter(self, queryset, name, value):
        if value:
            serial_number_filter = (
                Q(allowed_serial_numbers__iexact="")
                | Q(allowed_serial_numbers__isnull=True)
                | Q(allowed_serial_numbers__icontains=value)
            )
            return queryset.filter(serial_number_filter)
        return queryset

    def exclude_special_link_types_filter(self, queryset, name, value):
        if value:
            serial_number_filter = Q(
                (
                    Q(allowed_serial_numbers__isnull=True)
                    | Q(allowed_serial_numbers__iexact="")
                ),
                (
                    Q(allowed_batch_numbers__iexact="")
                    | Q(allowed_batch_numbers__isnull=True)
                ),
            )
            return queryset.filter(serial_number_filter)
        return queryset


class ProductUrlRequestFilter(FilterSet):
    gtin = filters.CharFilter(method="gtin_filter", field_name="gtin")

    class Meta:
        model = ProductUrlRequest
        fields = {
            "id": ["exact", "in"],
            "product_url": ["exact", "in"],
            "product": ["exact", "in"],
            "link_type": ["exact", "in"],
            "language": ["exact", "in"],
            "requested_by": ["exact", "in", "isnull"],
            "approved_by": ["exact", "in", "isnull"],
        }

    def gtin_filter(self, queryset, name, value):
        if value:
            return queryset.filter(
                Q(product__gtin=value) | Q(product_url__product__gtin=value)
            )
        return queryset


class ProductUrlChangeRequestsFilter(FilterSet):
    gtin = filters.CharFilter(method="gtin_filter", field_name="gtin")

    class Meta:
        model = ProductUrlChangeRequests
        fields = {
            "id": ["exact", "in"],
            "request_id": ["exact", "in"],
            "requested_by": ["exact", "in"],
            "resolved_by": ["exact", "in"],
        }

    def gtin_filter(self, queryset, name, value):
        if value:
            return queryset.filter(
                Q(request__product__gtin=value)
                | Q(request__product_url__product__gtin=value)
            )
        return queryset
