import hashlib
from collections import OrderedDict, defaultdict
from io import BytesIO
from uuid import uuid4

from django.contrib.auth import user_logged_out
from django.contrib.auth.models import Group
from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Count, Q
from django.http import HttpResponse
from django.template.loader import get_template
from jwt import DecodeError, ExpiredSignatureError
from openpyxl import load_workbook
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.generics import GenericAPIView
from rest_framework.response import Response
from weasyprint import HTML
from openpyxl.styles import Alignment, Font, PatternFill

from custom_drf_utilities import (
    CustomTokenObtainPairSerializer,
    IsAuthenticatedOrOptions,
    JNJModelViewSet,
    PermissionCheck,
    data_validator,
)
from model_helpers import (
    add_sheet_list_validator,
    create_excel,
    create_sheet_with_list,
    save_user_from_email,
    send_file,
)
from msft_helpers import MSFTGraphAPI, MSFTOAuth, verify_msft_auth
from simplejwt_extensions import decode_jwt
from translatable_constants import CONSTANTS, Roles
from usermgmt import filters, models, serializers
from usermgmt.models import UserOAuthToken


class AuditLogViewSet(JNJModelViewSet):
    serializer_class = serializers.AuditLogSerializer
    filterset_class = filters.AuditLogFilter
    ordering_fields = ("id",)
    search_fields = ("id",)
    queryset = models.AuditLog.objects.all()
    permission_classes = [IsAuthenticatedOrOptions]
    methods_not_allowed = ["post", "patch", "put", "delete"]

    @action(
        detail=False,
        methods=["post"],
        serializer_class=serializers.EntityQueryParamSerializer,
    )
    def audit_trail_report(self, request, pk=None, *args, **kwargs):
        if not request.user.groups.filter(name=Roles.SuperAdmin.value).exists():
            return Response(status=status.HTTP_403_FORBIDDEN)
            
        # check type of report from query params
        report_type = request.query_params.get("type", "html")
        context = {"audit_logs": self.filter_queryset(self.get_queryset())}
        if report_type == "pdf" or report_type == None:
            # convert created to %Y-%m-%d %H:%M:%S UTC
            for audit_log in context["audit_logs"]:
                audit_log.created = audit_log.created.strftime("%Y-%m-%d %H:%M:%S UTC")
            # create pdf
            pdfname = f"{str(uuid4())}.pdf"
            template_file = "audit_log_table.html"
            template = get_template(template_file)
            a = HTML(string=template.render(context), base_url=request.build_absolute_uri())
            pdf_file = a.write_pdf()
            response = HttpResponse(content=pdf_file, content_type="application/pdf")
            response["Content-Disposition"] = f"attachment; filename={pdfname}"
            return response
        elif report_type == "xlsx":
            # excel title
            title = "Audit Trail Report"
            # excel columns
            column_data = OrderedDict({
                "User": ["user"],
                "Action": ["action"],
                "Old Data": ["old_data"],
                "New Data": ["new_data"],
                "Created": ["created"],
            })
            # excel data
            serializer_data = []
            for audit_log in context["audit_logs"]:
                serializer_data.append(
                    {
                        "user": audit_log.user.email,
                        "action": audit_log.action,
                        "old_data": audit_log.old_data,
                        "new_data": audit_log.new_data,
                        "created": audit_log.created.strftime("%Y-%m-%d %H:%M:%S UTC"),
                    }
                )
            # excel validations
            column_validations = {}
            # create excel
            excel = create_excel( serializer_data, column_data, title, column_validations)
            # set max column width
            for column in excel.active.columns:
                max_length = 0
                column = column[0].column_letter
                for cell in excel.active[column]:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(cell.value)
                    except:
                        pass
                adjusted_width = (max_length + 2) * 1.2
                # adjusted_width to be max 60
                adjusted_width = 60 if adjusted_width > 60 else adjusted_width
                excel.active.column_dimensions[column].width = adjusted_width
                # set word wrap
                for cell in excel.active[column]:
                    cell.alignment = Alignment(wrap_text=True)
            # set column header color
            for cell in excel.active[1]:
                cell.fill = PatternFill(start_color="E0E0E0", end_color="E0E0E0", fill_type="solid")
                cell.font = Font(bold=True)
            # send excel
            return send_file(excel)


class LanguageViewSet(JNJModelViewSet):
    serializer_class = serializers.LanguageSerializer
    filterset_class = filters.LanguageFilter
    ordering_fields = ("id",)
    search_fields = ("id",)
    queryset = models.Language.objects.all()
    permission_classes = [IsAuthenticatedOrOptions]
    methods_not_allowed = ["post", "patch", "put", "delete"]


class CountryViewSet(JNJModelViewSet):
    serializer_class = serializers.CountrySerializer
    filterset_class = filters.CountryFilter
    ordering_fields = ("id", "name")
    search_fields = ("id", "name")
    queryset = models.Country.objects.all()
    permission_classes = [IsAuthenticatedOrOptions]
    methods_not_allowed = ["post", "patch", "put", "delete"]


class UserViewSet(JNJModelViewSet):
    serializer_class = serializers.UserSerializer
    filterset_class = filters.UserFilter
    ordering_fields = ("id",)
    search_fields = ("id", "username", "first_name", "last_name", "email")
    queryset = models.User.objects.all()
    permission_classes = [IsAuthenticatedOrOptions]
    methods_not_allowed = ["post", "patch", "put", "delete"]

    @action(
        detail=False,
        methods=["get"],
        serializer_class=serializers.EntityQueryParamSerializer,
    )
    @data_validator(query_params=True)
    def currentuser(
        self, request, validated_data, serializer, pk=None, *args, **kwargs
    ):
        response_data = serializers.UserSerializer(request.user).data
        response_data["is_jnj_superadmin"] = False
        if request.user.groups.filter(name=Roles.SuperAdmin.value).exists():
            response_data["is_jnj_superadmin"] = True
        if validated_data.get("entity"):
            entity_role = models.EntityRole.objects.filter(
                user=request.user, entity=validated_data.get("entity")
            ).first()
            if entity_role:
                response_data["role"] = serializers.GroupSerializer(
                    entity_role.group
                ).data
        return Response(response_data)

    @action(
        detail=False,
        methods=["get"],
        serializer_class=serializers.SearchUsersSerializer,
    )
    @data_validator(query_params=True)
    def search_users(
        self, request, validated_data, serializer, pk=None, *args, **kwargs
    ):
        search_text = validated_data.get("search")
        new_token_object = verify_msft_auth(request)
        if not new_token_object:
            return Response(status=status.HTTP_403_FORBIDDEN)
        # search users logic
        is_success, search_users = MSFTGraphAPI(
            new_token_object.access_token
        ).search_users(search_text)
        response_status = (
            status.HTTP_200_OK if is_success else status.HTTP_400_BAD_REQUEST
        )
        return Response(search_users.get("value", None), status=response_status)


class LinkTypeViewSet(JNJModelViewSet):
    serializer_class = serializers.LinkTypeSerializer
    filterset_class = filters.LinkTypeFilter
    ordering_fields = ("id",)
    search_fields = ("id",)
    queryset = models.LinkType.objects.all()
    permission_classes = [IsAuthenticatedOrOptions]
    methods_not_allowed = ["post", "patch", "put", "delete"]


class EntityViewSet(JNJModelViewSet):
    serializer_class = serializers.EntitySerializer
    filterset_class = filters.EntityFilter
    ordering_fields = ("id",)
    search_fields = ("id", "country__name")
    queryset = models.Entity.objects.all()
    permission_classes = [IsAuthenticatedOrOptions, PermissionCheck]
    methods_not_allowed = ["delete"]

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        instance.delete_entity()
        return Response(status=status.HTTP_204_NO_CONTENT)

    def create(self, request, *args, **kwargs):
        principle_name = request.data.pop("principle_name")
        if not principle_name:
            return Response(
                {"message": CONSTANTS["USER_PRINCIPLE_NAME"]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        new_token_object = verify_msft_auth(request)
        if not new_token_object:
            return Response(status=status.HTTP_403_FORBIDDEN)
        admin_user = models.User.objects.filter(username=principle_name).first()
        if not admin_user:
            is_success, search_users = MSFTGraphAPI(
                new_token_object.access_token
            ).get_user_basic_profile(principle_name)
            if not search_users:
                return Response(status=status.HTTP_404_NOT_FOUND)
            admin_user = save_user_from_email(search_users)
        serializer = self.get_serializer(data=request.data)
        try:
            serializer.is_valid(raise_exception=True)
        except ValidationError:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        try:
            self.perform_create(serializer)
        except Exception as e:
            message = str(e)
            if e.args and len(e.args) > 0:
                message = str(e.args[0])
            try:
                return Response(eval(message), status=status.HTTP_400_BAD_REQUEST)
            except Exception:
                return Response(
                    {"message": message}, status=status.HTTP_400_BAD_REQUEST
                )
        models.EntityRole.objects.create(
            entity_id=serializer.data.get("id"),
            user=admin_user,
            group=Group.objects.get(name=Roles.LEAdmin.value),
        )
        return Response(status=status.HTTP_201_CREATED)

    @action(
        detail=True,
        methods=["get"],
        serializer_class=serializers.DownloadExcelInputSerializer,
    )
    @data_validator(query_params=True)
    def download_product_excel(
        self, request, validated_data, serializer, pk=None, *args, **kwargs
    ):
        should_add_existing_data = validated_data.get("is_data_required", False)
        action = (
            "download_product_excel_with_data"
            if should_add_existing_data
            else "download_product_excel_without_data"
        )
        models.AuditLog.objects.create(
            user=request.user, action=action, payload=validated_data
        )
        instance = self.get_object()
        logged_in_user_role = set(
            models.EntityRole.objects.filter(
                user=request.user, entity=instance
            ).values_list("group__name", flat=True)
        )
        if logged_in_user_role and Roles.LEAdmin.value not in logged_in_user_role:
            return Response(
                {"message": CONSTANTS["NO_DOWNLOAD_ACCESS"]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        title = "Products Export"
        column_data = OrderedDict(
            {
                "Action": ["action"],
                "GTIN": ["gtin"],
                "Product Description": ["product_description"],
                "Default Link Type": ["default_link_type"],
                "Default Language": ["default_language"],
            }
        )
        column_validations = {}
        serializer_data = {}
        if should_add_existing_data:
            export_data = instance.products.all()
            serializer = serializers.ProductExportSerializer(export_data, many=True)
            serializer_data = serializer.data

        # data excel sheet generation
        excel_object = create_excel(
            serializer_data, column_data, title, column_validations
        )
        main_sheet = excel_object["Products Export"]

        # settings problematic column types
        col = main_sheet.column_dimensions["B"]
        col.number_format = "@"

        link_type_data = list(models.LinkType.objects.values_list("name", flat=True))
        language_data = list(models.Language.objects.values_list("name", flat=True))
        gtin_data = list(instance.products.values_list("gtin", flat=True))

        # data sheets
        create_sheet_with_list(
            excel_object,
            "Action",
            None,
            ["None", "Add", "Update", "Deactivate"],
            1,
            True,
            True,
        )
        create_sheet_with_list(excel_object, "GTIN", None, gtin_data, 2, True, True)
        create_sheet_with_list(
            excel_object, "Link Type", None, link_type_data, 3, True, True
        )
        create_sheet_with_list(
            excel_object, "Language", None, language_data, 4, True, True
        )

        # main sheet validations
        add_sheet_list_validator(main_sheet, "'Action'!A:A", "A")
        # add_sheet_list_validator(main_sheet, "'GTIN'!A:A", "B")
        add_sheet_list_validator(main_sheet, "'Link Type'!A:A", "D")
        add_sheet_list_validator(main_sheet, "'Language'!A:A", "E")

        # set column width
        main_sheet.column_dimensions["A"].width = 15
        main_sheet.column_dimensions["B"].width = 20
        main_sheet.column_dimensions["C"].width = 50
        main_sheet.column_dimensions["D"].width = 20
        main_sheet.column_dimensions["E"].width = 20

        return send_file(excel_object)

    @action(
        detail=True,
        methods=["post"],
        serializer_class=serializers.UploadExcelInputSerializer,
    )
    @transaction.atomic
    @data_validator()
    def upload_product_excel(self, request, pk=None, *args, **kwargs):
        models.AuditLog.objects.create(user=request.user, action="upload_product_excel")
        instance = self.get_object()
        logged_in_user_role = set(
            models.EntityRole.objects.filter(
                user=request.user, entity=instance
            ).values_list("group__name", flat=True)
        )
        if logged_in_user_role and Roles.LEAdmin.value not in logged_in_user_role:
            return Response(
                {"message": CONSTANTS["NO_UPLOAD_ACCESS"]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        file = request.data.get("file", None)
        file_data = file.read()
        wb = load_workbook(filename=BytesIO(file_data), data_only=True)
        sheet = wb.worksheets[0]
        if sheet.max_column != 5:
            return Response(
                {"message": CONSTANTS["COL_NUMBER"]}, status=status.HTTP_400_BAD_REQUEST
            )
        found_errors = False
        errors = defaultdict(dict)
        input_data = []
        for index, row in enumerate(sheet.rows):
            if index == 0:
                continue
            row = [x.value for x in list(row)]
            data = {
                "action": row[0],
                "gtin": row[1],
                "product_description": row[2],
                "default_link_type": row[3],
                "default_language": row[4],
            }
            serializer_instance = serializers.UploadProductExelRowSerializer(data=data)
            if not serializer_instance.is_valid(raise_exception=False):
                found_errors = True
                errors[index] = serializer_instance.errors
            row_data = serializer_instance.validated_data
            input_data.append(row_data)
        success_message = {}
        if found_errors:
            return Response({"row_level_errors": errors}, status=status.HTTP_400_BAD_REQUEST)
        else:
            for index, row_data in enumerate(input_data):
                # try catch for each row
                try:
                    if row_data.get("action") == "Add":
                        try:
                            product = models.Product.objects.filter(
                                gtin__endswith=row_data.get("gtin").lstrip("0")
                            ).first()
                            if not product:
                                product = models.Product.objects.create(
                                    gtin=row_data.get("gtin"),
                                    product_description=row_data.get("product_description"),
                                    default_link_type=row_data.get("default_link_type"),
                                    default_language=row_data.get("default_language"),
                                )
                            else:
                                success_message[
                                    row_data.get("gtin").lstrip("0")
                                ] = "Product has been added to the entity - but default link and language entered prior is what will be retained"
                            instance.products.add(product)
                        except Exception as e:
                            found_errors = True
                            error_message = (
                                getattr(e, "detail", None)
                                if getattr(e, "detail", None)
                                else str(e)
                            )
                            if errors[index].get("row", None):
                                errors[index].get("row").append(error_message)
                            else:
                                errors[index]["row"] = [error_message]
                    if row_data.get("action") == "Update":
                        product = instance.products.filter(
                            gtin__endswith=row_data.get("gtin").lstrip("0")
                        ).first()
                        if not product:
                            found_errors = True
                            if errors[index].get("gtin", None):
                                errors[index].get("gtin").append(
                                    f'"{row_data.get("gtin")}" GTIN not allowed to update for this entity'
                                )
                            else:
                                errors[index]["gtin"] = [
                                    "GTIN not allowed to update for this entity"
                                ]
                        else:
                            product.default_language = row_data.get("default_language")
                            product.default_link_type = row_data.get("default_link_type")
                            product.product_description = row_data.get(
                                "product_description"
                            )
                            product.save()
                    if row_data.get("action") == "Deactivate":
                        product = instance.products.filter(
                            gtin__endswith=row_data.get("gtin").lstrip("0")
                        )
                        if not product.exists():
                            found_errors = True
                            if errors[index].get("gtin", None):
                                errors[index].get("gtin").append(
                                    f'"{row_data.get("gtin")}" GTIN not allowed to remove for this entity'
                                )
                            else:
                                errors[index]["gtin"] = [
                                    "GTIN not allowed to remove for this entity"
                                ]
                        try:
                            instance.products.remove(product.first())
                            # if (
                            #     product.first().annotate(entity_count=Count("products"))
                            #     .filter(entity_count=1)
                            #     .exists()
                            # ):
                            #     product.delete_product()
                        except Exception as e:
                            found_errors = True
                            error_message = (
                                getattr(e, "detail", None)
                                if getattr(e, "detail", None)
                                else str(e)
                            )
                            if errors[index].get("row", None):
                                errors[index].get("row").append(error_message)
                            else:
                                errors[index]["row"] = [error_message]
                except Exception as e:
                    found_errors = True
                    error_message = (
                        getattr(e, "detail", None)
                        if getattr(e, "detail", None)
                        else str(e)
                    )
                    if errors[index].get("row", None):
                        errors[index].get("row").append(error_message)
                    else:
                        errors[index]["row"] = [error_message]
        if found_errors:
            return Response({"row_level_errors": errors}, status=status.HTTP_400_BAD_REQUEST)
        return Response(status=status.HTTP_200_OK)

    @action(
        detail=True,
        methods=["get"],
        serializer_class=serializers.DownloadExcelInputSerializer,
    )
    @data_validator(query_params=True)
    def download_excel(
        self, request, validated_data, serializer, pk=None, *args, **kwargs
    ):
        should_add_existing_data = validated_data.get("is_data_required", False)
        action = (
            "download_url_excel_with_data"
            if should_add_existing_data
            else "download_url_excel_without_data"
        )
        models.AuditLog.objects.create(user=request.user, action=action)
        instance = self.get_object()
        logged_in_user_role = set(
            models.EntityRole.objects.filter(
                user=request.user, entity=instance
            ).values_list("group__name", flat=True)
        )
        if logged_in_user_role and Roles.DataEntry.value not in logged_in_user_role:
            return Response(
                {"message": CONSTANTS["NO_DOWNLOAD_ACCESS"]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        title = "Entity Product URLs Export"
        column_data = OrderedDict(
            {
                "Action": ["action"],
                "GTIN": ["gtin"],
                "Batch No": ["batch_no"],
                "Link Type": ["link_type"],
                "Language": ["language"],
                "URL": ["url"],
                "Link Title": ["link_title"],
            }
        )
        column_validations = {}
        serializer_data = {}
        if should_add_existing_data:
            export_data = models.ProductUrl.objects.filter(
                product_id__in=instance.products.all()
            )
            serializer = serializers.ExcelExportSerializer(export_data, many=True)
            serializer_data = serializer.data

        # data excel sheet generation
        excel_object = create_excel(
            serializer_data, column_data, title, column_validations
        )

        main_sheet = excel_object["Entity Product URLs Export"]

        # settings problematic column types
        col = main_sheet.column_dimensions["B"]
        col.number_format = "@"

        link_type_data = list(models.LinkType.objects.values_list("name", flat=True))
        language_data = list(models.Language.objects.values_list("name", flat=True))
        gtin_data = list(instance.products.values_list("gtin", flat=True))

        # data sheets
        create_sheet_with_list(
            excel_object,
            "Action",
            None,
            ["None", "Add", "Update", "Deactivate"],
            1,
            True,
            True,
        )
        create_sheet_with_list(excel_object, "GTIN", None, gtin_data, 2, True, True)
        create_sheet_with_list(
            excel_object, "Link Type", None, link_type_data, 3, True, True
        )
        create_sheet_with_list(
            excel_object, "Language", None, language_data, 4, True, True
        )

        # main sheet validations
        add_sheet_list_validator(main_sheet, "'Action'!A:A", "A")
        add_sheet_list_validator(main_sheet, "'GTIN'!A:A", "B")
        add_sheet_list_validator(main_sheet, "'Link Type'!A:A", "D")
        add_sheet_list_validator(main_sheet, "'Language'!A:A", "E")

        # column width
        main_sheet.column_dimensions["A"].width = 10
        main_sheet.column_dimensions["B"].width = 20
        main_sheet.column_dimensions["C"].width = 20
        main_sheet.column_dimensions["D"].width = 40
        main_sheet.column_dimensions["E"].width = 20
        main_sheet.column_dimensions["F"].width = 50
        main_sheet.column_dimensions["G"].width = 50

        return send_file(excel_object)

    @action(
        detail=True,
        methods=["post"],
        serializer_class=serializers.UploadExcelInputSerializer,
    )
    @transaction.atomic
    @data_validator()
    def upload_excel(self, request, pk=None, *args, **kwargs):
        models.AuditLog.objects.create(user=request.user, action="upload_url_excel")
        instance = self.get_object()
        logged_in_user_role = set(
            models.EntityRole.objects.filter(
                user=request.user, entity=instance
            ).values_list("group__name", flat=True)
        )
        if logged_in_user_role and Roles.DataEntry.value not in logged_in_user_role:
            return Response(
                {"message": CONSTANTS["NO_UPLOAD_ACCESS"]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        file = request.data.get("file", None)
        file_data = file.read()
        wb = load_workbook(filename=BytesIO(file_data), data_only=True)
        sheet = wb.worksheets[0]
        if sheet.max_column != 7:
            return Response(
                {"message": CONSTANTS["COL_NUMBER"]}, status=status.HTTP_400_BAD_REQUEST
            )
        allowed_gtins = list(instance.products.values_list("gtin", flat=True))
        found_errors = False
        errors = defaultdict(dict)
        input_data = []
        default_check_data = {}
        for index, row in enumerate(sheet.rows):
            if index == 0:
                continue
            row = [x.value for x in list(row)]
            data = {
                "action": row[0],
                "gtin": row[1],
                "batch_no": row[2],
                "link_type": row[3],
                "language": row[4],
                "url": row[5],
                "link_title": row[6],
            }
            serializer_instance = serializers.UploadExelRowSerializer(data=data)
            if not serializer_instance.is_valid(raise_exception=False):
                found_errors = True
                errors[index] = serializer_instance.errors
            if (
                not serializer_instance.errors.get("gtin", None)
                and row[1] not in allowed_gtins
            ):
                found_errors = True
                if errors[index].get("gtin", None):
                    errors[index].get("gtin").append(
                        f'"{row[1]}" GTIN not allowed for this entity'
                    )
                else:
                    errors[index]["gtin"] = ["GTIN not allowed for this entity"]
            row_data = serializer_instance.validated_data
            input_data.append(row_data)
            if row_data.get("gtin"):
                if row_data.get("gtin").gtin not in default_check_data:
                    default_check_data[row_data.get("gtin").gtin] = {
                        "is_default_available": False,
                        "default_language": row_data.get("gtin").default_language.name,
                        "default_link_type": row_data.get("gtin").default_link_type,
                    }
                if (
                    row_data.get("language") == row_data.get("gtin").default_language
                    and row_data.get("link_type") == row_data.get("gtin").default_link_type
                ):
                    if row_data.get("action") == "Deactivate":
                        default_check_data[row_data.get("gtin").gtin][
                            "is_default_available"
                        ] = False
                    else:
                        default_check_data[row_data.get("gtin").gtin][
                            "is_default_available"
                        ] = True
        product_errors = {}
        for product in default_check_data:
            if not default_check_data[product]["is_default_available"]:
                found_errors = True
                product_errors[
                    product
                ] = f"Default URL for this product doesn't exists. Default Language: {default_check_data[product]['default_language']}, Default Link Type: {default_check_data[product]['default_link_type']}"
        if found_errors:
            return Response(
                {"product_errors": product_errors, "row_level_errors": errors},
                status=status.HTTP_400_BAD_REQUEST,
            )
        else:
            for index, row_data in enumerate(input_data):
                if row_data.get("action") == "Add":
                    try:
                        models.ProductUrlRequest.objects.create(
                            product=row_data.get("gtin"),
                            link_type=row_data.get("link_type"),
                            language=row_data.get("language"),
                            url=row_data.get("url"),
                            requested_by=request.user,
                            allowed_batch_numbers=row_data.get("batch_no"),
                            link_title=row_data.get("link_title"),
                        )
                    except Exception as e:
                        found_errors = True
                        error_message = (
                            getattr(e, "detail", None)
                            if getattr(e, "detail", None)
                            else str(e)
                        )
                        if errors[index].get("row", None):
                            errors[index].get("row").append(error_message)
                        else:
                            errors[index]["row"] = [error_message]
                if row_data.get("action") == "Update":
                    product_url_request = models.ProductUrlRequest.objects.filter(
                        Q(
                            language=row_data.get("language"),
                            link_type=row_data.get("link_type"),
                            approved_by__isnull=True,
                        )
                        & (
                            Q(product_url__product=row_data.get("gtin"))
                            | Q(product=row_data.get("gtin"))
                        )
                    )
                    if not product_url_request.exists():
                        product_url = models.ProductUrl.objects.filter(
                            language=row_data.get("language"),
                            link_type=row_data.get("link_type"),
                        ).first()
                        if not product_url:
                            found_errors = True
                            if errors[index].get("row", None):
                                errors[index].get("row").append(
                                    CONSTANTS["PRODUCT_URL_NOT_EXIST"]
                                )
                            else:
                                errors[index]["row"] = [
                                    CONSTANTS["PRODUCT_URL_NOT_EXIST"]
                                ]
                        else:
                            models.ProductUrlRequest.objects.create(
                                product_url=product_url,
                                link_type=row_data.get("link_type"),
                                language=row_data.get("language"),
                                url=row_data.get("url"),
                                requested_by=request.user,
                            )
                    else:
                        try:
                            product_url_request.update(
                                url=row_data.get("url"), requested_by=request.user
                            )
                            product_url_request.first().producturlchangerequests_set.update(
                                resolved_by=request.user
                            )
                        except Exception as e:
                            error_message = (
                                getattr(e, "detail", None)
                                if getattr(e, "detail", None)
                                else str(e)
                            )
                            found_errors = True
                            if errors[index].get("row", None):
                                errors[index].get("row").append(error_message)
                            else:
                                errors[index]["row"] = [error_message]
                if row_data.get("action") == "Deactivate":
                    product_url = models.ProductUrl.objects.filter(
                        language=row_data.get("language"),
                        link_type=row_data.get("link_type"),
                        product=row_data.get("gtin"),
                    )
                    if not product_url.exists() or product_url.count() > 1:
                        found_errors = True
                        if errors[index].get("row", None):
                            errors[index].get("row").append(
                                CONSTANTS["PRODUCT_URL_NOT_EXIST"]
                            )
                        else:
                            errors[index]["row"] = [CONSTANTS["PRODUCT_URL_NOT_EXIST"]]
                    else:
                        product_url = product_url.first()
                        try:
                            models.ProductUrlRequest.objects.create(
                                product_url=product_url,
                                link_type=row_data.get("link_type"),
                                language=row_data.get("language"),
                                url=row_data.get("url"),
                                requested_by=request.user,
                                is_delete=True,
                                link_title=row_data.get("link_title"),
                            )
                        except Exception as e:
                            found_errors = True
                            error_message = (
                                getattr(e, "detail", None)
                                if getattr(e, "detail", None)
                                else str(e)
                            )
                            if errors[index].get("row", None):
                                errors[index].get("row").append(error_message)
                            else:
                                errors[index]["row"] = [error_message]
        if found_errors:
            return Response(
                {"product_errors": product_errors, "row_level_errors": errors},
                status=status.HTTP_400_BAD_REQUEST,
            )
        return Response(status=status.HTTP_200_OK)

    @action(
        detail=False,
        methods=["post"],
        serializer_class=serializers.EntityProductSerializer,
    )
    def download_entity_product_report(self, request, pk=None, *args, **kwargs):
        entities = self.filter_queryset(self.get_queryset())
        title = "Entity Products Report"
        column_data = OrderedDict(
            {
                "Entity Name": ["entity", "name"],
                "Added by User": ["user", "email"],
                "Product GTIN": ["product", "gtin"],
                "Pending Requests": ["product", "pending_requests"],
                "Change Requests": ["product", "change_requests"],
                "Approved Requests": ["product", "approved_requests"],
                "Default Language": ["product", "default_language", "name"],
                "Default Link Type": ["product", "default_link_type", "name"],
            }
        )
        serializer_data = self.get_serializer(
            models.EntityProduct.objects.all(entity=entities), many=True
        ).data

        # data excel sheet generation
        excel_object = create_excel(serializer_data, column_data, title, {})
        return send_file(excel_object)


class ProductViewSet(JNJModelViewSet):
    serializer_class = serializers.ProductSerializer
    filterset_class = filters.ProductFilter
    ordering_fields = ("id", "gtin", "entity")
    search_fields = ("id", "gtin")
    queryset = models.Product.objects.all()
    permission_classes = [IsAuthenticatedOrOptions]
    methods_not_allowed = ["delete"]

    @action(
        detail=False,
        methods=["post"],
        serializer_class=serializers.UnApprovedProductUrlRequestReportSerializer,
    )
    def download_pending_requests(self, request, pk=None, *args, **kwargs):
        urls = models.ProductUrlRequest.objects.filter(approved_by__isnull=True)
        title = "Product Pending Requests Report"
        column_data = OrderedDict(
            {
                "Requested Action": ["action"],
                "GTIN": ["gtin"],
                "Link Type": ["link_type", "name"],
                "Language": ["language", "name"],
                "URL": ["url"],
                "Link Title": ["link_title"],
                "Requested By": ["requested_by", "username"],
                "Requested At": ["created"],
                "Has Changes Requests": ["has_change_requests"],
            }
        )
        serializer_data = self.get_serializer(urls, many=True).data

        # data excel sheet generation
        excel_object = create_excel(serializer_data, column_data, title, {})
        return send_file(excel_object)


class EntityRoleViewSet(JNJModelViewSet):
    serializer_class = serializers.EntityRoleSerializer
    filterset_class = filters.EntityRoleFilter
    ordering_fields = ("id", "entity", "group", "user")
    search_fields = (
        "id",
        "group__name",
        "user__username",
        "user__email",
        "entity__name",
    )
    queryset = models.EntityRole.objects.all()
    permission_classes = [IsAuthenticatedOrOptions]

    def create(self, request, *args, **kwargs):
        principle_name = request.data.pop("principle_name")
        if not principle_name:
            return Response(
                {"message": CONSTANTS["USER_PRINCIPLE_NAME"]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        role_user = models.User.objects.filter(username=principle_name).first()
        if not role_user:
            new_token_object = verify_msft_auth(request)
            if not new_token_object:
                return Response(status=status.HTTP_403_FORBIDDEN)
            request.data["user_id"] = new_token_object.id
            is_success, search_users = MSFTGraphAPI(
                new_token_object.access_token
            ).get_user_basic_profile(principle_name)
            if not is_success:
                return Response(
                    {"message": CONSTANTS["INVALID_PRINCIPLE_NAME"]},
                    status=status.HTTP_400_BAD_REQUEST,
                )
            role_user = save_user_from_email(search_users)
        if (
            request.data["group_name"] == Roles.LEAdmin.value
            and not request.user.groups.filter(name=Roles.SuperAdmin.value).exists()
        ):
            return Response(
                {"message": CONSTANTS["NO_ACCESS"]}, status=status.HTTP_400_BAD_REQUEST
            )
        request.data["user_id"] = role_user.id
        request.data["created_by_id"] = request.user.id
        return super().create(request, *args, **kwargs)

    def update(self, request, *args, **kwargs):
        principle_name = request.data.pop("principle_name", False)
        if principle_name:
            role_user = models.User.objects.filter(username=principle_name).first()
            if not role_user:
                new_token_object = verify_msft_auth(request)
                if not new_token_object:
                    return Response(status=status.HTTP_403_FORBIDDEN)
                request.data["user_id"] = new_token_object.id
                is_success, search_users = MSFTGraphAPI(
                    new_token_object.access_token
                ).get_user_basic_profile(principle_name)
                if not is_success:
                    return Response(
                        {"message": CONSTANTS["INVALID_PRINCIPLE_NAME"]},
                        status=status.HTTP_400_BAD_REQUEST,
                    )
                role_user = save_user_from_email(search_users)
            request.data["user_id"] = role_user.id
        return super().update(request, *args, **kwargs)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        logged_in_user_role = set(
            models.EntityRole.objects.filter(
                user=request.user, entity=instance.entity
            ).values_list("group__name", flat=True)
        )
        if logged_in_user_role and Roles.LEAdmin.value not in logged_in_user_role:
            return Response(
                {"message": CONSTANTS["NO_DELETE_ACCESS"]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        instance.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

    @action(detail=False, methods=["post"])
    def download_report(self, request, pk=None, *args, **kwargs):
        models.AuditLog.objects.create(
            user=request.user, action="download_user_roles_report"
        )
        title = "User Roles Report"
        column_data = OrderedDict(
            {
                "User": ["user", "email"],
                "Entity Name": ["entity", "name"],
                "Role Name": ["role", "name"],
                "Created By User": ["created_by", "email"],
                "Created At": ["created"],
            }
        )
        serializer_data = self.get_serializer(self.get_queryset(), many=True).data

        # data excel sheet generation
        excel_object = create_excel(serializer_data, column_data, title, {})
        return send_file(excel_object)


class ProductUrlViewSet(JNJModelViewSet):
    serializer_class = serializers.ProductUrlSerializer
    filterset_class = filters.ProductUrlFilter
    ordering_fields = (
        "id",
        "product__gtin",
        "link_type__name",
        "language__name",
        "url",
    )
    search_fields = ("id", "product__gtin", "link_type__name", "language__name", "url")
    queryset = models.ProductUrl.objects.all()
    methods_not_allowed = ["post", "patch", "put", "delete"]


class ProductUrlRequestViewSet(JNJModelViewSet):
    serializer_class = serializers.ProductUrlRequestSerializer
    filterset_class = filters.ProductUrlRequestFilter
    ordering_fields = (
        "id",
        "product__gtin",
        "link_type__name",
        "language__name",
        "url",
    )
    search_fields = ("id", "product__gtin", "link_type__name", "language__name", "url")
    queryset = models.ProductUrlRequest.objects.all()
    permission_classes = [IsAuthenticatedOrOptions]
    methods_not_allowed = ["delete"]

    @action(detail=True, methods=["post"])
    def approve_url_request(self, request, pk=None, *args, **kwargs):
        url_request = self.get_object()
        url_request.approved_by = request.user
        url_request.save()
        return Response(status=status.HTTP_200_OK)


class ProductUrlChangeRequestsViewSet(JNJModelViewSet):
    serializer_class = serializers.ProductUrlChangeRequestsSerializer
    filterset_class = filters.ProductUrlChangeRequestsFilter
    ordering_fields = ("id",)
    search_fields = ("id",)
    queryset = models.ProductUrlChangeRequests.objects.all()
    permission_classes = [IsAuthenticatedOrOptions]
    methods_not_allowed = ["delete"]

    @action(detail=True, methods=["post"])
    def resolve_url_change_request(self, request, pk=None, *args, **kwargs):
        url_request = self.get_object()
        url_request.resolved_by = request.user
        url_request.save()
        return Response(status=status.HTTP_200_OK)


class LoginView(GenericAPIView):
    serializer_class = serializers.MSFTAuthCodeSerializer
    authentication_classes = []
    permission_classes = []

    @data_validator()
    def post(self, request, validated_data, serializer, pk=None, *args, **kwargs):
        auth_code = validated_data.get("code")
        is_success, token_object = MSFTOAuth().get_access_token_from_code(auth_code)
        if not is_success or not token_object["access_token"]:
            return Response(status=400)
        access_token = token_object["access_token"]
        access_token_hash = hashlib.sha256(access_token.encode()).hexdigest()
        refresh_token = token_object["refresh_token"]
        # todo: validate id_token to prevent middleman attacks using id_token
        # id_token = ms_access_token_response["id_token"]
        user_details = MSFTGraphAPI(access_token).get_user_details_from_token()
        user_principal_name = user_details.get("userPrincipalName").lower()
        logged_in_user = models.User.objects.filter(
            username=user_principal_name
        ).first()
        if not logged_in_user:
            logged_in_user = save_user_from_email(user_details)
        UserOAuthToken.objects.create(
            access_token=access_token,
            refresh_token=refresh_token,
            access_token_hash=access_token_hash,
            user=logged_in_user,
        )
        jnj_refresh_token = CustomTokenObtainPairSerializer.get_token(
            logged_in_user, oauth_token_hash=access_token_hash
        )
        jnj_access_token = jnj_refresh_token.access_token
        models.AuditLog.objects.create(user=logged_in_user, action="login")
        return Response(
            {"access": str(jnj_access_token), "refresh": str(jnj_refresh_token)},
            status=status.HTTP_200_OK,
        )


class LogoutView(GenericAPIView):
    def get(self, request):
        # Check if request was made with JWT Token
        token = (
            request.headers.get("Authorization").split()[-1]
            if request.headers.get("Authorization", "").startswith("Bearer")
            else None
        )
        if token:
            try:
                decoded_token = decode_jwt(token)
                out_token = UserOAuthToken.objects.filter(
                    access_token_hash=decoded_token.get("oauth_token_hash")
                )
                if out_token:
                    out_token.delete()
            except (DecodeError, KeyError, ExpiredSignatureError):
                pass
        user_logged_out.send(sender=request.user, request=request, user=request.user)
        models.AuditLog.objects.create(user=request.user, action="logout")
        return Response(status=status.HTTP_200_OK)


class ReportsView(GenericAPIView):
    def get(self, request):
        # Check if request was made with JWT Token
        token = (
            request.headers.get("Authorization").split()[-1]
            if request.headers.get("Authorization", "").startswith("Bearer")
            else None
        )
        if token:
            try:
                decoded_token = decode_jwt(token)
                out_token = UserOAuthToken.objects.filter(
                    access_token_hash=decoded_token.get("oauth_token_hash")
                )
                if out_token:
                    out_token.delete()
            except (DecodeError, KeyError, ExpiredSignatureError):
                pass
        user_logged_out.send(sender=request.user, request=request, user=request.user)
        return Response(status=status.HTTP_200_OK)
