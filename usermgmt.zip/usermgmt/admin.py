from __future__ import unicode_literals

from django.contrib import admin
from django.contrib.admin import display
from easy_select2 import select2_modelform

from django_utilities import JNJModelAdmin  # , JNJModelIsDeleteAdmin
from usermgmt import models


@admin.register(models.User)
class UserAdmin(JNJModelAdmin):
    form = select2_modelform(models.User)
    list_display = ("username", "first_name", "last_name", "email")


@admin.register(models.Language)
class LanguageAdmin(JNJModelAdmin):
    form = select2_modelform(models.Language)
    list_display = ("name", "iso_639_1_code", "iso_639_1_code")


@admin.register(models.Country)
class CountryAdmin(JNJModelAdmin):
    form = select2_modelform(models.Country)
    list_display = ("name",)


@admin.register(models.LinkType)
class LinkTypeAdmin(JNJModelAdmin):
    form = select2_modelform(models.LinkType)
    list_display = ("name", "tag", "description")


@admin.register(models.Entity)
class EntityAdmin(JNJModelAdmin):
    form = select2_modelform(models.Entity)
    list_display = ("name", "country__name")

    @display(ordering="country__name", description="country")
    def country__name(self, obj):
        return obj.country.name

    @display(ordering="entity__name", description="entity")
    def entity__name(self, obj):
        return obj.entity.name

    @display(ordering="user__username", description="user")
    def user__username(self, obj):
        return obj.user.username


@admin.register(models.EntityProduct)
class EntityProductAdmin(JNJModelAdmin):
    form = select2_modelform(models.EntityProduct)
    list_display = ("entity__name", "product__gtin", "added_by_user__username")

    @display(ordering="entity__name", description="country")
    def entity__name(self, obj):
        return obj.entity.name

    @display(ordering="product__gtin", description="entity")
    def product__gtin(self, obj):
        return obj.product.gtin

    @display(ordering="added_by_user__username", description="user")
    def added_by_user__username(self, obj):
        return getattr(obj.added_by_user, "username", None)


@admin.register(models.Product)
class ProductAdmin(JNJModelAdmin):
    form = select2_modelform(models.Product)
    list_display = (
        "gtin",
        "product_description",
        "default_link_type__name",
        "default_language__name",
    )

    @display(ordering="entity__name", description="entity name")
    def entity__name(self, obj):
        return obj.entity.name

    @display(ordering="default_link_type__name", description="default link type name")
    def default_link_type__name(self, obj):
        return getattr(obj.default_link_type, "name", None)

    @display(ordering="default_language__name", description="default language name")
    def default_language__name(self, obj):
        return getattr(obj.default_language, "name", None)


@admin.register(models.EntityRole)
class EntityRoleAdmin(JNJModelAdmin):
    form = select2_modelform(models.EntityRole)
    list_display = ("user__username", "entity__name", "group__name")

    @display(ordering="user__username", description="username")
    def user__username(self, obj):
        return obj.user.username

    @display(ordering="entity__name", description="entity name")
    def entity__name(self, obj):
        return obj.entity.name

    @display(ordering="group__name", description="group name")
    def group__name(self, obj):
        return obj.group.name


@admin.register(models.ProductUrl)
class ProductUrlAdmin(JNJModelAdmin):
    form = select2_modelform(models.ProductUrl)
    list_display = ("product__gtin", "link_type__name", "language__name", "url")

    @display(ordering="product__gtin", description="gtin")
    def product__gtin(self, obj):
        return obj.product.gtin

    @display(ordering="link_type__name", description="link_type")
    def link_type__name(self, obj):
        return obj.link_type.name

    @display(ordering="language__name", description="language")
    def language__name(self, obj):
        return obj.language.name


@admin.register(models.ProductUrlRequest)
class ProductUrlRequestAdmin(JNJModelAdmin):
    form = select2_modelform(models.ProductUrlRequest)
    list_display = (
        "product_url",
        "product__gtin",
        "link_type__name",
        "language__name",
        "url",
        "requested_by__username",
        "approved_by__username",
        "is_delete",
    )

    @display(ordering="product__gtin", description="gtin")
    def product__gtin(self, obj):
        return obj.product.gtin if obj.product else None

    @display(ordering="link_type__name", description="link_type")
    def link_type__name(self, obj):
        return obj.link_type.name

    @display(ordering="language__name", description="language")
    def language__name(self, obj):
        return obj.language.name

    @display(ordering="requested_by__username", description="request by username")
    def requested_by__username(self, obj):
        return obj.requested_by.username

    @display(ordering="approved_by__username", description="approved by username")
    def approved_by__username(self, obj):
        return obj.approved_by.username if obj.approved_by else None


@admin.register(models.ProductUrlChangeRequests)
class ProductUrlChangeRequestsAdmin(JNJModelAdmin):
    form = select2_modelform(models.ProductUrlChangeRequests)
    list_display = (
        "request__id",
        "request__product__gtin",
        "requested_by__username",
        "resolved_by__username",
    )

    @display(ordering="request__id", description="request id")
    def request__id(self, obj):
        return obj.request.id

    @display(ordering="request__product__gtin", description="gtin")
    def request__product__gtin(self, obj):
        return (
            obj.request.product.gtin
            if obj.request.product
            else obj.request.product_url.product.gtin
        )

    @display(ordering="requested_by__username", description="request by username")
    def requested_by__username(self, obj):
        return obj.requested_by.username

    @display(ordering="resolved_by__username", description="resolved by username")
    def resolved_by__username(self, obj):
        return obj.resolved_by.username if obj.resolved_by else None


@admin.register(models.AuditLog)
class AuditLogAdmin(JNJModelAdmin):
    form = select2_modelform(models.AuditLog)
    list_display = ("user__username", "action", "old_data", "new_data", "payload")

    @display(ordering="user__username", description="user username")
    def user__username(self, obj):
        return obj.user.username if obj.user else None
