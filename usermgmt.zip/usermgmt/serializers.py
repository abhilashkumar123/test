from rest_framework import serializers

from custom_drf_utilities import JNJModelSerializer
from model_helpers import GetLoggedInUser
from translatable_constants import CONSTANTS, Roles
from usermgmt.models import (
    AuditLog,
    Country,
    Entity,
    EntityProduct,
    EntityRole,
    Group,
    Language,
    LinkType,
    Product,
    ProductUrl,
    ProductUrlChangeRequests,
    ProductUrlRequest,
    User,
)


class AuditLogSerializer(JNJModelSerializer):
    class Meta:
        model = AuditLog
        fields = "__all__"


class LanguageSerializer(JNJModelSerializer):
    class Meta:
        model = Language
        fields = "__all__"


class GroupSerializer(JNJModelSerializer):
    class Meta:
        model = Group
        fields = ("id", "name")


class LinkTypeSerializer(JNJModelSerializer):
    class Meta:
        model = LinkType
        fields = "__all__"


class CountrySerializer(JNJModelSerializer):
    class Meta:
        model = Country
        fields = "__all__"


class UserSerializer(JNJModelSerializer):
    class Meta:
        model = User
        fields = ("id", "username", "first_name", "last_name", "email")


class ProductExportSerializer(JNJModelSerializer):
    action = serializers.SerializerMethodField(read_only=True)
    default_link_type = serializers.SerializerMethodField(read_only=True)
    default_language = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Product
        fields = (
            "action",
            "gtin",
            "product_description",
            "default_link_type",
            "default_language",
        )

    def get_action(self, obj):
        return "None"

    def get_default_link_type(self, obj):
        return obj.default_link_type.name if obj.default_link_type else None

    def get_default_language(self, obj):
        return obj.default_language.name if obj.default_language else None


class ProductSerializer(JNJModelSerializer):
    default_link_type = LinkTypeSerializer(read_only=True)
    default_language = LanguageSerializer(read_only=True)
    pending_requests = serializers.SerializerMethodField(read_only=True)
    approved_requests = serializers.SerializerMethodField(read_only=True)
    change_requests = serializers.SerializerMethodField(read_only=True)
    default_link_type_id = serializers.PrimaryKeyRelatedField(
        queryset=LinkType.objects.all(),
        write_only=True,
        required=True,
        source="default_link_type",
    )
    default_language_id = serializers.PrimaryKeyRelatedField(
        queryset=Language.objects.all(),
        write_only=True,
        required=True,
        source="default_language",
    )

    class Meta:
        model = Product
        fields = "__all__"

    def get_pending_requests(self, obj):
        return obj.pending_requests_count

    def get_approved_requests(self, obj):
        return obj.approved_requests_count

    def get_change_requests(self, obj):
        return obj.change_requests_count


class EntitySerializer(JNJModelSerializer):
    admin = serializers.SerializerMethodField(read_only=True)
    country_id = serializers.PrimaryKeyRelatedField(
        source="country",
        write_only=True,
        required=True,
        allow_null=False,
        queryset=Country.objects.all(),
    )
    country = CountrySerializer(read_only=True)
    product_ids = serializers.SlugRelatedField(
        slug_field="gtin",
        source="products",
        write_only=True,
        required=False,
        many=True,
        queryset=Product.objects.all(),
    )
    products = ProductSerializer(many=True, read_only=True)

    class Meta:
        model = Entity
        fields = "__all__"

    def get_admin(self, obj):
        admin = EntityRole.objects.filter(
            entity=obj, group__name=Roles.LEAdmin.value
        ).first()
        if admin:
            return UserSerializer(admin.user).data
        return None


class EntityProductSerializer(JNJModelSerializer):
    added_by_user = UserSerializer(read_only=True)
    product = ProductSerializer(read_only=True)
    entity = EntitySerializer(read_only=True)

    class Meta:
        model = EntityProduct
        fields = "__all__"


class AddEntitySerializer(EntitySerializer):
    principle_name = serializers.EmailField(
        required=True, allow_null=False, write_only=True
    )

    class Meta:
        model = Entity
        fields = "__all__"


class ManageEntityLinkTypes(serializers.Serializer):
    link_types = serializers.PrimaryKeyRelatedField(
        queryset=LinkType.objects.all(),
        write_only=True,
        many=True,
        required=True,
        allow_null=False,
    )


class EntityRoleSerializer(JNJModelSerializer):
    user = UserSerializer(read_only=True)
    user_id = serializers.PrimaryKeyRelatedField(
        source="user",
        write_only=True,
        required=True,
        allow_null=False,
        queryset=User.objects.all(),
    )
    created_by = UserSerializer(read_only=True)
    created_by_id = serializers.PrimaryKeyRelatedField(
        source="created_by",
        write_only=True,
        required=True,
        allow_null=False,
        queryset=User.objects.all(),
    )
    entity = EntitySerializer(read_only=True)
    entity_id = serializers.PrimaryKeyRelatedField(
        source="entity",
        write_only=True,
        required=True,
        allow_null=False,
        queryset=Entity.objects.all(),
    )
    group = GroupSerializer(read_only=True)
    group_name = serializers.SlugRelatedField(
        slug_field="name",
        source="group",
        write_only=True,
        required=True,
        allow_null=False,
        queryset=Group.objects.all(),
    )

    class Meta:
        model = EntityRole
        fields = "__all__"


class EntityQueryParamSerializer(serializers.Serializer):
    entity = serializers.PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), required=False, write_only=True
    )


class SearchUsersSerializer(serializers.Serializer):
    search = serializers.CharField(required=True, write_only=True, min_length=3)


class ProductUrlSerializer(JNJModelSerializer):
    product = ProductSerializer(read_only=True)
    link_type = LinkTypeSerializer(read_only=True)
    language = LanguageSerializer(read_only=True)
    is_default = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = ProductUrl
        fields = "__all__"

    def get_is_default(self, obj):
        return (
            True
            if obj.link_type == obj.product.default_link_type
            and obj.language == obj.product.default_language
            else False
        )


class ProductUrlRequestSerializer(JNJModelSerializer):
    product = ProductSerializer(read_only=True)
    product_id = serializers.PrimaryKeyRelatedField(
        queryset=Product.objects.all(),
        write_only=True,
        required=False,
        allow_null=True,
        source="product",
    )
    product_url = ProductUrlSerializer(read_only=True)
    product_url_id = serializers.PrimaryKeyRelatedField(
        queryset=Product.objects.all(),
        write_only=True,
        required=False,
        allow_null=True,
        source="product_url",
    )
    link_type = LinkTypeSerializer(read_only=True)
    link_type_id = serializers.PrimaryKeyRelatedField(
        queryset=LinkType.objects.all(),
        write_only=True,
        required=False,
        allow_null=True,
        source="link_type",
    )
    language = LanguageSerializer(read_only=True)
    language_id = serializers.PrimaryKeyRelatedField(
        queryset=Language.objects.all(),
        write_only=True,
        required=False,
        allow_null=True,
        source="language",
    )
    requested_by = UserSerializer(read_only=True)
    requested_by_id = serializers.HiddenField(
        default=GetLoggedInUser(), source="requested_by"
    )

    class Meta:
        model = ProductUrlRequest
        fields = "__all__"
        read_only_fields = ("approved_by",)


class UnApprovedProductUrlRequestReportSerializer(JNJModelSerializer):
    product = ProductSerializer(read_only=True)
    product_url = ProductUrlSerializer(read_only=True)
    link_type = LinkTypeSerializer(read_only=True)
    language = LanguageSerializer(read_only=True)
    requested_by = UserSerializer(read_only=True)
    action = serializers.SerializerMethodField()
    gtin = serializers.SerializerMethodField()
    has_change_requests = serializers.SerializerMethodField()

    class Meta:
        model = ProductUrlRequest
        fields = "__all__"

    def get_action(self, obj):
        if obj.product:
            return "Add"
        if obj.product_url:
            return "Delete" if obj.is_delete else "Update"

    def get_gtin(self, obj):
        return obj.product.gtin if obj.product else obj.product_url.product.gtin

    def get_has_change_requests(self, obj):
        return (
            "Yes"
            if obj.producturlchangerequests_set.filter(
                resolved_by__isnull=True
            ).exists()
            else "No"
        )


class ProductUrlChangeRequestsSerializer(JNJModelSerializer):
    request = ProductUrlRequestSerializer(read_only=True)
    request_id = serializers.PrimaryKeyRelatedField(
        queryset=ProductUrlRequest.objects.all(),
        write_only=True,
        required=True,
        allow_null=False,
        source="request",
    )
    requested_by = UserSerializer(read_only=True)
    requested_by_id = serializers.HiddenField(
        default=GetLoggedInUser(), source="requested_by"
    )

    class Meta:
        model = ProductUrlChangeRequests
        fields = "__all__"
        read_only_fields = ("resolved_by",)


class UserLoginSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=300, required=True)
    password = serializers.CharField(required=True, write_only=True)


class MSFTAuthCodeSerializer(serializers.Serializer):
    code = serializers.CharField(required=True, write_only=True)


class ExcelExportSerializer(JNJModelSerializer):
    action = serializers.SerializerMethodField(read_only=True)
    gtin = serializers.SerializerMethodField(read_only=True)
    batch_no = serializers.CharField(read_only=True)
    link_type = serializers.SerializerMethodField(read_only=True)
    language = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = ProductUrl
        fields = (
            "action",
            "gtin",
            "batch_no",
            "link_type",
            "url",
            "language",
            "link_title",
        )

    def get_gtin(self, obj):
        return obj.product.gtin

    def get_action(self, obj):
        return "None"

    def get_link_type(self, obj):
        return obj.link_type.name

    def get_language(self, obj):
        return obj.language.name


class DownloadExcelInputSerializer(serializers.Serializer):
    is_data_required = serializers.BooleanField(default=True, write_only=True)


class UploadExcelInputSerializer(serializers.Serializer):
    file = serializers.FileField(required=True, allow_empty_file=False)

    def validate_file(self, obj):
        if obj.name.split(".")[-1] not in ["xlsx", "xls", "xlsm"]:
            raise serializers.ValidationError(CONSTANTS["ONLY_EXCEL"])


class UploadExelRowSerializer(serializers.Serializer):
    action = serializers.ChoiceField(
        choices=["None", "Add", "Update", "Deactivate"], write_only=True, required=True
    )
    gtin = serializers.SlugRelatedField(
        queryset=Product.objects.all(),
        write_only=True,
        slug_field="gtin",
        required=True,
        error_messages={"does_not_exist": "Product with GTIN {value} does not exist."},
    )
    batch_no = serializers.CharField(
        min_length=1, max_length=28, allow_null=True, allow_blank=True
    )
    link_type = serializers.SlugRelatedField(
        queryset=LinkType.objects.all(),
        write_only=True,
        slug_field="name",
        required=True,
        error_messages={
            "does_not_exist": "Link Type with name {value} does not exist."
        },
    )
    language = serializers.SlugRelatedField(
        queryset=Language.objects.all(),
        write_only=True,
        slug_field="name",
        required=True,
        error_messages={"does_not_exist": "Language with name {value} does not exist."},
    )
    url = serializers.URLField(required=True, write_only=True)
    link_title = serializers.CharField(
        min_length=0, max_length=200, allow_null=True, allow_blank=True
    )


class UploadProductExelRowSerializer(serializers.Serializer):
    action = serializers.ChoiceField(
        choices=["None", "Add", "Update", "Deactivate"], write_only=True, required=True
    )
    gtin = serializers.CharField(
        min_length=8, max_length=14, allow_null=True, allow_blank=True
    )
    product_description = serializers.CharField(
        min_length=0, max_length=1000, allow_null=True, allow_blank=True
    )
    default_link_type = serializers.SlugRelatedField(
        queryset=LinkType.objects.all(),
        write_only=True,
        slug_field="name",
        required=False,
        error_messages={
            "does_not_exist": "Link Type with name {value} does not exist."
        },
        allow_null=True,
    )
    default_language = serializers.SlugRelatedField(
        queryset=Language.objects.all(),
        write_only=True,
        slug_field="name",
        required=False,
        error_messages={"does_not_exist": "Language with name {value} does not exist."},
        allow_null=True,
    )
