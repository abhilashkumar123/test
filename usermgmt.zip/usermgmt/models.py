from django.contrib.auth.models import AbstractUser, Group
from django.db import models, transaction
from django.db.models import Count, Q
from django.db.models.signals import m2m_changed
from django_tools.middlewares import ThreadLocal
from rest_framework.validators import ValidationError

from django_utilities import JNJBaseModel
from gs1_helpers import ValidateGtin
from translatable_constants import CONSTANTS, Roles


class User(AbstractUser, JNJBaseModel):
    @property
    def fullname(self):
        return self.get_full_name() or self.email


class Language(JNJBaseModel):
    name = models.CharField(max_length=64, unique=True)
    iso_639_1_code = models.CharField(max_length=32, unique=True)
    iso_639_2_code = models.CharField(max_length=32, unique=True)

    def __str__(self):
        return f"{self.name}-{self.iso_639_1_code}-{self.iso_639_2_code}"


class Country(JNJBaseModel):
    name = models.CharField(max_length=32, unique=True)

    def __str__(self):
        return "{}".format(self.name)


class LinkType(JNJBaseModel):
    name = models.CharField(max_length=64, unique=True)
    tag = models.CharField(max_length=64, unique=True)
    description = models.TextField()
    voc_link = models.URLField(unique=True)

    def __str__(self):
        return "{}".format(self.name)


class Product(JNJBaseModel):
    gtin = models.CharField(max_length=14, unique=True)
    product_description = models.TextField()
    default_link_type = models.ForeignKey(
        LinkType,
        null=True,
        blank=True,
        on_delete=models.PROTECT,
        related_name="default_link_type",
    )
    default_language = models.ForeignKey(
        Language,
        null=True,
        blank=True,
        on_delete=models.PROTECT,
        related_name="default_language",
    )

    def __str__(self):
        return f"{self.gtin}"

    def clean(self):
        if self.gtin:
            if not ValidateGtin(self.gtin).validate():
                raise ValidationError(CONSTANTS["INVALID_GTIN"])
            if (
                Product.objects.filter(gtin__endswith=self.gtin.lstrip("0"))
                .exclude(id=self.id)
                .exists()
            ):
                raise ValidationError(CONSTANTS["UNIQUE_GTIN"])

    def delete_product(self):
        product_urls_to_delete = ProductUrl.objects.filter(product=self)
        product_url_requets_to_delete = ProductUrlRequest.objects.filter(
            Q(product=self) | Q(product_url__in=product_urls_to_delete)
        )
        ProductUrlChangeRequests.objects.filter(
            request__in=product_url_requets_to_delete
        ).delete()
        product_url_requets_to_delete.delete()
        product_urls_to_delete.delete()
        self.delete()

    @classmethod
    def on_pre_save(self, instance, created, *args, **kwargs):
        if not created:
            old_object = Product.objects.get(pk=instance.pk)
            instance.old_data = {
                "name": old_object.gtin,
                "product_description": old_object.product_description,
                "default_link_type": old_object.default_link_type.name,
                "default_language": old_object.default_language.name,
            }

    @classmethod
    def on_post_save(self, instance, created, *args, **kwargs):
        request = ThreadLocal.get_current_request()
        new_data = {
            "name": instance.gtin,
            "product_description": instance.product_description,
            "default_link_type": instance.default_link_type.name,
            "default_language": instance.default_language.name,
        }
        if created:
            AuditLog.objects.create(
                new_data=new_data, user=request.user, action="created_product"
            )
        else:
            AuditLog.objects.create(
                new_data=new_data,
                old_data=instance.old_data,
                user=request.user,
                action="updated_product",
            )

    @classmethod
    def on_post_delete(self, instance, **kwargs):
        request = ThreadLocal.get_current_request()
        new_data = {
            "name": instance.gtin,
            "product_description": instance.product_description,
            "default_link_type": instance.default_link_type.name,
            "default_language": instance.default_language.name,
        }
        AuditLog.objects.create(
            user=request.user, action="product_deleted", new_data=new_data
        )

    @property
    def approved_requests_count(self):
        return ProductUrl.objects.filter(product=self).count()

    @property
    def pending_requests_count(self):
        return (
            ProductUrlRequest.objects.filter(
                (
                    (Q(product=self) | Q(product_url__product=self))
                    & Q(approved_by__isnull=True)
                    & (Q(producturlchangerequests__isnull=True) | ~Q(producturlchangerequests__resolved_by__isnull=True))
                )
            )
            .distinct()
            .count()
        )

    @property
    def change_requests_count(self):
        return (
            ProductUrlRequest.objects.filter(
                (
                    (Q(product=self) | Q(product_url__product=self))
                    & Q(approved_by__isnull=True)
                    & Q(producturlchangerequests__isnull=False)
                    & Q(producturlchangerequests__resolved_by__isnull=True)
                )
            )
            .distinct()
            .count()
        )


class Entity(JNJBaseModel):
    name = models.CharField(max_length=32)
    country = models.ForeignKey(Country, on_delete=models.PROTECT)
    products = models.ManyToManyField(
        Product, related_name="products", blank=True, through="EntityProduct"
    )

    def __str__(self):
        return f"{self.name}"

    @classmethod
    def m2m_changed(cls, sender, instance, action, reverse, pk_set, **kwargs):
        request = ThreadLocal.get_current_request()
        if action == "post_add" and pk_set:
            EntityProduct.objects.filter(entity=instance.id, product__in=pk_set).update(
                added_by_user=request.user
            )
            added_products = Product.objects.filter(id__in=pk_set)
            new_data = {
                "gtins_added": list(added_products.values_list("gtin", flat=True)),
                "entity_name": instance.name,
            }
            AuditLog.objects.create(
                new_data=new_data, user=request.user, action="add_entity_products"
            )
        if action == "post_remove" and pk_set:
            deleted_products = Product.objects.filter(id__in=pk_set)
            new_data = {
                "gtins_delete": list(deleted_products.values_list("gtin", flat=True)),
                "entity_name": instance.name,
            }
            AuditLog.objects.create(
                new_data=new_data, user=request.user, action="deactivate_entity_products"
            )
            products_to_delete = Product.objects.filter(id__in=pk_set)
            with transaction.atomic():
                for product_to_delete in products_to_delete.iterator():
                    if (
                        Entity.objects.filter(products=product_to_delete)
                        .exclude(id=instance.id)
                        .count()
                        == 0
                    ):
                        product_to_delete.delete_product()

    class Meta:
        unique_together = ("name", "country")

    def delete_entity(self):
        products_to_delete = self.products.annotate(
            entity_count=Count("products")
        ).filter(entity_count=1)
        product_urls_to_delete = ProductUrl.objects.filter(
            product__in=products_to_delete
        )
        product_url_requests_to_delete = ProductUrlRequest.objects.filter(
            Q(product__in=products_to_delete)
            | Q(product_url__in=product_urls_to_delete)
        )
        ProductUrlChangeRequests.objects.filter(
            request__in=product_url_requests_to_delete
        ).delete()
        product_url_requests_to_delete.delete()
        product_urls_to_delete.delete()
        products_to_delete.delete()
        EntityRole.objects.filter(entity=self).delete()
        self.delete()

    @classmethod
    def on_pre_save(self, instance, created, *args, **kwargs):
        if not created:
            old_object = Entity.objects.get(id=instance.id)
            instance.old_data = {
                "name": old_object.name,
                "country": old_object.country.name,
            }

    @classmethod
    def on_post_save(cls, instance, created, *args, **kwargs):
        request = ThreadLocal.get_current_request()
        new_data = {"name": instance.name, "country": instance.country.name}
        if created:
            AuditLog.objects.create(
                new_data=new_data, user=request.user, action="created_entity"
            )
        elif instance.old_data != new_data:
            AuditLog.objects.create(
                new_data=new_data,
                old_data=instance.old_data,
                user=request.user,
                action="updated_entity",
            )

    @classmethod
    def on_post_delete(self, instance, **kwargs):
        request = ThreadLocal.get_current_request()
        data = {
            "entity": instance.name,
            "group": instance.country.name,
            "user": list(instance.products.values_list("gtin", flat=True)),
        }
        AuditLog.objects.create(
            user=request.user, action="entity_deleted", new_data=data
        )


class EntityProduct(JNJBaseModel):
    added_by_user = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="entity_product_added_user",
    )
    entity = models.ForeignKey(Entity, on_delete=models.PROTECT)
    product = models.ForeignKey(Product, on_delete=models.PROTECT)

    def __str__(self):
        return f"{self.entity.name}-{self.product.gtin}"

    def clean(self):
        request = ThreadLocal.get_current_request()
        if not self.added_by_user:
            self.added_by_user = request.user


class EntityRole(JNJBaseModel):
    user = models.ForeignKey(User, on_delete=models.PROTECT, related_name="user")
    entity = models.ForeignKey(Entity, on_delete=models.PROTECT)
    group = models.ForeignKey(Group, on_delete=models.PROTECT)
    created_by = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name="created_by_user",
        null=True,
        blank=True,
    )

    class Meta:
        unique_together = ("user", "entity", "group")

    def clean(self):
        if self.group.name == Roles.SuperAdmin.value:
            raise ValidationError(CONSTANTS["CANNOT_ADD_SUPERADMIN_ENTITY"])

    @classmethod
    def on_post_save(self, instance, created, *args, **kwargs):
        request = ThreadLocal.get_current_request()
        data = {
            "entity": instance.entity.name,
            "group": instance.group.name,
            "user": instance.user.fullname,
        }
        if instance.group.name == Roles.LEAdmin.value:
            AuditLog.objects.create(
                user=request.user, action="leadmin_role_added", new_data=data
            )
        if instance.group.name == Roles.DataEntry.value:
            AuditLog.objects.create(
                user=request.user, action="dataentry_role_added", new_data=data
            )
        if instance.group.name == Roles.Approver.value:
            AuditLog.objects.create(
                user=request.user, action="approver_role_added", new_data=data
            )

    @classmethod
    def on_post_delete(self, instance, **kwargs):
        request = ThreadLocal.get_current_request()
        data = {
            "entity": instance.entity.name,
            "group": instance.group.name,
            "user": instance.user.fullname,
        }
        if instance.group.name == Roles.LEAdmin.value:
            AuditLog.objects.create(
                user=request.user, action="leadmin_role_deleted", new_data=data
            )
        if instance.group.name == Roles.DataEntry.value:
            AuditLog.objects.create(
                user=request.user, action="dataentry_role_deleted", new_data=data
            )
        if instance.group.name == Roles.Approver.value:
            AuditLog.objects.create(
                user=request.user, action="approver_role_deleted", new_data=data
            )


class ProductUrl(JNJBaseModel):
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    link_type = models.ForeignKey(LinkType, on_delete=models.PROTECT)
    language = models.ForeignKey(Language, on_delete=models.PROTECT)
    url = models.URLField()
    link_title = models.TextField(null=True, blank=True)
    # todo: remove this post deployment. very bad code.
    allowed_batch_numbers = models.TextField(null=True, blank=True)
    allowed_serial_numbers = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"{self.product.gtin}-{self.link_type.name}-{self.language.name}"

    def clean(self):
        if (
            ProductUrl.objects.filter(
                language=self.language,
                link_type=self.link_type,
                product=self.product_id,
            )
            .exclude(id=self.id)
            .exists()
        ):
            raise ValidationError(CONSTANTS["ONLY_LINK_PER_PRODUCT_LANGUAGE"])

    def delete_product_url(self):
        product_url_requests_to_delete = ProductUrlRequest.objects.filter(
            Q(product_url=self)
            | Q(product=self.product, link_type=self.link_type, language=self.language)
        )
        product_url_change_requests_to_delete = ProductUrlChangeRequests.objects.filter(
            request__in=product_url_requests_to_delete
        )
        if product_url_change_requests_to_delete.exists():
            product_url_change_requests_to_delete.delete()
        if product_url_requests_to_delete.exists():
            product_url_requests_to_delete.delete()
        self.delete()

    def on_pre_save(cls, instance, created, *args, **kwargs):
        if not created:
            old_object = ProductUrl.objects.get(id=instance.pk)
            instance.old_data = {
                "gtin": old_object.product.gtin,
                "link_type": old_object.link_type.name,
                "language": old_object.language.name,
                "url": old_object.url,
                "link_title": old_object.link_title,
                "allowed_batch_numbers": old_object.allowed_batch_numbers,
                "allowed_serial_numbers": old_object.allowed_serial_numbers
            }
            
    @classmethod
    def on_post_save(self, instance, created, *args, **kwargs):
        request = ThreadLocal.get_current_request()
        data = {
            "gtin": instance.product.gtin,
            "link_type": instance.link_type.name,
            "language": instance.language.name,
            "url": instance.url,
            "link_title": instance.link_title,
            "allowed_batch_numbers": instance.allowed_batch_numbers,
            "allowed_serial_numbers": instance.allowed_serial_numbers
        }

        if created:
            AuditLog.objects.create(
                user=request.user, action="product_url_created", new_data=data
            )
        else:
            AuditLog.objects.create(
                user=request.user, action="product_url_updated", new_data=data, old_data=instance.old_data
            )

    @classmethod
    def on_post_delete(self, instance, **kwargs):
        request = ThreadLocal.get_current_request()
        data = {
            "gtin": instance.product.gtin,
            "link_type": instance.link_type.name,
            "language": instance.language.name,
            "url": instance.url,
            "link_title": instance.link_title,
            "allowed_batch_numbers": instance.allowed_batch_numbers,
            "allowed_serial_numbers": instance.allowed_serial_numbers
        }
        AuditLog.objects.create(
            user=request.user, action="product_url_deleted", new_data=data
        )


class ProductUrlRequest(JNJBaseModel):
    product_url = models.ForeignKey(
        ProductUrl, on_delete=models.PROTECT, null=True, blank=True
    )
    product = models.ForeignKey(
        Product, on_delete=models.PROTECT, null=True, blank=True
    )
    link_type = models.ForeignKey(LinkType, on_delete=models.PROTECT)
    language = models.ForeignKey(Language, on_delete=models.PROTECT)
    url = models.URLField()
    is_delete = models.BooleanField(default=False)
    requested_by = models.ForeignKey(
        User, on_delete=models.PROTECT, related_name="requested_by"
    )
    approved_by = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name="approved_by",
        null=True,
        blank=True,
    )
    link_title = models.TextField(null=True, blank=True)
    # todo: remove this post deployment. very bad code.
    allowed_batch_numbers = models.TextField(null=True, blank=True)
    allowed_serial_numbers = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"{self.product.gtin if self.product else self.product_url.product.gtin} - {self.language.name} - {self.link_type.name}"

    @classmethod
    def on_pre_save(self, instance, created, *args, **kwargs):
        if not created:
            old_object = ProductUrlRequest.objects.get(pk=instance.pk)
            instance.old_data = {
                "name": old_object.gtin,
                "link_type": old_object.link_type.name,
                "language": old_object.language.name,
                "allowed_batch_numbers": old_object.allowed_batch_numbers,
                "allowed_serial_numbers": old_object.allowed_serial_numbers,
                "url": old_object.url,
            }
    @classmethod
    def on_post_save(self, instance, created, *args, **kwargs):
        request = ThreadLocal.get_current_request()
        new_data = {
            "product": instance.product.gtin
            if instance.product
            else instance.product_url.product.gtin,
            "link_type": instance.link_type.name,
            "language": instance.language.name,
            "allowed_batch_numbers": instance.allowed_batch_numbers,
            "allowed_serial_numbers": instance.allowed_serial_numbers,
            "url": instance.url,
        }
        try:
            if instance.approved_by:
                if instance.is_delete:
                    AuditLog.objects.create(
                        new_data=new_data,
                        old_data=instance.old_data,
                        user=request.user,
                        action="approved_deactivate_product_url_request",
                    )
                    try:
                        instance.product_url.delete_product_url()
                    except Exception:
                        instance.product_url.delete()
                else:
                    if instance.product_url:
                        AuditLog.objects.create(
                            new_data=new_data,
                            old_data=instance.old_data,
                            user=request.user,
                            action="approved_update_product_url_request",
                        )
                    elif instance.product:
                        AuditLog.objects.create(
                            new_data=new_data,
                            old_data=instance.old_data,
                            user=request.user,
                            action="approved_create_product_url_request",
                        )
                        
            else:
                old_url_data = {
                    "product": instance.product.gtin
                    if instance.product
                    else instance.product_url.product.gtin,
                    "link_type": instance.link_type.name,
                    "language": instance.language.name,
                    "allowed_batch_numbers": instance.allowed_batch_numbers,
                    "allowed_serial_numbers": instance.allowed_serial_numbers,
                    "url": instance.url,
                }
                if instance.is_delete:
                    AuditLog.objects.create(
                        new_data=new_data,
                        old_data=old_url_data,
                        user=request.user,
                        action="deactivate_product_url_request",
                    )
                else:
                    AuditLog.objects.create(
                        new_data=new_data,
                        old_data=instance.old_data,
                        user=request.user,
                        action="update_product_url_request",
                    )
        except Exception:
            if instance.product_url:
                old_data = {
                    "product": instance.product_url.product.gtin,
                    "link_type": instance.product_url.link_type.name,
                    "language": instance.product_url.language.name,
                    "allowed_batch_numbers": instance.product_url.allowed_batch_numbers,
                    "allowed_serial_numbers": instance.product_url.allowed_serial_numbers,
                    "url": instance.product_url.url,
                }
                AuditLog.objects.create(
                    new_data=new_data,
                    old_data=old_data,
                    user=request.user,
                    action="update_product_url_request",
                )
            elif created:
                AuditLog.objects.create(
                    new_data=new_data,
                    user=request.user,
                    action="new_product_url_request",
                )

    @classmethod
    def on_pre_save(cls, instance, created, *args, **kwargs):
        if instance.id:
            old_instance = ProductUrlRequest.objects.filter(id=instance.id).first()
            instance.old_data = {
                "product": old_instance.product.gtin
                if old_instance.product
                else old_instance.product_url.product.gtin,
                "link_type": old_instance.link_type.name,
                "language": old_instance.language.name,
                "allowed_batch_numbers": old_instance.allowed_batch_numbers,
                "allowed_serial_numbers": old_instance.allowed_serial_numbers,
                "url": old_instance.url,
            }
            if old_instance.approved_by:
                raise ValidationError(
                    CONSTANTS["CANNOT_UPDATE_APPROVER_AFTER_RESOLVED"]
                )
            else:
                if instance.approved_by:
                    if instance.product_url or instance.is_delete:
                        product_url = ProductUrl.objects.get(id=instance.product_url.id)
                        if not instance.is_delete:
                            product_url.link_type = instance.link_type
                            product_url.language = instance.language
                            product_url.url = instance.url
                            product_url.allowed_batch_numbers = (
                                instance.allowed_batch_numbers
                            )
                            product_url.link_title = instance.link_title
                            product_url.save()
                    if instance.product:
                        ProductUrl.objects.create(
                            link_type=instance.link_type,
                            language=instance.language,
                            url=instance.url,
                            product=instance.product,
                            allowed_batch_numbers=instance.allowed_batch_numbers,
                            allowed_serial_numbers=instance.allowed_serial_numbers,
                            link_title=instance.link_title,
                        )
                else:
                    ProductUrlChangeRequests.objects.filter(
                        request_id=instance.id
                    ).update(resolved_by=instance.requested_by)

    def save(
        self, force_insert=False, force_update=False, using=None, update_fields=None
    ):
        if self.pk:
            old_instance = ProductUrlRequest.objects.filter(id=self.pk).first()
            if old_instance.approved_by:
                raise ValidationError(
                    CONSTANTS["CANNOT_UPDATE_APPROVER_AFTER_RESOLVED"]
                )
        super(ProductUrlRequest, self).save()

    def clean(self):
        if self.requested_by and self.requested_by == self.approved_by:
            raise ValidationError(CONSTANTS["CANNOT_APPROVE_OWN_REQUEST"])
        if self.is_delete and not self.product_url:
            raise ValidationError(CONSTANTS["PRODUCT_URL_MANDATORY_TO_DELETE"])
        if not self.product_url and not self.product:
            raise ValidationError(CONSTANTS["URL_UPDATE_REQUEST_FIELDS_MANDATORY"])
        if self.product and self.product_url:
            raise ValidationError(CONSTANTS["INVALID_CHANGE_REQUEST"])
        product_gtin = (
            self.product.gtin if self.product else self.product_url.product.gtin
        )
        if self.product:
            if ProductUrl.objects.filter(
                language=self.language,
                link_type=self.link_type,
                product__gtin=product_gtin,
            ).exists():
                raise ValidationError(CONSTANTS["INVALID_CHANGE_REQUEST"])
        if (
            ProductUrlRequest.objects.filter(
                (
                    Q(product__gtin=product_gtin)
                    | Q(product_url__product__gtin=product_gtin)
                )
                & Q(language=self.language)
                & Q(link_type=self.link_type)
                & Q(approved_by__isnull=True)
            )
            .exclude(id=self.pk)
            .exists()
        ):
            raise ValidationError(CONSTANTS["PRODUCT_TWO_CHANGE_REQUESTS"])
        if self.approved_by:
            check_access = Q(user=self.approved_by, group__name=Roles.Approver.value)
            if self.product:
                check_access = check_access & Q(entity__products__in=[self.product_id])
            else:
                check_access = check_access & Q(
                    entity__products__in=[self.product_url.product_id]
                )
            if not EntityRole.objects.filter(check_access).exists():
                raise ValidationError(CONSTANTS["CANNOT_APPROVE_URL"])
            if self.producturlchangerequests_set.filter(
                resolved_by__isnull=True
            ).exists():
                raise ValidationError(CONSTANTS["CANNOT_APPROVE_UNTIL_ALL_RESOLVED"])
        if self.requested_by:
            check_access = Q(user=self.requested_by, group__name=Roles.DataEntry.value)
            if self.product:
                check_access = check_access & Q(entity__products__in=[self.product_id])
            else:
                check_access = check_access & Q(
                    entity__products__in=[self.product_url.product_id]
                )
            if not EntityRole.objects.filter(check_access).exists():
                raise ValidationError(CONSTANTS["CANNOT_REQUEST_URL"])


class ProductUrlChangeRequests(JNJBaseModel):
    request = models.ForeignKey(ProductUrlRequest, on_delete=models.PROTECT)
    comment = models.TextField()
    requested_by = models.ForeignKey(
        User, on_delete=models.PROTECT, related_name="change_request_requested_by"
    )
    resolved_by = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name="change_request_resolved_by",
        null=True,
        blank=True,
    )

    def save(
        self, force_insert=False, force_update=False, using=None, update_fields=None
    ):
        if self.pk:
            old_instance = ProductUrlChangeRequests.objects.filter(id=self.pk).first()
            if old_instance and old_instance.resolved_by:
                raise ValidationError(
                    CONSTANTS["CANNOT_UPDATE_APPROVER_AFTER_RESOLVED"]
                )
        super(ProductUrlChangeRequests, self).save()

    def clean(self):
        if self.request.approved_by and (not self.pk or not self.resolved_by):
            raise ValidationError(
                CONSTANTS["CANNOT_ADD_CHANGE_REQUESTS_AFTER_APPROVAL"]
            )

    @classmethod
    def on_pre_save(cls, instance, created, *args, **kwargs):
        if not created:
            old_object = ProductUrlChangeRequests.objects.get(id=instance.pk)
            instance.old_data = {
                "url": old_object.request.__str__(),
                "comment": old_object.comment
            }

    @classmethod
    def on_post_save(cls, instance, created, *args, **kwargs):
        request = ThreadLocal.get_current_request()
        new_data = {"url": instance.request.__str__(), "comment": instance.comment}
        if created:
            AuditLog.objects.create(
                new_data=new_data, user=request.user, action="added_product_url_change_request"
            )
        else:
            AuditLog.objects.create(
                new_data=new_data,
                old_data=instance.old_data,
                user=request.user,
                action="updated_product_url_change_request",
            )


class UserOAuthToken(JNJBaseModel):
    access_token = models.TextField()
    access_token_hash = models.CharField(unique=True, max_length=256)
    refresh_token = models.TextField()
    user = models.ForeignKey(User, on_delete=models.CASCADE)


class AuditLog(JNJBaseModel):
    """
    Actions:
    User Logged In
    Download Product Data
    Upload Product Data
    Download URL Data
    Upload URL Data

    Model Level Changes Log:
    EntityRole
    Entity
    Product
    ProductUrlRequest
    ProductURLChangeRequest : Comments
    """

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    action = models.CharField(max_length=256)
    old_data = models.JSONField(null=True, blank=True)
    new_data = models.JSONField(null=True, blank=True)
    payload = models.JSONField(null=True, blank=True)


m2m_changed.connect(Entity.m2m_changed, sender=Entity.products.through)
