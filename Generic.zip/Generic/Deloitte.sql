/* Kolkata Office Address :-  */
Bengal Intelligent Park, Building Omega
13th , 14th Block - EP & GP
Sector - V, Salt Lake
Electronics Complex
West Bengal
700091

Deloitte Shared Services India LLP, Bengal Intelligent Park, 
OMEGA, 13th & 14th Floor, EP Block, Sector V, 
Bidhannagar, Kolkata, West Bengal 700091

/* Main Address */
6th & 7th Floor.
Plot No 4 Technopolis Sector 5, Salt Lake
Kolkata 700091, West bengal

/* ITS */
PS Arcadia
9th Floor, 4A, Abanindra Nath
Thakur Sarani,
Kolkata 700 016,
West Bengal



https://mytechnology.deloitte.com/


abhilaskumar@deloitte.com
jjethani@deloitte.com

amemail.deloitte.com
usindianhpd@deloitte.com
KRITINUT :- Share
Please charge 8 hours for Tuesday, 
December 14, 2021 to “CEDXXXXX-01-01-01-0000 CONTINUING EDUCATION”. 
Replace the XXXXX with the last five digits of the Cost Center number 
found on your DTE homepage. Please refer to the attached document for further assistance.

-----------------------------------------------------------------------------------------
/* 28th Sept 4:30 PM */
/* Zumba – Movement for Health (04.30 PM - 5.30 PM IST, 28th Sep 2022) */

https://deloitte.zoom.us/w/93900737339?tk=K9JVIvR_wKflhbES8RsWA7T6OIWZDKSsBAY8NgkR6vE.DQMAAAAV3OuLOxZxdFRpdzBveFI4YThtUXV0RTFsdHFBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA&pwd=bTJPU00va2hoeWJiU0g5SzlMSVdQUT09&uuid=WN_sW6QeENXS5SxzvLjv_h6sA




-----------------------------------------------------------------------------------------
/* Password Reset :- */
https://passwordreset.microsoftonline.com/

-----------------------------------------------------------------------------------------
/* Location Change :- */
[‎29-‎Mar-‎22 6:31 PM]  Jethani, Jyoti Pradeep:  
Militha Mondol :- For Location Change
 
[‎29-‎Mar-‎22 6:31 PM]  Jethani, Jyoti Pradeep:  
engagement specialist :- Rizwana Haji for project change
 
-----------------------------------------------------------------------------------------
/* Charge Code */
USI SamrtPhone :- GAA57983-01-01-01-0000
-----------------------------------------------------------------------------------------
/* MFA */
C:\Users\abhilaskumar\Desktop\Abhilash\Generic\MFA_Reconfigure_Scenarios.pdf
-----------------------------------------------------------------------------------------
/* Coach */
Your coach is Krishnamohan Joshi - JKRISHNAMOHAN@DELOITTE.COM
-----------------------------------------------------------------------------------------
/* Personal Information */
Personnel Number:00682281
Company Code:1202
Cost Center:120257224  >>> 120257983 (New)

reply all
abhilaskumar@deloitte.com
abhilaskumar@deloitte.com
Nawadih123
Nawadih321
Nawadih1234 > Latest
Kum500082TS
Person ID: 00682281 
Personnel number: 00682281
Employee Id :-  682281
Cost Center :- 0120257224 >>> 120257983 (New)
Company Code :- 1202
Senior Consultant
Senior Consultant TMC ETI USI Hyd  >>> OLD
Senior Consultant TMC Dev USI Hyd  >>> NEW


ABHILASH KUMAR
Email: abhilaskumar@deloitte.com
Business: Tax and Legal
Business_Area: Tax and Legal
Business_Line: TMC Enterprise Tax Integration
Country: United States
Level: Senior
Office: Hyderabad



CED57224-01-01-01-0000
Senior Consultant SQL Server
TMC Dev :- 
TMC Dev USI Hyd Hyderabad
Coach Name :- 



My Manager
Jen Deutsch

ORGANIZATIONAL INFORMATION :- 
Legal entity: Deloitte TAX India Pvt Lt 
Business area: Tax Management Consulting Business 
line: TMC Enterprise Tax Integration
Industry: NT - Not Designated Practice 
area: TMC - TMC Development myInsight CE Dev

CONTACTS :- 
Coach :- Krishnamohan Joshi
Resource manager :- Jahnavi Billa Jahnavi


RM >>> asmita nayak 
Send email 
cc :- janvi

add skill set

1) TOD :- CE Excellence Page >>> Complete this
REach to buddy for help

2) Which project is allocated send mail to Mohan >>

3) Tuesday 11:00 am to 11:30 2nd tuesday every month zoom call

4) Complete mandatory training

4) Update mysource :- Monday :- Must
5) DTE :- Every Friday :- Must

6) Add certification details

7) 

Hi Asmita,

This is Abhilash Kumar and I have joined Deloitte last month on 6th Dec 2021.
But till now I have not been allocated into any project.
Employee Id :-  682281
Skills Set :- Azure, Azure Data Factory, Azure Databricks using Python, Azure SQL
Database :- Azure SQL Server, Oracle, Teradata
Language :- PL/SQL,Python DB dev, SQL, Unix Shell Scripting

Could you please tag me any project as per my skill set.

Thanks & Regards,
Abhilash Kumar

but your skills are not per the ETI group..... 
ETI group mostly has SAP & Oracle projects
CSG group has Python Azure etc projects


-----------------------------------------------------------------------------------------
/* Amex Card */
/* American Express Card */
Your new Card is expected to arrive by Tuesday, 15 February, 2022
Carrier:- Blue Dart
Shipping to:- 815301,
Tuesday, 15 February


Application ID: IN-1100221009
682281
Phone :
040 71253600
SR CONSULTANT
00/02
L AND T INFOTECH
HYDERABAD
SR DATA ENG
040 22618181

Abhilash Kumar
Power House Chowk
Barganda
Giridih
815301
In Front Of Rana Furniture
Ashok Kumar
Ashok Kumar Baishkhiyar

https://www.americanexpressindia.co.in/apps/ckyc/afc.html
Thank you.
We have recorded your input related to the additional KYC details. There is no further action required from you at this point.
For further queries, please contact us at : Toll Free - 18001801188, Landline Number - 0124-2801188, Mon - Sun, 9 AM - 9 PM IST

Thank you! Your digital application has been submitted. 
Your Application ID is: IN-1100221009
abhilaskumar@deloitte.com

/* Office Address */
HYDERABAD-BLOCK D
4TH FL RMZ FUTURA BLOCK D, PLOT NO.14&15 ROAD NO.2, HITEC CITY LAYOUT, MADHAPUR, HYDERABAD, 500081, India

Hi Team,

I checked my entire mail including spam/junk folder but I didn’t find any link
where I can update/edit the application.

Kindly send the link through I can update the address or
Please update below address for my application.

/* Office Address */
HYDERABAD-BLOCK D
4TH FL RMZ FUTURA BLOCK D, PLOT NO.14&15 ROAD NO.2, HITEC CITY LAYOUT, MADHAPUR, HYDERABAD, 500081, India

Thanks,
Abhilash Kumar



-----------------------------------------------------------------------------------------
/* USI Smartphone Programme */
Samsung Galaxy S20 FE 5G 	:- ₹ 37,199
Samsung Galaxy A52s 5G 		:- ₹ 34,223
Samsung Galaxy M52 5G 		:- ₹ 31,359
Samsung Galaxy A52 			:- ₹ 26,465
Samsung Galaxy M42 5G 		:- ₹ 23,519
Samsung Galaxy M32 5G 		:- ₹ 22,539
Samsung Galaxy M51 			:- ₹ 21,999
Samsung Galaxy A32 			:- ₹ 20,077
Samsung Galaxy F42 5G 		:- ₹ 19,599
Samsung Galaxy M32 			:- ₹ 16,659
Samsung Galaxy A22 			:- ₹ 16,882



Samsung Galaxy A52s 5G 		:- ₹ 34,223 :- 4500 mah, 189gm, 6.5 Inch, Android 11, One UI 3.1,
Qualcomm SM7325 Snapdragon 778G 5G (6 nm), Shared Slot, 128GB 8GB RAM/256GB 8GB RAM
64 + 12 + 5 + 5 :- Rear Camera
32 :- Front Camera

/* Times Prime Membership */
7979...


/* PLAN DETAILS */

Name of the Purchaser:Abhilash Kumar
Mobile Number:+91 7979919363
Plan Purchased:Servify Protect for Samsung Devices
Plan Purchase Date:15 Feb 2022
Device Purchase Date:15 Feb 2022
Device Model:Galaxy M52 5G
IMEI 1:358205230381470
IMEI 2:358658170381472
PLAN COVERAGE DETAILS

ADLD:
Device is covered for - 12 MONTHS
Coverage Start Date - 15 Feb 2022
Coverage Ends Midnight - 14 Feb 2023

Mail Subject line :- [EXT] Your plan is now activated - Servify Protect for Samsung Devices

For Service on Phone :- https://me.servify.in/login



-------------------------------------------------------------------------------------------
/* Name Change :-  */
Hope you’re doing well.
Your new legal name has been successfully updated in the system as requested i.e., 
last name, First name(KUMAR, ABHILASH).

Once the SAP is updated, the changes will reflect after 5 -7 business days in 
other applications such as TOD, DTE and DPN etc. If the changes are not reflecting or 
for changes in Skype/Outlook/Preferred name/Display name, please contact the
 Technology Call Center for further assistance.

We are closing the ticket, please contact Hrcompliance@deloitte.com if you have any queries.



If you have specific questions related to independence, please reach out to complianceonboarding@deloitte.com to discuss your situation with an independence advisor.
Contact us at usdstart@deloitte.com or Deloitte Call Center at 1800 2582 2222.

Hi Team,

Still My name has not been updated in payroll section.
Due to which wrong name is getting printed in salry slip.
Please update this section too.

Please find the attached screenshot.
File NAme :- PAyroll_Wrong_Name

Thanks,
Abhilash Kumar




-------------------------------------------------------------------------------------------



If your Deloitte device is lost or stolen, immediately call 1800 2582 2222 or via live chat.


Info Excelity is now Info Ceridian! 
Please write to Info info@ceridian.com for queries on IPSF, LTA & HR Workways.


Not Able to update PAN, Aadhar and UAN number
Hi Team,

I am trying to update PAN, Aadhar and UAN number in https://ess.excelityglobal.com/ProcessServletSSO
portal.But it is not allowing me to do.It is not editable.
Could you please help me on this.

Thanks,
Abhilash Kumar







Skills Profile can be accessed through your ToD homepage. 
Navigate to My Information 
--> Qualifications & Expertise --> Skills. 
A VPN connection is required to access Skills Profile when working remotely.






Welcome, Abhilash Kumar Abhilash Kumar Personnel 
Number: 00682281 Company Code: 1202 Cost Center: 0120257224	>>> 120257983

nAME cHANGE :- 
Your request has been received with the request number: 11244713 
and will be dealt within 2 business days.


/* bANK iSSUE */
If you are having issues editing an account, contact the 
CallCenter at +1 800 DELOITTE (+1 800 335 6488).

/* Send email to general query */
usiobaassignments@deloitte.com [undefined:usiobaassignments@deloitte.com]








Hi Team,

Please find the attached New_Hire Document.
I have digitally signed in the document wherever it was required.
As I have not recieved my Relieving letter yet, So will share on or before 6th Feb.
Couldn't attach my photo in New_Hire Document, so sending it here as an attachment.
Kindly let me know if anything is missing.

Thanks,
Abhilash Kumar
'

Hi Lisa,

I tried my best to give below answers.
1) A fun fact about you :- I have very bad handwriting
2) Your favorite sports team :- Indian Cricket Team
3) Your favorite hobby :- Playing & Watching Cricket
4) Anything else that may be fun to know about you :- I am a fun-loving guy
who loves to visit new new places along with friends and family.

Thanks,
Abhilash 





for charge code :- 
Jethani, Jyoti Pradeep :- jjethani@deloitte.com
Jahnavi, Billa <bjahnavi@deloitte.com>


for teams :-
18002582222


Samsung :- Claim it
iPhone :- 

US-NationalPTINMailb@deloitte.com
TPIN Issue

Hi Team,

I could see PTIN Status Confirmation tab in red color where I need to take some
action but when I am tryng to open it is not opening.
Please find the attached screenshot.
Kindly look into this.

Thanks,
Abhilash

180025822222



MCD Contact Number :- • Call 1 877 TOCMPLY (1 877 862 6759) 7 a.m. to 8 p.m. Eastern Time
OR Raise ticket here.
https://selfticket.deloittenet.deloitte.com/supportrequesthome.aspx?catID=4


Deloitte Call Center: Deloitte Call Center is the single point of contact 
for talent, payroll, benefits,
business applications such as DTE and Expense questions, and general technology support.
• Technology Request
• Inside the office – dial 2222
• Outside the office - +1 800 DELOITTE (+1 800 335 6488)
• International - +1 615 882 7777


----------------------------------------------------------------------------------------------
/* Sodexo :- */
Personnel Number:00682281
abhilaskumar@deloitte.com
https://web.zetaapps.in/#/super-card/8608135_8caebf43-1e4e-4767-855b-6946d630780f/cloudCards

https://deloittenet.deloitte.com/PC/PracticeComm/regions/India/SS/Finance/Pages/Sodexo_Meal_Card.aspx
Hyderabad		Sairam Paladi	sairam.paladi@sodexo.com 9618339876

Sodexo :- 103174272792
Activation Code for your Sodexo Card ending with 7526 is 40857564

6375130553007526
103174272792
Sodexo :- 
In case of any immediate assistance please reach out to us on our 
Contact Center numbersh 022-6919 6919, 022-4919 6919 (24*7 Support)
In case of any further assistance, feel free to reach us on:
Phone – 022-6919 6919,022-4919 6919 (24x7)
E-mail – Consumer@india.sodexo.com

Sodexo :- 103174272792
Activation Code for your Sodexo Card ending with 7526 is 40857564


E-mail – Consumer@india.sodexo.com

Not able to OPT-IN Sodexo Card
Hi Team,

While opting Sodexo it is saying window was open till 20th Dec.
Due to some technical reason I couldn''t OPT-IN sodexo.
Could you please let me know is there any possiblity to opt in now.
Since I am a new joinee so I have activated the card now.

Thanks,
Abhilash Kumar

/* In June window will open */

Card Reference No. :- 103174272792	Registered Mobile No. :-	Registered Email :- ABHILASKUMAR@DELOITTE.COM
Activate your card now, to enjoy all the benefits:
1.  Visit https://activation.sodexobrs.com
2.  Enter your official e-mail ID
3.  Enter the 12-digit card reference number mentioned above
4.  Click on 'Get Activation Code'
5.  Provide KYC information
6.  Enter activation code received on e-mail
7.  Complete OTP-based mobile number verification
8.  Click on 'Activate Card'
/* Activated */
Once you have activated your card, download the Sodexo-Zeta app and start using your Sodexo Meal Pass. DOWNLOAD NOW!
Sodexo Representatives will never ask you to share confidential information like card details, OTP, PIN, CVV, Password etc. 
If you receive any such calls, please report it immediately on 1800 267 3030 or send us an email at consumer@india.sodexo.com
Fees applicable on your card:
Card Replacement Fee (charged per instance): ₹ 100
Inactive Card Fee (charged per month if the card does not have a credit or debit transaction in 90 days) : ₹ 0
Insufficient Fund Fee (charged per transaction that is declined due to insufficient balance on card) : ₹ 0

Call our Customer Service team on
1800 267 3030/1800 103 3030
Write to
consumer@india.sodexo.com

----------------------------------------------------------------------------------------------



https://people.deloitte/
https://people.deloitteresources.com/

Prior to the collective disconnect, 
your issues and questions should be directed to usdstart@deloitte.com or 
call 1 800 2582 2222 and select option 2 for help.

Contact USIndiaOfficesW2D@Deloitte.com and USIndiaOnboarding@Deloitte.com 
with questions about week 1.Contact us at usdstart@deloitte.com or Deloitte 
Call Center at 1800 2582 2222.

----------------------------------------------------------------------------------------------
/* DStart */
1) Digital Paperwork :- 
Submit your beneficiary nomination details
i) Nimination Register :- 
https://deloittenet.deloitte.com/PC/PracticeComm/regions/India/SS/Finance/Pages/NOMINATIONS_fin.aspx

ii) Submit your E-nominations on the UAN portal
https://deloittenet.deloitte.com/PC/PracticeComm/regions/India/SS/Finance/Pages/Form11.aspx


2) Technology :- /* Check one more time. So many things are there */
i) Get familiar with technology used daily
https://dstart.deloitte.com/birds-eye-view/task-view/card-detail/63


General guidance on how to order peripherals and accessories for laptops
https://becurious.edcast.eu/pathways/new-hire-center_test_pathway/cards/107512708
/* Check this link for Hybrid Productivity Allowance expense type */
/* Product that can be bought is listed here */
/* Total 15k */

Categories covered under that program are webcams, speakerphones, 
headphones, light kits, laptop stands, 
keyboards, mice, external monitor, and USB hubs.  




use the Hybrid Productivity Allowance expense type)
https://becurious.edcast.eu/pathways/new-hire-center_test_pathway/cards/107512708


What is the charge code to be used?

Please use your specific WBS (Example: GAAXXXXX-01-01-01-0000)
Charge Code :- GAA57224-01-01-01-0000
Number: 00682281 Company Code: 1202 Cost Center: 0120257224	>>> 120257983

Please charge 8 hours for Tuesday, 
December 14, 2021 to “CEDXXXXX-01-01-01-0000 CONTINUING EDUCATION”. 
Replace the XXXXX with the last five digits of the Cost Center number 
found on your DTE homepage. Please refer to the attached document for further assistance.

Charge Code for Tax Project :- LPE57224	-01-01-01-0000 

New Charge Code :- WBS Code :- LPE04197-01-01-01-0000 

/* Kolkata */
Cost Centre  :- 120259942 /* Last 5 Digit in charge Code */
Charge Code :- GAA59942-01-01-01-0000



3) Orientation :- 
i) Plug into life at Deloitte
/* https://dstart.deloitte.com/birds-eye-view/task-view/card-detail/443 */
What do I need to do?
Follow @LifeAtDeloitte on Facebook, Twitter, or Instagram.
Follow @Deloitte on LinkedIn.
Check out the Life at Deloitte site designed to immerse you in Deloitte’s culture.
Who we are
Diversity, Equity, & Inclusion
Corporate Citizenship
Well-being
Listen to the podcasts in the resources section to better understand your Business Chemistry and to empower your well-being.
Review the Deloitte Diversity, Equity, and Inclusion Transparency Report.
Download the WorkWell app. The WorkWell app brings our existing Empowered Well-being resources straight to your mobile device in a convenient and user-friendly format.

ii) Learn about Diversity, Equity, & Inclusion (DEI)
/* https://dstart.deloitte.com/birds-eye-view/task-view/card-detail/438 */

iii) Learn about performance management at Deloitte
/* https://dstart.deloitte.com/birds-eye-view/task-view/card-detail/176 */

iv) Add interests and skills to your Cura Dashboard
/* https://dstart.deloitte.com/birds-eye-view/task-view/card-detail/86 */


----------------------------------------------------------------------------------------------
/* Add Skill */
https://becurious.edcast.eu/me/learners-dashboard

----------------------------------------------------------------------------------------------
/* Solve it */
https://solveit.deloitte.com/

Type problem and get solution.Everything is present there.
Try to use this


----------------------------------------------------------------------------------------------
/* About */
I have total 8 years of experience in IT industry and was working as a specialist data Engineer.
and below are my skills.
Cloud :- Data Engineer in Azure, ADF pipelines, Azure Data Bricks,  Azure SQL, ADLS Gen1/Gen2, Azure Key Vault
Database :-  Oracle (11g,12c,18c), Teradata (13,14,15,16), SQL Server, PL/SQL developer.
Language :- SQL, Python, Unix, PL/SQL
OS :- Linux, Windows

Currently joined deloitte as Senior Tax Consultant at Hyderabad Location.
Looking forward to have a fruitful IT career.


Yes, alligned to Oracle[‎12/‎9/‎2021 2:06 PM]  Jethani, Jyoti Pradeep:  
who is your buddy?
 
ohh yes meanwhile you are not aligned to any projects, so 
update CED on MySource with the hoours you need to complete mandatury trainings

its a continuos education code, used when we are taking or imparting any trainings
yes there too CED followed by RC code 


you can see your RC code on top ribbon on DTE page
timesheet page is called dte

----------------------------------------------------------------------------------------------

/* DLaunch: Deloitte’s Culture of Integrity */

https://ecodeinternal.deloitte.com/home
https://secure.ethicspoint.com/domain/media/en/gui/1357/index.html
https://mcd.deloittenet.deloitte.com/Default.aspx


Based on the content of this course, which are the appropriate resources to turn to for help and reporting of concerns about work-related ethical challenges?
1,2,3

Key points
Glenn Stastny and his team would like to encourage you to remember the following key points as you progress in your career at Deloitte:

You should never feel inclined to attempt to resolve ethical challenges on your own.
When these challenges arise, raise your hand and seek help from colleagues in your managerial chain-of-command, who have more experience and who can collaborate with you to identify the best course of action.
Make sure to consult the many helpful resources Deloitte provides, including our Shared Values, our Code of Ethics, Talent, and the Integrity Helpline, whenever something at work or a client site seems ethically questionable.


You’ve almost reached the end of this course. Take a moment and consider how well you 
can do these things now:

Recognize the Shared Values that articulate who we are and what we stand for at Deloitte.
Apply our Shared Values to various ethical challenges.
Identify components of Deloitte’s Ethics program, which are available to help you.
Next, take another look at our Shared Values in the downloadable resource document. 
Theen, spend some time memorizing them. In the days ahead, you’ll have opportunities to add 
to what you’ve learned about Deloitte’s culture and Shared Values in this course, so you’ll 
be better prepared to take action if you’re faced with or become aware of an ethical 
challenge.

Finally, remember that at Deloitte, when we set high standards, always act with integrity, 
collaborate effectively across the organization, and deliver outstanding value to 
our clients, we can truly thrive.

2) /* Introduction to Deloitte Tracking & Trading */

Welcome to Introduction to Deloitte Tracking & Trading.

This course is made up of eight interactive lessons that you can move through at your own pace. When each lesson and all required activities are completed, the lesson title will be highlighted and marked with a check. Once you’ve completed all the lessons, you will be able to access the final exam. This course will take around 90 minutes to complete.

To begin, select the first lesson, What are my responsibilities?, and you''ll learn how this online training works.

Because of your role in the Deloitte US Firms, you are required to maintain a portfolio of your Financial Relationships in the Tracking & Trading system. This portfolio must be kept current at all times.

After completing the course, you will:

Recognize how the Tracking & Trading system supports Deloitte’s Independence Policy.
Identify Financial Relationships that are attributable to you and require monitoring.
Recognize how the Tracking & Trading system is used to report Financial Relationships.
Identify the responsibilities you have for maintaining - and keeping current - your portfolio in the Tracking & Trading system.

Your requirements
At this stage in your career (a newly hired, directly admitted or promoted Partner or Professional Staff, or other role change), there are three primary compliance areas that require your immediate attention.

Mandatory Learning
Tracking & Trading
Representation

Tracking & Trading
Populate and maintain your Tracking & Trading portfolio in the Deloitte Tracking & Trading system. Enter the name, but not the quantity or value, of certain Financial Relationships. 
Your information must be kept current and 
should be reviewed periodically and whenever there is a change in your Financial Relationships.
**Everyone will have something to report because, at a minimum, the institution where your paycheck is direct deposited is reportable.


Representation
Submit a special purpose representation where you will be asked to respond to a number of questions regarding your compliance with independence and other firm policies in addition to attesting to the completeness of your Tracking & Trading portfolio. Periodic Representations on Independence, Ethics, and Compliance will be required throughout your employment/association with Deloitte.



Maintaining compliance
Your compliance with Independence Policy is monitored by Independence & Conflicts Network. Noncompliance with any of your Independence Requirements is subject to disciplinary action as set forth in APR 105 Expectations Concerning Independence Policies Concerning Ethics and Compliance Standards and the Consequences of Noncompliance. If you are found to be in violation of Independence Policy, the result can be a policy Violation or a regulation Violation. Depending on the severity of the Violation, the consequences can range from a warning to monetary implications and, in rare situations, termination.

Any questions you may have regarding your responsibilities to comply with Independence Policy can be directed to any of the following:

The Compliance HelpDesk
Independence & Conflicts Network
Your local office Audit Professional Practice Director (Audit PPD)
Functional Risk Manager
For contact information, visit the Independence Contacts page on DeloitteNet.




1) Which of the following will review the information supplied in
your Tracking & Trading portfolio?

The SEC/PCAOB/AICPA and internal personnel in Independence & Conflicts Network will 
review the information supplied in your Tracking & Trading portfolio.

2) 
If you do not comply with Independence policy, you are subject to disciplinary action. Noncompliance with any of your Independence Requirements is subject to disciplinary action as set forth in APR 105 Expectations Concerning Ethics and Compliance Standards and the Consequences of Noncompliance.
The Tracking & Trading system will help you maintain compliance with Independence Policy and is your responsibility to maintain. Your information must be kept current and should be reviewed whenever there is a change in your Financial Relationships.
The My Compliance Dashboard will list your outstanding independence requirements in detail and provide due dates.
The solution to the exercise is now shown.

/* all True */





Abhilash Kumar abhilaskumar@deloitte.com
Aarti S
Abhijit Roy
Apoorva S
Avishek Majumdar
Mishra Subhrata
Mohak Sethi
Prakhar Goyal
Sejal Jain
Sharma Preeti
Shravan H
Shrey Agarwal
Sreenivas Avula Shanmuka
TAnvi Mittal


Staffit Aceesss :- 
https://deloitteglobal.service-now.com/sp/?id=form&table=sc_req_item&filter=&sys_id=872bed6c87ac0910717520ee8bbb35fa&v=


I joined Deloitte on 6th Dec.Still I haven''t got access to staffit.

· Relevant screenshot/screenshot of the error message (if any) :- Attached
· Your role in STAFFIT (Practitioner, Resource Requester or Resource Manager): Senior Consultant
· Device/browser details :- Chrome
· Are you using a Deloitte managed laptop or your personal laptop? :- Deloitte managed laptop
· Are you connected to VPN? :- Tried both
· Steps to reproduce the issue. :- Open https://staffit.deloitteresources.com/saml2/sp/acs



6:20 PM :- 4:50 AM


6:20 PM =4:50 AM


HelpCenterTeam@csod.com
Completed Training not reflecting

Hi Team,

I have completed "Deloitte Time and Expense Reporting in US" on 21st Dec 2021.
Still it is not reflecting as completed in my dashboard.
Please find the completed screenshot.
Please look into this.

Thanks,
Abhilash Kumar


/* Zoom */
Hi Team,

I am trying to login into to my account through zoom app but it is showing error.
Please find the attached screenshot.

Thanks,
Abhilash Kumar

--------------------------------------------------------------------------------------------
/* Teams Access */
https://deloitteus.service-now.com/sp?id=sp_kb_article&sys_id=f5fcbe1bdb521414cc9662eb8a9619b3

--------------------------------------------------------------------------------------------
/* Medical Health */
/* Bajaj */
/* Login */
https://ecard.bajajallianz.com/hCard/Health_Ecard/hlth_cardlogin.jsp
https://ecard.bajajallianz.com/hCard/Health_Ecard/hlth_cardlogin.jsp

Health Card :- 
C:\Users\abhilaskumar\Desktop\Abhilash\DTS-22-682281.pdf
C:\Users\abhilaskumar\Desktop\Abhilash\Medical\Health Card\
DTS-22-682281.pdf
DTS-22-682281A.pdf
DTS-22-682281B.pdf
DTS-22-682281F.pdf
DTS-22-682281G.pdf
                       
					   
Policy Document :- 
C:\Users\abhilaskumar\Desktop\Abhilash\MedicalInsurancePolicyGuide1805.pdf
/* Everything is present in this document */
Deloitte dedicated direct number for Health cashless & reimbursement claims: 020 67031700
Toll free numbers of Bajaj Allianz
1800 103 2529 (toll free for only Health Claims)

/* Deloitte insurance helpdesk :- */
E-Mail ID: usindiainsurancebenefits@DELOITTE.com
India number- 040-66705656
US Number: +1.615.718.5656
Sreenivas Mangillipalli- 09989725911

Customer Experience - CX
Bajaj Allianz General Insurance Company Ltd.
Escalation Matrix: Level 1) Prajyot Sankanna :- Prajyot.Sankanna01@bajajallianz.co.in
Level 2) Vishal Vaishnavi :- Vishal.Vaishnavi@bajajallianz.co.in
Level 3) Pranali Yerunkar :- Pranali.Yerunkar@bajajallianz.co.in
Level 4) Suraj Suryawanshi :- Suraj.Suryawanshi02@bajajallianz.co.in
.	To check online claim status, click on :- https://general.bajajallianz.com/BagicNxt/InHouseSP/hm/externalUserCC.jsp
.	To download health and wellness e-card, click on :- https://hcm.bajajallianz.com/BagicHCM/Health_Ecard/hlth_idcrddwn.jsp
.	To download health claim forms, click on :- https://www.bajajallianz.com/health-insurance-plans/health-insurance-claim-process.html
.	To download Caringly Yours App, click on :- https://www.bajajallianz.com/bajaj-allianz-mobile-app.html


Personnel Number:00682281


abhi.k.cvraman@gmail.com
8093772483
30-Nov-2021
04-Dec-2021
diarrhea 

abhilaskumar@deloitte.com
Policy Number : OG-22-1919-8403-00000105
ID Card No : 
DTS-22-682281  :- Abhilash Kumar
DTS-22-682281A :- Aakrity Kumari
DTS-22-682281B :- Ayansh Kumar
DTS-22-682281F :- Ashok Kumar
DTS-22-682281G :- Indu Devi

Policy Number : OG-22-1919-8403-00000105
Valid Up To : 31-Aug-2022
Name : KUMAR ABHILASH
Gender : Male
Date of Birth : 08-Jan-1991
Age : 30
ID Card No : DTS-22-682281
Company Name : DELOITTE TAX SERVICES INDIA PRIVATE LIMITED



Corporate Policy Details:
Policy No: OG-22-1919-8403-00000105
Policy Name: Deloitte Tax Services India Private Limited


Wrong DOB for Beneficiary
helpdesk_ccm@bajajallianz.co.in

Hi Team,
I could see one of my added Beneficiary DOB is not correct.
10 days back I made the changes and submitted still old one got processed.

Policy No: OG-22-1919-8403-00000105
Beneficiary Name	:- Indu Devi
DOB :- 08-Jan-1991 :- This is wrong

Actual DOB :- 06/June/1968

Kindly update the same as I am not getting any option to edit the details.

Thanks,
Abhilash Kumar



Claim Number	OC-22-1002-8403-00225206
Please note your reference number IN-1002-5161127 before uploading the documents.



You have not register your Mobile Number. 
Please contact health@bajajallianz.co.in

Path :- C:\Users\abhilaskumar\Desktop\Abhilash\Generic\Mobile_Not_Updated.PNG
mobile number registration in My Policy Account

Hi Team,

Also kindly add my phone number in my Policy Account as its showing blank.
Please find the attached screenshot.
Policy Number : OG-22-1919-8403-00000105

Mobile Number :- 8093772483
EMail Id :- abhilaskumar@deloitte.com

Thanks,
Abhilash Kumar

health@bajajallianz.co.in

Hi Team,

My Contact detail is already updated in deloitte portal.
Could you please took that and update in your portal.
Please find the attached screenshot.

Thanks,
Abhilash Kumar

/* Outside Deloitte Network */
Log in ID: Use your Deloitte Email ID
Password: 3UQLSU2M
Policy Number: OG-22-1919-8403-00000105
https://deloittenet.deloitte.com/TalentOnDemand/Benefits/USI/Medical/Documents/Processforenrollment.pdf


https://ecard.bajajallianz.com/hCard/Health_Ecard/hlth_cardlogin.jsp
Log in ID: Use your Deloitte Email ID
Password: MNQ2YT0I
Policy Number: OG-23-1919-8403-00000103









https://ecard.bajajallianz.com/hCard/Health_Ecard/hlth_cardlogin.jsp
https://ecard.bajajallianz.com/hCard/Health_Ecard/hlth_cardlogin.jsp

/* Talent BA */
Apt, Prashant <prapt@deloitte.com> 
prapt@deloitte.com
Beneficiary Name not coming while claim 

Hi Prashant,

I have enrolled my Father In Law "Ashok Kumar" in Bajaj Allianz insurance policy.
I would like to apply a reimbursement but during claim process his name is not displaying.
Please find the attached screenshot.

Could you please look into this.

Thanks,
Abhilash Kumar

Hi Team,

I would like to freeze the details (no change to dependents details & sum insured) and initiate the claim.
Please do the needful.

Thanks a lot!
Abhilash Kumar


/* Claim For Father In Law */
Hospital Name :- Abhay Institute Of Medical Sciences
1) 26th Dec 2021 :- OP/35155/2122 :- 100
2) 

Hospital name- ABHAY INSTITUTE OF MEDICAL SCIENCES
Registration no- 64993
Date of Admission- 26/12/2021
Date of discharge- 30/12/2021
Amount  Money receipt			MOP        		DOP
100     C/48169/21-22    	Cash      		26/12/2021
8400   	C/48170/21-22 		debit card 		26/12/2021
13000 	C/48184/21-22 		debit card 		26/12/2021
20000 	C/48194/21-22 		debit card 		26/12/2021
10000 	C/48195/21-22     	Cash     		26/12/2021
117200 	C/48248/21-22   	Cash      		27/12/2021
50000 	C/48255/21-22 		E-payment 		27/12/2021
50000 	C/48621/21-22 		debit card 		29/12/2021
2000  	C/48636/21-22    	Cash        	29/12/2021
2400  	C/48740/21-22 		debit card  	30/12/2021


Hospital name- ABHAY INSTITUTE OF MEDICAL SCIENCES
Registration no- 64993
Date of Admission- 26/12/2021
Date of discharge- 30/12/2021
Amount  Money receipt      MOP        DOP
100/-      C/48169/21-22    Cash      26/12/2021
8400/-   C/48170/21-22 debit card 26/12/2021
13000/- C/48184/21-22 debit card 26/12/2021
20000/- C/48194/21-22 debit card 26/12/2021
10000/- C/48195/21-22     Cash     26/12/2021
117200/ C/48248/21-22   Cash      27/12/2021
50000/ C/48255/21-22 E-payment 27/12/2021
50000/ C/48621/21-22 debit card 29/12/2021
2000/-  C/48636/21-22    Cash        29/12/2021
2400/-  C/48740/21-22 debit card  30/12/2021 
 
MEDICINE SHOP BILL-
Amount   Bill No        MOP            DOP
1300/-    R-074126      Cash         26/12/2021
2219/-    R-074166      debit card   26/12/2021
379/-     R-074852      Cash         29/12/2021
325/-     R-075064      debit card   30/12/2021
534/-     R-075478      Cash         01/01/2022


100+8400+13000+20000+10000+117200+50000+50000+2000+2400+1300+2219+379+325+534
= 277857

Final :- 273634

100+8400+13000+20000+10000+117200+50000+50000+2000+2400+534
= 273634

290000
heart bloock 
Other specified heart block


App :- caringly yours
Policy number :- OG-22-1919-8403-00000105	
Claim Number  :- OC-22-1002-8403-00261205

Dear Sir/Madam,

We are in receipt of claim documents pertaining to KUMARI JYOTI and same has been registered with us, 
reference Claim ID number is 5081858 

The reference number is generated on receipt of below documents/Intimation.

CLID : 5081858 
Policy No : OG-22-1301-8403-00000002
Proposer Name: SONATA FINANCE PVT. LTD.
Patient Name:KUMARI JYOTI
Claim Number:OC-22-1002-8403-00264082
 
All communications are being tracked through the above reference number 
and we request you to retain the subject line in future correspondence.

Details of claim settlement can also checked on the website 3 days post 
the submission of documents at the following link: 
http://general.bajajallianz.com/BagicNxt/b2c/customer/claim_enquiry_new.jsp

Assuring you of our best services every time, all the time.


Email :- hat@bajajallianz.co.in
dr.hat@bajajallianz.co.in
document.tracking@bajajallianz.co.in


Subject :- Document for Reimbursement 

Hi Team,

For mentioned Claim, some documents were required.I have attached all documents.
Please check this.

Policy Number : OG-22-1919-8403-00000105
ID Card No : DTS-22-682281  :- Abhilash Kumar
Claim Number: OC-22-1002-8403-00264082


i) Kindly provide Final Bill(as you submitted only payment receipt ) :- FinalBill.pdf (Attached)

ii) Kindly provide clear copy of pharmacy bills :- PharmacyBills.pdf (Attached)
As Ink quality was not good in printer at hospital.So this way only I recieved the bill.
Please consider it.

iii) Original Discharge Summary of ASHOK KUMAR stating the date of admission, date of discharge, presenting complaints
with duration ,clinical condition, detailed line of treatment, final diagnosis and past medical and surgical history
with duration. :- DischargeSummary.pdf (Attached)

iv) kindly provide all investigation reports done supporting to the diagnosis. :- InvestigationReport.pdf (Attached)

v) Kindly provide KYC (Know your customer) form with photo dully completed filled and signed by insured along with
AML documents: Pan card/passport/Voter identity card (For identity proof), Bank account statement/electricity bill/
Telephone bill (For the residential proof) :- KYC_Identidy_Address.pdf
Identity Proof :- Driving License
Address Proof :- Bank Statement

vi) DocumentRecoveryIntimation.pdf (Attached)

Thanks,
Abhilash Kumar

Please note your reference number IN-1002-5249121 before uploading the documents.

pharmecy bill :- 
break up of 267000
investigation report
kyc

IN-1002-5264243

TRANSACTION STATUSFAILURE
TRANSACTION REFERENCE NUMBERWSBI0942976996
TRANSACTION DATE AND TIME01-03-2022 11:30:41
AMERICAN EXPRESS CARD NUMBERXXXX XXXXXX 51009
MOBILE NO8093772483
EMAIL IDABHI.K.CVRAMAN@GMAIL.COM
PAYMENT AMOUNT (Rs.)26359.00
PAID FROMSTATE BANK OF INDIA

Oli Shaikh <Oli.Shaikh@bajajallianz.co.in>
HelpDesk_CCM@bajajallianz.co.in

Hi Team,

This is the only bill I have.Kindly consider those bills which is clear
and ignore the non-visible one.
Please confirm can I claim it in next claim, If I got those bills after some days.

Thanks,
Abhilash Kumar



Hi Team,

Kindly consider those bills which is clear
and ignore the non-visible one.
Thanks,
Abhilash Kumar


100+8400+13000+20000+10000+117200+50000+50000+2000+2400+534
= 273634


Hi Team,

I have updated all documents as per below request.

1) Kindly provide clear copy of pharmacy bills :- I have removed the amount from claim form where pharmacy bill was not clear.
Attaching new claim form.(ClaimForm.docx).

2) Kindly provide breakup for Rs:260000/- toward cath lab :- 
All bill copy attached.(Ignore the bill which is not clear)(All_Bills.pdf)

3) kindly provide all investigation reports done supporting to the diagnosis. :- 
It is already submitted.Again attaching the same.(InvestigationReport.pdf)

4) Kindly provide KYC (Know your customer) form with photo dully completed filled and signed by insured along with
AML documents: Pan card/passport/Voter identity card (For identity proof), Bank account statement/electricity bill/
Telephone bill (For the residential proof).(Kindly provide PAN card) :- (KYC_Identidy_Address.pdf)
Identity Proof :- PAN card
Address Proof :- Bank Statement /* Included PAN Card */

Please check the documents uploaded.
/* Please note your reference number IN-1002-5264410 before uploading the documents. */

Thanks,
Abhilash Kumar

Hi Team,

I have provided all documents as per requested documents list still Status is showing as "DEFICIENT".
Could you please check this.

Thanks,
Abhilash Kumar


Hi Team,

Please find the required missing document.
BrekUP Doc :- BreakUp.pdf
Investigation Report :- 
Investigation Report.pdf
Investigation Report 1.pdf
Investigation Report 2.pdf

All these are uploaded under below reference number.
Reference number  IN-1002-5277715

Thanks,
Abhilash Kumar

Please note your reference number IN-1002-5277715 before uploading the documents.



Hi Team,

Please find the attached investigation report. As I am not able to login to insurance portal. So Couldn’t upload it.
Kindly let me know is it fine to send it here.

Thanks,
Abhilash Kumar

Hi Team,

I have uploaded the investigation report through “Carringly Yours” app as through Deloitte portal it is not opening.
Kindly check the doc and process the claim.

Thanks,
Abhilash Kumar



Please note your reference number IN-1002-5282922 before uploading the documents.

Hi Team,

I have already provided breakup bills for 260000 still due to this state changed to dificient.
Take a look into attached BreakUp bills.

Please find the required missing document.
BrekUP Doc :- BreakUp.pdf

All these are uploaded under below reference number.
Reference number  IN-1002-5277715

Thanks,
Abhilash Kumar

--------------------------------------------------------------------------------------------
/* Medibuddy */
https://mbportal.medibuddy.in/DeloitteBBNew.aspx
https://mbportal.medibuddy.in/
/* Check any cost is there or not and register */

Helpline contact number - +91 99999 91555
Helpline email id - hello@medibuddy.in
Escalation contacts – Deloitte: usindiaotherbenefits@DELOITTE.com
CIC - 2222 or 1800-D-E-L-O-I-T-T-E

682281@deloitte
00682281@deloitte
abhilaskumar@deloitte.com
08011991

Path :- C:\Users\abhilaskumar\Desktop\Abhilash\Screenshot\MediBuddy_Login_Issue.png

hello@medibuddy.in

Not able to login

Hi Team,
I am not able to login into mbportal.medibuddy.in sit.
It is saying "Login failed!.Please check your username/password".

EmailId :- abhilaskumar@deloitte.com
DOB :- 08011991
Mob No :- 8093772483
Company :- Deloitte

Please find the attached screenshot.

07022069000 :- 


usindiaotherbenefits@DELOITTE.com
Not able to login to Medibuddy portal

Hi Team,
I am not able to login into mbportal.medibuddy.in sit.
It is saying "Login failed!.Please check your username/password".

Tried USer Name as empid@Deloitte and DOB as password.Still it is not working.
Please look into this


/* Doctors on Call */
https://mbportal.medibuddy.in/deloittedoc.aspx

 
--------------------------------------------------------------------------------------------
/* Vintage Circle */
https://deloitte.vantagecircle.com/myaccount/redeem
Check about reedem of Gift Card 

/* 3000 Points are there.Redeem it */


--------------------------------------------------------------------------------------------
/* Car Lease */
https://deloittenet.deloitte.com/TalentOnDemand/Benefits/USI/AdditionalPrograms/Pages/CarLeaseProgram.aspx

--------------------------------------------------------------------------------------------
/* Subsidy on certain item worth 25000 / 25K */
C:\Users\abhilaskumar\Desktop\Abhilash\WellbeingSubsidyProgramDocument.pdf
C:\Users\abhilaskumar\Desktop\Abhilash\WellbeingSubsidyFAQs.pdf
/* Must Check and buy certain item */

Path :- C:\Users\abhilaskumar\Desktop\Abhilash\Generic\WellBeingSubsidyProgram.pdf
Path :- C:\Users\abhilaskumar\Desktop\Abhilash\Generic\WellBeingSubsidyFAQs.pdf

https://resources.deloitte.com/sites/US/About/Policies/Admin/Pages/home.aspx?India_500_520_CP

please contact the Deloitte Contact Center at +1 800 2582 2222 or x2222 

Fitness equipment (including bicycles, treadmills, yoga mats, and running shoes)

Sports and recreational classes (including sport league fees, court rentals, gardening, and music classes)
Fitness technology (including smart watches, activity trackers, and consoles)
Gym memberships (including fitness-related classes, and online classes/subscriptions)
Ergonomic office furniture (including desks, chairs, and lumbar support)
Sustainable/Societal well-being (including composting equipment, gardening supplies, 
and electric vehicle charging equipment)


/* Good Link for detail description */
https://resources.deloitte.com/sites/US/About/Bus/Talent/Pages/we-are-Deloitte-USI.aspx


/* What is this */
Well-Being Subsidy: The Well-being Subsidy is a benefit that gives our professionals 
the flexibility to choose the services and products that support their unique well-being 
needs by offering eligible participants funds each fiscal year towards the purchase of 
one or a combination of a wide array of qualifying items.
 

Hybrid Productivity Allowance: To help you have an eminent, equitable, and consistent hybrid 
experience no matter where you are working, Deloitte is offering reimbursement on qualifying 
technology through the Hybrid Productivity Allowance. (Note: This allowance is not available to PPMDs)
 

Hybrid Commuting Reimbursement: To alleviate anxiety about public transportation and support 
being together with colleagues and clients in moments that matter, we are allowing for the 
reimbursement of certain commuting costs that are not otherwise reimbursable.

 
--------------------------------------------------------------------------------------------
/* Benefit Programme */
https://dstart.deloitte.com/birds-eye-view/task-view/card-detail/69
/* Must Look into all link */

--------------------------------------------------------------------------------------------
/* Education Centre */
https://becurious.edcast.eu/pathways/new-hire-center_test_pathway

/* Check how is it */

--------------------------------------------------------------------------------------------
/* Office Address */
HYDERABAD-BLOCK D
4TH FL RMZ FUTURA BLOCK D, PLOT NO.14&15 ROAD NO.2, HITEC CITY LAYOUT, MADHAPUR, HYDERABAD, 500081, India

--------------------------------------------------------------------------------------------
/* Leave */
https://deloittenet.deloitte.com/TalentOnDemand/Benefits/USI/Leaves/pages/PaidTimeOffProgram.aspx

The PTO program offers all eligible USI professionals 30 days of accrued leave 
and 9 days of 
Additional Medical Leave totaling to 39 days. 

In the new program, the leaves are organized as 
18 Privileged leaves (PL), 
12 Casual/Sick leaves (CL/SL), and 
9 Additional Medical Leaves (AML). 

File NAme :- C:\Users\abhilaskumar\Desktop\Abhilash\Leave Rule.jpg

/* Leave In Cash */
https://deloittenet.deloitte.com/TalentOnDemand/Benefits/USI/Leaves/Pages/ApplyforaLeaveUSI.aspx


/* Additional Leave */
In addition, please be aware you may be eligible for Approved Absence (APA) through April 2, 2022. 
If you are not able to work given personal or health reasons related to COVID-19 
(for example, COVID-19 diagnosis, lack of dependent care options as a result of school 
closures, caring for a sick family member, or time away from work to receive your 
COVID-19 vaccination or booster shot), you are able to charge APA for up to the 
equivalent of 5 business days (or 40 hours), using the time in a 
manner that is best suited to stabilize your situation. The 40 hours 
is inclusive of the previously announced APA time available for 
vaccination against COVID-19. IMPORTANT NOTE: This additional time 
off from work is NOT additional PTO and may NOT be used for any reason(s) 
unrelated to COVID-19, such as vacation, relaxation, or personal 
commitments or needs that are not related to COVID-19.




--------------------------------------------------------------------------------------------
/* Referral */
https://deloittenet.deloitte.com/PC/PracticeComm/regions/India/SS/Talent/Pages/USIndiaTalentReferralProgram.aspx

--------------------------------------------------------------------------------------------
/* Investment */
You can submit your investment proofs till January 14, 2022, 11:59 p.m. (IST).
All investment proofs will be accepted as per the IPSF guidelines only.

1. Visit HR Workways: https://talentsites.deloittenet.deloitte.com/vendorsso/indiapayroll.aspx
2. Visit 'Year-end’ > 'IPSF 2021-2022’
3. Enter your investment details and generate the bar-coded IPSF report.
4. Scan/take picture of all proofs, and digitally sign all system generated IPSF forms along with the supporting documents (in .pdf format)
5. Zip all the proofs and the IPSF bar-coded sheet in a folder and rename it using the guidelines given in the process document as part of the IPSF kit.
6. Visit Image Upload > Upload IPSF Proof Images and upload your zip folder.


Flat No 164 23, Building Name B P C L Staff Colony, 
Block Sector Chembur, 
Road Near Ashish Theatre 
MUMBAI, MAHARASHTRA, 400074


IDFC Tax Advantage (ELSS) Direct Plan
Growth
3256245/38 05 Oct 2021 29,998.50 Groww
2
MOTILAL OSWAL LONG TERM EQUITY
FUND - DIRECT GROWTH
91028749052 12 Jul 2021 19,999.00 Groww
3 Axis Long Term Equity Direct Plan Growth 91048163743 14 Sep 2021 49,997.50 Groww
4
Axis Long Term Equity Fund - Direct -
Growth
91048163743 01 Jun 2021 9,999.50 Groww


LARSEN and TOUBRO INFOTECH LIMITED

IPSF Report :- 
https://deloittenet.deloitte.com/PC/PracticeComm/regions/India/SS/Finance/Pages/IPSF.aspx

Professionals who’ve submitted IPSF during the annual IPSF window, must check the status of 
their IPSF submissions to know their tax liability for deductions in February and March payroll.
It is recommended that they go through the IPSF approval/ reject reports, that will be hosted on 
HR Workways usually in second week of February. They will also be able to understand their final 
Income Tax liability applicable for a particular FY (as on that date) by viewing the mock income 
tax computation sheet which will also be hosted on HR Workways for their 
reference during the same time.

Important points to keep in mind:

This is only applicable to Full Time Employees who’ve submitted their IPSF and uploaded proofs on HR workways during December (applicable existing employees) and January (applicable for new hires).
The IPSF approval report will not be available to professionals who didn’t take any action on IPSF submission or whose IPSF submission was incomplete, for those professionals, only their mock tax computation sheets will be available showing the tax liability for deductions in February and March payroll.
Proofs submitted will be validated and approved as per IPSF & IT guidelines.
If any of the proofs get rejected, the reject reason will be shown on the IPSF approval report itself.
If all proofs were submitted as per IPSF guidelines and if they have been rejected erroneously, professionals must write to info@ceridian.com immediately (not later than the timeline mentioned in the mail communication) providing details of discrepancies observed. Such discrepancies will be handled appropriately and rectified in February payslip (as applicable).
Any discrepancies reported post the timeline mentioned in mail communication, will not be considered.
No additional proofs or investment details will be considered post January. Professionals will have to claim the tax benefit for such proofs while filing their income tax returns.
Further communications on the approval window dates will be released by Info Ceridian team.  



Important Note ? Action Required:
As per our record, you have not submitted the Signed Form 12BB. The signed Form 12BB submission 
is mandatory to consider investment details for tax calculation as per IT Rule. 
Even though the qualifying investment details status shows as ?Approved? in this 
report, it will not be considered for Tax calculation unless the signed Form 12BB 
is submitted. Hence, you are requested to send the signed scanned copy to 
info@ceridian.com by mentioning your company name, employee id 
in the body of the email and subject line as ?Form 12BB Signed Copy?.

Form 12BB Signed Copy
info@ceridian.com

Hi Team,

Please find the attached Form 12BB.
company name :- Deloitte USI
employee id :- 682281

Thanks,
Abhilash Kumar

/* Missed LTI salary slip due to which tax deducted in LTI is no considered */
/* Get it at the time of filing ITR */







--------------------------------------------------------------------------------------------
HRWorkWays :- 
/* Nomination addition */
/* My Nominations */
Power House Chowk, Barganda, Opposite Rana Furniture Giridih, Jharkhand 815301 
aakrity Kumari
05/01/1992


--------------------------------------------------------------------------------------------
Hi Team,

As 24th Dec 2021 was a holiday. So I Kept my timesheet 0 for that day.
But now I am getting mail regarding missing time and it is under compliance. 
Could you please let me know what would be the charge code for this and
how I can fill it now.Also what would be the time I need to enter.

Since Ongoing week is also a holiday.So hour and charge code do i need to put while
filling timesheet.

Thanks,
Abhilash Kumar


--------------------------------------------------------------------------------------------
/* 70 % */
1) Which of the following is NOT one of the Principles of the Global Principles of Business Conduct (Global Code)?
Professional development and support
Respect, diversity, and fair treatment
Social responsibility
Accountability :- T

2) We do not condone illegal or unethical behavior by our suppliers, contractors and alliance partners” is a commitment from which Principle in the Global Principles of Business Conduct (Global Code)?
Integrity :- T
Social responsibility
Responsible supply chain
Fair business practices

3) When using the Ethical decision-making model, which of the following do you NOT need to consider when considering alternative actions and their outcomes/consequences?
How the actions align with our Principles and Values
T :- What actions or behaviors are allowed at competitor organizations
If there are applicable policies, laws, or regulations
How the actions might impact our business strategy or objectives


4) When is the best time to consult?
After assessing the dilemma’s risks and sensitivities
At any time :- T
After identifying an ethical dilemma
Upon suspecting an ethical dilemma


5) Which of the following would NOT be an appropriate resource to consult if you suspect misconduct?
Your manager/supervisor or other trusted leaders
Talent
The ethics officer
T :- Former Deloitte colleagues who might have had similar experiences :- T

6) Of the following responses to a situation, which are likely indicators of an ethical dilemma?
T :- You feel embarrassed to tell family, friends, or co-workers.
T :- You are personally uncomfortable about the course of action. :- 
T :- You are concerned whether a course of action is illegal or unethical. :- 
T :- You wonder whether someone’s behavior is unfair and dishonest.

7) Who is responsible for speaking up about misconduct which has been witnessed within a team?
Only those who were directly involved
Only those who are sure misconduct is occurring
Only the team leader
T :- Everyone who witnessed or suspects the misconduct

8) Which of the following are steps of the Ethical decision-making model?
Consider alternative actions and their outcomes/consequences.
Identify the dilemma and assess the potential risks.
Evaluate the potential profitability of your best course of action.
T :- Decide the best course of action and implement it.


9) “We are straightforward and honest in our professional opinions and business relationships” is a commitment from which Principle in the Global Principles of Business Conduct (Global Code)?
Integrity :- T
Respect, diversity, and fair treatment
Professional development and support
Professional behavior

10) Which statement about the Global Principles of Business Conduct (Global Code) is FALSE?
It provides the foundation for how our people hope to behave most of the time.
T :- It calls for compliance with the Global Code, member firm codes of conduct, and related Deloitte policies.
It asserts that we have a responsibility to raise our voice when we become aware of anything inconsistent with it.
It states that retaliation against those who raise ethical concerns in good faith is not tolerated.
========================================================================================================
/* 80 % */
1) Which of the following must occur prior to engaging, contracting with, or assigning client work to third parties?
Interview the third parties and conduct an internet search to make sure there are no negative press articles about them

T1 :- Submit third parties to the Anti-Corruption Compliance Group for a risk and compliance assessment

Submit third parties to the Third-party Risk Management Gateway for a risk and compliance review

Coordinate with ITS and Talent to get them access to the Deloitte network and Deloitte buildings


2) Which of the following would not be considered an “Export” for the purposes of Export Controls?
T1 :- Sending an email discussing project timelines to a Deloitte team member outside of the United States, when no Export Controlled information is in the email

Presenting Export Controlled information via Skype on a conference call with a Non-US Person

Taking a hard drive with Export Controlled information abroad on a trip, but not using it

Dialing in via remote VPN to a server with Export Controlled information on it from outside of the United States

3) Is it acceptable to pass a resume of a Foreign Official client’s nephew to Talent, even if Deloitte is pursuing an opportunity with that client?
T1 :- No, because it could be considered “Anything of Value”

Yes, as long as the candidate is appropriately qualified for the position

Yes, but you cannot attempt to influence the hiring process or decision or insinuate to the client that you have any ability to do so

Only if it is pre-approved by Deloitte’s Anti-Corruption Compliance Group

4) For the purposes of the FCPA, which of the following most closely reflects the concept of “corrupt intent“?
The intent to talk to a client about Deloitte’s services

T1 :- The intent to unfairly secure a deal

The intent to evade US or foreign income taxes

The intent to unfairly influence an election

5) Which of the following actions with respect to Foreign Officials would likely not be considered providing “Anything of Value” for the purposes of the FCPA?

Scheduling a side trip to an off-site resort location after a meeting with potential clients and paying for their trip costs

Offering gifts to potential clients, such as expensive tickets to sporting events

A product promotion available to all clients and potential clients

T1 :- Inviting a potential client to an invitation-only conference that will promote Deloitte’s profile. Deloitte plans to cover the hotel and dinners for the client and their spouse


6) Which of the following engagements do you think could be affected by Export Controls or Economic Sanctions? Select all that apply.
T1 :- An audit engagement with an aviation firm in a US city that supplies airplanes to the military

T1 :- An M&A consultation with a cybersecurity firm in a non-US country that’s being bought by a US-based corporation

T1 :- An enterprise risk analysis for a US-based firm that supports supply chain operational consulting for the CIA

T1 :- Checking your Deloitte email regarding a project for a US government agency while traveling outside of the US


7) The Foreign Corrupt Practices Act (FCPA) contains a variety of criteria for evaluating whether an act may be a violation of its provisions, but it can essentially be broken down into three fundamental factors. Which of the following is NOT one of the three factors?
Are you dealing with a Foreign Official?

Are you providing “Anything of Value”?

T1 :- Are your actions intended to influence that Foreign Official to use their position to benefit you (or your employer) (i.e., do you have corrupt intent)?

Are you dealing with a sanctioned country?

8) When is it acceptable to hire a Foreign Official’s relative for a Deloitte position?
When the Foreign Official is not currently an active client with Deloitte

When the Foreign Official is only a prospective client

T1 :- When the relative goes through the normal Talent hiring processes and would be the best candidate under any circumstances and neither the Foreign Official nor the Deloitte personnel referring the relative attempted to influence the hiring decision

It’s never appropriate


9) Which of the following is true about sanctions?
Sanctions targets are located in sanctioned countries only

They only pertain to sanctioned countries and industries

T1 :- Sanctions targets can be located anywhere in the world

They only pertain to those dealing with parties who reside in sanctioned countries

10) A third party violated the FCPA while acting as a subcontractor to Deloitte. Which of the following is true about Deloitte’s liability?
If Deloitte was not aware that the third party was engaging in the activity, Deloitte would not be held responsible for the violation

T1 :- Deloitte can be held responsible, even if Deloitte was not aware that the third party was engaging in activity that could result in the violation

Deloitte would be held responsible only if Deloitte was aware that the third party was violating the FCPA but did nothing about it

If, upon learning that the third party was violating the FCPA, Deloitte immediately reported the activity, Deloitte cannot be held responsible for the violation



11) You are working on a Deloitte engagement and developing Software with a high level of encryption for information security purposes. Can you share the Software code with your colleague at Deloitte who is a Non-US Person?

No, encryption codes in Software cannot be shared with Non-US Persons

Yes, if the Non-US Person is located in the United States

T1 :- It may be permissible to share with a Non-US Person, but only if he or she has received the appropriate US government authorization

If the Non-US Person is from an authorized country, the Software code can be shared

12) Which of the following is an example of appropriately transmitting Export Controlled information?
Downloading Export Controlled files while outside the United States

Saving or sharing Export Controlled files on a server that is administered and maintained by Non-US Persons

Sharing Export Controlled Technical Data with a Non-US Person residing in the United States

T1 :- Emailing Export Controlled Technical Data to a US green card holder in the United States

13) What steps should you take if, while working on an engagement with Export Controlled Items and Services, you find that no controls have been put in place to mitigate the risk of sharing data with unauthorized persons?
T1 :- Contact your engagement lead and the Trade Compliance Group and ask for assistance developing a Technology Control Plan

Contact your client and the US Department of Defense for proper authorizations

Do nothing since the engagement team is only US Persons

Contact the Trade Compliance Group and your client
-------------------------------------------------------------------------------------------------
In case of any questions/queries/clarifications, you may contact US India BI team at usindiabi@deloitte.com.
Documents Required: Service Certificate & Relieving Letter



usindiabiemployment@deloitte.com
Relieving Letter

Hi Team,

Please find the attached Relieving Letter of my last employement.
As I have not recieved my Service Certificate yet.
I may recieve this by end of this month.

Thanks,
Abhilash Kumar



Dev Ops ::- Intract Client :- Deployement :- Sai Himakar, Diwakar, Sravani
QA Team :- 
Dev Team :- 
US TSO Dev Team :- UI + DB

Ankush :- Lead
Rama :- MAnagers
MAnoj :- Managers

1) Set up VPN.Check with 
2) UI Access
3) Visual & SSMS :- Ticket & 


Sai Chowdary, Maddipati Himakar <msaichowdary@deloitte.com>; :- Not Available
Sri Varun, Sri Varun <srsrivarun@deloitte.com> 
tvijaymurari@deloitte.com :- Freshers
 
/* Visual Studio Install */
https://my.visualstudio.com/benefits












10.10.0.11
sa
Virtual_01!!

10.10.0.1


Azure :- 
DP 900 :- Basic :- Azure SQL, DB iNstances , Iaas, Paas, File Formate, :- Simple

Dp 201 :- 
Dp 202 :- 

Dp 203 :- ADF & DAtaBricks :- Tough

ADF :- 
Free Subscription :- How to get this from Deloitte.

Azure Data FActory
Azure DAta Bricks :- Python/Scala/Spark SQL
Adls Gen2
Azuer Key VAult
Logic App :- 

Azure Function :- c#, .Net, Python

/* MAnogna for testing */

drop table if exists A
CREATE TABLE A
(id INT,
name nvarchar(10));

Insert into A values (1,'Active');
--Insert into A values (2,'InActive');

drop table if exists B
CREATE TABLE B
(id INT,
name nvarchar(10));

Insert into B values (1,'Active');
Insert into B values (1,'InActive');


SELECT A.id,B.name
from A inner join B on (A.id=B.id and A.name like '%' + B.name + '%')


SELECT A.id,B.name
from A left join B on (A.id=B.id and A.name like '%' + B.name + '%')

SELECT A.id,B.name
from A left join B on (A.id=B.id and B.name like '%' + A.name + '%')

SELECT A.id,A.name,B.name
from A left join B on A.id=B.id and (CHARINDEX(A.name, B.name)>0)

SELECT A.id,B.name
from A left outer join B on A.id=B.id and A.Name like Concat('%',B.Name,'%')

 


SELECT A.id,A.name,B.Id,B.name
from A left join B on (B.name like '%' + A.name + '%')


SELECT DC_ID,ScenarioPackLegalID,* FROM lem.ScenarioAtrributesValues WHERE DC_ID=62

SELECT TAB.ScenarioPackLegalID AS ScenarioPackLegalID
FROM
(
SELECT SAV.DC_ID AS DC_ID,SAV.Value AS Value,SAV.ScenarioPackLegalID AS ScenarioPackLegalID
FROM lem.ScenarioAtrributesValues AS SAV WITH(NOLOCK)
INNER JOIN @FilteredNonParent AS Filters ON (SAV.Value LIKE '%' + Filters.FilterValues + '%')
WHERE ScenarioID=@ScenarioID
GROUP BY SAV.DC_ID,SAV.Value,SAV.ScenarioPackLegalID HAVING COUNT(SAV.DC_ID)>=@FilterCount 
) TAB INNER JOIN @FilteredNonParent AS Filters ON (TAB.DC_ID = Filters.DC_ID)
GROUP BY TAB.ScenarioPackLegalID


------------------------------------------------------------------------

Hi Abhishek,

Please find my Brief Introduction.

I was born on 8th Jan 1991 in Giridih Jharkhand.
I did my schooling from Giridih and Intermediate from Ranchi.
I completed my Engineering from C.V.Raman College Of Engineering.

I have total 8+ Years of experience in IT industry.
Till now I have worked as DB PL/SQL Developer and also worked as Azure Data Engineer.

I am a Smart Worker and Consistent Performer.

I like to play and watch Cricket.
I also like to spend time with family and friends.


------------------------------------------------------------------------
/* Adding As part of Sprint 23 Notes Requirement */
INSERT INTO @AddedAgreementData
SELECT @CustomerProfileId,AgreementNumber,ReasonKey,'N' AS IsUpdated
FROM @TEMPResult
GROUP BY AgreementNumber;

SET @VisibilityId = (SELECT Id from NotesVisibility where Type='Public');
SET @CategoryId = (SELECT Id from NotesCategory where CategoryDesc='Profile');

SELECT @RowVal = COUNT(*) FROM @AddedAgreementData;
SET @IdVal = 1 ;

WHILE @IdVal <= @RowVal
BEGIN
SET @listAgreements = (SELECT TOP 1 'Add Agreement ' + AgreementNumber +' Performed for ' + ReasonKey
FROM @AddedAgreementData WHERE IsUpdated='N') ;

SET @AgreementNumber_Val= (SELECT TOP 1 AgreementNumber FROM @AddedAgreementData WHERE IsUpdated='N');
DELETE FROM @Notes_Data
INSERT INTO @Notes_Data values(@Customerprofileid,@listAgreements,@VisibilityId,@CategoryId,0,0);
EXEC [dbo].[AddNotes] @Notes_Data,@User,@Insert_Flag OUTPUT

UPDATE @AddedAgreementData
SET IsUpdated='Y'
WHERE CustomerProfileId=@CustomerProfileId AND AgreementNumber = @AgreementNumber_Val;        

SET @IdVal = @IdVal + 1;
SET @listAgreements=NULL;
END;


------------------------------------------------------------------------

select top 10 * into wwf.WFInstanceChecklist_Test from wwf.WFInstanceChecklist


DECLARE @Src_Tab AS TABLE
(id			INT IDENTITY(1,1),
InstanceID INT,
Wrong_Question NVARCHAR(100),
Correct_Question NVARCHAR(100));

INSERT INTO @Src_Tab VALUES (53,'Option1','Option1_ABK');
INSERT INTO @Src_Tab VALUES (53,'Option2','Option2_ABK');
INSERT INTO @Src_Tab VALUES (797,'Option1','Option1_ABK');
INSERT INTO @Src_Tab VALUES (797,'Option2','Option2_ABK');

SELECT * FROM @Src_Tab

DECLARE @RowVal INT 
DECLARE @IdVal INT
DECLARE @InstanceID_Val INT
DECLARE @Wrong_Question_Val 	 NVARCHAR(100)
DECLARE @Correct_Question_Val  NVARCHAR(100)

SELECT @RowVal = COUNT(*) FROM @Src_Tab;
SET @IdVal = 1 ;

WHILE @IdVal <= @RowVal
BEGIN

	SET @InstanceID_Val = (SELECT InstanceID FROM @Src_Tab WHERE id = @IdVal)
	SET @Wrong_Question_Val = (SELECT Wrong_Question FROM @Src_Tab WHERE id = @IdVal)
	SET @Correct_Question_Val = (SELECT Correct_Question FROM @Src_Tab WHERE id = @IdVal)

	UPDATE wwf.WFInstanceChecklist_Test
	SET ChecklistXML = REPLACE(ChecklistXML,@Wrong_Question_Val,@Correct_Question_Val)
	WHERE InstanceID=@InstanceID_Val
	
	SET @IdVal = @IdVal + 1;
	SET @InstanceID_Val=NULL;
	SET @Wrong_Question_Val=NULL;
	SET @Correct_Question_Val=NULL;

END

SELECT * FROM wwf.WFInstanceChecklist_Test
WHERE InstanceID IN (53,797)





787

InstanceID
53

53
61
239
787
797
812
876
887
911
938



Facts About Abhilash!


Hi Team,

As I have already ordered it using my personal card and amount has already been got deducted.
Also order status is showing as Confirmed.
Could you please let me know what do I need to do get the deducted amount back in my Personal card.
Please find the attached screenshot.

Thanks,
Abhilash Kumar

-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
/* Ethics For Success */




-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------

USICounselorAssignments@deloitte.com
Niketu Bhatt
Nikbhatt

Coach Change Request

Hi Team,

As I have been tagged into TMC Dev group and accordingly my coach should be assigned.
My current coach is Krishnamohan Joshi.
It would be greatly appreciated if you could please initiate the step to change 
it to Deepak Agarwal.
Email Id :- deepagarwal@deloitte.com

Thanks,
Abhilash Kumar


TMC Dev


2021/GIR/3933/BK1/3670
2021/GIR/3933/BK1/3670
2021/GIR/3933/BK1/3670
2021/GIR/3933/BK1/3670



Tax 360 :- 


independence@deloitte.com

Update Tracking & Trading portfolio

Hi Team,
I have updated Tracking & Trading portfolio as per mail instructions.
Please find the attached screenshot.

Thanks,
Abhilash Kumar


Kolkata
Bengal Intelligent Park, Building Omega
13th , 14th Block - EP & GP
Sector - V, Salt Lake
Electronics Complex
West Bengal
700091
Phone :
(033) 6612 1000

Fax :
91 33 6612 1001


/* By Mail */
6th & 7th Floors.
Plot No. 4, Technopolis 
Sector V, Salt Lake, Kolkata 700091
West Bengal
Map link



/* Car Lease */

i20 :- 
MARKET 
FIXED
My ALD Access 
Tohoma

ALD contacts
Name: Pavani Talluri
Email id: pavani.talluri@aldautomotive.com
Phone number: 9502722233
ALD customer car:lets.drivetogether@aldautomotive.com;
Phone number: 18002095253



Name: Mr. Praneel Sharma
Email id: praneel.sharma@orixindiaft.com
Phone number: 91541 40668
Location: Hyderabad Tower 1, Ground floor, Service provider area


For any escalations,

1) anil.k@ORIXindia.com (call Anil on 91601 11559)
2) surjoshankar.sengupta@orixindia.com (call Surjo on 9830786971)

and cc usicarleaseadministration@deloitte.com

https://secure-web.cisco.com/1VB-mccbzUuxTYoIroLCjTXXK9bTzlCmTTOICLdOR2CabJz1artE7uA-pJL7u9OiUTCRN8TUzXv-ypO4GJwlRHbeaworR1jJxfXGTlonVCohqrUwh9e4OVHohhrjA7mUy2O5kl-EbsOpXboH9g7BXKEj419rIS2muF-LwO5QieMbDbU-3DJpOuHMJAgsGA45m-yeFHMLFl-vPuXvO3-K1za0xYGp33hg2QfmG1FfD8OgtJgZ8vNTQHQ7zXBq2EKPKQCzZJByOlKtosY3n4Ake5AEO5m-3S2RgzbpnIqz9-w-eNtUljwHkpeg6kY9awfKoyFENTB2kyOj9Djw2ovkH1aZRHf7ynUTs0elsKQyhIHkpc0fLN0fTs5epaytqpifW33LaWEQboXPI0ZnLtTgffUEVLkdwQwpxrjtmF9QiFRKl9kSTgCRObTf09YNeVKxiqb4CDDjWnA57VF1MezhWCp5u7z24gimnBrdFb9ca5v5e4Ke4sJTxRuzGexjS6zrgdkU5C9iAB9VO2xtZ6dOrbA/https%3A%2F%2FMy ALD-web-prd.azurewebsites.net/assets/ald/images/brand-logo.png
http://secure-web.cisco.com/1OtcYyBSuOZbTEw68PJm_JVoheYlqacmWa2Ej2EmgYDRMafklkqa3nno_GNQI4ruJzSKj3_S91jwJPOzX5V9DqUo5IGW2zGJdXvQrg6DP_mST-D5zyDh_EScLUZRMKgS0F_XWlDZqgxcwYgyJ_I5__EsFk-CQlUOisZN5ZK9N1AsRNbVn2IdhjlSmXcPsg4uVXglvIHczvwh8ZL4PHlJq3eN8IwJmxzbkU0Hu3micoFlf26CsOTcpkdbwu4YqW7Fu0S0JjwlWKxd3rCTZstpmQvX4ZJyBRpMxZ_OuEAIVOxcSThBp7soIvt2AYf7AVzn4F_GwYDsJmGbqZIcCo_wwmfED3xAyVv_LSgGNyMSlvQF6El-6x3DWbk9gsyDpj54uR8XVZQdOxgZauq5Is0MSoksR6W5i7IVnpABeWrTCN3Tw4Wb-9EBN8m6cPTexKXcia-FAeDAiHVMdaiiAR6Inu_wZs6zOT9T8szpCu8-OEv5sUXyEbionhG6ENTKV_wUnId5ndo6Jk9XF-AhNBBB7Jg/http%3A%2F%2Fgo.aldautomotive.com%2Flnk%2FEAAAAvjbzkgAAAAAAAAAAMTFKWUAAAAAX5kAAAAAABBCjwBirKVTcnc9xUoXQC6lWVbl_JBM4AAGPIw%2F1%2FhBc7JaW6z6QTK76tOne8YA%2FaHR0cHM6Ly93d3cubXlhbGQuaW4vc3RhcnQvZW5kLWZvcmdvdC1wYXNzd29yZD9rZXk9NWU1Y2I3ZTItNjZkZC00ODY2LWE0Y2YtNzU2NDE4YmU2M2E2JmN1bHR1cmU9ZW4tdXM



7th July :- 10:00 PM



Project Change :- 
/* https://resources.deloitte.com/sites/dme/people/Pages/ME-HR-Team.aspx */
/* Tax */
Muhtaseb, Lamisse <lmuhtaseb@DELOITTE.com>
Salame, Hadil <hsalame@deloitte.com>
Dcosta, Shynelle <sdcosta@deloitte.com>
Bush, Jodie <jobush@deloitte.com>



ESSsupport@deloitte.com

/* 18th July 2022 */
jjethani@deloitte.com
achakrabartty@deloitte.com


Rajeev Agarwal :- 
TTC USI Lead


rajeaggarwal@deloitte.com 

Hi Rajeev,

This is Abhilash Kumar. Currently working in an internal Project as support engineer in TAX module.
As my profile is completely on Development side but I put in a project where 90% work is based on bugs raised via tickets.
I have never worked as a support engineer and also do not want to continue my career in this direction.

I would like continue my career as Azure Data Engineer on development side where I have past experience on it .
it would be greatly appreciated If you could give some time to discuss on it and Relocate me to any other project on Azure side.

Thanks,









https://rpm.deloitteresources.com/web/reports/team-member

/* Snapshot */
TDM Internal Projects
TDM Internal Projects
LPE04197-01-01-01-0000
LPE04197-01-01-01-0000

01/31/2022 - 06/17/2022

https://rpm.deloitteresources.com/web/reports/team-member
Project description (optional) :- 
deepagarwal@deloitte.com

In this projects I have worked on below Items.
i) Bug Raised by Clients :- 
Ex :- 27434,27572 ,27566,27566,27568,28064,27721,25644
28845,28926,28966,29303,27786,
28754,29540,29486,29611

ii) XML Removal from SP :- 
iii) Scenario Planner DataModel XMLA :- 
iv) Scenario Planner New SPs for DM and UI :- 





https://gtp-tmc2.visualstudio.com/TaxPortal/_workitems/edit/30783/

/* 28th Sept 2022 */
/* https://rpm.deloitteresources.com/web/request-snapshots/request */


06/18/2022 TO 09/30/2022
TDM Internal Projects
TDM Internal Projects
LPE04197-01-01-01-0000
LPE04197-01-01-01-0000
LPE04197-01-01-01-0000

During this period I worked on below Items.
i) Bugs :- 31622,31887,31267, 31328,31250,31021,
31173,31107,31000,23012,30470

ii) SST Pull Design & Implementation :- 
iii) Delete Review Notes User Story :- 
iv) 1042 Data Migration for JPMC :- 


10/01/2022 TO 12/31/2022
TDM Internal Projects
LPE04197-01-01-01-0000

During this period I worked on below Items.
i) All Bugs related to Scenario pack pull classes.
ii) Completed implementation of NEW SST pull design and bug resolve.
iii) Completed analysis and complete development of 1042 data migration.
iv) Data Model Synonym creation

Tasks & Bug :- 
17833 :- 1042 Data Migratio
31859/31890/32502,31861,31960,32876,33012,33178,33309
31328 :- Synonym
Bugs & Task :-  33204,33090,30981,32750,32908,
32937,32907, 32769,30960,32414,32070,32270,32191,32124,31622,
31887,31267,31250,31021,31173,32916,31328
SST Pull :- 31846
 

32124





Voucher Number 		Voucher Pin	Amount	Expiry Date
6000170211079948	113076 		₹1000	2023-09-26
6000170218689541	219833 		₹1000	2023-09-26
6000170217371248	138103 		₹2000	2023-09-26
6000170212830388	149876 		₹2000	2023-08-05
6000170211862294	131726 		₹1000	2023-08-05
ZVCT02AABUIS1GT2 				₹500	30-04-2023
ZVCT02AABQ63M4W2				₹500	30-04-2023
/* zUMBA */
https://deloitte.zoom.us/w/93900737339?tk=K9JVIvR_wKflhbES8RsWA7T6OIWZDKSsBAY8NgkR6vE.DQMAAAAV3OuLOxZxdFRpdzBveFI4YThtUXV0RTFsdHFBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA&pwd=bTJPU00va2hoeWJiU0g5SzlMSVdQUT09&uuid=WN_sW6QeENXS5SxzvLjv_h6sA#success








Hybrid Commuting Reimbursement


Seat Booking Status at Kolkata Office

Hi Deepak,

I raised a seat request yesterday at 12 AM for Kolkata Technopolis office on 31st Oct but it got stuck at waiting list 4.
Please find the attached Screenshot.
Now Magnet APP is not allowing me to book any other seat for that day.


/* Main Address */
6th & 7th Floor.
Plot No 4 Technopolis Sector 5, Salt Lake
Kolkata 700091, West bengal



Himalayan inn guest house, mb 689, Biswa Bangla Sarani, Mahish Bathan, Block, Mohisbathan, Kolkata, West Bengal 700156


Pizza party :- 
Hi Team,
To ease out the pressure of Release 16.1, let us connect for our Pizza Day(Hybrid 😊)  and here are the ground rules to enjoy your meal together and have some fun together.
1.	Place Pizza/food item of your choice from any Food Vendor from your respective location, the max limit will be INR 700/-
2.	Reimburse the same using - LPE08855-01-01-11-0000
3.	To avail this you will have to join the virtual connect tomorrow 
4.	Do review the Business Meals policy and adhere to the guidelines, this is a Non-Alcohol Business Meal during Office Hours.
Note: Do turn on your video to have those face to face interactions  😊.
Please place the order beforehand, so it’s ready during our virtual connect. 
If you have an corporate card, Please use corporate card to order the food. Below is the policy
For group virtual meals, employees should use their individual corporate cards to purchase the meals and submit reimbursement. Gift cards should not be provided to cover the costs.



kapurji colony :- 12km :- 15k :- 3bhk :- 
new town :- 5.4km :- 15k :- 2bhk



[11:46 AM] Agarwal, Deepak
Agarwal, DeepakHope everyone charged the expense in DTE for yesterday's lunch with the WBS provided in my email\invite
Charge code for this is - Reimburse the same using - LPE08855-01-01-11-0000

[11:45 AM] Agarwal, Deepak
Agarwal, DeepakAnd for today afternoon\evening, please order your favorite snack - Rs. 200 per person. Hyd team is ordering donuts. Charge code will be shared by Rizwana
Charge code for this is - 
Reimburse the same using - LPE08855-01-01-05-0000
'


Leave Request Approval

Hi Niketu,

Please take a look into below leave request and approve it.
All are planned PTO.

25th Nov :- Cousin marriage
2nd Dec :- Planned Doctor Visit
8th Dec and 9th Dec :- Property Registration

Thanks,





This is to confirm that your resignation with USI Deloitte has been submitted 
on Deloitte’s online resignation system. Your system generated 
last working date considering 60 days of notice period is 2/6/2023. 
(Please note that, 
the last working date mentioned on the Bidding adieu email (point 3) 
will be considered as your official last date with the firm post 
receiving the confirmation from Talent Engagement Specialist. 
Please await for the official note)


Your unique resignation ID is ELE-74017 Please note that submission 
into the system does not constitute acceptance of your resignation, 
and you are bound by all terms and conditions provided in the 
Non-Disclosure, Non-Solicit and Intellectual Property Rights Assignment 
Agreement until you are finally relieved from the services of the Company. 
On acceptance of resignation and subsequent relieving, you will be bound 
by several post-employment obligations, including Confidentiality 
and Non-Solicitation of personnel and clients.



Office visit on 19th & 20th

Hi Niketu,

On 19th and 20th I will not be able to visit office.
As on 24/25th, a surgery is planned.
During this time I need to be fullly fit and fine.
As I have to travel to kolkata from my home town via train and there is high chance
of getting sick in cold weather.
So please approve this request.

Thanks,



River Scape A, Flat N0 1001,Casa
Rio,Kalyan Shil Road,Nilaje,
Mumbai,421204,MUMBAI,MAHARASHTRA

Flat No 164 23, 
Building Name B P C L Staff Colony, 
Block Sector Chembur, 
Near Ashish Theatre 
MUMBAI, MAHARASHTRA, 400074



682281

682281IPSF202223.zip



Resignation :- 
usiindiaexitmanagement@deloitte.com
USI India Exit Management <USIIndiaExitManagement@deloitte.com> 
Abhishek Agarwal abhishekagarwal@deloitte.com 
 
 
Exception Request for Desktop Pick up Request

Hi Team,

My last working date is on 6th Feb 2023.
I am going to ITS office to return all asstes except my monitor
As it is very big and can not carry along with my other luggage.

Kindly schedule a pick 
It would be highly appreciated if you could please schedule a pick of monitor
from my curreny location OR give me an address I will courier it to that location

Thanks


 Hi Abhilash,

Currently we are not handling any assets pickup request to submit the monitor in person at Deloitte office.

Thanks
Manohar

 
Hi Team,

It came to me via courier.
Kindly give me an address where I can send it through courier only.
It would not be possible for me carry such a big box while travelling along with my other luggage.
Kindly look into it.


mmondol@deloitte.com
Desktop PickUp Request

Hi Milita,

Could you please schedule a pick of Desktop from my home location
or please provide me an address where I can courier it.
As it is impossible for me to carry such a big box along with my other luggage.
Please look into this.

Thanks



performanceIO
operationalAnalyst

/* ITS Kolkata */

9th Floor, PS ARCADIA CENTRAL, Ps Arcadia Central, 4A, Camac St, Kankaria Estates, Elgin, Kolkata, West Bengal 700017


9th Floor, PS ARCADIA CENTRAL, 
Ps Arcadia Central, 4A, Camac St, 
Kankaria Estates, Elgin, Kolkata, West Bengal 700017


08. Return your access card/ID badge
ID Card to be submitted along with other peripherals
Hyderabad,Pune,Kolkata,Chennai-USHydBadging@deloitte.com 
Bengaluru–USBlrBadging@deloitte.com
Mumbai–USMumbaiBadging@deloitte.com 
Delhi–USDelhiBadging@deloitte.com


Asset submission at the office
Detailed information on off-boarding process will be communicated through 
Off- boarding mail which will be sent 1-2 weeks prior to the last date 
on Deloitte & personal email ID.
You can directly visit



please reach out to our Talent CIC team 
at +91 406670 2222 or 1800-2582-2222 (toll free).
 
USHydBadging@deloitte.com 
 
Asset Return at Technopolis Kolkata Office
 
Hi Team,

My last wokring day is on 6th Feb 2023.
I am visitng Kolkata to return my assets.
Could you please confirm can I submit it in Technopolis Office.
Or is there any office where do I need to visit.

US India ELE Separations <USIELESeparations@deloitte.com>
USIIndiaExitManagement@deloitte.com 
 
 
As per trail mail, Please visit at Kolkata ITS Hub from Monday to Friday 
between 0900H to 1800H. for submission Photo ID access with ITS assets. 
in addition You can contact Kolkata security shift cell at +918981747676 
for any on-ground support required from security standpoint. 
Kolkata ITS Hub address details given below for your reference please.
 
Deloitte Consulting India Pvt ltd                
PD Arcadia, 4/A camac street,
Abani Nath Thakur sarani
Kolkaka – 700016
Beside Viva plantaloons
Building name – Taniqs

 /* MAp */
 Deloitte, 11, RDB Blvd, GP Block, Sector V, Kolkata, West Bengal 700091
 
 
 Kankaria Estates, Elgin, Kolkata, West Bengal 700017

 
 Not Recieved bidding adieu email 
 
 
USIIndiaExitManagement@deloitte.com 

Hi Team,

I have not received bidding adieu email as my LWD is on 6th Feb.
Could you please check on this.
Also could you please confirm when will I get my relieving letter.
Will it be send to my personal mail?

Thanks,

 
 
 
 
 
 