amemail.deloitte.com
usindianhpd@deloitte.com

Please charge 8 hours for Tuesday, 
December 14, 2021 to “CEDXXXXX-01-01-01-0000 CONTINUING EDUCATION”. 
Replace the XXXXX with the last five digits of the Cost Center number 
found on your DTE homepage. Please refer to the attached document for further assistance.

-----------------------------------------------------------------------------------------
/* Coach */
Your coach is Krishnamohan Joshi - JKRISHNAMOHAN@DELOITTE.COM
-----------------------------------------------------------------------------------------
/* Personal Information */
Personnel Number:00682281
Company Code:1202
Cost Center:120257224

reply all
abhilaskumar@deloitte.com
abhilaskumar@deloitte.com
Nawadih123
Kum500082TS
Person ID: 00682281 
Personnel number: 00682281
Employee Id :-  682281
0120257224
Company Code :- 1202
Senior Consultant
Senior Consultant TMC ETI USI Hyd

ABHILASH KUMAR
Email: abhilaskumar@deloitte.com
Business: Tax and Legal
Business_Area: Tax and Legal
Business_Line: TMC Enterprise Tax Integration
Country: United States
Level: Senior
Office: Hyderabad



CED57224-01-01-01-0000
Senior Consultant SQL Server
TMC Dev :- 
TMC ETI USI Hyderabad
Coach Name :- 



My Manager
Jen Deutsch

ORGANIZATIONAL INFORMATION :- 
Legal entity: Deloitte TAX India Pvt Lt 
Business area: Tax Management Consulting Business 
line: TMC Enterprise Tax Integration
Industry: NT - Not Designated Practice 
area: TMC - TMC Development myInsight CE Dev

CONTACTS :- 
Coach :- Krishnamohan Joshi
Resource manager :- Jahnavi Billa Jahnavi


RM >>> asmita nayak 
Send email 
cc :- janvi

add skill set

1) TOD :- CE Excellence Page >>> Complete this
REach to buddy for help

2) Which project is allocated send mail to Mohan >>

3) Tuesday 11:00 am to 11:30 2nd tuesday every month zoom call

4) Complete mandatory training

4) Update mysource :- Monday :- Must
5) DTE :- Every Friday :- Must

6) Add certification details

7) 

Hi Asmita,

This is Abhilash Kumar and I have joined Deloitte last month on 6th Dec 2021.
But till now I have not been allocated into any project.
Employee Id :-  682281
Skills Set :- Azure, Azure Data Factory, Azure Databricks using Python, Azure SQL
Database :- Azure SQL Server, Oracle, Teradata
Language :- PL/SQL,Python DB dev, SQL, Unix Shell Scripting

Could you please tag me any project as per my skill set.

Thanks & Regards,
Abhilash Kumar

but your skills are not per the ETI group..... 
ETI group mostly has SAP & Oracle projects
CSG group has Python Azure etc projects


-----------------------------------------------------------------------------------------
/* USI Smartphone Programme */
Samsung Galaxy S20 FE 5G 	:- ₹ 37,199
Samsung Galaxy A52s 5G 		:- ₹ 34,223
Samsung Galaxy M52 5G 		:- ₹ 31,359
Samsung Galaxy A52 			:- ₹ 26,465
Samsung Galaxy M42 5G 		:- ₹ 23,519
Samsung Galaxy M32 5G 		:- ₹ 22,539
Samsung Galaxy M51 			:- ₹ 21,999
Samsung Galaxy A32 			:- ₹ 20,077
Samsung Galaxy F42 5G 		:- ₹ 19,599
Samsung Galaxy M32 			:- ₹ 16,659
Samsung Galaxy A22 			:- ₹ 16,882



Samsung Galaxy A52s 5G 		:- ₹ 34,223 :- 4500 mah, 189gm, 6.5 Inch, Android 11, One UI 3.1,
Qualcomm SM7325 Snapdragon 778G 5G (6 nm), Shared Slot, 128GB 8GB RAM/256GB 8GB RAM
64 + 12 + 5 + 5 :- Rear Camera
32 :- Front Camera



-------------------------------------------------------------------------------------------
/* Name Change :-  */
Hope you’re doing well.
Your new legal name has been successfully updated in the system as requested i.e., 
last name, First name(KUMAR, ABHILASH).

Once the SAP is updated, the changes will reflect after 5 -7 business days in 
other applications such as TOD, DTE and DPN etc. If the changes are not reflecting or 
for changes in Skype/Outlook/Preferred name/Display name, please contact the
 Technology Call Center for further assistance.

We are closing the ticket, please contact Hrcompliance@deloitte.com if you have any queries.



If you have specific questions related to independence, please reach out to complianceonboarding@deloitte.com to discuss your situation with an independence advisor.
Contact us at usdstart@deloitte.com or Deloitte Call Center at 1800 2582 2222.

Hi Team,

Still My name has not been updated in payroll section.
Due to which wrong name is getting printed in salry slip.
Please update this section too.

Please find the attached screenshot.
File NAme :- PAyroll_Wrong_Name

Thanks,
Abhilash Kumar




-------------------------------------------------------------------------------------------



If your Deloitte device is lost or stolen, immediately call 1800 2582 2222 or via live chat.


Info Excelity is now Info Ceridian! 
Please write to Info info@ceridian.com for queries on IPSF, LTA & HR Workways.


Not Able to update PAN, Aadhar and UAN number
Hi Team,

I am trying to update PAN, Aadhar and UAN number in https://ess.excelityglobal.com/ProcessServletSSO
portal.But it is not allowing me to do.It is not editable.
Could you please help me on this.

Thanks,
Abhilash Kumar







Skills Profile can be accessed through your ToD homepage. 
Navigate to My Information 
--> Qualifications & Expertise --> Skills. 
A VPN connection is required to access Skills Profile when working remotely.






Welcome, Abhilash Kumar Abhilash Kumar Personnel 
Number: 00682281 Company Code: 1202 Cost Center: 0120257224	

nAME cHANGE :- 
Your request has been received with the request number: 11244713 
and will be dealt within 2 business days.


/* bANK iSSUE */
If you are having issues editing an account, contact the 
CallCenter at +1 800 DELOITTE (+1 800 335 6488).

/* Send email to general query */
usiobaassignments@deloitte.com [undefined:usiobaassignments@deloitte.com]








Hi Team,

Please find the attached New_Hire Document.
I have digitally signed in the document wherever it was required.
As I have not recieved my Relieving letter yet, So will share on or before 6th Feb.
Couldn't attach my photo in New_Hire Document, so sending it here as an attachment.
Kindly let me know if anything is missing.

Thanks,
Abhilash Kumar
'

Hi Lisa,

I tried my best to give below answers.
1) A fun fact about you :- I have very bad handwriting
2) Your favorite sports team :- Indian Cricket Team
3) Your favorite hobby :- Playing & Watching Cricket
4) Anything else that may be fun to know about you :- I am a fun-loving guy
who loves to visit new new places along with friends and family.

Thanks,
Abhilash 





for charge code :- 
Jethani, Jyoti Pradeep
Jahnavi, Billa <bjahnavi@deloitte.com>


for teams :-
18002582222


Samsung :- Claim it
iPhone :- 

US-NationalPTINMailb@deloitte.com
TPIN Issue

Hi Team,

I could see PTIN Status Confirmation tab in red color where I need to take some
action but when I am tryng to open it is not opening.
Please find the attached screenshot.
Kindly look into this.

Thanks,
Abhilash

180025822222



MCD Contact Number :- • Call 1 877 TOCMPLY (1 877 862 6759) 7 a.m. to 8 p.m. Eastern Time
OR Raise ticket here.
https://selfticket.deloittenet.deloitte.com/supportrequesthome.aspx?catID=4


Deloitte Call Center: Deloitte Call Center is the single point of contact 
for talent, payroll, benefits,
business applications such as DTE and Expense questions, and general technology support.
• Technology Request
• Inside the office – dial 2222
• Outside the office - +1 800 DELOITTE (+1 800 335 6488)
• International - +1 615 882 7777


----------------------------------------------------------------------------------------------
/* Sodexo :- */
https://deloittenet.deloitte.com/PC/PracticeComm/regions/India/SS/Finance/Pages/Sodexo_Meal_Card.aspx
Hyderabad		Sairam Paladi	sairam.paladi@sodexo.com
9618339876

Sodexo :- 103174272792
Activation Code for your Sodexo Card ending with 7526 is 40857564

Sodexo :- 
In case of any immediate assistance please reach out to us on our 
Contact Center numbers 022-6919 6919, 022-4919 6919 (24*7 Support)
In case of any further assistance, feel free to reach us on:
Phone – 022-6919 6919,022-4919 6919 (24x7)
E-mail – Consumer@india.sodexo.com

Sodexo :- 103174272792
Activation Code for your Sodexo Card ending with 7526 is 40857564


E-mail – Consumer@india.sodexo.com

Not able to OPT-IN Sodexo Card
Hi Team,

While opting Sodexo it is saying window was open till 20th Dec.
Due to some technical reason I couldn''t OPT-IN sodexo.
Could you please let me know is there any possiblity to opt in now.
Since I am a new joinee so I have activated the card now.

Thanks,
Abhilash Kumar

----------------------------------------------------------------------------------------------



https://people.deloitte/
https://people.deloitteresources.com/

Prior to the collective disconnect, 
your issues and questions should be directed to usdstart@deloitte.com or 
call 1 800 2582 2222 and select option 2 for help.

Contact USIndiaOfficesW2D@Deloitte.com and USIndiaOnboarding@Deloitte.com 
with questions about week 1.Contact us at usdstart@deloitte.com or Deloitte 
Call Center at 1800 2582 2222.

----------------------------------------------------------------------------------------------
/* DStart */
1) Digital Paperwork :- 
Submit your beneficiary nomination details
i) Nimination Register :- 
https://deloittenet.deloitte.com/PC/PracticeComm/regions/India/SS/Finance/Pages/NOMINATIONS_fin.aspx

ii) Submit your E-nominations on the UAN portal
https://deloittenet.deloitte.com/PC/PracticeComm/regions/India/SS/Finance/Pages/Form11.aspx


2) Technology :- /* Check one more time. So many things are there */
i) Get familiar with technology used daily
https://dstart.deloitte.com/birds-eye-view/task-view/card-detail/63


General guidance on how to order peripherals and accessories for laptops
https://becurious.edcast.eu/pathways/new-hire-center_test_pathway/cards/107512708
/* Check this link for Hybrid Productivity Allowance expense type */
/* Product that can be bought is listed here */
/* Total 15k */


use the Hybrid Productivity Allowance expense type)
https://becurious.edcast.eu/pathways/new-hire-center_test_pathway/cards/107512708


What is the charge code to be used?

Please use your specific WBS (Example: GAAXXXXX-01-01-01-0000)

Charge Code :- GAA57224-01-01-01-0000


Number: 00682281 Company Code: 1202 Cost Center: 0120257224	

Please charge 8 hours for Tuesday, 
December 14, 2021 to “CEDXXXXX-01-01-01-0000 CONTINUING EDUCATION”. 
Replace the XXXXX with the last five digits of the Cost Center number 
found on your DTE homepage. Please refer to the attached document for further assistance.

3) Orientation :- 
i) Plug into life at Deloitte
/* https://dstart.deloitte.com/birds-eye-view/task-view/card-detail/443 */
What do I need to do?
Follow @LifeAtDeloitte on Facebook, Twitter, or Instagram.
Follow @Deloitte on LinkedIn.
Check out the Life at Deloitte site designed to immerse you in Deloitte’s culture.
Who we are
Diversity, Equity, & Inclusion
Corporate Citizenship
Well-being
Listen to the podcasts in the resources section to better understand your Business Chemistry and to empower your well-being.
Review the Deloitte Diversity, Equity, and Inclusion Transparency Report.
Download the WorkWell app. The WorkWell app brings our existing Empowered Well-being resources straight to your mobile device in a convenient and user-friendly format.

ii) Learn about Diversity, Equity, & Inclusion (DEI)
/* https://dstart.deloitte.com/birds-eye-view/task-view/card-detail/438 */

iii) Learn about performance management at Deloitte
/* https://dstart.deloitte.com/birds-eye-view/task-view/card-detail/176 */

iv) Add interests and skills to your Cura Dashboard
/* https://dstart.deloitte.com/birds-eye-view/task-view/card-detail/86 */


----------------------------------------------------------------------------------------------
/* Add Skill */
https://becurious.edcast.eu/me/learners-dashboard

----------------------------------------------------------------------------------------------
/* Solve it */
https://solveit.deloitte.com/

Type problem and get solution.Everything is present there.
Try to use this


----------------------------------------------------------------------------------------------
/* About */
I have total 8 years of experience in IT industry and was working as a specialist data Engineer.
and below are my skills.
Cloud :- Data Engineer in Azure, ADF pipelines, Azure Data Bricks,  Azure SQL, ADLS Gen1/Gen2, Azure Key Vault
Database :-  Oracle (11g,12c,18c), Teradata (13,14,15,16), SQL Server, PL/SQL developer.
Language :- SQL, Python, Unix, PL/SQL
OS :- Linux, Windows

Currently joined deloitte as Senior Tax Consultant at Hyderabad Location.
Looking forward to have a fruitful IT career.


Yes, alligned to Oracle[‎12/‎9/‎2021 2:06 PM]  Jethani, Jyoti Pradeep:  
who is your buddy?
 
ohh yes meanwhile you are not aligned to any projects, so 
update CED on MySource with the hoours you need to complete mandatury trainings

its a continuos education code, used when we are taking or imparting any trainings
yes there too CED followed by RC code 


you can see your RC code on top ribbon on DTE page
timesheet page is called dte

----------------------------------------------------------------------------------------------

/* DLaunch: Deloitte’s Culture of Integrity */

https://ecodeinternal.deloitte.com/home
https://secure.ethicspoint.com/domain/media/en/gui/1357/index.html
https://mcd.deloittenet.deloitte.com/Default.aspx


Based on the content of this course, which are the appropriate resources to turn to for help and reporting of concerns about work-related ethical challenges?
1,2,3

Key points
Glenn Stastny and his team would like to encourage you to remember the following key points as you progress in your career at Deloitte:

You should never feel inclined to attempt to resolve ethical challenges on your own.
When these challenges arise, raise your hand and seek help from colleagues in your managerial chain-of-command, who have more experience and who can collaborate with you to identify the best course of action.
Make sure to consult the many helpful resources Deloitte provides, including our Shared Values, our Code of Ethics, Talent, and the Integrity Helpline, whenever something at work or a client site seems ethically questionable.


You’ve almost reached the end of this course. Take a moment and consider how well you 
can do these things now:

Recognize the Shared Values that articulate who we are and what we stand for at Deloitte.
Apply our Shared Values to various ethical challenges.
Identify components of Deloitte’s Ethics program, which are available to help you.
Next, take another look at our Shared Values in the downloadable resource document. 
Theen, spend some time memorizing them. In the days ahead, you’ll have opportunities to add 
to what you’ve learned about Deloitte’s culture and Shared Values in this course, so you’ll 
be better prepared to take action if you’re faced with or become aware of an ethical 
challenge.

Finally, remember that at Deloitte, when we set high standards, always act with integrity, 
collaborate effectively across the organization, and deliver outstanding value to 
our clients, we can truly thrive.

2) /* Introduction to Deloitte Tracking & Trading */

Welcome to Introduction to Deloitte Tracking & Trading.

This course is made up of eight interactive lessons that you can move through at your own pace. When each lesson and all required activities are completed, the lesson title will be highlighted and marked with a check. Once you’ve completed all the lessons, you will be able to access the final exam. This course will take around 90 minutes to complete.

To begin, select the first lesson, What are my responsibilities?, and you''ll learn how this online training works.

Because of your role in the Deloitte US Firms, you are required to maintain a portfolio of your Financial Relationships in the Tracking & Trading system. This portfolio must be kept current at all times.

After completing the course, you will:

Recognize how the Tracking & Trading system supports Deloitte’s Independence Policy.
Identify Financial Relationships that are attributable to you and require monitoring.
Recognize how the Tracking & Trading system is used to report Financial Relationships.
Identify the responsibilities you have for maintaining - and keeping current - your portfolio in the Tracking & Trading system.

Your requirements
At this stage in your career (a newly hired, directly admitted or promoted Partner or Professional Staff, or other role change), there are three primary compliance areas that require your immediate attention.

Mandatory Learning
Tracking & Trading
Representation

Tracking & Trading
Populate and maintain your Tracking & Trading portfolio in the Deloitte Tracking & Trading system. Enter the name, but not the quantity or value, of certain Financial Relationships. 
Your information must be kept current and 
should be reviewed periodically and whenever there is a change in your Financial Relationships.
**Everyone will have something to report because, at a minimum, the institution where your paycheck is direct deposited is reportable.


Representation
Submit a special purpose representation where you will be asked to respond to a number of questions regarding your compliance with independence and other firm policies in addition to attesting to the completeness of your Tracking & Trading portfolio. Periodic Representations on Independence, Ethics, and Compliance will be required throughout your employment/association with Deloitte.



Maintaining compliance
Your compliance with Independence Policy is monitored by Independence & Conflicts Network. Noncompliance with any of your Independence Requirements is subject to disciplinary action as set forth in APR 105 Expectations Concerning Independence Policies Concerning Ethics and Compliance Standards and the Consequences of Noncompliance. If you are found to be in violation of Independence Policy, the result can be a policy Violation or a regulation Violation. Depending on the severity of the Violation, the consequences can range from a warning to monetary implications and, in rare situations, termination.

Any questions you may have regarding your responsibilities to comply with Independence Policy can be directed to any of the following:

The Compliance HelpDesk
Independence & Conflicts Network
Your local office Audit Professional Practice Director (Audit PPD)
Functional Risk Manager
For contact information, visit the Independence Contacts page on DeloitteNet.




1) Which of the following will review the information supplied in
your Tracking & Trading portfolio?

The SEC/PCAOB/AICPA and internal personnel in Independence & Conflicts Network will 
review the information supplied in your Tracking & Trading portfolio.

2) 
If you do not comply with Independence policy, you are subject to disciplinary action. Noncompliance with any of your Independence Requirements is subject to disciplinary action as set forth in APR 105 Expectations Concerning Ethics and Compliance Standards and the Consequences of Noncompliance.
The Tracking & Trading system will help you maintain compliance with Independence Policy and is your responsibility to maintain. Your information must be kept current and should be reviewed whenever there is a change in your Financial Relationships.
The My Compliance Dashboard will list your outstanding independence requirements in detail and provide due dates.
The solution to the exercise is now shown.

/* all True */





Abhilash Kumar abhilaskumar@deloitte.com
Aarti S
Abhijit Roy
Apoorva S
Avishek Majumdar
Mishra Subhrata
Mohak Sethi
Prakhar Goyal
Sejal Jain
Sharma Preeti
Shravan H
Shrey Agarwal
Sreenivas Avula Shanmuka
TAnvi Mittal


Staffit Aceesss :- 
https://deloitteglobal.service-now.com/sp/?id=form&table=sc_req_item&filter=&sys_id=872bed6c87ac0910717520ee8bbb35fa&v=


I joined Deloitte on 6th Dec.Still I haven''t got access to staffit.

· Relevant screenshot/screenshot of the error message (if any) :- Attached
· Your role in STAFFIT (Practitioner, Resource Requester or Resource Manager): Senior Consultant
· Device/browser details :- Chrome
· Are you using a Deloitte managed laptop or your personal laptop? :- Deloitte managed laptop
· Are you connected to VPN? :- Tried both
· Steps to reproduce the issue. :- Open https://staffit.deloitteresources.com/saml2/sp/acs



6:20 PM :- 4:50 AM


6:20 PM =4:50 AM


HelpCenterTeam@csod.com
Completed Training not reflecting

Hi Team,

I have completed "Deloitte Time and Expense Reporting in US" on 21st Dec 2021.
Still it is not reflecting as completed in my dashboard.
Please find the completed screenshot.
Please look into this.

Thanks,
Abhilash Kumar


/* Zoom */
Hi Team,

I am trying to login into to my account through zoom app but it is showing error.
Please find the attached screenshot.

Thanks,
Abhilash Kumar

--------------------------------------------------------------------------------------------
/* Teams Access */
https://deloitteus.service-now.com/sp?id=sp_kb_article&sys_id=f5fcbe1bdb521414cc9662eb8a9619b3

--------------------------------------------------------------------------------------------
/* Medical Health */
/* Bajaj */
https://ecard.bajajallianz.com/hCard/Health_Ecard/hlth_cardlogin.jsp

Health Card :- 
C:\Users\abhilaskumar\Desktop\Abhilash\HealthCard_DTS-22-682281.pdf

Policy Document :- 
C:\Users\abhilaskumar\Desktop\Abhilash\MedicalInsurancePolicyGuide1805.pdf
/* Everything is present in this document */

abhi.k.cvraman@gmail.com
8093772483
30-Nov-2021
04-Dec-2021
diarrhea 

abhilaskumar@deloitte.com
Policy Number : OG-22-1919-8403-00000105
ID Card No : DTS-22-682281
Policy Number : OG-22-1919-8403-00000105
Valid Up To : 31-Aug-2022
Name : KUMAR ABHILASH
Gender : Male
Date of Birth : 08-Jan-1991
Age : 30
ID Card No : DTS-22-682281
Company Name : DELOITTE TAX SERVICES INDIA PRIVATE LIMITED

Claim Number	OC-22-1002-8403-00225206
Please note your reference number IN-1002-5161127 before uploading the documents.


You have not register your Mobile Number. 
Please contact health@bajajallianz.co.in

mobile number registration

Hi Team,

Also kindly add my phone number in my account.
Mobile Number :- 8093772483
EMail Id :- abhilaskumar@deloitte.com

Thanks,
Abhilash Kumar

health@bajajallianz.co.in

Hi Team,

My Contact detail is already updated in deloitte portal.
Could you please took that and update in your portal.
Please find the attached screenshot.

Thanks,
Abhilash Kumar


--------------------------------------------------------------------------------------------
/* Medibuddy */
https://mbportal.medibuddy.in/DeloitteBBNew.aspx
/* Check any cost is there or not and register */

Helpline contact number - +91 99999 91555
Helpline email id - hello@medibuddy.in
Escalation contacts – Deloitte: usindiaotherbenefits@DELOITTE.com
CIC - 2222 or 1800-D-E-L-O-I-T-T-E


--------------------------------------------------------------------------------------------
/* Vintage Circle */
https://deloitte.vantagecircle.com/myaccount/redeem
Check about reedem of Gift Card 

--------------------------------------------------------------------------------------------
/* Car Lease */
https://deloittenet.deloitte.com/TalentOnDemand/Benefits/USI/AdditionalPrograms/Pages/CarLeaseProgram.aspx

--------------------------------------------------------------------------------------------
/* Subsidy on certain item worth 25000 / 25K */
C:\Users\abhilaskumar\Desktop\Abhilash\WellbeingSubsidyProgramDocument.pdf
C:\Users\abhilaskumar\Desktop\Abhilash\WellbeingSubsidyFAQs.pdf
/* Must Check and buy certain item */

https://resources.deloitte.com/sites/US/About/Policies/Admin/Pages/home.aspx?India_500_520_CP

please contact the Deloitte Contact Center at +1 800 2582 2222 or x2222 

Fitness equipment (including bicycles, treadmills, yoga mats, and running shoes)

Sports and recreational classes (including sport league fees, court rentals, gardening, and music classes)
Fitness technology (including smart watches, activity trackers, and consoles)
Gym memberships (including fitness-related classes, and online classes/subscriptions)
Ergonomic office furniture (including desks, chairs, and lumbar support)
Sustainable/Societal well-being (including composting equipment, gardening supplies, 
and electric vehicle charging equipment)

 
 
--------------------------------------------------------------------------------------------
/* Benefit Programme */
https://dstart.deloitte.com/birds-eye-view/task-view/card-detail/69
/* Must Look into all link */

--------------------------------------------------------------------------------------------
/* Education Centre */
https://becurious.edcast.eu/pathways/new-hire-center_test_pathway

/* Check how is it */

--------------------------------------------------------------------------------------------
/* Office Address */
HYDERABAD-BLOCK D
4TH FL RMZ FUTURA BLOCK D, PLOT NO.14&15 ROAD NO.2, HITEC CITY LAYOUT, MADHAPUR, HYDERABAD, 500081, India

--------------------------------------------------------------------------------------------
/* Leave */
https://deloittenet.deloitte.com/TalentOnDemand/Benefits/USI/Leaves/pages/PaidTimeOffProgram.aspx

The PTO program offers all eligible USI professionals 30 days of accrued leave and 9 days of 
Additional Medical Leave totaling to 39 days. 

In the new program, the leaves are organized as 
18 Privileged leaves (PL), 
12 Casual/Sick leaves (CL/SL), and 
9 Additional Medical Leaves (AML).

File NAme :- C:\Users\abhilaskumar\Desktop\Abhilash\Leave Rule.jpg

/* Leave In Cash */
https://deloittenet.deloitte.com/TalentOnDemand/Benefits/USI/Leaves/Pages/ApplyforaLeaveUSI.aspx

--------------------------------------------------------------------------------------------
/* Referral */
https://deloittenet.deloitte.com/PC/PracticeComm/regions/India/SS/Talent/Pages/USIndiaTalentReferralProgram.aspx

--------------------------------------------------------------------------------------------
/* Investment */
You can submit your investment proofs till January 14, 2022, 11:59 p.m. (IST).
All investment proofs will be accepted as per the IPSF guidelines only.

1. Visit HR Workways: https://talentsites.deloittenet.deloitte.com/vendorsso/indiapayroll.aspx
2. Visit 'Year-end’ > 'IPSF 2021-2022’
3. Enter your investment details and generate the bar-coded IPSF report.
4. Scan/take picture of all proofs, and digitally sign all system generated IPSF forms along with the supporting documents (in .pdf format)
5. Zip all the proofs and the IPSF bar-coded sheet in a folder and rename it using the guidelines given in the process document as part of the IPSF kit.
6. Visit Image Upload > Upload IPSF Proof Images and upload your zip folder.


Flat No 164 23, Building Name B P C L Staff Colony, 
Block Sector Chembur, 
Road Near Ashish Theatre 
MUMBAI, MAHARASHTRA, 400074


IDFC Tax Advantage (ELSS) Direct Plan
Growth
3256245/38 05 Oct 2021 29,998.50 Groww
2
MOTILAL OSWAL LONG TERM EQUITY
FUND - DIRECT GROWTH
91028749052 12 Jul 2021 19,999.00 Groww
3 Axis Long Term Equity Direct Plan Growth 91048163743 14 Sep 2021 49,997.50 Groww
4
Axis Long Term Equity Fund - Direct -
Growth
91048163743 01 Jun 2021 9,999.50 Groww


LARSEN and TOUBRO INFOTECH LIMITED


--------------------------------------------------------------------------------------------
Hi Team,

As 24th Dec 2021 was a holiday. So I Kept my timesheet 0 for that day.
But now I am getting mail regarding missing time and it is under compliance. 
Could you please let me know what would be the charge code for this and
how I can fill it now.Also what would be the time I need to enter.

Since Ongoing week is also a holiday.So hour and charge code do i need to put while
filling timesheet.

Thanks,
Abhilash Kumar


--------------------------------------------------------------------------------------------
/* 70 % */
1) Which of the following is NOT one of the Principles of the Global Principles of Business Conduct (Global Code)?
Professional development and support
Respect, diversity, and fair treatment
Social responsibility
Accountability :- T

2) We do not condone illegal or unethical behavior by our suppliers, contractors and alliance partners” is a commitment from which Principle in the Global Principles of Business Conduct (Global Code)?
Integrity :- T
Social responsibility
Responsible supply chain
Fair business practices

3) When using the Ethical decision-making model, which of the following do you NOT need to consider when considering alternative actions and their outcomes/consequences?
How the actions align with our Principles and Values
T :- What actions or behaviors are allowed at competitor organizations
If there are applicable policies, laws, or regulations
How the actions might impact our business strategy or objectives


4) When is the best time to consult?
After assessing the dilemma’s risks and sensitivities
At any time :- T
After identifying an ethical dilemma
Upon suspecting an ethical dilemma


5) Which of the following would NOT be an appropriate resource to consult if you suspect misconduct?
Your manager/supervisor or other trusted leaders
Talent
The ethics officer
T :- Former Deloitte colleagues who might have had similar experiences :- T

6) Of the following responses to a situation, which are likely indicators of an ethical dilemma?
T :- You feel embarrassed to tell family, friends, or co-workers.
T :- You are personally uncomfortable about the course of action. :- 
T :- You are concerned whether a course of action is illegal or unethical. :- 
T :- You wonder whether someone’s behavior is unfair and dishonest.

7) Who is responsible for speaking up about misconduct which has been witnessed within a team?
Only those who were directly involved
Only those who are sure misconduct is occurring
Only the team leader
T :- Everyone who witnessed or suspects the misconduct

8) Which of the following are steps of the Ethical decision-making model?
Consider alternative actions and their outcomes/consequences.
Identify the dilemma and assess the potential risks.
Evaluate the potential profitability of your best course of action.
T :- Decide the best course of action and implement it.


9) “We are straightforward and honest in our professional opinions and business relationships” is a commitment from which Principle in the Global Principles of Business Conduct (Global Code)?
Integrity :- T
Respect, diversity, and fair treatment
Professional development and support
Professional behavior

10) Which statement about the Global Principles of Business Conduct (Global Code) is FALSE?
It provides the foundation for how our people hope to behave most of the time.
T :- It calls for compliance with the Global Code, member firm codes of conduct, and related Deloitte policies.
It asserts that we have a responsibility to raise our voice when we become aware of anything inconsistent with it.
It states that retaliation against those who raise ethical concerns in good faith is not tolerated.
========================================================================================================
/* 80 % */
1) Which of the following must occur prior to engaging, contracting with, or assigning client work to third parties?
Interview the third parties and conduct an internet search to make sure there are no negative press articles about them

T1 :- Submit third parties to the Anti-Corruption Compliance Group for a risk and compliance assessment

Submit third parties to the Third-party Risk Management Gateway for a risk and compliance review

Coordinate with ITS and Talent to get them access to the Deloitte network and Deloitte buildings


2) Which of the following would not be considered an “Export” for the purposes of Export Controls?
T1 :- Sending an email discussing project timelines to a Deloitte team member outside of the United States, when no Export Controlled information is in the email

Presenting Export Controlled information via Skype on a conference call with a Non-US Person

Taking a hard drive with Export Controlled information abroad on a trip, but not using it

Dialing in via remote VPN to a server with Export Controlled information on it from outside of the United States

3) Is it acceptable to pass a resume of a Foreign Official client’s nephew to Talent, even if Deloitte is pursuing an opportunity with that client?
T1 :- No, because it could be considered “Anything of Value”

Yes, as long as the candidate is appropriately qualified for the position

Yes, but you cannot attempt to influence the hiring process or decision or insinuate to the client that you have any ability to do so

Only if it is pre-approved by Deloitte’s Anti-Corruption Compliance Group

4) For the purposes of the FCPA, which of the following most closely reflects the concept of “corrupt intent“?
The intent to talk to a client about Deloitte’s services

T1 :- The intent to unfairly secure a deal

The intent to evade US or foreign income taxes

The intent to unfairly influence an election

5) Which of the following actions with respect to Foreign Officials would likely not be considered providing “Anything of Value” for the purposes of the FCPA?

Scheduling a side trip to an off-site resort location after a meeting with potential clients and paying for their trip costs

Offering gifts to potential clients, such as expensive tickets to sporting events

A product promotion available to all clients and potential clients

T1 :- Inviting a potential client to an invitation-only conference that will promote Deloitte’s profile. Deloitte plans to cover the hotel and dinners for the client and their spouse


6) Which of the following engagements do you think could be affected by Export Controls or Economic Sanctions? Select all that apply.
T1 :- An audit engagement with an aviation firm in a US city that supplies airplanes to the military

T1 :- An M&A consultation with a cybersecurity firm in a non-US country that’s being bought by a US-based corporation

T1 :- An enterprise risk analysis for a US-based firm that supports supply chain operational consulting for the CIA

T1 :- Checking your Deloitte email regarding a project for a US government agency while traveling outside of the US


7) The Foreign Corrupt Practices Act (FCPA) contains a variety of criteria for evaluating whether an act may be a violation of its provisions, but it can essentially be broken down into three fundamental factors. Which of the following is NOT one of the three factors?
Are you dealing with a Foreign Official?

Are you providing “Anything of Value”?

T1 :- Are your actions intended to influence that Foreign Official to use their position to benefit you (or your employer) (i.e., do you have corrupt intent)?

Are you dealing with a sanctioned country?

8) When is it acceptable to hire a Foreign Official’s relative for a Deloitte position?
When the Foreign Official is not currently an active client with Deloitte

When the Foreign Official is only a prospective client

T1 :- When the relative goes through the normal Talent hiring processes and would be the best candidate under any circumstances and neither the Foreign Official nor the Deloitte personnel referring the relative attempted to influence the hiring decision

It’s never appropriate


9) Which of the following is true about sanctions?
Sanctions targets are located in sanctioned countries only

They only pertain to sanctioned countries and industries

T1 :- Sanctions targets can be located anywhere in the world

They only pertain to those dealing with parties who reside in sanctioned countries

10) A third party violated the FCPA while acting as a subcontractor to Deloitte. Which of the following is true about Deloitte’s liability?
If Deloitte was not aware that the third party was engaging in the activity, Deloitte would not be held responsible for the violation

T1 :- Deloitte can be held responsible, even if Deloitte was not aware that the third party was engaging in activity that could result in the violation

Deloitte would be held responsible only if Deloitte was aware that the third party was violating the FCPA but did nothing about it

If, upon learning that the third party was violating the FCPA, Deloitte immediately reported the activity, Deloitte cannot be held responsible for the violation



11) You are working on a Deloitte engagement and developing Software with a high level of encryption for information security purposes. Can you share the Software code with your colleague at Deloitte who is a Non-US Person?

No, encryption codes in Software cannot be shared with Non-US Persons

Yes, if the Non-US Person is located in the United States

T1 :- It may be permissible to share with a Non-US Person, but only if he or she has received the appropriate US government authorization

If the Non-US Person is from an authorized country, the Software code can be shared

12) Which of the following is an example of appropriately transmitting Export Controlled information?
Downloading Export Controlled files while outside the United States

Saving or sharing Export Controlled files on a server that is administered and maintained by Non-US Persons

Sharing Export Controlled Technical Data with a Non-US Person residing in the United States

T1 :- Emailing Export Controlled Technical Data to a US green card holder in the United States

13) What steps should you take if, while working on an engagement with Export Controlled Items and Services, you find that no controls have been put in place to mitigate the risk of sharing data with unauthorized persons?
T1 :- Contact your engagement lead and the Trade Compliance Group and ask for assistance developing a Technology Control Plan

Contact your client and the US Department of Defense for proper authorizations

Do nothing since the engagement team is only US Persons

Contact the Trade Compliance Group and your client
-------------------------------------------------------------------------------------------------
In case of any questions/queries/clarifications, you may contact US India BI team at usindiabi@deloitte.com.
Documents Required: Service Certificate & Relieving Letter



usindiabiemployment@deloitte.com
Relieving Letter

Hi Team,

Please find the attached Relieving Letter of my last employement.
As I have not recieved my Service Certificate yet.
I may recieve this by end of this month.

Thanks,
Abhilash Kumar



Dev Ops ::- Intract Client :- Deployement :- Sai Himakar, Diwakar, Sravani
QA Team :- 
Dev Team :- 
US TSO Dev Team :- UI + DB

Ankush :- Lead
Rama :- MAnagers
MAnoj :- Managers

1) Set up VPN.Check with 
2) UI Access
3) Visual & SSMS :- Ticket & 


Sai Chowdary, Maddipati Himakar <msaichowdary@deloitte.com>; :- Not Available
Sri Varun, Sri Varun <srsrivarun@deloitte.com> 
tvijaymurari@deloitte.com :- Freshers
 
/* Visual Studio Install */
https://my.visualstudio.com/benefits










Password :- 

10.10.0.11
sa
Virtual_01!!

10.10.0.1


Azure :- 
DP 900 :- Basic :- Azure SQL, DB iNstances , Iaas, Paas, File Formate, :- Simple

Dp 201 :- 
Dp 202 :- 

Dp 203 :- ADF & DAtaBricks :- Tough

ADF :- 
Free Subscription :- How to get this from Deloitte.

Azure Data FActory
Azure DAta Bricks :- Python/Scala/Spark SQL
Adls Gen2
Azuer Key VAult
Logic App :- 

Azure Function :- c#, .Net, Python

/* MAnogna for testing */

drop table if exists A
CREATE TABLE A
(id INT,
name nvarchar(10));

Insert into A values (1,'Active');
--Insert into A values (2,'InActive');

drop table if exists B
CREATE TABLE B
(id INT,
name nvarchar(10));

Insert into B values (1,'Active');
Insert into B values (1,'InActive');


SELECT A.id,B.name
from A inner join B on (A.id=B.id and A.name like '%' + B.name + '%')


SELECT A.id,B.name
from A left join B on (A.id=B.id and A.name like '%' + B.name + '%')

SELECT A.id,B.name
from A left join B on (A.id=B.id and B.name like '%' + A.name + '%')

SELECT A.id,A.name,B.name
from A left join B on A.id=B.id and (CHARINDEX(A.name, B.name)>0)

SELECT A.id,B.name
from A left outer join B on A.id=B.id and A.Name like Concat('%',B.Name,'%')

 


SELECT A.id,A.name,B.Id,B.name
from A left join B on (B.name like '%' + A.name + '%')


SELECT DC_ID,ScenarioPackLegalID,* FROM lem.ScenarioAtrributesValues WHERE DC_ID=62

SELECT TAB.ScenarioPackLegalID AS ScenarioPackLegalID
FROM
(
SELECT SAV.DC_ID AS DC_ID,SAV.Value AS Value,SAV.ScenarioPackLegalID AS ScenarioPackLegalID
FROM lem.ScenarioAtrributesValues AS SAV WITH(NOLOCK)
INNER JOIN @FilteredNonParent AS Filters ON (SAV.Value LIKE '%' + Filters.FilterValues + '%')
WHERE ScenarioID=@ScenarioID
GROUP BY SAV.DC_ID,SAV.Value,SAV.ScenarioPackLegalID HAVING COUNT(SAV.DC_ID)>=@FilterCount 
) TAB INNER JOIN @FilteredNonParent AS Filters ON (TAB.DC_ID = Filters.DC_ID)
GROUP BY TAB.ScenarioPackLegalID


------------------------------------------------------------------------

Hi Abhishek,

Please find my Brief Introduction.

I was born on 8th Jan 1991 in Giridih Jharkhand.
I did my schooling from Giridih and Intermediate from Ranchi.
I completed my Engineering from C.V.Raman College Of Engineering.

I have total 8+ Years of experience in IT industry.
Till now I have worked as DB PL/SQL Developer and also worked as Azure Data Engineer.

I am a Smart Worker and Consistent Performer.

I like to play and watch Cricket.
I also like to spend time with family and friends.


------------------------------------------------------------------------
/* Adding As part of Sprint 23 Notes Requirement */
INSERT INTO @AddedAgreementData
SELECT @CustomerProfileId,AgreementNumber,ReasonKey,'N' AS IsUpdated
FROM @TEMPResult
GROUP BY AgreementNumber;

SET @VisibilityId = (SELECT Id from NotesVisibility where Type='Public');
SET @CategoryId = (SELECT Id from NotesCategory where CategoryDesc='Profile');

SELECT @RowVal = COUNT(*) FROM @AddedAgreementData;
SET @IdVal = 1 ;

WHILE @IdVal <= @RowVal
BEGIN
SET @listAgreements = (SELECT TOP 1 'Add Agreement ' + AgreementNumber +' Performed for ' + ReasonKey
FROM @AddedAgreementData WHERE IsUpdated='N') ;

SET @AgreementNumber_Val= (SELECT TOP 1 AgreementNumber FROM @AddedAgreementData WHERE IsUpdated='N');
DELETE FROM @Notes_Data
INSERT INTO @Notes_Data values(@Customerprofileid,@listAgreements,@VisibilityId,@CategoryId,0,0);
EXEC [dbo].[AddNotes] @Notes_Data,@User,@Insert_Flag OUTPUT

UPDATE @AddedAgreementData
SET IsUpdated='Y'
WHERE CustomerProfileId=@CustomerProfileId AND AgreementNumber = @AgreementNumber_Val;        

SET @IdVal = @IdVal + 1;
SET @listAgreements=NULL;
END;


----------------

select top 10 * into wwf.WFInstanceChecklist_Test from wwf.WFInstanceChecklist


DECLARE @Src_Tab AS TABLE
(id			INT IDENTITY(1,1),
InstanceID INT,
Wrong_Question NVARCHAR(100),
Correct_Question NVARCHAR(100));

INSERT INTO @Src_Tab VALUES (53,'Option1','Option1_ABK');
INSERT INTO @Src_Tab VALUES (53,'Option2','Option2_ABK');
INSERT INTO @Src_Tab VALUES (797,'Option1','Option1_ABK');
INSERT INTO @Src_Tab VALUES (797,'Option2','Option2_ABK');

SELECT * FROM @Src_Tab

DECLARE @RowVal INT 
DECLARE @IdVal INT
DECLARE @InstanceID_Val INT
DECLARE @Wrong_Question_Val 	 NVARCHAR(100)
DECLARE @Correct_Question_Val  NVARCHAR(100)

SELECT @RowVal = COUNT(*) FROM @Src_Tab;
SET @IdVal = 1 ;

WHILE @IdVal <= @RowVal
BEGIN

	SET @InstanceID_Val = (SELECT InstanceID FROM @Src_Tab WHERE id = @IdVal)
	SET @Wrong_Question_Val = (SELECT Wrong_Question FROM @Src_Tab WHERE id = @IdVal)
	SET @Correct_Question_Val = (SELECT Correct_Question FROM @Src_Tab WHERE id = @IdVal)

	UPDATE wwf.WFInstanceChecklist_Test
	SET ChecklistXML = REPLACE(ChecklistXML,@Wrong_Question_Val,@Correct_Question_Val)
	WHERE InstanceID=@InstanceID_Val
	
	SET @IdVal = @IdVal + 1;
	SET @InstanceID_Val=NULL;
	SET @Wrong_Question_Val=NULL;
	SET @Correct_Question_Val=NULL;

END

SELECT * FROM wwf.WFInstanceChecklist_Test
WHERE InstanceID IN (53,797)





787

InstanceID
53

53
61
239
787
797
812
876
887
911
938



Facts About Abhilash!





Kumar, Abhilash is inviting you to a scheduled Zoom meeting.

Topic: checklist Discussion
Time: Jan 17, 2022 05:00 PM Mumbai, Kolkata, New Delhi

Join Zoom Meeting
https://deloitte.zoom.us/j/98270962143?pwd=aHRRdmNGblczMlJXSGphNGkzYVpGdz09

Password: 144198

One tap mobile
+13126266799,,98270962143# US (Chicago)
+16465189805,,98270962143# US (New York)

Dial by your location
        +1 312 626 6799 US (Chicago)
        +1 646 518 9805 US (New York)
        +1 720 928 9299 US (Denver)
        +1 213 338 8477 US (Los Angeles)
Meeting ID: 982 7096 2143
Password: 144198
Find your local number: https://deloitte.zoom.us/u/acPs67KHBm

        Join by SIP
			98270962143.144198@zoomcrc.com


Join by H.323
162.255.37.11 (US West)
162.255.36.11 (US East)
221.122.88.195 (China)
115.114.131.7 (India Mumbai)
115.114.115.7 (India Hyderabad)
213.19.144.110 (Amsterdam Netherlands)
213.244.140.110 (Germany)
103.122.166.55 (Australia Sydney)
103.122.167.55 (Australia Melbourne)
209.9.211.110 (Hong Kong SAR)
149.137.40.110 (Singapore)
64.211.144.160 (Brazil)
149.137.68.253 (Mexico)
69.174.57.160 (Canada Toronto)
65.39.152.160 (Canada Vancouver)
207.226.132.110 (Japan Tokyo)
149.137.24.110 (Japan Osaka)
Meeting ID: 982 7096 2143
Password: 144198

Join by Skype for Business
https://deloitte.zoom.us/skype/98270962143

ustmcdevops :- Team Name

-------------------------


10.10.0.45


Hi Abhilash,

Here is the stack trace for wwf.GetTasksByMetadata:

declare @p1 mst.DynamicGlobalFilterInput
insert into @p1 values(N'Jurisdiction',N'United States',N'0',N'2',1,1)
insert into @p1 values(N'TaxProcess',N'Innovation',N'0',N'4',1,1)
insert into @p1 values(N'Project',N'',N'71',N'',1,1)
insert into @p1 values(N'TaskStatus',N'Running',N'0',N'',1,1)
insert into @p1 values(N'TaxYear',N'2022',N'3',N'2022',0,1)

exec wwf.GetTasksByMetaData @Filters=@p1,@sortByColumn=N'DueDate   ASC',@sortDirection=N'',@TaskId=0,@count=100,@userID=1011,@allTasksFlag=0,@dueSoonDays=5,@dateFilter=N'all',@Module=N''

The priority column is being returned with a value of NULL.

SELECT TOP (1000) [ID]
      ,[ItemID]
      ,[DC_ID]
      ,[Value]
      ,[AddOn]
      ,[EditOn]
      ,[AddBy]
      ,[EditBy]
      ,[Archived]
      ,[ParentName]
  FROM [Deloitte.Tax.Database.TaxPortalDOGJ1189].[tpc].[DynamicColsValues_TP2]
  WHERE ItemID=3695

The DC_ID for Priority Column is 78.


your company needs you yo adjust these settings 
your company needs you to adjust these settings to comply with organizational policies


https://expense.deloitte.com/app/
https://uswasfdp.deloitte.com/sap/bc/ui5_ui5/sap/ztime_tge/index.html#/


https://signup.myherbalife.com/contract/en-IN/SignUp/Agreements
1. Prior Associateship or Participation: If the PC or the PC’s spouse owned or participated in an Herbalife Nutrition Associateship or an Herbalife Nutrition Preferred Customer Program, please provide the information requested.

2. Preferred Customer (“PC”) must be at least 18 years of age with a mailing address at a residence in India and must complete this Preferred Customer Application (Application) and submit to Herbalife International India Private Limited (“Herbalife Nutrition”) using the mailing address provided.

3. A PC may be registered with Herbalife International India Private Limited for Preferred Customer program only after an existing Associate of Herbalife Nutrition sponsors him/her.

4. Limitations: The Herbalife Nutrition products purchased under the Program are for the PC’s and PC’s household’s personal consumption. The PC acknowledges that he/she will not: 1) sell Herbalife Nutrition products or services (this obligation continues, even after the Herbalife Nutrition Preferred Customer status is terminated); (2) recruit or sponsor others to be Independent Herbalife Nutrition Associates or Preferred Customers; or (3) be entitled to receive compensation of any kind under the Herbalife Nutrition Sales and Marketing Plan. Reselling Herbalife Nutrition products or recruiting or sponsoring activities may result in the termination of the PC’s Preferred Customer status. If the PC ever wishes to sell Herbalife Nutrition products and build an Herbalife Nutrition business, the PC shall contact his/her Sponsor or call Herbalife Nutrition at 1800-102-2444 for information on how to convert a PC status to Independent Herbalife Nutrition Associate under the PC’s current Sponsor.

5. The relationship between Herbalife Nutrition and the PC shall be solely that of a seller and Purchaser-consumer and, for the avoidance of doubt, not that of an agent and principal in any manner.

6. All sales by Herbalife Nutrition of its products to the PC shall be on terms and conditions as stipulated herein and shall be subject to other terms and conditions as may be specified in Herbalife Nutrition’s official purchase order forms, in any electronic form, as may be amended from time to time at Herbalife Nutrition’s sole discretion without any prior notice to PC. Herbalife Nutrition at its sole discretion may permit the PC to have access to specified/designated websites only and the PC acknowledges that such access shall not be his/her right under any circumstances.

7. PC shall make complete payment for the purchase of products prior to the dispatch / pick-up of the goods, as prescribed by Herbalife Nutrition. PC is eligible for discounted price of the products offered by Herbalife Nutrition, as decided solely by Herbalife Nutrition from time to time.

8. All statutory taxes and levies shall be collected by Herbalife Nutrition from the PC and remitted as per applicable laws from time to time without prior intimation.

9. If the PC fails to pick up the products within 72 hours of such notice for pick up, Herbalife Nutrition shall be entitled to ship the products on “to pay” basis to the current address in Herbalife Nutrition records. On non-receipt of the products by the PC Herbalife Nutrition shall be entitled to dispose the goods/ products on the sole account and risk of the PC in all respects without any further notice to the Preferred Customer and without any liability.

10. Herbalife Nutrition wants its customers to be 100% satisfied with their purchases. If, for any reason, the PC is not completely satisfied with any Herbalife Nutrition product he/she purchased from either Herbalife Nutrition or an Independent Herbalife Nutrition Associate, he/she may return it within 30 days of delivery for a refund of the purchase price or a product exchange. The PC may request a refund by calling us on 1800-102-2444, or by following the instructions on in.MyHerbalife.com. If he/she purchased the product from an Independent Herbalife Nutrition Associate, he/she may also contact the Associate to request a refund or exchange.

11. PC shall not be entitled to advertise the products and/or the business of Herbalife Nutrition nor use of any of the intellectual property of Herbalife Nutrition in any manner whatsoever. However, PC may use/wear Herbalife Nutrition branded materials.

12. In the event a PC wishes to become an Associate of Herbalife Nutrition, they may do so by complying with all the requirements such as by filling in and submitting an application form for Associateship, prior to the commencement of such business operations. In that event, ID number allotted to Preferred Customer status may also remain valid for the status of Associateship, as may be decided by Herbalife Nutrition in its sole discretion provided that the PC after becoming an Associate shall comply with all laws applicable as amended from time to time for his/ her business. Herbalife Nutrition shall neither be responsible nor liable for any noncompliance of laws by him/her.

13. Relationship with PC’s Sponsor: The Herbalife Nutrition Independent Associate who enrolled the PC to the Preferred Customer program is the PC’s Sponsor.

In the event that the PC or the PC’s spouse decide to submit an Herbalife Nutrition Associateship Application while enrolled as a Preferred Customer, the PC’s current Sponsor will remain the Sponsor for the PC’s or the PC’s spouse’s Herbalife Nutrition Associateship.

If the PC or the PC’s spouse decide to become an Herbalife Nutrition Independent Associate or Preferred Customer under another Sponsor, the PC and the PC’s spouse must observe a waiting period ("Period of Inactivity") prior to signing a new Agreement. If the PC or the PC’s spouse perform any activity during the Period of Inactivity, the Period of inactivity will restart. The new starting date for the Period of Activity will be the day after such activity has taken place.

Period of Inactivity for Preferred Customers (not applicable to Associates who convert to Preferred Customer): Preferred Customers may submit an Herbalife Nutrition Associateship or Preferred Customership Agreement under a new Sponsor after 180 consecutive days of no activity (starting from the date of the original application, last renewal, or last order whichever is later). This is allowable on a rolling basis while enrolled as a Preferred Customer.

Period of Inactivity for Associates who convert to Preferred Customer and want to change their Sponsor: Associates who convert to Preferred Customer and want to change Sponsors must fulfill the Preferred Customer waiting period of 180 consecutive days of inactivity (starting from the date of the original application, last renewal, or last order whichever is later), as well as the waiting period applicable to the Associateship level at the time of their conversion to Preferred Customer, prior to signing a new Agreement. These waiting periods may run concurrently, but the later of the two must be fulfilled.

Should the PC or the PC’s spouse enroll as a Herbalife Nutrition Associate under another Sponsor without complying with the Period of Inactivity, Herbalife Nutrition may terminate the Associateship, place it under the original Sponsor (along with any future downline), or take any other action it deems appropriate in its sole discretion.

Activities prohibited during the Period of Inactivity include but are not limited to being involved in the Herbalife Nutrition business in any way, purchasing products utilizing the discount offered through the Preferred Customer Program, referring others to the Preferred Customer Program through the Referral Program (where applicable), engaging in prohibitions per limitations stated in Clause 4: Limitations of this Application.

Note: Visiting a Nutrition Club as a customer is not considered activity.

14. In the event this agreement is terminated, the PC and their spouse may apply for a Preferred Customer Program under a different sponsor only after a lapse of the Period of Inactivity as reflected in Clause 13: Relationship with your Sponsor from the date of termination.

15. Force Majeure: Neither party hereto shall be liable to the other if and to the extent that the performance or delay in performance of any of its obligations under this agreement is prevented, restricted, delayed or interfered with due to circumstances beyond the reasonable control of such party, including but not limited to Government legislations/regulations, fire, floods explosions, epidemics, accidents, acts of nature, wars, riots, strikes, lockouts or other concerned act of workmen and such other events. The party claiming an event of force majeure shall promptly notify the other party in writing and provide full particulars of the cause or event and the date of the first occurrence thereof, as soon as possible after the event and also keep the other party informed of any further developments. The Party so affected shall use its best efforts to remove the cause of non-performance, and the parties shall resume performance hereunder.

16. Upon Herbalife Nutrition receiving a written request from the PC to cancel the Preferred Customer status such PC and their spouse shall not be entitled to the benefits under this Program.

17. The PC is hereby advised that his/her personally-identifiable information (the “Personal Information”) will be used to correspond with him/her for a variety of purposes, such as communications that provide the opportunity to continue the term as a PC, to respond to requests or to provide the PC with information that Herbalife Nutrition may consider to be of interest to the PC (the “Purposes”). The information will be held securely and confidentially and for as long as is necessary for the Purposes. The Personal Information of the PC will be shared with Herbalife Nutrition’s related or affiliated companies, including Herbalife Nutrition companies located outside of India which will ensure the same level of security and confidentiality.

18. The PC agrees that he/she shall not disclose, lend, divulge or otherwise permit any other party to use his/her login ID or password for any purpose whatsoever, including, but not limited to, the purchase of products from Herbalife Nutrition.

19. Herbalife Nutrition reserves the right to reject the Preferred Customer application at its sole discretion. In case of misuse of the Preferred Customer status, Herbalife Nutrition reserves the right to cancel a Preferred Customer registration in the Program and terminate this Agreement.

20. The PC may terminate this agreement at any time by giving a prior written notice of Thirty (30) days to Herbalife Nutrition. In the event that the PC is appointed as an Independent Herbalife Nutrition Associate, this Agreement shall terminate automatically, with immediate effect. Herbalife Nutrition may at any time terminate this Agreement forthwith with cause due to any legal or regulatory requirements by giving a written notice to the PC. In the event Herbalife Nutrition terminates this Agreement for such cause, PC shall not be entitled to re- register for Preferred Customer program.

21. No Assignment: This agreement is entered into on a personal basis, and neither this agreement nor any of the rights or obligations of the PC arising hereunder may be assigned or transferred without the prior written consent of Herbalife Nutrition.

22. The PC hereby specifically agrees that Herbalife Nutrition shall at its sole discretion may change, modify, add, delete, substitute and amend any of the terms and conditions of this Agreement, Declaration and Undertaking, in any manner whatsoever, at any time, without prior notice to the PC.

23. Severability: If any provision of these Terms and Conditions is declared invalid or unenforceable, the remaining provisions shall remain in full force and effect.

24. Arbitration: Herbalife Nutrition tries to resolve any dispute amicably and informally. However, if there is a dispute arising from this Agreement or the sale or use of Herbalife Nutrition products that cannot be resolved informally, the PC and Herbalife Nutrition agree to resolve the dispute by binding arbitration rather than in court. All disputes, differences and/or claims arising from this Agreement or as to the construction, meaning or effect hereof or as to the rights and liabilities of the parties shall be settled by arbitration to be held in Bengaluru, India, in accordance with the provisions of the Arbitration and Conciliation Act, 1996. The award of the arbitrator shall be final and binding on all parties concerned.

25. Governing Law & Jurisdiction: This agreement and all questions relating to its interpretation shall be governed by and construed in accordance with the laws of the Republic of India. This agreement and all transactions between Herbalife International India Private Limited and the PC hereunder, including pursuant to this Preferred Customer Program, are subject to the exclusive jurisdiction of the Courts at Bengaluru, India.


Your Preferred Customer ID
W1C1468434

W1C473443
KUM


You will receive a confirmation email shortly at abhi.cvraman@gmail.com to confirm your application.

Dear Abhilash,

Congratulations on your successful sign up.

We are pleased to inform, based on your online sign up submission, you are now registered as “Preferred Customer”.

Your unique Herbalife Preferred Customer ID No – W1C1468434

As a Preferred Customer you will get these great benefits:

Customers use the products for personal consumption and Purchase them at a discount.
Access to India MyHerbalife.com to order products.
Accumulate points towards higher discount levels.



22100 :- Jamin
5000 :- mutation 1 :- Ashish
5000 :- mutation 2 :- Anup
=32100 :- 

15000 :- Mutation 2 :- Ashish

US-USI BI CE <usindiabiemployment@deloitte.com>

usindiabiemployment@deloitte.com 

Sarvartravels.com :- 07947336301






May  :- 2nd, 23rd & 24th 
June :- 3rd
July :- 26th
Aug  :- 9th,10th,11th


sanjeev.kumar481@outlook.com



Hi Bindish,

As this meeting scheduled randomly so it got unnoticed.
I will make sure to join next time.

If any document is made keeping feedback provided by team members, please share with me. 
I Will Add my points if it is relevent.

Thanks,
Abhilash Kumar


Hi Bindish,

I had a chat with Naveen after our discussion and he said he will share the result today.
But Still he has not shared it.

Since we have data getting dependecy on DevOps team.If that team is not sharing the result
even after sending multiple reminder mail (Keeping You in cc) and chat theen Bug can not be resolved at right time.

Thanks,


Hi Bindish,

As I can see steps to reproduce the bugs are not written properly in any of the bug.
Can we ask QA team to follow a standard input written below.

Steps to Reproduce the bug :- 
/* Detailed Steps */
i) 
ii) 

Actual Result :- /* Result coming now with supporting screeshots */

Expected Result :- 

Additional information :- /* If any */


If this way we will get the bug then it will be easy for us to debug it.

Thanks,



Bhandaridih, Jharkhand 815352

Tax 360 :- Plan for next year
Snapshot :- 
Perform :- Technical 
Firm :- Extra Work



====================================================================================
i) Cardiology George Joseph 
MBBS, MD, DM 
Professor

Cardiology Doctors List Christian Medical College Vellore
Christian Medical College, Vellore
Address: Thorapadi P.O, Vellore, Tamil Nadu
Email: directorate@cmcvellore.ac.in
Website:
www.cmch-vellore.edu
Contact No: 
0416-2282010


George Joseph, MD, DM (Card.). FCSI :- 1
Viji Samuel Thomson, MD, DNB, DM (Card) FIC (Aus)
Sujith Thomas Chacko, MD, DM (Card), FRACP (Cardio)
Mithun Jacob Varghese, MD, DM, DNB
Paul V.George, MD, DM (Card.)
John Jose E., MD, DM (Card)
Oommen George, MD, DM
Sunil Chandy, MD, DM, M.Phil, FRCP
Lijo Varghese, MD, DM
Anoop George Alex, MD, DM
David Chase, MD, DM (Card). Voc. Gradhi



Dr. Hiren Kevadiya (Cardiac Electrophysiologist)
Cardiology :- Hindi



Dr. Oommen George
Dr. Tejas V. Patel
Dr. Hiren Kevadiya (Cardiac Electrophysiologist)
Dr. Aman Chaturvedi
Dr. Pradip Maity
Dr. Deepak Sinha
Dr. T J Pradeep Kumar


Dr. Pratheesh George Mathen
Dr. Rakesh P
Dr. Debasish Danda
Dr. Anooup Gorge Alex
Dr. Rajinderpal Boparai
Dr. Rishiraj Bhatt
Dr. Akja Jha
Dr. Praveen Kumar
Dr. Abira Nousheen
Dr. Praveen Kumar


Dr. O.C. Abraham
Dr. Anand Zachariah




210719W00304
ZFFSML5


Dr. Indranil Dutta
Dr. Kapil Kumawat


Tween craft cartoon video maker animated app




























