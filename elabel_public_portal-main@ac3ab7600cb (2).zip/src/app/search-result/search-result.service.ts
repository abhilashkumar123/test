import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiSchema } from 'src/app/schemas/common-schema';
import { environment } from 'src/environments/environment';

let headers;
declare var GS1DigitalLinkToolkit: any;
@Injectable({
  providedIn: 'root'
})
export class SearchResultService {

  constructor(
    private http: HttpClient
  ) { }
  getProductList = (gs1ElementStrings: string, callback: Function) => {
    let gs1dlt = new GS1DigitalLinkToolkit();
    let gs1DigitalLinkURI;
    try{
      gs1DigitalLinkURI = gs1dlt.gs1ElementStringsToGS1DigitalLink(gs1ElementStrings, false, environment.gs1Url);
    }catch(e){
      alert('Invalid GS1 Element String');
      return;
    }

    // check if the gs1DigitalLinkURI contains query parameters
    let separator = gs1DigitalLinkURI.indexOf('?') > -1 ? '&' : '?';
    // append the query parameters
    gs1DigitalLinkURI += separator + 'linkType=all';

    // Fetch headers
    headers = new Headers();
    headers.append("Accept-Language", "");
    headers.append('Accept', 'application/linkset+json');

    /** Collection */
    let collection = {
      anchor: '',
      itemDescription: '',
    };

    if (gs1DigitalLinkURI.indexOf('9506000134352') !== -1) {
      gs1DigitalLinkURI = gs1DigitalLinkURI.replace(environment.gs1Url, "https://id.gs1.org");
    }
    /** If values are array merge to masterCollection */
    let masterCollection: any[] = [];
    fetch(gs1DigitalLinkURI, { headers })
      .then(response => response.json())
      .then(data => {
        collection = data.linkset[0];

        let values = Object.values(collection);
        values.forEach((value) => {
          if (Array.isArray(value)) {
            masterCollection = masterCollection.concat(value);
          }
        });

        let list = masterCollection.map(item => {
          let lang;
          if (item?.hreflang) {
            lang = item.hreflang[0];
          }
          return {
            url: item.href,
            type: 'fa-cube',
            content: item.type,
            name: item.title || 'Product Information',
            lang: (lang || '').toUpperCase(),
          }
        });

        // remove data with empty url or lang
        list = list.filter(item => {
          return item.url && item.lang;
        }).filter((value, index, self) =>
          index === self.findIndex((t) => (
            t.url === value.url && t.name === value.name && t.lang === value.lang && t.content === value.content
          ))
        )

        if (localStorage.getItem('isHcp') === 'true') {
          collection.anchor += '?linkType=gs1:smpc'
        }
        callback(list, collection.itemDescription, collection.anchor)
      });
  }


}
