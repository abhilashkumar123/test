import { Component, OnInit } from '@angular/core';
import {DomSanitizer} from '@angular/platform-browser';
import { SearchResultService } from './search-result.service';
import { SearchProducts} from '../schemas/common-schema';
import {ActivatedRoute, Router} from "@angular/router";

declare var GS1DigitalLinkToolkit: any;
@Component({
  selector: 'app-search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.css']
})
export class SearchResultComponent implements OnInit {
  list!: SearchProducts[];
  name = "";
  iframeUrl = '';
  gtin = "";
  batch = "";
  gs1ElementStrings = ""
  gs1Array:any;
  isYellow = false;
  isRed = false;
  isNormal = true;
  showNavigationMobileView = true;
  activeItem: any;
  showFrame = true;

  constructor(private sanitizer: DomSanitizer, private searchResultService: SearchResultService, private route: ActivatedRoute,
    private router: Router) { 
    this.route.params.subscribe(params => {
      if(params['gs1ElementStrings']){
        this.gs1ElementStrings = params['gs1ElementStrings'].replaceAll('--',')').replaceAll('-','(');
        return;
      }
      if (params['gtin']) {
        this.gtin = params['gtin'];
        this.gs1ElementStrings = "01" + this.gtin;
      }else{
        alert('No GTIN found');
        return;
      }

      if (params['batch']) {
        this.gs1ElementStrings = "01" + this.gtin + "10" + params['batch'];
      }
      
    });
  }

  ngOnInit(): void {
    const self = this;
    /* Service method to get Product list */
    this.searchResultService.getProductList(this.gs1ElementStrings, (list: SearchProducts[], name:string, url:string) => {
      self.name = name;
      self.list = list;
      
      self.list[0].active = true;
      if (window.innerWidth > 768) {
        this.openIframeUrl(self.list[0], '');
      }
    });

    let gs1dlt = new GS1DigitalLinkToolkit();
    this.gs1Array = gs1dlt.extractFromGS1elementStrings(this.gs1ElementStrings);

    self.isRed = false;
    self.isYellow = false;
    self.isNormal = true;
    
    if(self.gs1Array['17']){
      /* convert yymmdd to timestamp */
      let expiry = new Date('20' + self.gs1Array['17'].substring(0, 2) 
        + '-' + self.gs1Array['17'].substring(2, 4) 
        + '-' + self.gs1Array['17'].substring(4));
      /* check how many more to days to expire */
      let daysToExpire = Math.floor((expiry.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));

      self.gs1Array['17'] = '20' + self.gs1Array['17'].substring(0, 2) 
        + '-' + self.gs1Array['17'].substring(2, 4) 
        + '-' + self.gs1Array['17'].substring(4);
      if(daysToExpire <= 0){
        self.isNormal = false;
        self.isRed = true;
        self.gs1Array['17'] += ` - Expired`
      }else if(daysToExpire < 30){
        self.isNormal = false;
        self.isYellow = true;
        self.gs1Array['17'] += ` - ${daysToExpire} days to expire`;
      }else{
        self.isNormal = true;
      }
    }
  }

  openIframeUrl(list: SearchProducts, device: string) {
    this.showFrame = false;
    if(device === 'sm-device'){
      this.showNavigationMobileView = false;
    }
    this.activeItem = list;
    // check if the url is pdf or not
    setTimeout(() => {
      this.showFrame = true;
      if (list.url.includes('.pdf')) {
        this.iframeUrl = 'https://drive.google.com/viewerng/viewer?embedded=true&url=' + list.url;
        setTimeout(() => {
          this.iframeUrl = this.iframeUrl + '&random=' + Math.random();
        }, 100);
      }else this.iframeUrl = list.url;
      this.list.forEach(listItem => listItem.active = false);
      list.active = true;
    }, 100);
  }

  routingToBackUrl = () => {
    if(!this.showNavigationMobileView){
      this.showNavigationMobileView = true;
      this.activeItem = null;
      return;
    }
    this.router.navigate(['/']);
  }

}
