import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { ZXingScannerComponent } from '@zxing/ngx-scanner';
import { BarcodeFormat } from '@zxing/library';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';

declare var ZXing: any;
declare var GS1DigitalLinkToolkit: any;
@Component({
  selector: 'app-home-banner',
  templateUrl: './home-banner.component.html',
  styleUrls: ['./home-banner.component.css']
})
export class HomeBannerComponent implements OnInit {
  outputData = '';
  showResult = false;
  closeResult = '';
  scannerEnabled = true;
  isHcp = localStorage.getItem("isHcp") == "true" ? true : false;
  isYellow = false;
  isRed = false;
  isNormal = true;

  product: any;
  gs1Array: any;

  @ViewChild('scanner', { static: false })
  scanner!: ZXingScannerComponent;
  @ViewChild('mymodal', { static: false })
  mymodal!: ElementRef;
  @ViewChild('mymodalUpload', { static: false })
  mymodalUpload!: ElementRef;

  constructor(private modalService: NgbModal, private router: Router) { }

  ngOnInit(): void {
  }

  /* Barcode scanning Module show event */
  scanQrcode() {
    /* Barcode scanning result show in a modal */
    this.modalService.open(this.mymodal, { ariaLabelledBy: 'scanModalLabel', windowClass: 'scanModal' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }


  /* Barcode scanning success calback */
  scanSuccessHandler(event: string) {
    if (!this.scannerEnabled) return;
    this.scannerEnabled = false;

    this.product = { rawData: event, validCode: true };
    this.generateData()

    this.showResult = true;
  }

  generateData() {
    var gs1dlt = new GS1DigitalLinkToolkit();
    const self = this;

    if (this.product.rawData.length == 8 || this.product.rawData.length == 12 || this.product.rawData.length == 13) {
      this.product.rawData = this.product.rawData.padStart(14, '0');
      this.product.rawData = "01" + this.product.rawData;
    }

    console.log(this.product);
    if (this.product.rawData.indexOf("http") == 0) {
      try {
        this.gs1Array = gs1dlt.extractFromGS1digitalLink(this.product.rawData);
      } catch (error) {
        this.product.validCode = false
      }
    } else {
      try {
        this.product.rawData = this.product.rawData.replace('0', "0");
        this.gs1Array = gs1dlt.extractFromGS1elementStrings(this.product.rawData);
      } catch (error) {
        this.product.validCode = false
      }
    }

    if (Object.keys(this.gs1Array).length == 0) {
      this.product.validCode = false
    }

    try {
      self.product.gs1ElementStrings = "";
      Object.keys(this.gs1Array).forEach(function (key) {
        self.product.gs1ElementStrings += "(" + key + ")" + self.gs1Array[key] + "";
      });
      self.product.gs1DigitalLinkURI = gs1dlt.gs1ElementStringsToGS1DigitalLink(self.product.gs1ElementStrings, false, environment.gs1Url);
      self.product.gs1ElementStrings = gs1dlt.gs1digitalLinkToGS1elementStrings(self.product.gs1DigitalLinkURI, true);
      self.product.formatedString = self.product.gs1ElementStrings;
    } catch (e: any) {
      console.log(e.message);
    }
    self.product.formatedString = (self.product.gs1ElementStrings || this.product.rawData).replace(/\(/g, ' (').replace(/\)/g, ') ');

    self.isRed = false;
    self.isYellow = false;
    self.isNormal = true;
    if (self.gs1Array['17']) {
      /* convert yymmdd to timestamp */
      var expiry = new Date('20' + self.gs1Array['17'].substring(0, 2)
        + '-' + self.gs1Array['17'].substring(2, 4)
        + '-' + self.gs1Array['17'].substring(4));
      /* check how many more to days to expire */
      var daysToExpire = Math.floor((expiry.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));

      self.gs1Array['17'] = '20' + self.gs1Array['17'].substring(0, 2)
        + '-' + self.gs1Array['17'].substring(2, 4)
        + '-' + self.gs1Array['17'].substring(4);
      if (daysToExpire <= 0) {
        self.isNormal = false;
        self.isRed = true;
        self.gs1Array['17'] += ` - Expired`
      } else if (daysToExpire < 30) {
        self.isNormal = false;
        self.isYellow = true;
        self.gs1Array['17'] += ` - ${daysToExpire} days to expire`;
      } else {
        self.isNormal = true;
      }
    }
  }

  scanAgain() {
    this.showResult = false;
    this.scannerEnabled = true;
  }

  showMore() {
    console.log("show more");

    if (!this.product.validCode) {
      if (this.product.rawData.indexOf("http") == 0) {
        window.open(this.product.rawData, '_blank');
        return;
      } else {
        alert("No GTIN Found");
      }
    }

    if (this.product.gs1DigitalLinkURI.indexOf('9506000134352') !== -1) {
      this.product.gs1DigitalLinkURI = this.product.gs1DigitalLinkURI.replace(environment.gs1Url, "https://id.gs1.org");
    }
    // Fetch headers
    let headers = new Headers();
    headers.append('Accept', 'application/linkset+json');
    fetch(this.product.gs1DigitalLinkURI, { headers })
      .then(response => response.json())
      .then(() => {
        // go to search page
        this.showResult = false;
        this.scannerEnabled = true;
        this.modalService.dismissAll();
        this.router.navigateByUrl('/search/' + this.product.gs1ElementStrings.replaceAll('(', '-').replaceAll(')', '--'));
      }).catch(error => {
        alert("Sorry, There is no GTIN related to this product.");
      });


  }

  uploadBarcodeImage(input: any) {
    const codeReader = new ZXing.BrowserMultiFormatReader();
    const self = this;
    if (input.target.files && input.target.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e: any) {
        input.target.value = null;
        /* get base64 encoded image */
        var base64 = e.target.result;

        const hints = new Map();
        const formats = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17];

        hints.set(ZXing.DecodeHintType.POSSIBLE_FORMATS, formats);
        hints.set(ZXing.DecodeHintType.TRY_HARDER, true);
        codeReader.decodeFromImage(null, base64, hints).then((result: any) => {
          self.product = { rawData: result.text, validCode: true };
          self.generateData();

          /* Barcode scanning result show in a modal */
          self.modalService.open(self.mymodalUpload, { ariaLabelledBy: 'scanModalLabel', windowClass: 'scanModal' }).result.then((result) => {
            self.closeResult = `Closed with: ${result}`;
          }, (reason) => {
            self.closeResult = `Dismissed ${self.getDismissReason(reason)}`;
          });

        }).catch((err: any) => {
          alert("Sorry, Readers were not able to detect the code.");
        })
      };

      reader.readAsDataURL(input.target.files[0]);
    }
  }

  changeHcp(event: boolean) {
    this.isHcp = !this.isHcp;
    localStorage.setItem("isHcp", this.isHcp.toString());
  }

  onSearch(gtin: string, batch: string) {
    /** set gtin to 14 character length if it is either 8, 12, 13 */
    if (gtin.length == 8 || gtin.length == 12 || gtin.length == 13) {
      gtin = gtin.padStart(14, '0');
    }

    let href = "";
    if (gtin.length == 14) {
      /** navigate to search page */
      href = `01/${gtin}`;
    }
    else {
      alert("Invalid GTIN");
      return;
    }

    if (batch.length > 0) {
      href = `01/${gtin}/10/${batch}`;
    }

    var gs1DigitalLinkURI = "";
    gs1DigitalLinkURI = environment.gs1Url + '/' + href;

    // Fetch headers
    let headers = new Headers();
    headers.append('Accept', 'application/linkset+json');
    fetch(gs1DigitalLinkURI, { headers })
      .then(response => response.json())
      .then(() => {
        // go to search page
        this.showResult = false;
        this.scannerEnabled = true;
        this.modalService.dismissAll();
        this.router.navigateByUrl('/search/' + href);
      }).catch(error => {
        alert("Sorry, There is no GTIN related to this product.");
      });
  }

  /* Barcode scanning failure calback */
  scanFailureHandler(event: any) {
    // handle scan failure, usually better to ignore and keep scanning.
  }

  onTorchCompatible(event: any) {
    // handle scan failure, usually better to ignore and keep scanning.
  }

  camerasFoundHandler(event: any) {
    // handle scan failure, usually better to ignore and keep scanning.
  }

  camerasNotFoundHandler(event: Event) {
    // handle scan failure, usually better to ignore and keep scanning.
  }

  scanErrorHandler(event: any) {
    // handle scan failure, usually better to ignore and keep scanning.
  }

  scanCompleteHandler(event: any) {
    // handle scan complete
    if (event != undefined && !this.scannerEnabled) {
      /** get format code */
      this.product.format = event.format;
      /** get barcode name from BarcodeFormat */
      this.product.formatName = BarcodeFormat[this.product.format].replace(/\_/g, "");

      console.log(this.product);
    }
  }

  /* Modal close reason get method */
  getDismissReason(reason: any): string {
    this.showResult = false;
    this.scannerEnabled = true;
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  closeScanner() {
    this.modalService.dismissAll();
  }

}