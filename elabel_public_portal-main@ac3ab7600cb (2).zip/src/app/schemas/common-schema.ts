export enum Status {
  SUCCESS = 'Success',
  EXCEPTION = 'Exception',
  FAILED = 'Failed',
}
export interface HeaderSchema {
  token: string;
  json: string;
}
export interface ApiSchema {
  message: Status;
  response: any;
  status: number;
  statusCode: string;
  timestamp: number;
}

export interface SearchProducts {
  url: string;
  type: string;
  name: string;
  lang: string;
  active: boolean;
}
