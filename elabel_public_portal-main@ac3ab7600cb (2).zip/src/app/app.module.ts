import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { HomeBannerComponent } from './home-banner/home-banner.component';
import { SearchResultComponent } from './search-result/search-result.component';

import { SafePipe } from '../app/search-result/safe.pipe';

import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
// the scanner!
import { ZXingScannerModule } from '@zxing/ngx-scanner';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    HomeBannerComponent,
    SearchResultComponent,
    SafePipe
  ],
  imports: [
    BrowserModule,
    NgbModule,
    // gets the scanner ready!
    ZXingScannerModule,
    AppRoutingModule,
    HttpClientModule
  ],
  exports: [
    SafePipe
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
