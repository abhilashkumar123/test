export const environment = {
  production: true,
  gs1Url: 'https://elabel-qa.azurewebsites.net',
  version: '2.0.0'
};