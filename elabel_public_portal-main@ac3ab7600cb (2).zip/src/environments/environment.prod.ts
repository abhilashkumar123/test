export const environment = {
  production: true,
  gs1Url: 'https://elabel.jnj.com',
  version: '2.0.0'
};
