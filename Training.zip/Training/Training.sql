
----------------------------------------------------------------------------------------------

/* DLaunch: Deloitte’s Culture of Integrity */

https://ecodeinternal.deloitte.com/home
https://secure.ethicspoint.com/domain/media/en/gui/1357/index.html
https://mcd.deloittenet.deloitte.com/Default.aspx


Based on the content of this course, which are the appropriate resources to turn to for help and reporting of concerns about work-related ethical challenges?
1,2,3

Key points
Glenn Stastny and his team would like to encourage you to remember the following key points as you progress in your career at Deloitte:

You should never feel inclined to attempt to resolve ethical challenges on your own.
When these challenges arise, raise your hand and seek help from colleagues in your managerial chain-of-command, who have more experience and who can collaborate with you to identify the best course of action.
Make sure to consult the many helpful resources Deloitte provides, including our Shared Values, our Code of Ethics, Talent, and the Integrity Helpline, whenever something at work or a client site seems ethically questionable.


You’ve almost reached the end of this course. Take a moment and consider how well you 
can do these things now:

Recognize the Shared Values that articulate who we are and what we stand for at Deloitte.
Apply our Shared Values to various ethical challenges.
Identify components of Deloitte’s Ethics program, which are available to help you.
Next, take another look at our Shared Values in the downloadable resource document. 
Theen, spend some time memorizing them. In the days ahead, you’ll have opportunities to add 
to what you’ve learned about Deloitte’s culture and Shared Values in this course, so you’ll 
be better prepared to take action if you’re faced with or become aware of an ethical 
challenge.

Finally, remember that at Deloitte, when we set high standards, always act with integrity, 
collaborate effectively across the organization, and deliver outstanding value to 
our clients, we can truly thrive.

2) /* Introduction to Deloitte Tracking & Trading */

Welcome to Introduction to Deloitte Tracking & Trading.

This course is made up of eight interactive lessons that you can move through at your own pace. When each lesson and all required activities are completed, the lesson title will be highlighted and marked with a check. Once you’ve completed all the lessons, you will be able to access the final exam. This course will take around 90 minutes to complete.

To begin, select the first lesson, What are my responsibilities?, and you''ll learn how this online training works.

Because of your role in the Deloitte US Firms, you are required to maintain a portfolio of your Financial Relationships in the Tracking & Trading system. This portfolio must be kept current at all times.

After completing the course, you will:

Recognize how the Tracking & Trading system supports Deloitte’s Independence Policy.
Identify Financial Relationships that are attributable to you and require monitoring.
Recognize how the Tracking & Trading system is used to report Financial Relationships.
Identify the responsibilities you have for maintaining - and keeping current - your portfolio in the Tracking & Trading system.

Your requirements
At this stage in your career (a newly hired, directly admitted or promoted Partner or Professional Staff, or other role change), there are three primary compliance areas that require your immediate attention.

Mandatory Learning
Tracking & Trading
Representation

Tracking & Trading
Populate and maintain your Tracking & Trading portfolio in the Deloitte Tracking & Trading system. Enter the name, but not the quantity or value, of certain Financial Relationships. 
Your information must be kept current and 
should be reviewed periodically and whenever there is a change in your Financial Relationships.
**Everyone will have something to report because, at a minimum, the institution where your paycheck is direct deposited is reportable.


Representation
Submit a special purpose representation where you will be asked to respond to a number of questions regarding your compliance with independence and other firm policies in addition to attesting to the completeness of your Tracking & Trading portfolio. Periodic Representations on Independence, Ethics, and Compliance will be required throughout your employment/association with Deloitte.



Maintaining compliance
Your compliance with Independence Policy is monitored by Independence & Conflicts Network. Noncompliance with any of your Independence Requirements is subject to disciplinary action as set forth in APR 105 Expectations Concerning Independence Policies Concerning Ethics and Compliance Standards and the Consequences of Noncompliance. If you are found to be in violation of Independence Policy, the result can be a policy Violation or a regulation Violation. Depending on the severity of the Violation, the consequences can range from a warning to monetary implications and, in rare situations, termination.

Any questions you may have regarding your responsibilities to comply with Independence Policy can be directed to any of the following:

The Compliance HelpDesk
Independence & Conflicts Network
Your local office Audit Professional Practice Director (Audit PPD)
Functional Risk Manager
For contact information, visit the Independence Contacts page on DeloitteNet.




1) Which of the following will review the information supplied in
your Tracking & Trading portfolio?

The SEC/PCAOB/AICPA and internal personnel in Independence & Conflicts Network will 
review the information supplied in your Tracking & Trading portfolio.

2) 
If you do not comply with Independence policy, you are subject to disciplinary action. Noncompliance with any of your Independence Requirements is subject to disciplinary action as set forth in APR 105 Expectations Concerning Ethics and Compliance Standards and the Consequences of Noncompliance.
The Tracking & Trading system will help you maintain compliance with Independence Policy and is your responsibility to maintain. Your information must be kept current and should be reviewed whenever there is a change in your Financial Relationships.
The My Compliance Dashboard will list your outstanding independence requirements in detail and provide due dates.
The solution to the exercise is now shown.

/* all True */


--------------------------------------------------------------------------------------------
/* 70 % */
1) Which of the following is NOT one of the Principles of the Global Principles of Business Conduct (Global Code)?
Professional development and support
Respect, diversity, and fair treatment
Social responsibility
Accountability :- T

2) We do not condone illegal or unethical behavior by our suppliers, contractors and alliance partners” is a commitment from which Principle in the Global Principles of Business Conduct (Global Code)?
Integrity :- T
Social responsibility
Responsible supply chain
Fair business practices

3) When using the Ethical decision-making model, which of the following do you NOT need to consider when considering alternative actions and their outcomes/consequences?
How the actions align with our Principles and Values
T :- What actions or behaviors are allowed at competitor organizations
If there are applicable policies, laws, or regulations
How the actions might impact our business strategy or objectives


4) When is the best time to consult?
After assessing the dilemma’s risks and sensitivities
At any time :- T
After identifying an ethical dilemma
Upon suspecting an ethical dilemma


5) Which of the following would NOT be an appropriate resource to consult if you suspect misconduct?
Your manager/supervisor or other trusted leaders
Talent
The ethics officer
T :- Former Deloitte colleagues who might have had similar experiences :- T

6) Of the following responses to a situation, which are likely indicators of an ethical dilemma?
T :- You feel embarrassed to tell family, friends, or co-workers.
T :- You are personally uncomfortable about the course of action. :- 
T :- You are concerned whether a course of action is illegal or unethical. :- 
T :- You wonder whether someone’s behavior is unfair and dishonest.

7) Who is responsible for speaking up about misconduct which has been witnessed within a team?
Only those who were directly involved
Only those who are sure misconduct is occurring
Only the team leader
T :- Everyone who witnessed or suspects the misconduct

8) Which of the following are steps of the Ethical decision-making model?
Consider alternative actions and their outcomes/consequences.
Identify the dilemma and assess the potential risks.
Evaluate the potential profitability of your best course of action.
T :- Decide the best course of action and implement it.


9) “We are straightforward and honest in our professional opinions and business relationships” is a commitment from which Principle in the Global Principles of Business Conduct (Global Code)?
Integrity :- T
Respect, diversity, and fair treatment
Professional development and support
Professional behavior

10) Which statement about the Global Principles of Business Conduct (Global Code) is FALSE?
It provides the foundation for how our people hope to behave most of the time.
T :- It calls for compliance with the Global Code, member firm codes of conduct, and related Deloitte policies.
It asserts that we have a responsibility to raise our voice when we become aware of anything inconsistent with it.
It states that retaliation against those who raise ethical concerns in good faith is not tolerated.
========================================================================================================
/* 80 % */
1) Which of the following must occur prior to engaging, contracting with, or assigning client work to third parties?
Interview the third parties and conduct an internet search to make sure there are no negative press articles about them

T1 :- Submit third parties to the Anti-Corruption Compliance Group for a risk and compliance assessment

Submit third parties to the Third-party Risk Management Gateway for a risk and compliance review

Coordinate with ITS and Talent to get them access to the Deloitte network and Deloitte buildings


2) Which of the following would not be considered an “Export” for the purposes of Export Controls?
T1 :- Sending an email discussing project timelines to a Deloitte team member outside of the United States, when no Export Controlled information is in the email

Presenting Export Controlled information via Skype on a conference call with a Non-US Person

Taking a hard drive with Export Controlled information abroad on a trip, but not using it

Dialing in via remote VPN to a server with Export Controlled information on it from outside of the United States

3) Is it acceptable to pass a resume of a Foreign Official client’s nephew to Talent, even if Deloitte is pursuing an opportunity with that client?
T1 :- No, because it could be considered “Anything of Value”

Yes, as long as the candidate is appropriately qualified for the position

Yes, but you cannot attempt to influence the hiring process or decision or insinuate to the client that you have any ability to do so

Only if it is pre-approved by Deloitte’s Anti-Corruption Compliance Group

4) For the purposes of the FCPA, which of the following most closely reflects the concept of “corrupt intent“?
The intent to talk to a client about Deloitte’s services

T1 :- The intent to unfairly secure a deal

The intent to evade US or foreign income taxes

The intent to unfairly influence an election

5) Which of the following actions with respect to Foreign Officials would likely not be considered providing “Anything of Value” for the purposes of the FCPA?

Scheduling a side trip to an off-site resort location after a meeting with potential clients and paying for their trip costs

Offering gifts to potential clients, such as expensive tickets to sporting events

A product promotion available to all clients and potential clients

T1 :- Inviting a potential client to an invitation-only conference that will promote Deloitte’s profile. Deloitte plans to cover the hotel and dinners for the client and their spouse


6) Which of the following engagements do you think could be affected by Export Controls or Economic Sanctions? Select all that apply.
T1 :- An audit engagement with an aviation firm in a US city that supplies airplanes to the military

T1 :- An M&A consultation with a cybersecurity firm in a non-US country that’s being bought by a US-based corporation

T1 :- An enterprise risk analysis for a US-based firm that supports supply chain operational consulting for the CIA

T1 :- Checking your Deloitte email regarding a project for a US government agency while traveling outside of the US


7) The Foreign Corrupt Practices Act (FCPA) contains a variety of criteria for evaluating whether an act may be a violation of its provisions, but it can essentially be broken down into three fundamental factors. Which of the following is NOT one of the three factors?
Are you dealing with a Foreign Official?

Are you providing “Anything of Value”?

T1 :- Are your actions intended to influence that Foreign Official to use their position to benefit you (or your employer) (i.e., do you have corrupt intent)?

Are you dealing with a sanctioned country?

8) When is it acceptable to hire a Foreign Official’s relative for a Deloitte position?
When the Foreign Official is not currently an active client with Deloitte

When the Foreign Official is only a prospective client

T1 :- When the relative goes through the normal Talent hiring processes and would be the best candidate under any circumstances and neither the Foreign Official nor the Deloitte personnel referring the relative attempted to influence the hiring decision

It’s never appropriate


9) Which of the following is true about sanctions?
Sanctions targets are located in sanctioned countries only

They only pertain to sanctioned countries and industries

T1 :- Sanctions targets can be located anywhere in the world

They only pertain to those dealing with parties who reside in sanctioned countries

10) A third party violated the FCPA while acting as a subcontractor to Deloitte. Which of the following is true about Deloitte’s liability?
If Deloitte was not aware that the third party was engaging in the activity, Deloitte would not be held responsible for the violation

T1 :- Deloitte can be held responsible, even if Deloitte was not aware that the third party was engaging in activity that could result in the violation

Deloitte would be held responsible only if Deloitte was aware that the third party was violating the FCPA but did nothing about it

If, upon learning that the third party was violating the FCPA, Deloitte immediately reported the activity, Deloitte cannot be held responsible for the violation



11) You are working on a Deloitte engagement and developing Software with a high level of encryption for information security purposes. Can you share the Software code with your colleague at Deloitte who is a Non-US Person?

No, encryption codes in Software cannot be shared with Non-US Persons

Yes, if the Non-US Person is located in the United States

T1 :- It may be permissible to share with a Non-US Person, but only if he or she has received the appropriate US government authorization

If the Non-US Person is from an authorized country, the Software code can be shared

12) Which of the following is an example of appropriately transmitting Export Controlled information?
Downloading Export Controlled files while outside the United States

Saving or sharing Export Controlled files on a server that is administered and maintained by Non-US Persons

Sharing Export Controlled Technical Data with a Non-US Person residing in the United States

T1 :- Emailing Export Controlled Technical Data to a US green card holder in the United States

13) What steps should you take if, while working on an engagement with Export Controlled Items and Services, you find that no controls have been put in place to mitigate the risk of sharing data with unauthorized persons?
T1 :- Contact your engagement lead and the Trade Compliance Group and ask for assistance developing a Technology Control Plan

Contact your client and the US Department of Defense for proper authorizations

Do nothing since the engagement team is only US Persons

Contact the Trade Compliance Group and your client
-------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
/* Ethics For Success */
Path :- EthicsForSuccess.docx




-------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------

If you believe that you have observed or know of an actual or potential ethical violation, report the incident or conduct to any of the following resources:
a supervisor
a manager
Talent (HR)
a Partner, Principal, or Managing Director (PPMD)
Integrity Helpline for U.S., India, Mexico, and Israel at http://www.integrityhelp.com, or call:
1-866 850-1485 (within U.S.)
1-503-748-0570 (India and outside U.S.)
001-800-840-7909 (from Mexico)
1-809-21-4405 (from Israel)


APR 213 Harassment Policy (U.S.) for personnel in the U.S.


Hostile Environment
A hostile work environment is one type of harassment under federal and state law.

It describes conduct tied to a protected characteristic
It is offensive to a reasonable person
It is unwelcome and severe or pervasive enough that it makes the work environment hostile

This type of harassment is strictly prohibited by policy and the law. Remember – under some laws, a different standard is used to determine whether conduct constitutes harassment.

Quid Pro Quo
Quid pro quo (or this-for-that) is another type of harassment.

This type is most often associated with sexual harassment
It occurs when a manager or supervisor makes a request for sex, sexual favors or a sexual relationship in exchange for a promise to give a benefit (such as a promotion, new job or salary increase) or threatens to retaliate or take a significant negative action (such as a demotion or pay cut) based on the employee’s response to the request

This is also strictly prohibited by policy and the law.


What Is Sexual Harassment?
Sexual harassment is one form of prohibited, unlawful harassment and a type of sex discrimination. It’s not just about conduct that involves sexual advances, like asking someone out. It’s much broader than that.

Sexual harassment can include:

Unwelcome sexual advances
Requests for sexual favors
Any verbal and physical harassment of a sexual nature
Offensive or sexual remarks about a person’s appearance
Generally offensive comments about men or women
Looking at offensive materials such as pornography
Demanding sex or other favors in exchange for a promotion or other benefit



Protected Characteristics
The term protected characteristic has a very specific meaning. For conduct to be considered prohibited harassment, it must be based on or because of a protected characteristic.

Federal and state law can vary, but some of the most commonly protected characteristics include:

Race
Color
Gender
Sex
Sexual orientation
Gender identity and gender expression
National origin
Disability (including being regarded as disabled)
Religion
Creed
Age (40+)
Pregnancy (including pregnancy, childbirth or related medical conditions)
Genetic information
Marital status
Military or veteran status

Most states also have laws prohibiting harassment, and some provide broader protections.


Potential Consequences
01Violating our Nepotism policy that prohibits these kinds of relationships
02Overlooking policy violations or performance concerns of the employee you are dating
03Claims of a conflict of interest or favoritism by co-workers
04Allegations of coercion, sexual harassment and retaliation by the employee if the relationship sours
05Liability for the organization and, possibly, the manager personally
06If the manager and employee are overly flirtatious at work, it can make others uncomfortable and can lead to claims of harassment






