### Requirements
1. Python 3.9
2. MySQL
3. Python MySQL Connector

### Setup Instructions
```bash
pip install -r requirements.txt
```
```bash
# In ~/.bashrc add

export DBHOST=localhost
export DBNAME=jnj_gs1
export DBUSER=root
export DBPASS=1234
```
```bash
python manage.py migrate
```

```bash
# Django Admin Access and User Creation until integrated with MSFT
python manage.py createsuperuser
```

```bash
# load initial data
python manage.py loaddata fixtures/*.json
```

### Django Admin Access:
```bash
# Update settings.py
DEBUG=True
```

### API Documentation
1. Can be accessed via http://localhost:8000/api/1/ on local
2. Postman collection is available for better structure and testing if required

### TODO:
1. Microsoft Auth Integration
2. User Creation and APIs to get users from MSFT
3. URL Resolver Interface Page
4. Import Functionalities
5. Permission Management Update to Filter Data Dynamically to avoid security issues in API calls

## Set up MSSQL Docker Container
```bash
docker run -e "ACCEPT_EULA=1" -e "MSSQL_SA_PASSWORD=MyPass@word" -e "MSSQL_PID=Developer" -e "MSSQL_USER=SA" -p 1433:1433 -d --name=sql mcr.microsoft.com/azure-sql-edge
```

## Install Node SQL client
```bash
sudo npm install -g sql-cli
```

## Connect to MSSQL
```bash
mssql -u sa -p
```

