from enum import Enum, unique

from django.utils.translation import gettext_lazy as _
from frozendict import frozendict


@unique
class Roles(Enum):
    SuperAdmin = _("Super Admin")
    LEAdmin = _("LE Admin")
    DataEntry = _("Data Entry Operator")
    Approver = _("Approver")


CONSTANTS = frozendict(
    {
        "INVALID_GTIN": _("Please enter a valid GTIN"),
        "UNIQUE_GTIN": _("Product with this Gtin already exists."),
        "UPDATE_ALLOWED_LINK_TYPES_NOT_ALLOWED": _(
            "Update of allowed link types not allowed until relevant data is updated"
        ),
        "UPDATE_PRODUCT_ENTITY_NOT_ALLOWED": _(
            "Update of entity for a product is not allowed until relevant data is updated"
        ),
        "LINK_TYPE_NOT_ALLOWED_LEADMIN": _("Link Type is not allowed by LE Admin"),
        "PRODUCT_NOT_ALLOWED_LEADMIN": _("Product is not allowed for your LE Admin"),
        "DATA_ENTRY_ADMIN_UPDATE_NOT_ALLOWED": _(
            "Update of entity admin for data entry operator is not allowed"
        ),
        "CANNOT_ADD_SUPERADMIN_ENTITY": _("Cannot add super admin to an entity"),
        "CANNOT_ADD_ADMIN_LEADMIN": _("Cannot add admin to LE Admin"),
        "MUST_ADD_ADMIN_DEO_APPROVER": _(
            "Admin is mandatory for Data Entry Operator and Approver"
        ),
        "INVALID_LEADMIN": _("Invalid LE Admin"),
        "RESTRICT_PRODUCTS_LE_ADMIN": _("Cannot assign products to LE Admin"),
        "BOTH_ALL_RESTRICT_PRODUCTS_NOT_ALLOWED": _(
            "Cannot assign products and allow all products together"
        ),
        "CANNOT_REQUEST_URL": _(
            "Only data entry operators  can raise request or resolve change requests"
        ),
        "CANNOT_APPROVE_URL": _(
            "Only approvers  can approve or request change request"
        ),
        "CANNOT_APPROVE_UNTIL_ALL_RESOLVED": _(
            "Cannot approve until all change requests are resolved"
        ),
        "CANNOT_ADD_CHANGE_REQUESTS_AFTER_APPROVAL": _(
            "Cannot add change requests after approval is complete"
        ),
        "ONLY_ONE_DEFAULT": _("Only one default is allowed for each product"),
        "ONLY_LINK_PER_PRODUCT_LANGUAGE": _(
            "Only one link for each product allowed in a language"
        ),
        "PRODUCT_URL_LINK_TYPE_ALLOWED": _(
            "Link Type is not allowed for the product url"
        ),
        "URL_UPDATE_REQUEST_FIELDS_MANDATORY": _(
            "One of product or product url is mandatory to add change request"
        ),
        "PRODUCT_URL_MANDATORY_TO_DELETE": _("Product URL is mandatory to delete"),
        "CANNOT_UPDATE_APPROVER_AFTER_APPROVED": _(
            "Cannot update request data after it is approved"
        ),
        "CANNOT_UPDATE_APPROVER_AFTER_RESOLVED": _(
            "Cannot update change request after it is resolved"
        ),
        "CANNOT_UPDATE_DELETED_RECORD": _("Cannot update deleted record"),
        "INVALID_CHANGE_REQUEST": _("Invalid change request"),
        "ENTITY_NO_ADMIN": _("Admin not added to the entity yet"),
        "NO_ACCESS": _("Do do not have access to perform this action"),
        "INVALID_IDENTIFIER": _("Unsupported Identifier"),
        "INVALID_GTIN_RESOLVER": _("Invalid GTIN Input"),
        "GTIN_NOT_AVAILABLE": _(" Product Information is unavailable "),
        "USER_PRINCIPLE_NAME": _("Principle name is mandatory"),
        "INVALID_PRINCIPLE_NAME": _("Principle name is not valid"),
        "CANNOT_UPDATE_LEADMIN": _(
            "Cannot update LE Admin until corresponding data is resolved"
        ),
        "CANNOT_APPROVE_OWN_REQUEST": _("Approve operation could not be completed for data entered by the same user. This should be approved by a different user."),
        "NO_TWO_DEFAULTS": _("Cannot request for two defaults"),
        "NO_DELETE_ACCESS": _("You do not have access to delete this entry"),
        "NO_DOWNLOAD_ACCESS": _("You do not have access to download"),
        "NO_UPLOAD_ACCESS": _("You do not have access to upload"),
        "ONLY_EXCEL": _("You can only upload excel file"),
        "COL_NUMBER": _("Invalid number of columns in excel"),
        "INVALID_EXCEL": _("Invalid excel"),
        "PRODUCT_URL_NOT_EXIST": _("Product Url Doesn't Exist"),
        "PRODUCT_TWO_CHANGE_REQUESTS": _(
            "Cannot have two change requests for same product, linktype and language at a time"
        ),
    }
)
