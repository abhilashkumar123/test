import string
from typing import Optional
from uuid import uuid4

from django.db.models import Q
from django.http import HttpResponse
from openpyxl.workbook import Workbook
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.protection import SheetProtection
from openpyxl.writer.excel import save_virtual_workbook
from rest_framework.validators import ValidationError

from translatable_constants import CONSTANTS, Roles
from usermgmt.models import (
    EntityRole,
    Product,
    ProductUrl,
    ProductUrlChangeRequests,
    ProductUrlRequest,
    User,
)


class GetLoggedInAdminEntity(object):
    def set_context(self, serializer_field):
        self.user = serializer_field.context["request"].user

    def __call__(self):
        entity_admin_data = EntityRole.objects.filter(
            group__name=Roles.LEAdmin.value, user=self.user
        )
        if entity_admin_data.exists():
            entity_admin_data = entity_admin_data.first()
            return entity_admin_data.entity
        else:
            raise ValidationError(CONSTANTS["NO_ACCESS"])


class GetLoggedInUser(object):
    def set_context(self, serializer_field):
        self.user = serializer_field.context["request"].user

    def __call__(self):
        return self.user


def save_user_from_email(user_details):
    user_email = user_details["mail"].lower() if user_details.get("mail") else None
    user_principal_name = user_details.get("userPrincipalName").lower()
    user_object = User.objects.filter(username=user_principal_name).first()
    if not user_object:
        user_object = User(
            email=user_email,
            username=user_principal_name,
            is_superuser=False,
            is_staff=False,
            is_active=True,
            first_name=user_details.get("givenName"),
            last_name=user_details.get("surname", ""),
            password="removing later on",
        )
        user_object.save()
    user_object.set_unusable_password()
    return user_object


def create_excel(serializer_data, column_data, title, column_validations):
    wb = Workbook()
    ws = wb.active
    column_names = []
    column_values = []
    for key, value in column_data.items():
        column_names.append(key)
        column_values.append(value)
        column_code = string.ascii_uppercase[column_values.__len__() - 1]
        column_validator = column_validations.get(key)
        if column_validator:
            column_validator.add(f"{column_code}1:{column_code}1048576")
            ws.add_data_validation(column_validator)
    ws.title = title
    ws.append(column_names)
    for obj in serializer_data:
        row_values = []
        for column in column_values:
            row = obj
            for key in column:
                if row:
                    try:
                        row = row[key]
                    except Exception:
                        try:
                            row = row.get(key)
                        except Exception:
                            row = None
                    # if row is not string then convert it to string
                    if row and type(row) != str:
                        row = str(row)
            row_values.append(row)
        ws.append(row_values)
    dims = {}
    for row in ws.rows:
        for cell in row:
            if cell.value:
                dims[cell.column_letter] = (
                    max((dims.get(cell.column_letter, 0), len(str(cell.value)))) * 1.2
                )
    for col, value in dims.items():
        ws.column_dimensions[col].width = value
    return wb


def send_file(wb):
    filename = f"{str(uuid4())}.xlsx"
    save_virtual_workbook(wb)
    response = HttpResponse(
        content=save_virtual_workbook(wb), content_type="application/ms-excel"
    )
    response["Content-Disposition"] = f"attachment; filename={filename}"
    return response


def create_sheet_with_list(
    wb: Workbook,
    title: str,
    column_list: Optional[list],
    data_list: list,
    index: int,
    is_hidden: bool,
    is_protected: bool,
):
    sheet = wb.create_sheet(title, index)
    if is_hidden:
        sheet.sheet_state = "hidden"
    if column_list:
        sheet.append(column_list)
    if is_protected:
        sheet.protection = SheetProtection(
            sheet=True, objects=True, selectLockedCells=True, selectUnlockedCells=True
        )
        sheet.protection.enable()
        sheet.protection.set_password("jH437G*n%t")
    for data in data_list:
        row = data if type(data) == list else [data]
        sheet.append(row)


def add_sheet_list_validator(ws, list_formula, target_column):
    column_validator = DataValidation(type="list", formula1=list_formula)
    column_validator.add(f"{target_column}2:{target_column}1048576")
    ws.add_data_validation(column_validator)


def delete_product(product: Product):
    product_urls_to_delete = ProductUrl.objects.filter(product=product)
    product_url_requets_to_delete = ProductUrlRequest.objects.filter(
        Q(product=product) | Q(product_url__in=product_urls_to_delete)
    )
    ProductUrlChangeRequests.objects.filter(
        request=product_url_requets_to_delete
    ).delete()
    product_urls_to_delete.delete()
