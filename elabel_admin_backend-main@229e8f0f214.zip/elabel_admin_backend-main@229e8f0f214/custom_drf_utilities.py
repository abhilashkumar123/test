from collections import OrderedDict
from functools import wraps

from django_filters.rest_framework import DjangoFilterBackend
from drf_queryfields import QueryFieldsMixin
from rest_framework import serializers, status, viewsets
from rest_framework.filters import OrderingFilter, SearchFilter
from rest_framework.pagination import LimitOffsetPagination, _positive_int
from rest_framework.permissions import BasePermission
from rest_framework.response import Response
from rest_framework.validators import ValidationError
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework_simplejwt.tokens import RefreshToken


def drf_methods_not_allowed(func):
    @wraps(func)
    def inner(*args, **kwargs):
        self = args[0]
        request = args[1]
        if getattr(self, "methods_not_allowed", None):
            if request.method.lower() in self.methods_not_allowed:
                return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)
        return func(*args, **kwargs)

    return inner


class JNJLimitOffsetPagination(LimitOffsetPagination):
    def get_paginated_response(self, data):
        meta = {
            "count": self.count,
            "next": self.get_next_link(),
            "previous": self.get_previous_link(),
        }
        return Response(
            OrderedDict([("meta", meta), ("results", data), ("count", meta["count"])])
        )

    def get_limit(self, request):
        if self.limit_query_param:
            try:
                limit_query_param = request.query_params[self.limit_query_param]
                if limit_query_param == "all":
                    return self.count
                return _positive_int(
                    limit_query_param, strict=True, cutoff=self.max_limit
                )
            except (KeyError, ValueError):
                pass

        return self.default_limit


class IsAuthenticatedOrOptions(BasePermission):
    def has_permission(self, request, view):
        return (
            request.method in ["OPTIONS"]
            or request.user
            and request.user.is_authenticated
        )


class JNJModelViewSet(viewsets.ModelViewSet):
    search_fields = tuple()
    filter_backends = (DjangoFilterBackend, OrderingFilter, SearchFilter)

    # @log_timestamps
    @drf_methods_not_allowed
    def retrieve(self, request, *args, **kwargs):
        return super(JNJModelViewSet, self).retrieve(request, *args, **kwargs)

    # @log_timestamps
    @drf_methods_not_allowed
    def list(self, request, *args, **kwargs):
        return super(JNJModelViewSet, self).list(request, *args, **kwargs)

    @drf_methods_not_allowed
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        try:
            serializer.is_valid(raise_exception=True)
        except ValidationError:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        try:
            self.perform_create(serializer)
        except Exception as e:
            message = str(e)
            if e.args and len(e.args) > 0:
                message = str(e.args[0])
            try:
                return Response(eval(message), status=status.HTTP_400_BAD_REQUEST)
            except Exception:
                return Response(
                    {"message": message}, status=status.HTTP_400_BAD_REQUEST
                )
        headers = self.get_success_headers(serializer.data)
        response_needed = request.GET.get("response_needed", None)
        if response_needed:
            return Response(
                serializer.data, status=status.HTTP_201_CREATED, headers=headers
            )
        return Response(status=status.HTTP_201_CREATED, headers=headers)

    @drf_methods_not_allowed
    def update(self, request, *args, **kwargs):
        partial = kwargs.pop("partial", False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        if getattr(instance, "_prefetched_objects_cache", None):
            # If 'prefetch_related' has been applied to a queryset, we need to
            # forcibly invalidate the prefetch cache on the instance.
            instance._prefetched_objects_cache = {}
        response_needed = request.GET.get("response_needed", None)
        if response_needed:
            return Response(serializer.data)
        return Response()

    @drf_methods_not_allowed
    def partial_update(self, request, *args, **kwargs):
        kwargs["partial"] = True
        return self.update(request, *args, **kwargs)

    @drf_methods_not_allowed
    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        try:
            self.perform_destroy(instance)
        except Exception as e:
            message = str(e)
            if e.args and len(e.args) > 0:
                message = str(e.args[0])
            try:
                return Response(eval(message), status=status.HTTP_400_BAD_REQUEST)
            except Exception:
                return Response(
                    {"message": message}, status=status.HTTP_400_BAD_REQUEST
                )
        return Response(status=status.HTTP_204_NO_CONTENT)


def data_validator(serializer_class=None, query_params=False, **kws):
    def decorator(func):
        @wraps(func)
        def inner(self, request, *args, **kwargs):
            data = request.query_params if query_params else request.data
            serializer_class_final = (
                serializer_class if serializer_class else self.get_serializer
            )
            serializer = serializer_class_final(**{"data": data, **kws})
            serializer.is_valid(raise_exception=True)
            return func(
                self,
                request,
                validated_data=serializer.validated_data,
                serializer=serializer,
                *args,
                **kwargs
            )

        return inner

    return decorator


class PermissionCheck(BasePermission):
    def has_permission(self, request, view):
        perms = getattr(view, "permissions_required", None)
        if perms:
            perms = perms.split(".")
            return True
        return True


class JNJModelSerializer(QueryFieldsMixin, serializers.ModelSerializer):
    pass


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user, oauth_token_hash=None):
        token = RefreshToken.for_user(user)
        # Add custom claims
        if oauth_token_hash is not None:
            token["oauth_token_hash"] = oauth_token_hash
        return token
