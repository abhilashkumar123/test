from datetime import datetime

import six
from rest_framework.validators import ValidationError


class ValidateGtin:
    def __init__(self, gtin):
        self.gtin = gtin
        self.fill = 14
        self.valid_lengths = (8, 12, 13, 14, 18)
        self.gtin = self.__clean__()

    def validate(self):
        if not self.gtin.isdigit():
            return False
        elif len(self.gtin) not in self.valid_lengths:
            return False
        else:
            return int(self.gtin[-1]) == self.__checksum__()

    def __clean__(self):
        if isinstance(self.gtin, six.integer_types):
            return str(self.gtin).zfill(14)
        elif isinstance(self.gtin, six.string_types):
            return self.gtin.replace("-", "").strip().zfill(14)
        else:
            raise ValidationError("Expected string or integer type as input parameter")

    def __checksum__(self):
        total = 0
        for (i, c) in enumerate(self.gtin[:-1]):
            if i % 2 == 1:
                total = total + int(c)
            else:
                total = total + (3 * int(c))
        check_digit = (10 - (total % 10)) % 10
        return check_digit


class GS1URLValidators:
    def __init__(self):
        self.identifier_tree = {
            0: [],
            1: [0, 22, 10, 21, 17],
            22: [10, 21, 17],
            10: [21, 17],
            21: [17],
            17: [],
        }
        self.variable_mapping = {
            0: "SSCC",
            1: "GTIN",
            22: "CONSUMER_PRODUCT_VARIANT",
            10: "BATCH_NO",
            21: "SERIAL_NO",
            17: "EXPIRY_DATE",
        }
        self.variable_validators = {
            0: lambda x: self.is_equal(18, x),
            1: lambda x: ValidateGtin(x).validate(),
            22: lambda x: self.min_max_validator(1, 29, x),
            10: lambda x: self.min_max_validator(1, 20, x),
            21: lambda x: self.min_max_validator(1, 20, x),
            17: lambda x: self.validate_datestring(x) and self.is_equal(6, x),
        }

    def is_equal(self, check, value):
        return True if len(value) == check else False

    def min_max_validator(self, min, max, value):
        return True if min <= len(value) <= max else False

    def validate_datestring(self, date):
        try:
            datetime.strptime(date, "%d%m%y")
        except ValueError:
            return False
        return True

    def validate_value(self, identifier, value):
        if identifier not in self.variable_validators:
            return False
        if not self.variable_validators.get(identifier)(value):
            return False
        return True

    def validate_tree(self, input_tree):
        if not len(input_tree) > 0:
            return False
        if not input_tree[0] in [0, 1]:
            return False
        prev_identifier = input_tree[0]
        for identifier in input_tree[1:]:
            if identifier not in self.identifier_tree.get(prev_identifier):
                return False
            prev_identifier = identifier
        return True

    def validate_indentifier_values_tree(self, identifiers, values):
        if not self.validate_tree(identifiers):
            return False
        response_data = {}
        for i in range(len(values)):
            if not self.validate_value(identifiers[i], values[i]):
                return False
            response_data[identifiers[i]] = values[i]
        return response_data


def decompress_url(digital_link_url, host):
    from gs1_util import PyJsHoisted_decompressGS1DigitalLink_

    return PyJsHoisted_decompressGS1DigitalLink_(digital_link_url, False, host).value
