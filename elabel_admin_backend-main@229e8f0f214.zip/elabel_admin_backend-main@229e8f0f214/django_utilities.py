from django.core.exceptions import NON_FIELD_ERRORS, ValidationError
from django.db import models
from django.dispatch import receiver
from django.utils.timezone import now
from django.utils.translation import gettext_lazy as _
from import_export.admin import ImportExportModelAdmin

from translatable_constants import CONSTANTS


class AutoCreatedField(models.DateTimeField):
    """
    A DateTimeField that automatically populates itself at
    object creation.

    By default, sets editable=False, default=datetime.now.

    """

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("editable", False)
        kwargs.setdefault("default", now)
        super(AutoCreatedField, self).__init__(*args, **kwargs)


class AutoLastModifiedField(AutoCreatedField):
    """
    A DateTimeField that updates itself on each save() of the model.

    By default, sets editable=False and default=datetime.now.

    """

    def pre_save(self, model_instance, add):
        value = now()
        setattr(model_instance, self.attname, value)
        return value


class JNJBaseModel(models.Model):
    created = AutoCreatedField(_("created"))
    modified = AutoLastModifiedField(_("modified"))

    def save(self, *args, **kwargs):
        self.full_clean()
        super(JNJBaseModel, self).save(*args, **kwargs)

    def clean_fields(self, exclude=None):
        """
        Clean all fields and raise a ValidationError containing a dict
        of all validation errors if any occur.
        """
        if exclude is None:
            exclude = []

        errors = {}
        for f in self._meta.fields:
            raw_value = getattr(self, f.attname)
            if f.blank and raw_value in f.empty_values:
                continue
            try:
                setattr(self, f.attname, f.clean(raw_value, self))
            except ValidationError as e:
                errors[f.name] = e.error_list

        if errors:
            raise ValidationError(errors)

    def full_clean(self, exclude=None, validate_unique=True):
        """
        Call clean_fields(), clean(), and validate_unique() on the model.
        Raise a ValidationError for any errors that occur.
        """
        errors = {}
        if exclude is None:
            exclude = []
        else:
            exclude = list(exclude)
        self.clean_fields(exclude=exclude)
        # Form.clean() is run even if other validation fails, so do the
        # same with Model.clean() for consistency.
        self.clean()

        # Run unique checks, but only for fields that passed validation.
        if validate_unique:
            for name in errors:
                if name != NON_FIELD_ERRORS and name not in exclude:
                    exclude.append(name)
            try:
                self.validate_unique(exclude=exclude)
            except ValidationError as e:
                errors = e.update_error_dict(errors)
        if errors:
            raise ValidationError(errors)

    def on_pre_save(self, instance, created, *args, **kwargs):
        try:
            instance._pre_save_instance = self.__class__.objects.get(pk=instance.pk)
        except Exception:
            pass
        pass

    def on_post_save(self, instance, created, *args, **kwargs):
        pass

    def on_post_delete(self, instance, **kwargs):
        pass

    class Meta:
        abstract = True


@receiver(models.signals.pre_save)
def search_on_pre_save(sender, instance, *args, **kwargs):
    if issubclass(sender, JNJBaseModel):
        created = getattr(instance, "id") is None
        instance.on_pre_save(instance, created, *args, **kwargs)


@receiver(models.signals.post_delete)
def search_on_post_delete(sender, instance, **kwargs):
    if issubclass(sender, JNJBaseModel):
        instance.on_post_delete(instance, **kwargs)


@receiver(models.signals.post_save)
def search_on_post_save(sender, instance, created, *args, **kwargs):
    if issubclass(sender, JNJBaseModel):
        instance.on_post_save(instance, created, *args, **kwargs)


class IsDeleteBaseManager(models.Manager):
    use_in_migrations = True

    def filter(self, *args, **kwargs):
        if kwargs.get("is_delete") is False:
            return super().get_queryset().filter(*args, **kwargs)
        return self.get_queryset().filter(*args, **kwargs)

    def get_queryset(self):
        return super().get_queryset().filter(is_delete=False)


class BaseModelManagerPatchForMigrations(models.Manager):
    use_in_migrations = True


class JNJBaseIsDeleteModel(JNJBaseModel):
    """
    To use custom manager in reverse lookup refer to https://docs.djangoproject.com/en/2.2/topics/db/queries/#using-a-custom-reverse-manager
    """

    is_delete = models.BooleanField(default=False)
    all_objects = BaseModelManagerPatchForMigrations()
    objects = IsDeleteBaseManager()

    class Meta:
        abstract = True
        default_manager_name = "objects"

    def save(self, *args, **kwargs):
        if self.id:
            old_instance = self.__class__.all_objects.filter(id=self.id).first()
            if (
                self.is_delete
                and old_instance
                and self.is_delete == old_instance.is_delete
            ):
                raise ValidationError(
                    CONSTANTS["CANNOT_UPDATE_APPROVER_AFTER_RESOLVED"]
                )
        super(JNJBaseIsDeleteModel, self).save(*args, **kwargs)


class JNJModelAdmin(ImportExportModelAdmin):
    readonly_fields = ("created", "modified")
    save_as = True

    def get_list_display(self, request):
        updated_list_display = ("id",) + self.list_display + ("created", "modified")
        return updated_list_display

    def get_search_fields(self, request):
        updated_search_fields = ("id",) + self.list_display
        return updated_search_fields


class JNJModelIsDeleteAdmin(JNJModelAdmin):
    def has_delete_permission(self, request, obj=None):
        return False

    def has_change_permission(self, request, obj=None):
        if obj and hasattr(obj, "is_delete") and obj.is_delete:
            return False
        return True

    def get_queryset(self, request):
        return self.model.all_objects.all()
