"""jnj_gs1 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls.static import serve
from django.contrib import admin
from django.urls import include, path, re_path
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenRefreshView

from url_resolver.views import (
    URLResolverView,
    version,
    botminds_proxy,
    indiaapi_dummy,
    template_renderer,
    well_known_gs1resolver,
)
from usermgmt import views as usermgmt_views
from usermgmt.views import LoginView, LogoutView

router = DefaultRouter()
router.register(r"language", usermgmt_views.LanguageViewSet, basename="languages")
router.register(r"auditlog", usermgmt_views.AuditLogViewSet, basename="auditlogs")
router.register(r"country", usermgmt_views.CountryViewSet, basename="countries")
router.register(r"user", usermgmt_views.UserViewSet, basename="users")
router.register(r"linktype", usermgmt_views.LinkTypeViewSet, basename="linktypes")
router.register(r"entity", usermgmt_views.EntityViewSet, basename="entities")
router.register(r"product", usermgmt_views.ProductViewSet, basename="products")
router.register(r"role", usermgmt_views.EntityRoleViewSet, basename="roles")
router.register(r"producturl", usermgmt_views.ProductUrlViewSet, basename="producturls")
router.register(
    r"producturlrequest",
    usermgmt_views.ProductUrlRequestViewSet,
    basename="producturlrequests",
)
router.register(
    r"producturlrequest_changes",
    usermgmt_views.ProductUrlChangeRequestsViewSet,
    basename="producturlrequest_changes",
)


urlpatterns = [
    re_path(r"^static/(?P<path>.*)$", serve, {"document_root": settings.STATIC_ROOT}),
    re_path(r"^assets/(?P<path>.*)$", serve, {"document_root": settings.PORTAL_ASSETS}),
    re_path("admin/", admin.site.urls, name="admin"),
    re_path("api/1/", include(router.urls), name="api"),
    re_path("login/", LoginView.as_view(), name="login"),
    re_path("logout/", LogoutView.as_view(), name="logout"),
    re_path("refresh/", TokenRefreshView.as_view(), name="refresh"),
    path("botminds_proxy/", botminds_proxy, name="botminds_proxy"),
    path("version/", version, name="version"),
    path("template/<str:template_name>/", template_renderer, name="template_view"),
    path("00/<str:unique_code>/", indiaapi_dummy, name="indiaapi_dummy"),
    path(".well-known/gs1resolver", well_known_gs1resolver, name="well-known"),
    re_path("^", URLResolverView.as_view(), name="url_resolver"),
]
