import hashlib
from datetime import datetime

import jwt
import requests
from django.conf import settings
from requests import ReadTimeout
from rest_framework import status
from rest_framework.exceptions import ValidationError

from simplejwt_extensions import decode_jwt


class MSFTOAuth:
    def __init__(self):
        self.config = settings.MICROSOFT_APP_CREDENTIALS
        self.token_endpoint = self.config["TOKEN_ENDPOINT"]
        self.client_id = self.config["CLIENT_ID"]
        self.client_secret = self.config["CLIENT_SECRET"]
        self.authority = self.config["AUTHORITY"]
        self.scope = self.config["SCOPE"]
        self.tenant_id = self.config["TENANT_ID"]
        self.grant_type = self.config["GRANT_TYPE"]
        self.redirect_url = self.config["REDIRECT_URI"]

    def get_access_token_from_code(self, auth_code):
        url = f"{self.authority}{self.tenant_id}{self.token_endpoint}"
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        body = {
            "client_id": self.client_id,
            "scope": self.scope,
            "grant_type": "authorization_code",
            "code": auth_code,
            "redirect_uri": self.redirect_url,
        }
        if (
            self.redirect_url
            != "https://login.microsoftonline.com/common/oauth2/nativeclient"
        ):
            body["client_secret"] = self.client_secret
        response = requests.post(url, data=body, headers=headers)
        return status.is_success(response.status_code), response.json()

    def get_access_token_from_refresh_token(self, refresh_token):
        url = f"{self.authority}{self.tenant_id}{self.token_endpoint}"
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        body = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "scope": self.scope,
            "refresh_token": refresh_token,
            "grant_type": "refresh_token",
        }
        response = requests.post(url, data=body, headers=headers)
        return status.is_success(response.status_code), response.json()


class MSFTGraphAPI:
    def __init__(self, token):
        self.token = token
        config = settings.MICROSOFT_GRAPH_API_CONFIG
        self.base = config["base_url"]
        self.users = config["users_endpoint"]

    def send_request(self, method, url, ignore404=False, **kwargs):
        headers = {"Authorization": "Bearer {0}".format(self.token)}
        try:
            response = requests.request(
                method, url, headers=headers, timeout=10, **kwargs
            )
        except ReadTimeout:
            raise ValidationError("Microsoft Connection timed out")
        if not status.is_success(response.status_code):
            if response.status_code == 404 and ignore404:
                print(f"Microsoft Error: {response.text}")
            else:
                print(f"Microsoft Error: {response.text}")
        return response

    def get_user_details_from_token(self):
        url = (
            self.base
            + "/me?$select=businessPhones,displayName,givenName,jobTitle,mail,mobilePhone,officeLocation,preferredLanguage,surname,userPrincipalName,userType,id,department,city"
        )
        response = self.send_request("GET", url)
        return response.json() if status.is_success(response.status_code) else None

    def search_users(self, search_filter):
        url = (
            self.base
            + "/users?$filter=startswith(displayName, '{0}') or startswith(mail, '{0}') or startswith(userPrincipalName, '{0}')&$select=displayName,givenName,mail,jobTitle,userPrincipalName".format(
                search_filter
            )
        )
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": self.token,
        }
        response = requests.get(url, headers=headers)
        return status.is_success(response.status_code), response.json()

    def get_user_basic_profile(self, user_id):
        if user_id:
            url = f"{self.base}/users/{user_id}"
            response = self.send_request("GET", url)
            return status.is_success(response.status_code), response.json()
        return None


def verify_msft_auth(request):
    auth_header = request.headers.get("Authorization")
    if (
        not request.user.is_anonymous
        and auth_header
        and auth_header.startswith("Bearer ")
    ):
        auth_token = auth_header.split(" ")[1]
        from usermgmt.models import UserOAuthToken

        decoded_access_token = decode_jwt(auth_token)
        user_token_object = UserOAuthToken.objects.filter(
            access_token_hash=decoded_access_token["oauth_token_hash"]
        ).first()
        if user_token_object:
            alg = jwt.get_unverified_header(user_token_object.access_token)["alg"]
            decoded_access_token = jwt.decode(
                user_token_object.access_token,
                algorithms=[alg],
                options={"verify_signature": False},
            )
            token_expiry = datetime.utcfromtimestamp(decoded_access_token["exp"])
            if (token_expiry - datetime.utcnow()).total_seconds() < 600:
                (
                    is_success,
                    new_token_object,
                ) = MSFTOAuth().get_access_token_from_refresh_token(
                    user_token_object.refresh_token
                )
                if not is_success:
                    return False
                access_token = new_token_object["access_token"]
                access_token_hash = hashlib.sha256(access_token.encode()).hexdigest()
                refresh_token = new_token_object["refresh_token"]
                existing_token_object = UserOAuthToken.objects.get(
                    access_token_hash=user_token_object.access_token_hash
                )
                existing_token_object.access_token_hash = access_token_hash
                existing_token_object.access_token = access_token
                existing_token_object.refresh_token = refresh_token
                return existing_token_object
            else:
                return user_token_object
    return False
