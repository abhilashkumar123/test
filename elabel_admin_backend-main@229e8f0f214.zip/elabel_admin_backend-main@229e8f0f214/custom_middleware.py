class CORSMiddleware(object):
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        response[
            "access-control-allow-methods"
        ] = "GET, HEAD, POST, PUT, DELETE, PATCH, OPTIONS"
        response[
            "access-control-allow-headers"
        ] = "Origin,Content-Type,Accept,Authorization,X-CSRFToken,Tab-id,X-SESSIONID"
        response["access-control-allow-origin"] = "*"
        response["X-Frame-Options"] = "ALLOWALL"
        # Access-Control-Expose-Headers
        response["access-control-expose-headers"] = "Link, Content-Length"
        return response
