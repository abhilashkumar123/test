require("dotenv").config()
const gulp = require('gulp');
const git = require('gulp-git');
const path = require('path');
const log = require('fancy-log');
const run = require('gulp-run');
var argv = require('yargs').argv;
const repo_branch = argv.b ?? process.env.BUILD_BRANCH ?? 'main';
const repo_build = argv.c ?? process.env.BUILD_CONFIG ?? 'production';
const repo_path = argv.p ?? process.env.BUILD_PATH ?? 'elabel_public_portal';
gulp.task('print', function (done) {
    log(repo_path);
    done()
});
gulp.task('pull', function (done) {
    git.clone(`https://srajan15@sourcecode.jnj.com/scm/asx-ncyp/elabel_public_portal.git`, { args: path.join(`./${repo_path}` , '/.') }, function (err) {
        if (err) throw err;
        done()
    });
});
gulp.task("switch-branch", function (done) {
    console.log(`switching to ${repo_branch} branch`)
    git.checkout(`${repo_branch}`, { quiet: true, cwd: `./${repo_path}` }, function (err) {
        if (err) throw err;
        done()
    });
})
gulp.task("install", function (done) {
    return run('npm install', { cwd: `./${repo_path}` }).exec()
})
gulp.task("build-frontend", function (done) {
    return run(`ng build --configuration ${repo_build} --output-path ../assets/portal --output-hashing none`, { cwd: `./${repo_path}`  }).exec()
})
gulp.task("createDirs", function () {
    return run(`mkdir -p ./${repo_path}/`).exec()
})
gulp.task("set-permissions", function (done) {
    return run(`chmod -R 777 ./${repo_path}`).exec()
})
gulp.task("clean", function (done) {
    return run(`rm -rf ./${repo_path}`).exec()
})
gulp.task('default', gulp.series("clean", "createDirs", "set-permissions", "pull", "switch-branch", "install", "build-frontend", "clean"));
