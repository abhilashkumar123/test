import jwt
from django.conf import settings


def decode_jwt(token, verify=True):
    algo = settings.SIMPLE_JWT["ALGORITHM"]
    if algo.startswith("HS"):
        verify_key = settings.SIMPLE_JWT["SIGNING_KEY"]
    else:
        verify_key = settings.SIMPLE_JWT["VERIFYING_KEY"]
    return jwt.decode(token, verify_key, algorithms=[algo], verify=verify)
