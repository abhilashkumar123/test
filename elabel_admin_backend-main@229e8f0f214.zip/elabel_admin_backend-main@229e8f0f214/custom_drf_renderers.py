from rest_framework.renderers import JSONRenderer


class LinksetRenderer(JSONRenderer):
    media_type = "application/linkset+json"
