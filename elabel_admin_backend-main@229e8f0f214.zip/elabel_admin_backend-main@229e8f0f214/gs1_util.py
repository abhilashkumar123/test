__all__ = ["gs1_util"]

# Don't look below, you will not understand this Python code :) I don't.

from js2py.pyjs import *

# setting scope
var = Scope(JS_BUILTINS)
set_global_object(var)

# Code follows:
var.registers(
    [
        "binaryEncodingOfValue",
        "f",
        "extractFromGS1elementStrings",
        "getAIs",
        "tableOptReverse",
        "verifyCheckDigit",
        "extractFromGS1digitalLink",
        "stringSemantics",
        "decompressBinaryToGS1AIarray",
        "fixedLength",
        "repeat",
        "handleEncodings",
        "hexAlphabet",
        "canonical",
        "percentDecode",
        "gs1ElementStringsToCompressedGS1DigitalLink",
        "tableP",
        "regexSafe64",
        "analyseURIsemantics",
        "classSemantics",
        "identifiers",
        "decodeBinaryValue",
        "i",
        "a",
        "buildStructuredArray",
        "gs1ElementStringsToGS1DigitalLink",
        "determineEncoding",
        "compressGS1AIarrayToBinary",
        "q",
        "dateRangeSemantics",
        "dateTimeMinutesSemantics",
        "safeBase64Alphabet",
        "getIdentifiers",
        "dateSemantics",
        "quantitativeValueSemantics",
        "buildCompressedGS1digitalLink",
        "separateIDnonID",
        "getQualifiers",
        "tableOptKeys",
        "decompressGS1DigitalLink",
        "binaryEncodingOfGS1AIKey",
        "numberOfValueBits",
        "compressGS1DigitalLink",
        "binstrToHex",
        "tableF",
        "getFixedLength",
        "regexHexLower",
        "buildGS1elementStrings",
        "percentEncode",
        "invalidAssociations",
        "variableLength",
        "qualifiers",
        "padToLength",
        "byLength",
        "extractFromCompressedGS1digitalLink",
        "base642bin",
        "buildGS1digitalLink",
        "mandatoryAssociations",
        "mergeObjects",
        "verifySyntax",
        "dataAttributes",
        "regexAllNum",
        "getMatchesKeyword",
        "buildBinaryValue",
        "calculateCheckDigit",
        "key",
        "gs1compressedDigitalLinkToGS1elementStrings",
        "numberOfLengthBits",
        "fixedLengthTable",
        "tableS1",
        "analyseURI",
        "v",
        "handleDecodings",
        "tableOpt",
        "bin2base64",
        "getVariableLength",
        "decompressGS1DigitalLinkToStructuredArray",
        "gs1digitalLinkToGS1elementStrings",
        "getDataAttributes",
        "binaryEncodingOfNonGS1Value",
        "dateTimeSecondsSemantics",
        "regexHexUpper",
        "getMatchesAI",
    ]
)


@Js
def PyJsHoisted_getIdentifiers_(ai, this, arguments, var=var):
    var = Scope({"ai": ai, "this": this, "arguments": arguments}, var)
    var.registers(["ai"])
    return var.get("ai").get("type") == Js("I")


PyJsHoisted_getIdentifiers_.func_name = "getIdentifiers"
var.put("getIdentifiers", PyJsHoisted_getIdentifiers_)


@Js
def PyJsHoisted_getQualifiers_(ai, this, arguments, var=var):
    var = Scope({"ai": ai, "this": this, "arguments": arguments}, var)
    var.registers(["ai"])
    return var.get("ai").get("type") == Js("Q")


PyJsHoisted_getQualifiers_.func_name = "getQualifiers"
var.put("getQualifiers", PyJsHoisted_getQualifiers_)


@Js
def PyJsHoisted_getDataAttributes_(ai, this, arguments, var=var):
    var = Scope({"ai": ai, "this": this, "arguments": arguments}, var)
    var.registers(["ai"])
    return var.get("ai").get("type") == Js("D")


PyJsHoisted_getDataAttributes_.func_name = "getDataAttributes"
var.put("getDataAttributes", PyJsHoisted_getDataAttributes_)


@Js
def PyJsHoisted_getFixedLength_(ai, this, arguments, var=var):
    var = Scope({"ai": ai, "this": this, "arguments": arguments}, var)
    var.registers(["ai"])
    return var.get("ai").get("fixedLength") == Js(True)


PyJsHoisted_getFixedLength_.func_name = "getFixedLength"
var.put("getFixedLength", PyJsHoisted_getFixedLength_)


@Js
def PyJsHoisted_getVariableLength_(ai, this, arguments, var=var):
    var = Scope({"ai": ai, "this": this, "arguments": arguments}, var)
    var.registers(["ai"])
    return var.get("ai").get("fixedLength") == Js(False)


PyJsHoisted_getVariableLength_.func_name = "getVariableLength"
var.put("getVariableLength", PyJsHoisted_getVariableLength_)


@Js
def PyJsHoisted_getMatchesKeyword_(keyword, this, arguments, var=var):
    var = Scope({"keyword": keyword, "this": this, "arguments": arguments}, var)
    var.registers(["keyword"])

    @Js
    def PyJs_anonymous_1_(ai, this, arguments, var=var):
        var = Scope({"ai": ai, "this": this, "arguments": arguments}, var)
        var.registers(["ai"])
        return var.get("ai").get("title").callprop("indexOf", var.get("keyword")) > (-Js(1.0))

    PyJs_anonymous_1_._set_name("anonymous")
    return PyJs_anonymous_1_


PyJsHoisted_getMatchesKeyword_.func_name = "getMatchesKeyword"
var.put("getMatchesKeyword", PyJsHoisted_getMatchesKeyword_)


@Js
def PyJsHoisted_getMatchesAI_(num, this, arguments, var=var):
    var = Scope({"num": num, "this": this, "arguments": arguments}, var)
    var.registers(["num"])

    @Js
    def PyJs_anonymous_2_(el, this, arguments, var=var):
        var = Scope({"el": el, "this": this, "arguments": arguments}, var)
        var.registers(["el"])
        return var.get("el").get("ai") == var.get("num")

    PyJs_anonymous_2_._set_name("anonymous")
    return PyJs_anonymous_2_


PyJsHoisted_getMatchesAI_.func_name = "getMatchesAI"
var.put("getMatchesAI", PyJsHoisted_getMatchesAI_)


@Js
def PyJsHoisted_byLength_(length, this, arguments, var=var):
    var = Scope({"length": length, "this": this, "arguments": arguments}, var)
    var.registers(["length"])

    @Js
    def PyJs_anonymous_3_(element, this, arguments, var=var):
        var = Scope({"element": element, "this": this, "arguments": arguments}, var)
        var.registers(["element"])
        return var.get("element").get("ai").get("length") == var.get("length")

    PyJs_anonymous_3_._set_name("anonymous")
    return PyJs_anonymous_3_


PyJsHoisted_byLength_.func_name = "byLength"
var.put("byLength", PyJsHoisted_byLength_)


@Js
def PyJsHoisted_getAIs_(list, this, arguments, var=var):
    var = Scope({"list": list, "this": this, "arguments": arguments}, var)
    var.registers(["rv", "list", "i"])
    var.put("rv", Js([]))
    for PyJsTemp in var.get("list"):
        var.put("i", PyJsTemp)
        var.get("rv").callprop("push", var.get("list").get(var.get("i")).get("ai"))
    return var.get("rv")


PyJsHoisted_getAIs_.func_name = "getAIs"
var.put("getAIs", PyJsHoisted_getAIs_)


@Js
def PyJsHoisted_numberOfLengthBits_(maxLength, this, arguments, var=var):
    var = Scope({"maxLength": maxLength, "this": this, "arguments": arguments}, var)
    var.registers(["maxLength"])
    return var.get("Math").callprop(
        "ceil",
        ((var.get("Math").callprop("log", var.get("maxLength")) / var.get("Math").callprop("log", Js(2.0))) + Js(0.01)),
    )


PyJsHoisted_numberOfLengthBits_.func_name = "numberOfLengthBits"
var.put("numberOfLengthBits", PyJsHoisted_numberOfLengthBits_)


@Js
def PyJsHoisted_numberOfValueBits_(valueLength, this, arguments, var=var):
    var = Scope({"valueLength": valueLength, "this": this, "arguments": arguments}, var)
    var.registers(["valueLength"])
    return var.get("Math").callprop(
        "ceil",
        (
            (
                (var.get("valueLength") * var.get("Math").callprop("log", Js(10.0)))
                / var.get("Math").callprop("log", Js(2.0))
            )
            + Js(0.01)
        ),
    )


PyJsHoisted_numberOfValueBits_.func_name = "numberOfValueBits"
var.put("numberOfValueBits", PyJsHoisted_numberOfValueBits_)


@Js
def PyJsHoisted_calculateCheckDigit_(ai, gs1IDValue, this, arguments, var=var):
    var = Scope({"ai": ai, "gs1IDValue": gs1IDValue, "this": this, "arguments": arguments}, var)
    var.registers(
        ["l", "ai", "i", "reversed", "gs1IDValue", "total", "counter", "d", "multiplier", "expectedCheckDigit"]
    )
    var.put("counter", Js(0.0))
    var.put("reversed", Js(""))
    var.put("total", Js(0.0))
    pass
    if var.get("aiCheckDigitPosition").get(var.get("ai")) == Js("L"):
        var.put("l", var.get("gs1IDValue").get("length"))
    else:
        var.put("l", var.get("parseInt")(var.get("aiCheckDigitPosition").get(var.get("ai"))))
    pass
    # for JS loop
    var.put("i", (var.get("l") - Js(2.0)))
    while var.get("i") >= Js(0.0):
        try:
            var.put("d", var.get("gs1IDValue").callprop("substring", var.get("i"), (var.get("i") + Js(1.0))))
            if (var.get("counter") % Js(2.0)) == Js(0.0):
                var.put("multiplier", Js(3.0))
            else:
                var.put("multiplier", Js(1.0))
            var.put("total", (var.get("d") * var.get("multiplier")), "+")
            (var.put("counter", Js(var.get("counter").to_number()) + Js(1)) - Js(1))
        finally:
            (var.put("i", Js(var.get("i").to_number()) - Js(1)) + Js(1))
    var.put("expectedCheckDigit", ((Js(10.0) - (var.get("total") % Js(10.0))) % Js(10.0)))
    return var.get("expectedCheckDigit")


PyJsHoisted_calculateCheckDigit_.func_name = "calculateCheckDigit"
var.put("calculateCheckDigit", PyJsHoisted_calculateCheckDigit_)


@Js
def PyJsHoisted_verifyCheckDigit_(ai, gs1IDValue, this, arguments, var=var):
    var = Scope({"ai": ai, "gs1IDValue": gs1IDValue, "this": this, "arguments": arguments}, var)
    var.registers(["actualCheckDigit", "rv", "ai", "gs1IDValue", "checkDigitPosition", "expectedCheckDigit"])
    pass
    var.put("rv", Js(True))
    var.put("checkDigitPosition", var.get("aiCheckDigitPosition").get(var.get("ai")))
    if PyJsStrictNeq(var.get("checkDigitPosition"), var.get("undefined")):
        var.put("expectedCheckDigit", var.get("calculateCheckDigit")(var.get("ai"), var.get("gs1IDValue")))
        if var.get("checkDigitPosition") == Js("L"):
            var.put("checkDigitPosition", var.get("gs1IDValue").get("length"))
        else:
            var.put("checkDigitPosition", var.get("parseInt")(var.get("checkDigitPosition")))
        var.put(
            "actualCheckDigit",
            var.get("parseInt")(var.get("gs1IDValue").callprop("charAt", (var.get("checkDigitPosition") - Js(1.0)))),
        )
        if PyJsStrictNeq(var.get("actualCheckDigit"), var.get("expectedCheckDigit")):
            var.put("rv", Js(False))
            PyJsTempException = JsToPyException(
                var.get("Error").create(
                    (
                        (
                            (
                                (
                                    (
                                        (
                                            (
                                                Js(
                                                    "INVALID CHECK DIGIT:  An invalid check digit was found for the primary identification key ("
                                                )
                                                + var.get("ai")
                                            )
                                            + Js(")")
                                        )
                                        + var.get("gs1IDValue")
                                    )
                                    + Js(" ; the correct check digit should be ")
                                )
                                + var.get("expectedCheckDigit")
                            )
                            + Js(" at position ")
                        )
                        + var.get("checkDigitPosition")
                    )
                )
            )
            raise PyJsTempException
    return var.get("rv")


PyJsHoisted_verifyCheckDigit_.func_name = "verifyCheckDigit"
var.put("verifyCheckDigit", PyJsHoisted_verifyCheckDigit_)


@Js
def PyJsHoisted_verifySyntax_(ai, value, this, arguments, var=var):
    var = Scope({"ai": ai, "value": value, "this": this, "arguments": arguments}, var)
    var.registers(["value", "ai"])
    if PyJsStrictNeq(var.get("ai"), var.get("null")) and var.get("regexAllNum").callprop("test", var.get("ai")):
        if var.get("aiRegex").get(var.get("ai")).callprop("test", var.get("value")).neg():
            PyJsTempException = JsToPyException(
                (((Js("SYNTAX ERROR: invalid syntax for value of (") + var.get("ai")) + Js(")")) + var.get("value"))
            )
            raise PyJsTempException


PyJsHoisted_verifySyntax_.func_name = "verifySyntax"
var.put("verifySyntax", PyJsHoisted_verifySyntax_)


@Js
def PyJsHoisted_percentEncode_(input, this, arguments, var=var):
    var = Scope({"input": input, "this": this, "arguments": arguments}, var)
    var.registers(["charsToEscape", "testChar", "i", "input", "escaped"])
    var.put("charsToEscape", Js("#/%&+,!()*':;<=>?"))
    var.put("escaped", Js([]))
    # for JS loop
    var.put("i", Js(0.0))
    while var.get("i") < var.get("input").get("length"):
        try:
            var.put("testChar", var.get("input").callprop("substr", var.get("i"), Js(1.0)))
            if var.get("charsToEscape").callprop("indexOf", var.get("testChar")) > (-Js(1.0)):
                var.get("escaped").callprop(
                    "push",
                    (
                        Js("%")
                        + var.get("testChar")
                        .callprop("charCodeAt", Js(0.0))
                        .callprop("toString", Js(16.0))
                        .callprop("toUpperCase")
                    ),
                )
            else:
                var.get("escaped").callprop("push", var.get("testChar"))
        finally:
            (var.put("i", Js(var.get("i").to_number()) + Js(1)) - Js(1))
    return var.get("escaped").callprop("join", Js(""))


PyJsHoisted_percentEncode_.func_name = "percentEncode"
var.put("percentEncode", PyJsHoisted_percentEncode_)


@Js
def PyJsHoisted_percentDecode_(input, this, arguments, var=var):
    var = Scope({"input": input, "this": this, "arguments": arguments}, var)
    var.registers(["input"])
    return var.get("decodeURIComponent")(var.get("input"))


PyJsHoisted_percentDecode_.func_name = "percentDecode"
var.put("percentDecode", PyJsHoisted_percentDecode_)


@Js
def PyJsHoisted_repeat_(character, length, this, arguments, var=var):
    var = Scope({"character": character, "length": length, "this": this, "arguments": arguments}, var)
    var.registers(["length", "character", "i"])
    var.put("temp", Js(""))
    # for JS loop
    var.put("i", Js(0.0))
    while var.get("i") < var.get("length"):
        try:
            var.put("temp", Js("0"), "+")
        finally:
            (var.put("i", Js(var.get("i").to_number()) + Js(1)) - Js(1))
    return var.get("temp")


PyJsHoisted_repeat_.func_name = "repeat"
var.put("repeat", PyJsHoisted_repeat_)


@Js
def PyJsHoisted_padToLength_(input, requiredLength, this, arguments, var=var):
    var = Scope({"input": input, "requiredLength": requiredLength, "this": this, "arguments": arguments}, var)
    var.registers(["input", "requiredLength"])
    if var.get("input").get("length") < var.get("requiredLength"):
        var.put(
            "input",
            (
                var.get("repeat")(Js("0"), (var.get("requiredLength") - var.get("input").get("length")))
                + var.get("input")
            ),
        )
    return var.get("input")


PyJsHoisted_padToLength_.func_name = "padToLength"
var.put("padToLength", PyJsHoisted_padToLength_)


@Js
def PyJsHoisted_bin2base64_(binstr, this, arguments, var=var):
    var = Scope({"binstr": binstr, "this": this, "arguments": arguments}, var)
    var.registers(["numberRightPadZeros", "binFrag", "rv", "binstr", "i", "base64char", "numChar"])
    var.put("rv", Js(""))
    if (var.get("binstr").get("length") % Js(6.0)) > Js(0.0):
        var.put("numberRightPadZeros", (Js(6.0) - (var.get("binstr").get("length") % Js(6.0))))
        var.put("binstr", var.get("repeat")(Js("0"), var.get("numberRightPadZeros")), "+")
    var.put("numChar", (var.get("binstr").get("length") / Js(6.0)))
    # for JS loop
    var.put("i", Js(0.0))
    while var.get("i") < var.get("numChar"):
        try:
            var.put("binFrag", var.get("binstr").callprop("substr", (Js(6.0) * var.get("i")), Js(6.0)))
            var.put(
                "base64char",
                var.get("safeBase64Alphabet").callprop(
                    "substr", var.get("parseInt")(var.get("binFrag"), Js(2.0)), Js(1.0)
                ),
            )
            var.put("rv", var.get("base64char"), "+")
        finally:
            (var.put("i", Js(var.get("i").to_number()) + Js(1)) - Js(1))
    return var.get("rv")


PyJsHoisted_bin2base64_.func_name = "bin2base64"
var.put("bin2base64", PyJsHoisted_bin2base64_)


@Js
def PyJsHoisted_base642bin_(base64str, this, arguments, var=var):
    var = Scope({"base64str": base64str, "this": this, "arguments": arguments}, var)
    var.registers(["rv", "dec", "i", "base64str", "bin"])
    var.put("rv", Js(""))
    # for JS loop
    var.put("i", Js(0.0))
    while var.get("i") < var.get("base64str").get("length"):
        try:
            var.put(
                "dec",
                var.get("safeBase64Alphabet").callprop(
                    "indexOf", var.get("base64str").callprop("substr", var.get("i"), Js(1.0))
                ),
            )
            var.put("bin", var.get("dec").callprop("toString", Js(2.0)))
            if var.get("bin").get("length") < Js(6.0):
                var.put("bin", (var.get("repeat")(Js("0"), (Js(6.0) - var.get("bin").get("length"))) + var.get("bin")))
            var.put("rv", var.get("bin"), "+")
        finally:
            (var.put("i", Js(var.get("i").to_number()) + Js(1)) - Js(1))
    return var.get("rv")


PyJsHoisted_base642bin_.func_name = "base642bin"
var.put("base642bin", PyJsHoisted_base642bin_)


@Js
def PyJsHoisted_canonical_(obj, this, arguments, var=var):
    var = Scope({"obj": obj, "this": this, "arguments": arguments}, var)
    var.registers(["obj", "rv", "sortedKeys", "el"])
    var.put("rv", Js({}))
    var.put("sortedKeys", var.get("Object").callprop("keys", var.get("obj")).callprop("sort"))
    for PyJsTemp in var.get("sortedKeys"):
        var.put("el", PyJsTemp)
        if var.get("obj").callprop("hasOwnProperty", var.get("sortedKeys").get(var.get("el"))):
            var.get("rv").put(
                var.get("sortedKeys").get(var.get("el")), var.get("obj").get(var.get("sortedKeys").get(var.get("el")))
            )
    return var.get("rv")


PyJsHoisted_canonical_.func_name = "canonical"
var.put("canonical", PyJsHoisted_canonical_)


@Js
def PyJsHoisted_binstrToHex_(binstr, this, arguments, var=var):
    var = Scope({"binstr": binstr, "this": this, "arguments": arguments}, var)
    var.registers(["binstr"])
    return var.get("parseInt")(var.get("binstr"), Js(2.0)).callprop("toString", Js(16.0)).callprop("toUpperCase")


PyJsHoisted_binstrToHex_.func_name = "binstrToHex"
var.put("binstrToHex", PyJsHoisted_binstrToHex_)


@Js
def PyJsHoisted_extractFromGS1elementStrings_(elementStrings, this, arguments, var=var):
    var = Scope({"elementStrings": elementStrings, "this": this, "arguments": arguments}, var)
    var.registers(
        [
            "l",
            "fixedLengthAIs",
            "aikeys",
            "gsloc",
            "elementStringsLength",
            "i",
            "a",
            "el",
            "re",
            "cursor",
            "results",
            "aiCandidate",
            "matched",
            "firstTwoDigits",
            "obj",
            "r1",
            "buffer",
            "elementStrings",
            "gs",
            "k",
            "fixedLengths",
        ]
    )
    var.put("elementStrings", var.get("elementStrings").callprop("replace", JsRegExp("/^(]C1|]e0|]d2|]Q3)/"), Js("")))
    var.put("re", var.get("RegExp").create(Js("^\\((\\d{2,4}?)\\)")))
    if var.get("re").callprop("test", var.get("elementStrings")):
        var.put("r1", var.get("RegExp").create(Js("\\((\\d{2,4}?)\\)|([^(]+)"), Js("g")))
        var.put("aikeys", var.get("Object").callprop("keys", var.get("aiRegex")))
        var.put("obj", Js({}))
        pass
        if var.get("r1").callprop("test", var.get("elementStrings")):
            var.put("results", var.get("elementStrings").callprop("match", var.get("r1")))
            for PyJsTemp in var.get("results"):
                var.put("a", PyJsTemp)
                if (var.get("a") % Js(2.0)) == Js(0.0):
                    var.put("l", var.get("results").get(var.get("a")).get("length"))
                    var.put(
                        "k", var.get("results").get(var.get("a")).callprop("substr", Js(1.0), (var.get("l") - Js(2.0)))
                    )
                else:
                    if var.get("aikeys").callprop("indexOf", var.get("k")) != (-Js(1.0)):
                        if var.get("aiRegex").get(var.get("k")).callprop("test", var.get("results").get(var.get("a"))):
                            var.get("obj").put(var.get("k"), var.get("results").get(var.get("a")))
                        else:
                            PyJsTempException = JsToPyException(
                                var.get("Error").create(
                                    (
                                        (
                                            (Js("SYNTAX ERROR: invalid syntax for value of (") + var.get("k"))
                                            + Js(") : ")
                                        )
                                        + var.get("results").get(var.get("a"))
                                    )
                                )
                            )
                            raise PyJsTempException
        return var.get("obj")
    else:
        var.put("elementStringsLength", var.get("elementStrings").get("length"))
        var.put(
            "fixedLengths",
            Js(
                {
                    "00": Js(20.0),
                    "01": Js(16.0),
                    "02": Js(16.0),
                    "03": Js(16.0),
                    "04": Js(18.0),
                    "11": Js(8.0),
                    "12": Js(8.0),
                    "13": Js(8.0),
                    "14": Js(8.0),
                    "15": Js(8.0),
                    "16": Js(8.0),
                    "17": Js(8.0),
                    "18": Js(8.0),
                    "19": Js(8.0),
                    "20": Js(4.0),
                    "31": Js(10.0),
                    "32": Js(10.0),
                    "33": Js(10.0),
                    "34": Js(10.0),
                    "35": Js(10.0),
                    "36": Js(10.0),
                    "41": Js(16.0),
                }
            ),
        )
        var.put("fixedLengthAIs", var.get("Object").callprop("keys", var.get("fixedLengths")))
        var.put("gs", var.get("String").callprop("fromCharCode", Js(29.0)))
        var.put("cursor", Js(0.0))
        var.put("buffer", Js([]))
        while 1:
            var.put("firstTwoDigits", var.get("elementStrings").callprop("substr", var.get("cursor"), Js(2.0)))
            if var.get("fixedLengthAIs").callprop("indexOf", var.get("firstTwoDigits")) > (-Js(1.0)):
                var.put("l", var.get("fixedLengths").get(var.get("firstTwoDigits")))
                var.get("buffer").callprop(
                    "push", var.get("elementStrings").callprop("substr", var.get("cursor"), var.get("l"))
                )
                var.put("cursor", var.get("l"), "+")
                if var.get("elementStrings").callprop("substr", var.get("cursor"), Js(1.0)) == var.get("gs"):
                    (var.put("cursor", Js(var.get("cursor").to_number()) + Js(1)) - Js(1))
            else:
                var.put(
                    "gsloc",
                    var.get("elementStrings").callprop("substr", var.get("cursor")).callprop("indexOf", var.get("gs")),
                )
                if var.get("gsloc") > (-Js(1.0)):
                    var.get("buffer").callprop(
                        "push",
                        var.get("elementStrings")
                        .callprop("substr", var.get("cursor"))
                        .callprop("substr", Js(0.0), var.get("gsloc")),
                    )
                    var.put("cursor", var.get("gsloc"), "+")
                    (var.put("cursor", Js(var.get("cursor").to_number()) + Js(1)) - Js(1))
                else:
                    var.get("buffer").callprop("push", var.get("elementStrings").callprop("substr", var.get("cursor")))
                    var.put("cursor", var.get("elementStringsLength"))
            if not (var.get("cursor") < var.get("elementStringsLength")):
                break
        var.put("obj", Js({}))
        var.put("aiCandidate", Js(""))
        var.put("matched", Js(False))
        # for JS loop
        var.put("i", Js(0.0))
        while var.get("i") < var.get("buffer").get("length"):
            try:
                var.put("el", var.get("buffer").get(var.get("i")))
                # for JS loop
                var.put("k", Js(2.0))
                while var.get("k") <= Js(4.0):
                    try:
                        var.put("aiCandidate", var.get("el").callprop("substr", Js(0.0), var.get("k")))
                        if var.get("AIsByLength").get(var.get("k")).callprop("indexOf", var.get("aiCandidate")) > (
                            -Js(1.0)
                        ):
                            var.get("obj").put(var.get("aiCandidate"), var.get("el").callprop("substr", var.get("k")))
                            var.put("matched", Js(True))
                    finally:
                        (var.put("k", Js(var.get("k").to_number()) + Js(1)) - Js(1))
                if var.get("matched").neg():
                    PyJsTempException = JsToPyException(
                        var.get("Error").create((Js("No matching GS1 AI found for ") + var.get("el")))
                    )
                    raise PyJsTempException
            finally:
                (var.put("i", Js(var.get("i").to_number()) + Js(1)) - Js(1))
        return var.get("obj")


PyJsHoisted_extractFromGS1elementStrings_.func_name = "extractFromGS1elementStrings"
var.put("extractFromGS1elementStrings", PyJsHoisted_extractFromGS1elementStrings_)


@Js
def PyJsHoisted_buildGS1digitalLink_(gs1AIarray, useShortText, uriStem, nonGS1keyvaluePairs, this, arguments, var=var):
    var = Scope(
        {
            "gs1AIarray": gs1AIarray,
            "useShortText": useShortText,
            "uriStem": uriStem,
            "nonGS1keyvaluePairs": nonGS1keyvaluePairs,
            "this": this,
            "arguments": arguments,
        },
        var,
    )
    var.registers(
        [
            "j",
            "identifiers",
            "queryStringArray",
            "useShortText",
            "otherKeys",
            "uriStem",
            "gs1AIarray",
            "a",
            "path",
            "attributes",
            "queryString",
            "fixedLengthValues",
            "q",
            "qualifiers",
            "nonGS1keyvaluePairs",
            "canonicalStem",
            "webURI",
            "iok",
            "variableLengthValues",
            "other",
            "rv",
            "keys",
            "key",
            "k",
            "valid",
        ]
    )
    var.put("identifiers", Js([]))
    var.put("qualifiers", Js([]))
    var.put("attributes", Js([]))
    var.put("fixedLengthValues", Js([]))
    var.put("variableLengthValues", Js([]))
    var.put("otherKeys", Js([]))
    var.put("valid", Js(True))
    var.put("path", Js(""))
    var.put("queryStringArray", Js([]))
    var.put("queryString", Js(""))
    var.put("webURI", Js(""))
    var.put("canonicalStem", Js("https://id.gs1.org"))
    var.put("rv", Js({}))
    if (
        (PyJsStrictNeq(var.get("uriStem"), var.get("undefined")) and PyJsStrictNeq(var.get("uriStem"), var.get("null")))
        and PyJsStrictNeq(var.get("uriStem"), Js(""))
    ) and PyJsStrictEq(var.get("uriStem").callprop("substr", (-Js(1.0))), Js("/")):
        var.put(
            "uriStem",
            (
                (
                    var.get("uriStem").callprop("substr", Js(0.0), (var.get("uriStem").get("length") - Js(1.0)))
                    + var.get("path")
                )
                + var.get("queryString")
            ),
        )
    for PyJsTemp in var.get("gs1AIarray"):
        var.put("a", PyJsTemp)
        var.put("other", Js(True))
        if var.get("aiMaps").get("identifiers").callprop("indexOf", var.get("a")) != (-Js(1.0)):
            var.get("identifiers").callprop("push", var.get("a"))
            var.put("other", Js(False))
        if var.get("aiMaps").get("qualifiers").callprop("indexOf", var.get("a")) != (-Js(1.0)):
            var.get("qualifiers").callprop("push", var.get("a"))
            var.put("other", Js(False))
        if var.get("aiMaps").get("dataAttributes").callprop("indexOf", var.get("a")) != (-Js(1.0)):
            var.get("attributes").callprop("push", var.get("a"))
            var.put("other", Js(False))
        if var.get("aiMaps").get("fixedLength").callprop("indexOf", var.get("a")) != (-Js(1.0)):
            var.get("fixedLengthValues").callprop("push", var.get("a"))
            var.put("other", Js(False))
        if var.get("aiMaps").get("variableLength").callprop("indexOf", var.get("a")) != (-Js(1.0)):
            var.get("variableLengthValues").callprop("push", var.get("a"))
            var.put("other", Js(False))
        if var.get("other"):
            var.get("otherKeys").callprop("push", var.get("a"))
    if PyJsStrictNeq(var.get("identifiers").get("length"), Js(1.0)):
        var.put("valid", Js(False))
        PyJsTempException = JsToPyException(
            var.get("Error").create(
                (
                    (
                        (
                            (
                                Js(
                                    "The element string should contain exactly one primary identification key - it contained "
                                )
                                + var.get("identifiers").get("length")
                            )
                            + Js(" ")
                        )
                        + var.get("JSON").callprop("stringify", var.get("identifiers"))
                    )
                    + Js("; please check for a syntax error")
                )
            )
        )
        raise PyJsTempException
    else:
        var.get("verifySyntax")(
            var.get("identifiers").get("0"), var.get("gs1AIarray").get(var.get("identifiers").get("0"))
        )
        var.get("verifyCheckDigit")(
            var.get("identifiers").get("0"), var.get("gs1AIarray").get(var.get("identifiers").get("0"))
        )
        if var.get("useShortText"):
            if PyJsStrictNeq(var.get("aiShortCode").get(var.get("identifiers").get("0")), var.get("undefined")):
                var.put(
                    "path",
                    (
                        ((Js("/") + var.get("aiShortCode").get(var.get("identifiers").get("0"))) + Js("/"))
                        + var.get("percentEncode")(var.get("gs1AIarray").get(var.get("identifiers").get("0")))
                    ),
                )
            else:
                var.put(
                    "path",
                    (
                        ((Js("/") + var.get("identifiers").get("0")) + Js("/"))
                        + var.get("percentEncode")(var.get("gs1AIarray").get(var.get("identifiers").get("0")))
                    ),
                )
        else:
            var.put(
                "path",
                (
                    ((Js("/") + var.get("identifiers").get("0")) + Js("/"))
                    + var.get("percentEncode")(var.get("gs1AIarray").get(var.get("identifiers").get("0")))
                ),
            )
        if PyJsStrictNeq(var.get("aiQualifiers").get(var.get("identifiers").get("0")), var.get("undefined")):
            for PyJsTemp in var.get("aiQualifiers").get(var.get("identifiers").get("0")):
                var.put("j", PyJsTemp)
                var.put("q", var.get("aiQualifiers").get(var.get("identifiers").get("0")).get(var.get("j")))
                if var.get("qualifiers").callprop("indexOf", var.get("q")) != (-Js(1.0)):
                    if var.get("useShortText"):
                        if PyJsStrictNeq(var.get("aiShortCode").get(var.get("q")), var.get("undefined")):
                            var.put(
                                "path",
                                (
                                    ((Js("/") + var.get("aiShortCode").get(var.get("q"))) + Js("/"))
                                    + var.get("percentEncode")(var.get("gs1AIarray").get(var.get("q")))
                                ),
                                "+",
                            )
                        else:
                            var.put(
                                "path",
                                (
                                    ((Js("/") + var.get("q")) + Js("/"))
                                    + var.get("percentEncode")(var.get("gs1AIarray").get(var.get("q")))
                                ),
                                "+",
                            )
                    else:
                        var.put(
                            "path",
                            (
                                ((Js("/") + var.get("q")) + Js("/"))
                                + var.get("percentEncode")(var.get("gs1AIarray").get(var.get("q")))
                            ),
                            "+",
                        )
        if var.get("attributes").get("length") > Js(0.0):
            for PyJsTemp in var.get("attributes"):
                var.put("k", PyJsTemp)
                var.put("a", var.get("attributes").get(var.get("k")))
                if var.get("useShortText"):
                    if PyJsStrictNeq(var.get("aiShortCode").get(var.get("a")), var.get("undefined")):
                        var.get("queryStringArray").callprop(
                            "push",
                            (
                                (var.get("aiShortCode").get(var.get("a")) + Js("="))
                                + var.get("percentEncode")(var.get("gs1AIarray").get(var.get("a")))
                            ),
                        )
                    else:
                        var.get("queryStringArray").callprop(
                            "push",
                            (
                                (var.get("a") + Js("="))
                                + var.get("percentEncode")(var.get("gs1AIarray").get(var.get("a")))
                            ),
                        )
                else:
                    var.get("queryStringArray").callprop(
                        "push",
                        ((var.get("a") + Js("=")) + var.get("percentEncode")(var.get("gs1AIarray").get(var.get("a")))),
                    )
            var.put("queryString", (Js("?") + var.get("queryStringArray").callprop("join", Js("&"))))
        if (var.get("uriStem") == var.get("null")) or (var.get("uriStem") == Js("")):
            var.put("webURI", ((var.get("canonicalStem") + var.get("path")) + var.get("queryString")))
        else:
            var.put("webURI", ((var.get("uriStem") + var.get("path")) + var.get("queryString")))
        if var.get("otherKeys").get("length") > Js(0.0):
            var.put("queryStringArray", Js([]))
            for PyJsTemp in var.get("otherKeys"):
                var.put("iok", PyJsTemp)
                var.get("queryStringArray").callprop(
                    "push",
                    (
                        (var.get("otherKeys").get(var.get("iok")) + Js("="))
                        + var.get("gs1AIarray").get(var.get("otherKeys").get(var.get("iok")))
                    ),
                )
            if var.get("queryString") == Js(""):
                var.put("webURI", (Js("?") + var.get("queryStringArray").callprop("join", Js("&"))), "+")
            else:
                var.put("webURI", (Js("&") + var.get("queryStringArray").callprop("join", Js("&"))), "+")
        if PyJsStrictNeq(var.get("nonGS1keyvaluePairs"), Js({})) and (
            var.get("Object").callprop("keys", var.get("nonGS1keyvaluePairs")).get("length") > Js(0.0)
        ):
            var.put("queryStringArray", Js([]))
            var.put("keys", var.get("Object").callprop("keys", var.get("nonGS1keyvaluePairs")))
            for PyJsTemp in var.get("keys"):
                var.put("iok", PyJsTemp)
                var.put("key", var.get("keys").get(var.get("iok")))
                var.get("queryStringArray").callprop(
                    "push", ((var.get("key") + Js("=")) + var.get("nonGS1keyvaluePairs").get(var.get("key")))
                )
            if var.get("queryString") == Js(""):
                var.put("webURI", (Js("?") + var.get("queryStringArray").callprop("join", Js("&"))), "+")
            else:
                var.put("webURI", (Js("&") + var.get("queryStringArray").callprop("join", Js("&"))), "+")
    return var.get("webURI")


PyJsHoisted_buildGS1digitalLink_.func_name = "buildGS1digitalLink"
var.put("buildGS1digitalLink", PyJsHoisted_buildGS1digitalLink_)


@Js
def PyJsHoisted_buildStructuredArray_(gs1AIarray, otherArray, this, arguments, var=var):
    var = Scope({"gs1AIarray": gs1AIarray, "otherArray": otherArray, "this": this, "arguments": arguments}, var)
    var.registers(
        ["otherArray", "gs1AIarray", "keys", "rv", "map", "queryStringArray", "path", "a", "b", "k", "other", "valid"]
    )
    var.put("keys", Js([Js("identifiers"), Js("qualifiers"), Js("dataAttributes")]))
    var.put("map", Js({}))
    var.get("map").put("identifiers", Js([]))
    var.get("map").put("qualifiers", Js([]))
    var.get("map").put("dataAttributes", Js([]))
    var.get("map").put("other", Js([]))
    var.put("valid", Js(True))
    var.put("path", Js(""))
    var.put("queryStringArray", Js([]))
    var.put("rv", Js({}))
    for PyJsTemp in var.get("gs1AIarray"):
        var.put("a", PyJsTemp)
        var.put("b", Js({}))
        var.get("b").put(var.get("a"), var.get("gs1AIarray").get(var.get("a")))
        var.put("other", Js(True))
        for PyJsTemp in var.get("keys"):
            var.put("k", PyJsTemp)
            if var.get("aiMaps").get(var.get("keys").get(var.get("k"))).callprop("indexOf", var.get("a")) != (-Js(1.0)):
                var.get("map").get(var.get("keys").get(var.get("k"))).callprop("push", var.get("b"))
                var.put("other", Js(False))
        if var.get("other"):
            var.get("map").get("other").callprop("push", var.get("b"))
    for PyJsTemp in var.get("otherArray"):
        var.put("a", PyJsTemp)
        var.put("b", Js({}))
        var.get("b").put(var.get("a"), var.get("otherArray").get(var.get("a")))
        var.get("map").get("other").callprop("push", var.get("b"))
    if PyJsStrictNeq(var.get("map").get("identifiers").get("length"), Js(1.0)):
        var.put("valid", Js(False))
        PyJsTempException = JsToPyException(
            var.get("Error").create(
                (
                    (
                        (
                            (
                                Js(
                                    "The element string should contain exactly one primary identification key - it contained "
                                )
                                + var.get("map").get("identifiers").get("length")
                            )
                            + Js(" ")
                        )
                        + var.get("JSON").callprop("stringify", var.get("map").get("identifiers"))
                    )
                    + Js("; please check for a syntax error")
                )
            )
        )
        raise PyJsTempException
    else:
        var.get("verifySyntax")(
            var.get("map").get("identifiers").get("0"),
            var.get("gs1AIarray").get(var.get("map").get("identifiers").get("0")),
        )
        var.get("verifyCheckDigit")(
            var.get("map").get("identifiers").get("0"),
            var.get("gs1AIarray").get(var.get("map").get("identifiers").get("0")),
        )
    return var.get("map")


PyJsHoisted_buildStructuredArray_.func_name = "buildStructuredArray"
var.put("buildStructuredArray", PyJsHoisted_buildStructuredArray_)


@Js
def PyJsHoisted_analyseURIsemantics_(gs1DigitalLinkURI, this, arguments, var=var):
    var = Scope({"gs1DigitalLinkURI": gs1DigitalLinkURI, "this": this, "arguments": arguments}, var)
    var.registers(
        [
            "pimK",
            "csK",
            "j",
            "l",
            "xsdDateValue",
            "identifiers",
            "outputObject",
            "nonIDKeys",
            "isInstanceIdentifier",
            "v",
            "c",
            "rv2",
            "superClasses",
            "osa",
            "sixDigitToXsdDate",
            "xsdDateTimeValue",
            "sl",
            "m",
            "pathComponents",
            "uriStem",
            "drK",
            "iiaqV",
            "superClass",
            "maxTwelveDigitToXsdDateTime",
            "i",
            "excludeQueryString",
            "a",
            "determineFourDigitYear",
            "uncompressedDL",
            "aiKeys",
            "predicate",
            "q",
            "ki",
            "qualifiers",
            "qpos",
            "nonID",
            "dtsvK",
            "dtmvK",
            "xsdStartDateValue",
            "gs1DigitalLinkURI",
            "bareValue",
            "dataAttributes",
            "xsdEndDateValue",
            "rec20",
            "iiaqK",
            "rv",
            "otype",
            "context",
            "elementStrings",
            "fourthDigit",
            "qvK",
            "k",
            "ssK",
            "tenDigitToXsdDateTime",
            "value",
            "qv",
            "dvK",
        ]
    )

    @Js
    def PyJsHoisted_tenDigitToXsdDateTime_(tenDigit, this, arguments, var=var):
        var = Scope({"tenDigit": tenDigit, "this": this, "arguments": arguments}, var)
        var.registers(["re", "tenDigit", "intendedDateTime", "month", "mins", "hour", "intendedYear", "day", "year"])
        var.put(
            "re",
            var.get("RegExp").create(
                Js("\\d{2}(?:12|11|0\\d)(?:31|30|2\\d|1\\d|0[1-9])(?:0\\d|1\\d|2[0-4])(?:[0-5]\\d)")
            ),
        )
        if var.get("re").callprop("test", var.get("tenDigit")).neg():
            PyJsTempException = JsToPyException(
                var.get("Error").create(Js("input to date conversion did not match valid YYMMDDhhmm pattern"))
            )
            raise PyJsTempException
        else:
            var.put("year", var.get("tenDigit").callprop("substr", Js(0.0), Js(2.0)))
            var.put("month", var.get("tenDigit").callprop("substr", Js(2.0), Js(2.0)))
            var.put("day", var.get("tenDigit").callprop("substr", Js(4.0), Js(2.0)))
            var.put("hour", var.get("tenDigit").callprop("substr", Js(6.0), Js(2.0)))
            var.put("mins", var.get("tenDigit").callprop("substr", Js(8.0), Js(2.0)))
            var.put("intendedYear", var.get("determineFourDigitYear")(var.get("year")))
            var.put(
                "intendedDateTime",
                (
                    (
                        (
                            (
                                (
                                    (
                                        (((var.get("intendedYear") + Js("-")) + var.get("month")) + Js("-"))
                                        + var.get("day")
                                    )
                                    + Js("T")
                                )
                                + var.get("hour")
                            )
                            + Js(":")
                        )
                        + var.get("mins")
                    )
                    + Js(":00")
                ),
            )
            return var.get("intendedDateTime")

    PyJsHoisted_tenDigitToXsdDateTime_.func_name = "tenDigitToXsdDateTime"
    var.put("tenDigitToXsdDateTime", PyJsHoisted_tenDigitToXsdDateTime_)

    @Js
    def PyJsHoisted_maxTwelveDigitToXsdDateTime_(twelveDigit, this, arguments, var=var):
        var = Scope({"twelveDigit": twelveDigit, "this": this, "arguments": arguments}, var)
        var.registers(
            ["re", "min", "sec", "intendedDateTime", "month", "hour", "intendedYear", "day", "twelveDigit", "year"]
        )
        var.put(
            "re",
            var.get("RegExp").create(
                Js("\\d{2}(?:12|11|0\\d)(?:31|30|2\\d|1\\d|0[1-9])(?:0\\d|1\\d|2[0-4])(?:[0-5]\\d)?(?:[0-5]\\d)?")
            ),
        )
        if var.get("re").callprop("test", var.get("twelveDigit")).neg():
            PyJsTempException = JsToPyException(
                var.get("Error").create(Js("input to date conversion did not match valid YYMMDDhh[mm][ss] pattern"))
            )
            raise PyJsTempException
        else:
            var.put("year", var.get("twelveDigit").callprop("substr", Js(0.0), Js(2.0)))
            var.put("month", var.get("twelveDigit").callprop("substr", Js(2.0), Js(2.0)))
            var.put("day", var.get("twelveDigit").callprop("substr", Js(4.0), Js(2.0)))
            var.put("hour", var.get("twelveDigit").callprop("substr", Js(6.0), Js(2.0)))
            pass
            pass
            if var.get("twelveDigit").get("length") > Js(8.0):
                var.put("min", var.get("twelveDigit").callprop("substr", Js(8.0), Js(2.0)))
            else:
                var.put("min", Js("00"))
            if var.get("twelveDigit").get("length") > Js(10.0):
                var.put("sec", var.get("twelveDigit").callprop("substr", Js(10.0), Js(2.0)))
            else:
                var.put("sec", Js("00"))
            var.put("intendedYear", var.get("determineFourDigitYear")(var.get("year")))
            var.put(
                "intendedDateTime",
                (
                    (
                        (
                            (
                                (
                                    (
                                        (
                                            (((var.get("intendedYear") + Js("-")) + var.get("month")) + Js("-"))
                                            + var.get("day")
                                        )
                                        + Js("T")
                                    )
                                    + var.get("hour")
                                )
                                + Js(":")
                            )
                            + var.get("min")
                        )
                        + Js(":")
                    )
                    + var.get("sec")
                ),
            )
            return var.get("intendedDateTime")

    PyJsHoisted_maxTwelveDigitToXsdDateTime_.func_name = "maxTwelveDigitToXsdDateTime"
    var.put("maxTwelveDigitToXsdDateTime", PyJsHoisted_maxTwelveDigitToXsdDateTime_)

    @Js
    def PyJsHoisted_determineFourDigitYear_(year, this, arguments, var=var):
        var = Scope({"year": year, "this": this, "arguments": arguments}, var)
        var.registers(["currentYear", "currentCentury", "dt", "intendedYear", "year", "difference"])
        var.put("dt", var.get("Date").create())
        var.put("currentYear", (Js(1900.0) + var.get("dt").callprop("getYear")))
        var.put("currentCentury", (Js("") + var.get("currentYear")).callprop("substr", Js(0.0), Js(2.0)))
        var.put("difference", (var.get("year") - (var.get("currentYear") % Js(100.0))))
        pass
        if (var.get("difference") >= Js(51.0)) and (var.get("difference") <= Js(99.0)):
            var.put("intendedYear", ((var.get("currentCentury") - Js(1.0)) + var.get("year")))
        else:
            if (var.get("difference") >= (-Js(99.0))) and (var.get("difference") <= (-Js(50.0))):
                var.put("intendedYear", ((var.get("currentCentury") - (-Js(1.0))) + var.get("year")))
            else:
                var.put("intendedYear", (var.get("currentCentury") + var.get("year")))
        return var.get("intendedYear")

    PyJsHoisted_determineFourDigitYear_.func_name = "determineFourDigitYear"
    var.put("determineFourDigitYear", PyJsHoisted_determineFourDigitYear_)

    @Js
    def PyJsHoisted_sixDigitToXsdDate_(sixDigit, this, arguments, var=var):
        var = Scope({"sixDigit": sixDigit, "this": this, "arguments": arguments}, var)
        var.registers(["re", "intendedDate", "sixDigit", "month", "intendedYear", "day", "year", "lastDay"])
        var.put("re", var.get("RegExp").create(Js("\\d{2}(?:12|11|0\\d)(?:31|30|2\\d|1\\d|0\\d)")))
        if var.get("re").callprop("test", var.get("sixDigit")).neg():
            PyJsTempException = JsToPyException(
                var.get("Error").create(Js("input to date conversion did not match valid YYMMDD pattern"))
            )
            raise PyJsTempException
        else:
            var.put("year", var.get("sixDigit").callprop("substr", Js(0.0), Js(2.0)))
            var.put("month", var.get("sixDigit").callprop("substr", Js(2.0), Js(2.0)))
            var.put("day", var.get("sixDigit").callprop("substr", Js(4.0), Js(2.0)))
            var.put("intendedYear", var.get("determineFourDigitYear")(var.get("year")))
            var.put("lastDay", Js(31.0))
            if (
                ((var.get("month") == Js("04")) or (var.get("month") == Js("06"))) or (var.get("month") == Js("09"))
            ) or (var.get("month") == Js("11")):
                var.put("lastDay", Js(30.0))
            if var.get("month") == Js("02"):
                var.put("lastDay", Js(28.0))
                if ((var.get("intendedYear") % Js(400.0)) == Js(0.0)) or (
                    ((var.get("intendedYear") % Js(4.0)) == Js(0.0))
                    and ((var.get("intendedYear") % Js(100.0)) == Js(0.0)).neg()
                ):
                    var.put("lastDay", Js(29.0))
            if (var.get("day") - Js(0.0)) > var.get("lastDay"):
                PyJsTempException = JsToPyException(
                    var.get("Error").create(
                        Js(
                            "input to date conversion was a YYMMDD pattern with a value of DD too large for MM, e.g. 31st of June, 30th of February"
                        )
                    )
                )
                raise PyJsTempException
            pass
            if var.get("day") == Js("00"):
                var.put(
                    "intendedDate",
                    ((((var.get("intendedYear") + Js("-")) + var.get("month")) + Js("-")) + var.get("lastDay")),
                )
            else:
                var.put(
                    "intendedDate",
                    ((((var.get("intendedYear") + Js("-")) + var.get("month")) + Js("-")) + var.get("day")),
                )
            return var.get("intendedDate")

    PyJsHoisted_sixDigitToXsdDate_.func_name = "sixDigitToXsdDate"
    var.put("sixDigitToXsdDate", PyJsHoisted_sixDigitToXsdDate_)
    var.put("rv", var.get("analyseURI")(var.get("gs1DigitalLinkURI"), Js(True)))
    var.put("uncompressedDL", var.get("gs1DigitalLinkURI"))
    if (var.get("rv").get("detected") == Js("fully compressed GS1 Digital Link")) or (
        var.get("rv").get("detected") == Js("partially compressed GS1 Digital Link")
    ):
        var.put(
            "uncompressedDL",
            var.get("decompressGS1DigitalLink")(var.get("gs1DigitalLinkURI"), Js(False), var.get("rv").get("uriStem")),
        )
    var.put("qpos", var.get("uncompressedDL").callprop("indexOf", Js("?")))
    var.put("excludeQueryString", var.get("uncompressedDL").callprop("substr", Js(0.0), var.get("qpos")))
    var.put("rv2", var.get("analyseURI")(var.get("excludeQueryString"), Js(False)))
    var.put("identifiers", var.get("rv").get("structuredOutput").get("identifiers"))
    var.put("qualifiers", var.get("rv").get("structuredOutput").get("qualifiers"))
    var.put("dataAttributes", var.get("rv").get("structuredOutput").get("dataAttributes"))
    var.put("nonID", Js({}))
    var.put("elementStrings", Js({}))
    for PyJsTemp in var.get("qualifiers"):
        var.put("q", PyJsTemp)
        var.put("k", var.get("Object").callprop("keys", var.get("qualifiers").get(var.get("q"))))
        for PyJsTemp in var.get("k"):
            var.put("ki", PyJsTemp)
            var.get("nonID").put(
                var.get("k").get(var.get("ki")),
                var.get("qualifiers").get(var.get("q")).get(var.get("k").get(var.get("ki"))),
            )
            var.get("elementStrings").put(
                var.get("k").get(var.get("ki")),
                var.get("qualifiers").get(var.get("q")).get(var.get("k").get(var.get("ki"))),
            )
    for PyJsTemp in var.get("dataAttributes"):
        var.put("a", PyJsTemp)
        var.put("m", var.get("Object").callprop("keys", var.get("dataAttributes").get(var.get("a"))))
        for PyJsTemp in var.get("m"):
            var.put("ki", PyJsTemp)
            var.get("nonID").put(
                var.get("m").get(var.get("ki")),
                var.get("dataAttributes").get(var.get("a")).get(var.get("m").get(var.get("ki"))),
            )
            var.get("elementStrings").put(
                var.get("m").get(var.get("ki")),
                var.get("dataAttributes").get(var.get("a")).get(var.get("m").get(var.get("ki"))),
            )
    for PyJsTemp in var.get("identifiers"):
        var.put("i", PyJsTemp)
        var.put("k", var.get("Object").callprop("keys", var.get("identifiers").get(var.get("i"))))
        for PyJsTemp in var.get("k"):
            var.put("ki", PyJsTemp)
            var.get("elementStrings").put(
                var.get("k").get(var.get("ki")),
                var.get("identifiers").get(var.get("i")).get(var.get("k").get(var.get("ki"))),
            )
    var.get("rv").put("nonID", var.get("nonID"))
    var.put("nonIDKeys", var.get("Object").callprop("keys", var.get("rv").get("nonID")))
    var.put("aiKeys", var.get("Object").callprop("keys", var.get("elementStrings")))
    var.get("rv").put("primaryIdentifierMap", var.get("rv").get("structuredOutput").get("identifiers").get("0"))
    var.put("pimK", var.get("Object").callprop("keys", var.get("rv").get("primaryIdentifierMap")))
    var.get("rv").put("primaryIdentifier", var.get("pimK").get("0"))
    var.put("iiaqK", var.get("Object").callprop("keys", var.get("tableS1")))
    var.put("isInstanceIdentifier", Js(False))
    var.put("outputObject", Js({}))
    var.put(
        "context",
        Js(
            {
                "schema": Js("http://schema.org/"),
                "gs1": Js("https://gs1.org/voc/"),
                "rdf": Js("http://www.w3.org/1999/02/22-rdf-syntax-ns#"),
                "rdfs": Js("http://www.w3.org/2000/01/rdf-schema#"),
                "owl": Js("http://www.w3.org/2002/07/owl#"),
                "dcterms": Js("http://purl.org/dc/terms/"),
                "xsd": Js("http://www.w3.org/2001/XMLSchema#"),
                "skos": Js("http://www.w3.org/2004/02/skos/core#"),
                "gs1:value": Js({"@type": Js("xsd:float")}),
            }
        ),
    )
    if var.get("iiaqK").callprop("indexOf", var.get("rv").get("primaryIdentifier")) != (-Js(1.0)):
        var.put("iiaqV", var.get("tableS1").get(var.get("rv").get("primaryIdentifier")))
        if var.get("iiaqV").callprop("hasOwnProperty", Js("minLength")) and PyJsStrictNeq(
            var.get("iiaqV").get("minLength"), var.get("null")
        ):
            if var.get("rv").get("primaryIdentifier").get("length") >= var.get("iiaqV").get("minLength"):
                var.put("isInstanceIdentifier", Js(True))
        if var.get("iiaqV").callprop("hasOwnProperty", Js("requires")):
            if var.get("iiaqV").get("requires") == var.get("null"):
                var.put("isInstanceIdentifier", Js(True))
            else:
                for PyJsTemp in var.get("iiaqV").get("requires"):
                    var.put("v", PyJsTemp)
                    if var.get("nonIDKeys").callprop("indexOf", var.get("iiaqV").get("requires").get(var.get("v"))) != (
                        -Js(1.0)
                    ):
                        var.put("isInstanceIdentifier", Js(True))
    if var.get("isInstanceIdentifier"):
        var.get("outputObject").put("@id", var.get("excludeQueryString"))
        var.put("osa", Js([var.get("uncompressedDL")]))
        if PyJsStrictNeq(var.get("gs1DigitalLinkURI"), var.get("uncompressedDL")):
            var.get("osa").callprop("push", var.get("gs1DigitalLinkURI"))
        var.get("outputObject").put("owl:sameAs", var.get("osa"))
    else:
        var.get("outputObject").put("@id", Js("_:1"))
    var.get("rv").put("isInstanceIdentifier", var.get("isInstanceIdentifier"))
    var.put("csK", var.get("Object").callprop("keys", var.get("classSemantics")))
    var.put("ssK", var.get("Object").callprop("keys", var.get("stringSemantics")))
    var.put("qvK", var.get("Object").callprop("keys", var.get("quantitativeValueSemantics")))
    var.put("dvK", var.get("Object").callprop("keys", var.get("dateSemantics")))
    var.put("dtsvK", var.get("Object").callprop("keys", var.get("dateTimeSecondsSemantics")))
    var.put("dtmvK", var.get("Object").callprop("keys", var.get("dateTimeMinutesSemantics")))
    var.put("drK", var.get("Object").callprop("keys", var.get("dateRangeSemantics")))
    var.put("otype", Js([Js("rdfs:Class"), Js("owl:Class")]))
    for PyJsTemp in var.get("csK"):
        var.put("i", PyJsTemp)
        if var.get("aiKeys").callprop("indexOf", var.get("csK").get(var.get("i"))) != (-Js(1.0)):
            var.put("c", var.get("classSemantics").get(var.get("csK").get(var.get("i"))))
            var.put("otype", var.get("otype").callprop("concat", var.get("c")))
    var.get("outputObject").put("@type", var.get("otype"))
    var.put("uriStem", var.get("rv2").get("uriStem"))
    var.put(
        "pathComponents", var.get("rv2").get("pathComponents").callprop("substr", Js(1.0)).callprop("split", Js("/"))
    )
    if (var.get("pathComponents").get("length") > Js(2.0)) and (
        (var.get("pathComponents").get("length") % Js(2.0)) == Js(0.0)
    ):
        var.put("l", (var.get("pathComponents").get("length") - Js(2.0)))
        var.put("superClasses", Js([]))
        while 1:
            var.put("sl", var.get("pathComponents").callprop("slice", Js(0.0), var.get("l")))
            var.put("superClass", ((var.get("uriStem") + Js("/")) + var.get("sl").callprop("join", Js("/"))))
            var.get("superClasses").callprop("push", Js({"@id": var.get("superClass")}))
            var.put("l", (var.get("l") - Js(2.0)))
            if not (var.get("l") >= Js(2.0)):
                break
        if var.get("superClasses").get("length") > Js(0.0):
            var.get("outputObject").put("dcterms:isPartOf", var.get("superClasses"))
            var.get("outputObject").put("rdfs:subClassOf", var.get("superClasses"))
    for PyJsTemp in var.get("ssK"):
        var.put("i", PyJsTemp)
        if var.get("aiKeys").callprop("indexOf", var.get("ssK").get(var.get("i"))) != (-Js(1.0)):
            for PyJsTemp in var.get("stringSemantics").get(var.get("ssK").get(var.get("i"))):
                var.put("j", PyJsTemp)
                var.put("predicate", var.get("stringSemantics").get(var.get("ssK").get(var.get("i"))).get(var.get("j")))
                var.put("value", var.get("elementStrings").get(var.get("ssK").get(var.get("i"))))
                var.get("outputObject").put(var.get("predicate"), var.get("value"))
    for PyJsTemp in var.get("qvK"):
        var.put("i", PyJsTemp)
        if var.get("aiKeys").callprop("indexOf", var.get("qvK").get(var.get("i"))) != (-Js(1.0)):
            var.put(
                "predicate",
                var.get("quantitativeValueSemantics").get(var.get("qvK").get(var.get("i"))).get("p").get("0"),
            )
            var.put("rec20", var.get("quantitativeValueSemantics").get(var.get("qvK").get(var.get("i"))).get("rec20"))
            var.put("bareValue", var.get("elementStrings").get(var.get("qvK").get(var.get("i"))))
            var.put("fourthDigit", var.get("qvK").get(var.get("i")).callprop("charAt", Js(3.0)))
            var.put("value", var.get("bareValue"))
            # for JS loop
            var.put("i", Js(0.0))
            while var.get("i") < var.get("fourthDigit"):
                try:
                    var.put("value", (var.get("value") / Js(10.0)))
                finally:
                    (var.put("i", Js(var.get("i").to_number()) + Js(1)) - Js(1))
            var.put("qv", Js({}))
            var.get("qv").put("@type", Js("gs1:QuantitativeValue"))
            var.get("qv").put("gs1:unitCode", var.get("rec20"))
            var.get("qv").put("gs1:value", var.get("value").callprop("toString"))
            var.get("outputObject").put(var.get("predicate"), var.get("qv"))
    for PyJsTemp in var.get("dvK"):
        var.put("i", PyJsTemp)
        if var.get("aiKeys").callprop("indexOf", var.get("dvK").get(var.get("i"))) != (-Js(1.0)):
            for PyJsTemp in var.get("dateSemantics").get(var.get("dvK").get(var.get("i"))):
                var.put("j", PyJsTemp)
                var.put("predicate", var.get("dateSemantics").get(var.get("dvK").get(var.get("i"))).get(var.get("j")))
                var.get("context").put(var.get("predicate"), Js({"@type": Js("xsd:date")}))
                var.put("bareValue", var.get("elementStrings").get(var.get("dvK").get(var.get("i"))))
                var.put("xsdDateValue", var.get("sixDigitToXsdDate")(var.get("bareValue")))
                var.get("outputObject").put(var.get("predicate"), var.get("xsdDateValue"))
    for PyJsTemp in var.get("dtsvK"):
        var.put("i", PyJsTemp)
        if var.get("aiKeys").callprop("indexOf", var.get("dtsvK").get(var.get("i"))) != (-Js(1.0)):
            for PyJsTemp in var.get("dateTimeSecondsSemantics").get(var.get("dtsvK").get(var.get("i"))):
                var.put("j", PyJsTemp)
                var.put(
                    "predicate",
                    var.get("dateTimeSecondsSemantics").get(var.get("dtsvK").get(var.get("i"))).get(var.get("j")),
                )
                var.get("context").put(var.get("predicate"), Js({"@type": Js("xsd:dateTime")}))
                var.put("bareValue", var.get("elementStrings").get(var.get("dtsvK").get(var.get("i"))))
                var.put("xsdDateTimeValue", var.get("maxTwelveDigitToXsdDateTime")(var.get("bareValue")))
                var.get("outputObject").put(var.get("predicate"), var.get("xsdDateTimeValue"))
    for PyJsTemp in var.get("dtmvK"):
        var.put("i", PyJsTemp)
        if var.get("aiKeys").callprop("indexOf", var.get("dtmvK").get(var.get("i"))) != (-Js(1.0)):
            for PyJsTemp in var.get("dateTimeMinutesSemantics").get(var.get("dtmvK").get(var.get("i"))):
                var.put("j", PyJsTemp)
                var.put(
                    "predicate",
                    var.get("dateTimeMinutesSemantics").get(var.get("dtmvK").get(var.get("i"))).get(var.get("j")),
                )
                var.get("context").put(var.get("predicate"), Js({"@type": Js("xsd:dateTime")}))
                var.put("bareValue", var.get("elementStrings").get(var.get("dtmvK").get(var.get("i"))))
                var.put("xsdDateTimeValue", var.get("tenDigitToXsdDateTime")(var.get("bareValue")))
                var.get("outputObject").put(var.get("predicate"), var.get("xsdDateTimeValue"))
    for PyJsTemp in var.get("drK"):
        var.put("i", PyJsTemp)
        if var.get("aiKeys").callprop("indexOf", var.get("drK").get(var.get("i"))) != (-Js(1.0)):
            for PyJsTemp in var.get("dateRangeSemantics").get(var.get("drK").get(var.get("i"))):
                var.put("j", PyJsTemp)
                var.put(
                    "predicate", var.get("dateRangeSemantics").get(var.get("drK").get(var.get("i"))).get(var.get("j"))
                )
                var.put("bareValue", var.get("elementStrings").get(var.get("drK").get(var.get("i"))))
                if var.get("bareValue").get("length") == Js(6.0):
                    var.put("xsdDateValue", var.get("sixDigitToXsdDate")(var.get("bareValue")))
                    var.get("context").put(var.get("predicate"), Js({"@type": Js("xsd:dateTime")}))
                    var.get("outputObject").put(var.get("predicate"), var.get("xsdDateValue"))
                else:
                    if var.get("bareValue").get("length") == Js(12.0):
                        var.put(
                            "xsdStartDateValue",
                            var.get("sixDigitToXsdDate")(var.get("bareValue").callprop("substr", Js(0.0), Js(6.0))),
                        )
                        var.put(
                            "xsdEndDateValue",
                            var.get("sixDigitToXsdDate")(var.get("bareValue").callprop("substr", Js(6.0), Js(6.0))),
                        )
                        var.get("context").put((var.get("predicate") + Js("Start")), Js({"@type": Js("xsd:dateTime")}))
                        var.get("context").put((var.get("predicate") + Js("End")), Js({"@type": Js("xsd:dateTime")}))
                        var.get("outputObject").put((var.get("predicate") + Js("Start")), var.get("xsdStartDateValue"))
                        var.get("outputObject").put((var.get("predicate") + Js("End")), var.get("xsdEndDateValue"))
    var.get("outputObject").put("gs1:elementStrings", var.get("rv").get("elementStringsOutput"))
    var.get("rv").put(
        "semantics", var.get("Object").callprop("assign", Js({"@context": var.get("context")}), var.get("outputObject"))
    )
    return var.get("rv").get("semantics")
    pass
    pass
    pass
    pass


PyJsHoisted_analyseURIsemantics_.func_name = "analyseURIsemantics"
var.put("analyseURIsemantics", PyJsHoisted_analyseURIsemantics_)


@Js
def PyJsHoisted_analyseURI_(gs1DigitalLinkURI, extended, this, arguments, var=var):
    var = Scope(
        {"gs1DigitalLinkURI": gs1DigitalLinkURI, "extended": extended, "this": this, "arguments": arguments}, var
    )
    var.registers(
        [
            "firstSlashOfAllPath",
            "fi",
            "l",
            "numkey",
            "beforeQueryString",
            "pathInfo",
            "extended",
            "pathComponents",
            "numericPrimaryIdentifier",
            "gs1AIarray",
            "bql",
            "i",
            "afterProtocol",
            "pathCandidates",
            "uriStemPathComponents",
            "protocol",
            "searching",
            "pairs",
            "otherArray",
            "relevantPathComponents",
            "qs",
            "structuredArray",
            "pcl",
            "beforeFragment",
            "extracted",
            "cursor",
            "gs1DigitalLinkURI",
            "domain",
            "pcr",
            "pathElementIndex",
            "rv",
            "pcc",
            "pathElements",
            "p",
            "queryStringCandidates",
            "pci",
        ]
    )
    var.put("rv", Js({}))
    var.get("rv").put("fragment", Js(""))
    var.put("fi", var.get("gs1DigitalLinkURI").callprop("indexOf", Js("#")))
    var.put("beforeFragment", var.get("gs1DigitalLinkURI"))
    if var.get("fi") > (-Js(1.0)):
        var.get("rv").put("fragment", var.get("gs1DigitalLinkURI").callprop("substr", (Js(1.0) + var.get("fi"))))
        var.put("beforeFragment", var.get("gs1DigitalLinkURI").callprop("substr", Js(0.0), var.get("fi")))
    var.get("rv").put("queryString", Js(""))
    var.put("beforeQueryString", var.get("beforeFragment"))
    var.put("qs", var.get("beforeFragment").callprop("indexOf", Js("?")))
    if var.get("qs") > (-Js(1.0)):
        var.get("rv").put("queryString", var.get("beforeFragment").callprop("substr", (Js(1.0) + var.get("qs"))))
        var.put("beforeQueryString", var.get("beforeFragment").callprop("substr", Js(0.0), var.get("qs")))
    var.put("bql", var.get("beforeQueryString").get("length"))
    if var.get("beforeQueryString").callprop("substr", (var.get("bql") - Js(1.0)), Js(1.0)) == Js("/"):
        var.put(
            "beforeQueryString", var.get("beforeQueryString").callprop("substr", Js(0.0), (var.get("bql") - Js(1.0)))
        )
    var.put("cursor", Js(0.0))
    if var.get("beforeQueryString").callprop("indexOf", Js("http://")) == Js(0.0):
        var.put("cursor", Js(7.0))
    if var.get("beforeQueryString").callprop("indexOf", Js("https://")) == Js(0.0):
        var.put("cursor", Js(8.0))
    var.put("protocol", var.get("beforeQueryString").callprop("substr", Js(0.0), var.get("cursor")))
    var.put("afterProtocol", var.get("beforeQueryString").callprop("substr", var.get("cursor")))
    var.put("firstSlashOfAllPath", var.get("afterProtocol").callprop("indexOf", Js("/")))
    var.put("pathInfo", var.get("afterProtocol").callprop("substr", (Js(1.0) + var.get("firstSlashOfAllPath"))))
    var.get("rv").put("uriPathInfo", (Js("/") + var.get("pathInfo")))
    var.put("domain", var.get("afterProtocol").callprop("substr", Js(0.0), var.get("firstSlashOfAllPath")))
    var.put("pathComponents", var.get("pathInfo").callprop("split", Js("/")))
    var.put("relevantPathComponents", Js([]))
    var.put("uriStemPathComponents", Js([]))
    var.put("pcr", var.get("pathComponents").callprop("reverse"))
    var.put("pcl", var.get("pathComponents").get("length"))
    var.put("pci", var.get("pcl"))
    var.put("searching", Js(True))
    var.put("numericPrimaryIdentifier", Js(""))
    for PyJsTemp in var.get("pcr"):
        var.put("i", PyJsTemp)
        var.put("numkey", Js(""))
        var.put("pcc", var.get("pcr").get(var.get("i")))
        if var.get("regexAllNum").callprop("test", var.get("pcc")):
            var.put("numkey", var.get("pcc"))
        else:
            if var.get("shortCodeToNumeric").callprop("hasOwnProperty", var.get("pcc")):
                var.put("numkey", var.get("shortCodeToNumeric").get(var.get("pcc")))
        if PyJsStrictNeq(var.get("numkey"), Js("")) and var.get("searching"):
            if var.get("aiMaps").get("identifiers").callprop("indexOf", var.get("numkey")) > (-Js(1.0)):
                var.put("searching", Js(False))
                var.put("pci", (var.get("pcl") - var.get("i")))
                var.put("numericPrimaryIdentifier", var.get("numkey"))
                var.put(
                    "relevantPathComponents",
                    var.get("pcr")
                    .callprop("slice", Js(0.0), (var.get("parseInt")(var.get("i")) + Js(1.0)))
                    .callprop("reverse"),
                )
                var.put(
                    "uriStemPathComponents",
                    var.get("pcr").callprop("slice", (var.get("parseInt")(var.get("i")) + Js(1.0))).callprop("reverse"),
                )
    if var.get("relevantPathComponents").get("length") > Js(0.0):
        var.get("rv").put("pathComponents", (Js("/") + var.get("relevantPathComponents").callprop("join", Js("/"))))
    else:
        var.get("rv").put("pathComponents", Js(""))
    if var.get("uriStemPathComponents").get("length") > Js(0.0):
        var.get("rv").put(
            "uriStem",
            (
                ((var.get("protocol") + var.get("domain")) + Js("/"))
                + var.get("uriStemPathComponents").callprop("join", Js("/"))
            ),
        )
    else:
        var.get("rv").put("uriStem", (var.get("protocol") + var.get("domain")))
    var.get("rv").put(
        "queryString",
        var.get("rv").get("queryString").callprop("replace", var.get("RegExp").create(Js(";"), Js("g")), Js("&")),
    )
    var.put("pathCandidates", Js({}))
    var.put("pathElements", var.get("pathInfo").callprop("split", Js("/")))
    var.put("l", var.get("pathElements").get("length"))
    var.put("pathElementIndex", (var.get("l") - Js(2.0)))
    while var.get("pathElementIndex") >= Js(0.0):
        var.get("pathCandidates").put(
            var.get("pathElements").get(var.get("pathElementIndex")),
            var.get("percentDecode")(var.get("pathElements").get((Js(1.0) + var.get("pathElementIndex")))),
        )
        var.put("pathElementIndex", Js(2.0), "-")
    var.put("queryStringCandidates", Js({}))
    if PyJsStrictNeq(var.get("rv").get("queryString"), Js("")):
        var.put("pairs", var.get("rv").get("queryString").callprop("split", Js("&")))
        # for JS loop
        var.put("i", Js(0.0))
        while var.get("i") < var.get("pairs").get("length"):
            try:
                var.put("p", var.get("pairs").get(var.get("i")).callprop("split", Js("=")))
                if PyJsStrictNeq(var.get("p").get("0"), var.get("null")) and PyJsStrictNeq(
                    var.get("p").get("1"), var.get("null")
                ):
                    if var.get("shortCodeToNumeric").callprop("hasOwnProperty", var.get("p").get("0")):
                        var.get("queryStringCandidates").put(
                            var.get("shortCodeToNumeric").get(var.get("p").get("0")),
                            var.get("percentDecode")(var.get("p").get("1")),
                        )
                        var.get("queryStringCandidates").delete(var.get("p").get("0"))
                    else:
                        var.get("queryStringCandidates").put(
                            var.get("p").get("0"), var.get("percentDecode")(var.get("p").get("1"))
                        )
            finally:
                (var.put("i", Js(var.get("i").to_number()) + Js(1)) - Js(1))
    var.get("rv").put("pathCandidates", var.get("pathCandidates"))
    var.get("rv").put("queryStringCandidates", var.get("queryStringCandidates"))
    var.get("rv").put("detected", Js(""))
    var.get("rv").put("uncompressedPath", Js(""))
    var.get("rv").put("compressedPath", Js(""))
    var.get("rv").put("structuredOutput", Js(""))
    if (var.get("relevantPathComponents").get("length") > Js(0.0)) and (
        (var.get("relevantPathComponents").get("length") % Js(2.0)) == Js(0.0)
    ):
        if (
            var.get("aiRegex")
            .get(var.get("numericPrimaryIdentifier"))
            .callprop("test", var.get("relevantPathComponents").get("1"))
        ):
            var.get("rv").put("detected", Js("uncompressed GS1 Digital Link"))
            var.get("rv").put(
                "uncompressedPath", (Js("/") + var.get("relevantPathComponents").callprop("join", Js("/")))
            )
            if var.get("extended"):
                var.put("extracted", var.get("extractFromGS1digitalLink")(var.get("gs1DigitalLinkURI")))
                var.put("gs1AIarray", var.get("extracted").get("GS1"))
                var.put("otherArray", var.get("extracted").get("other"))
                var.put(
                    "structuredArray", var.get("buildStructuredArray")(var.get("gs1AIarray"), var.get("otherArray"))
                )
                var.get("rv").put("structuredOutput", var.get("structuredArray"))
                var.get("rv").put(
                    "elementStringsOutput",
                    var.get("gs1digitalLinkToGS1elementStrings")(var.get("gs1DigitalLinkURI"), Js(True)),
                )
    if (var.get("relevantPathComponents").get("length") == Js(3.0)) and var.get("regexSafe64").callprop(
        "test", var.get("relevantPathComponents").get("2")
    ):
        if (
            var.get("aiRegex")
            .get(var.get("numericPrimaryIdentifier"))
            .callprop("test", var.get("relevantPathComponents").get("1"))
        ):
            var.get("rv").put("detected", Js("partially compressed GS1 Digital Link"))
            var.get("rv").put(
                "uncompressedPath",
                (
                    Js("/")
                    + var.get("relevantPathComponents").callprop("slice", Js(0.0), Js(2.0)).callprop("join", Js("/"))
                ),
            )
            var.get("rv").put("compressedPath", var.get("relevantPathComponents").get("2"))
            if var.get("extended"):
                var.put("extracted", var.get("extractFromCompressedGS1digitalLink")(var.get("gs1DigitalLinkURI")))
                var.put("gs1AIarray", var.get("extracted").get("GS1"))
                var.put("otherArray", var.get("extracted").get("other"))
                var.put(
                    "structuredArray", var.get("buildStructuredArray")(var.get("gs1AIarray"), var.get("otherArray"))
                )
                var.get("rv").put("structuredOutput", var.get("structuredArray"))
                var.get("rv").put(
                    "elementStringsOutput",
                    var.get("gs1compressedDigitalLinkToGS1elementStrings")(var.get("gs1DigitalLinkURI"), Js(True)),
                )
    if (
        (var.get("rv").get("detected") == Js("")) and var.get("regexSafe64").callprop("test", var.get("pcr").get("0"))
    ) and PyJsStrictNeq(var.get("protocol"), Js("")):
        var.get("rv").put("detected", Js("fully compressed GS1 Digital Link"))
        var.get("rv").put("uncompressedPath", Js(""))
        var.get("rv").put("compressedPath", var.get("pcr").get("0"))
        if var.get("extended"):
            var.put("extracted", var.get("extractFromCompressedGS1digitalLink")(var.get("gs1DigitalLinkURI")))
            var.put("gs1AIarray", var.get("extracted").get("GS1"))
            var.put("otherArray", var.get("extracted").get("other"))
            var.put("structuredArray", var.get("buildStructuredArray")(var.get("gs1AIarray"), var.get("otherArray")))
            var.get("rv").put("structuredOutput", var.get("structuredArray"))
            var.get("rv").put(
                "elementStringsOutput",
                var.get("gs1compressedDigitalLinkToGS1elementStrings")(var.get("gs1DigitalLinkURI"), Js(True)),
            )
    return var.get("rv")


PyJsHoisted_analyseURI_.func_name = "analyseURI"
var.put("analyseURI", PyJsHoisted_analyseURI_)


@Js
def PyJsHoisted_mergeObjects_(obj1, obj2, this, arguments, var=var):
    var = Scope({"obj1": obj1, "obj2": obj2, "this": this, "arguments": arguments}, var)
    var.registers(["j", "i", "obj1", "obj2", "response"])
    var.put("response", Js({}))
    for PyJsTemp in var.get("obj1"):
        var.put("i", PyJsTemp)
        var.get("response").put(var.get("i"), var.get("obj1").get(var.get("i")))
    for PyJsTemp in var.get("obj2"):
        var.put("j", PyJsTemp)
        var.get("response").put(var.get("j"), var.get("obj2").get(var.get("j")))
    return var.get("response")


PyJsHoisted_mergeObjects_.func_name = "mergeObjects"
var.put("mergeObjects", PyJsHoisted_mergeObjects_)


@Js
def PyJsHoisted_extractFromGS1digitalLink_(gs1DigitalLinkURI, this, arguments, var=var):
    var = Scope({"gs1DigitalLinkURI": gs1DigitalLinkURI, "this": this, "arguments": arguments}, var)
    var.registers(
        [
            "queryString",
            "rv",
            "obj",
            "pathCandidates",
            "s",
            "numkey",
            "padGTIN",
            "candidates",
            "gs1DigitalLinkURI",
            "k",
            "queryStringCandidates",
            "uriPathInfo",
            "nonGS1queryStringCandidates",
        ]
    )

    @Js
    def PyJsHoisted_padGTIN_(ai, value, this, arguments, var=var):
        var = Scope({"ai": ai, "value": value, "this": this, "arguments": arguments}, var)
        var.registers(["value", "ai", "newvalue"])
        var.put("newvalue", var.get("value"))
        if (((var.get("ai") == Js("01")) or (var.get("ai") == Js("(01)"))) or (var.get("ai") == Js("02"))) or (
            var.get("ai") == Js("(02)")
        ):
            if var.get("value").get("length") == Js(8.0):
                var.put("newvalue", (Js("000000") + var.get("value")))
            if var.get("value").get("length") == Js(12.0):
                var.put("newvalue", (Js("00") + var.get("value")))
            if var.get("value").get("length") == Js(13.0):
                var.put("newvalue", (Js("0") + var.get("value")))
        return var.get("newvalue")

    PyJsHoisted_padGTIN_.func_name = "padGTIN"
    var.put("padGTIN", PyJsHoisted_padGTIN_)
    var.put("obj", Js({}))
    var.put("rv", Js({}))
    var.put("s", var.get("analyseURI")(var.get("gs1DigitalLinkURI"), Js(False)))
    var.put("queryString", var.get("s").get("queryString"))
    var.put("uriPathInfo", var.get("s").get("uriPathInfo"))
    var.put("pathCandidates", var.get("s").get("pathCandidates"))
    var.put("queryStringCandidates", var.get("s").get("queryStringCandidates"))
    var.put("nonGS1queryStringCandidates", Js({}))
    var.put("candidates", var.get("mergeObjects")(var.get("pathCandidates"), var.get("queryStringCandidates")))
    for PyJsTemp in var.get("candidates"):
        var.put("k", PyJsTemp)
        if var.get("candidates").callprop("hasOwnProperty", var.get("k")):
            if var.get("regexAllNum").callprop("test", var.get("k")).neg():
                if var.get("shortCodeToNumeric").callprop("hasOwnProperty", var.get("k")):
                    var.put("numkey", var.get("shortCodeToNumeric").get(var.get("k")))
                    var.get("candidates").put(var.get("numkey"), var.get("candidates").get(var.get("k")))
                    var.get("candidates").delete(var.get("k"))
                else:
                    var.get("nonGS1queryStringCandidates").put(var.get("k"), var.get("candidates").get(var.get("k")))
                    var.get("candidates").delete(var.get("k"))
    for PyJsTemp in var.get("candidates"):
        var.put("k", PyJsTemp)
        if var.get("candidates").callprop("hasOwnProperty", var.get("k")):
            var.get("verifySyntax")(var.get("k"), var.get("candidates").get(var.get("k")))
            var.get("verifyCheckDigit")(var.get("k"), var.get("candidates").get(var.get("k")))
            var.get("obj").put(var.get("k"), var.get("padGTIN")(var.get("k"), var.get("candidates").get(var.get("k"))))
    var.get("rv").put("GS1", var.get("obj"))
    var.get("rv").put("other", var.get("nonGS1queryStringCandidates"))
    return var.get("rv")
    pass


PyJsHoisted_extractFromGS1digitalLink_.func_name = "extractFromGS1digitalLink"
var.put("extractFromGS1digitalLink", PyJsHoisted_extractFromGS1digitalLink_)


@Js
def PyJsHoisted_extractFromCompressedGS1digitalLink_(gs1DigitalLinkURI, this, arguments, var=var):
    var = Scope({"gs1DigitalLinkURI": gs1DigitalLinkURI, "this": this, "arguments": arguments}, var)
    var.registers(
        [
            "binstr",
            "base64segment",
            "k",
            "uriPathInfo",
            "gs1primaryKey",
            "i",
            "gs1primaryKeyValue",
            "nonGS1queryStringCandidates",
            "queryString",
            "pairs",
            "gs1DigitalLinkURI",
            "index1",
            "objOther",
            "rv",
            "s",
            "objGS1",
            "firstFragment",
            "candidates",
            "p",
            "index2",
            "queryStringCandidates",
        ]
    )
    var.put("objGS1", Js({}))
    var.put("objOther", Js({}))
    var.put("rv", Js({}))
    var.put("s", var.get("analyseURI")(var.get("gs1DigitalLinkURI"), Js(False)))
    var.put("queryString", var.get("s").get("queryString"))
    var.put("uriPathInfo", var.get("s").get("uriPathInfo"))
    var.put("candidates", var.get("s").get("pathCandidates"))
    var.put("queryStringCandidates", var.get("s").get("queryStringCandidates"))
    var.put("nonGS1queryStringCandidates", Js({}))
    if PyJsStrictNeq(var.get("queryString"), Js("")):
        var.put(
            "queryString",
            var.get("queryString").callprop("replace", var.get("RegExp").create(Js(";"), Js("g")), Js("&")),
        )
        var.put("firstFragment", var.get("queryString").callprop("indexOf", Js("#")))
        if var.get("firstFragment") > (-Js(1.0)):
            var.put("queryString", var.get("queryString").callprop("substring", Js(0.0), var.get("firstFragment")))
        var.put("pairs", var.get("queryString").callprop("split", Js("&")))
        # for JS loop
        var.put("i", Js(0.0))
        while var.get("i") < var.get("pairs").get("length"):
            try:
                var.put("p", var.get("pairs").get(var.get("i")).callprop("split", Js("=")))
                if (
                    PyJsStrictNeq(var.get("p").get("0"), var.get("null"))
                    and PyJsStrictNeq(var.get("p").get("1"), var.get("null"))
                ) and (
                    var.get("regexAllNum").callprop("test", var.get("p").get("0")).neg()
                    and var.get("shortCodeToNumeric").callprop("hasOwnProperty", var.get("p").get("0")).neg()
                ):
                    var.get("nonGS1queryStringCandidates").put(
                        var.get("p").get("0"), var.get("percentDecode")(var.get("p").get("1"))
                    )
            finally:
                (var.put("i", Js(var.get("i").to_number()) + Js(1)) - Js(1))
    var.put("uriPathInfo", var.get("uriPathInfo").callprop("substr", Js(1.0)))
    if var.get("regexSafe64").callprop("test", var.get("uriPathInfo")):
        var.put("binstr", var.get("base642bin")(var.get("uriPathInfo")))
        var.put("objGS1", var.get("decompressBinaryToGS1AIarray")(var.get("binstr")))
    else:
        var.put("index1", var.get("uriPathInfo").callprop("indexOf", Js("/")))
        var.put("index2", var.get("uriPathInfo").callprop("lastIndexOf", Js("/")))
        var.put("gs1primaryKey", var.get("uriPathInfo").callprop("substr", Js(0.0), var.get("index1")))
        var.put("base64segment", var.get("uriPathInfo").callprop("substr", (Js(1.0) + var.get("index2"))))
        var.put(
            "gs1primaryKeyValue",
            var.get("uriPathInfo").callprop(
                "substr", (Js(1.0) + var.get("index1")), ((var.get("index2") - var.get("index1")) - Js(1.0))
            ),
        )
        var.put("objGS1", var.get("decompressBinaryToGS1AIarray")(var.get("base642bin")(var.get("base64segment"))))
        if var.get("regexAllNum").callprop("test", var.get("gs1primaryKey")):
            var.get("objGS1").put(var.get("gs1primaryKey"), var.get("gs1primaryKeyValue"))
        else:
            if var.get("shortCodeToNumeric").callprop("hasOwnProperty", var.get("gs1primaryKey")):
                var.get("objGS1").put(
                    var.get("shortCodeToNumeric").get(var.get("gs1primaryKey")), var.get("gs1primaryKeyValue")
                )
    for PyJsTemp in var.get("objGS1"):
        var.put("k", PyJsTemp)
        if (
            var.get("regexAllNum").callprop("test", var.get("k")).neg()
            and var.get("shortCodeToNumeric").callprop("hasOwnProperty", var.get("k")).neg()
        ):
            var.get("nonGS1queryStringCandidates").put(var.get("k"), var.get("objGS1").get(var.get("k")))
            var.get("objGS1").delete(var.get("k"))
    var.get("rv").put("GS1", var.get("objGS1"))
    var.get("rv").put("other", var.get("nonGS1queryStringCandidates"))
    return var.get("rv")


PyJsHoisted_extractFromCompressedGS1digitalLink_.func_name = "extractFromCompressedGS1digitalLink"
var.put("extractFromCompressedGS1digitalLink", PyJsHoisted_extractFromCompressedGS1digitalLink_)


@Js
def PyJsHoisted_buildGS1elementStrings_(gs1AIarray, brackets, this, arguments, var=var):
    var = Scope({"gs1AIarray": gs1AIarray, "brackets": brackets, "this": this, "arguments": arguments}, var)
    var.registers(
        [
            "gs1AIarray",
            "elementStringsPush",
            "fixedLengthValues",
            "i",
            "identifiers",
            "a",
            "qualifiers",
            "sortedAttributes",
            "elementStrings",
            "gs",
            "qualifiersForPrimary",
            "fixedLengthValuesOther",
            "qindex",
            "brackets",
            "variableLengthValues",
            "fixedLengthPrimaryIdentifier",
            "attributes",
        ]
    )

    @Js
    def PyJsHoisted_elementStringsPush_(elementStrings, ai, value, gs, this, arguments, var=var):
        var = Scope(
            {
                "elementStrings": elementStrings,
                "ai": ai,
                "value": value,
                "gs": gs,
                "this": this,
                "arguments": arguments,
            },
            var,
        )
        var.registers(["ai", "elementStrings", "gs", "value", "newvalue"])
        var.put("newvalue", var.get("value"))
        if (((var.get("ai") == Js("01")) or (var.get("ai") == Js("(01)"))) or (var.get("ai") == Js("02"))) or (
            var.get("ai") == Js("(02)")
        ):
            if var.get("value").get("length") == Js(8.0):
                var.put("newvalue", (Js("000000") + var.get("value")))
            if var.get("value").get("length") == Js(12.0):
                var.put("newvalue", (Js("00") + var.get("value")))
            if var.get("value").get("length") == Js(13.0):
                var.put("newvalue", (Js("0") + var.get("value")))
        var.get("elementStrings").callprop("push", ((var.get("ai") + var.get("newvalue")) + var.get("gs")))
        return var.get("elementStrings")

    PyJsHoisted_elementStringsPush_.func_name = "elementStringsPush"
    var.put("elementStringsPush", PyJsHoisted_elementStringsPush_)
    var.put("identifiers", Js([]))
    var.put("qualifiers", Js([]))
    var.put("attributes", Js([]))
    var.put("fixedLengthValues", Js([]))
    var.put("variableLengthValues", Js([]))
    var.put("elementStrings", Js([]))
    for PyJsTemp in var.get("gs1AIarray"):
        var.put("a", PyJsTemp)
        if var.get("gs1AIarray").callprop("hasOwnProperty", var.get("a")):
            if var.get("aiMaps").get("identifiers").callprop("indexOf", var.get("a")) != (-Js(1.0)):
                var.get("identifiers").callprop("push", var.get("a"))
            if var.get("aiMaps").get("qualifiers").callprop("indexOf", var.get("a")) != (-Js(1.0)):
                var.get("qualifiers").callprop("push", var.get("a"))
            if var.get("aiMaps").get("dataAttributes").callprop("indexOf", var.get("a")) != (-Js(1.0)):
                var.get("attributes").callprop("push", var.get("a"))
            if var.get("aiMaps").get("fixedLength").callprop("indexOf", var.get("a")) != (-Js(1.0)):
                var.get("fixedLengthValues").callprop("push", var.get("a"))
            if var.get("aiMaps").get("variableLength").callprop("indexOf", var.get("a")) != (-Js(1.0)):
                var.get("variableLengthValues").callprop("push", var.get("a"))
    if var.get("brackets") == Js(True):
        if PyJsStrictNeq(var.get("identifiers").get("length"), Js(1.0)):
            PyJsTempException = JsToPyException(
                var.get("Error").create(
                    (
                        (
                            (
                                (
                                    Js(
                                        "The associative array should contain exactly one primary identification key - it contained "
                                    )
                                    + var.get("identifiers").get("length")
                                )
                                + Js(" ")
                            )
                            + var.get("JSON").callprop("stringify", var.get("identifiers"))
                        )
                        + Js("; please check for a syntax error")
                    )
                )
            )
            raise PyJsTempException
        else:
            var.get("verifySyntax")(
                var.get("identifiers").get("0"), var.get("gs1AIarray").get(var.get("identifiers").get("0"))
            )
            var.get("verifyCheckDigit")(
                var.get("identifiers").get("0"), var.get("gs1AIarray").get(var.get("identifiers").get("0"))
            )
            var.put(
                "elementStrings",
                var.get("elementStringsPush")(
                    var.get("elementStrings"),
                    ((Js("(") + var.get("identifiers").get("0")) + Js(")")),
                    var.get("gs1AIarray").get(var.get("identifiers").get("0")),
                    Js(""),
                ),
            )
            if var.get("aiQualifiers").callprop("hasOwnProperty", var.get("identifiers").get("0")):
                var.put("qualifiersForPrimary", var.get("aiQualifiers").get(var.get("identifiers").get("0")))
                for PyJsTemp in var.get("qualifiersForPrimary"):
                    var.put("qindex", PyJsTemp)
                    if var.get("qualifiers").callprop(
                        "indexOf", var.get("qualifiersForPrimary").get(var.get("qindex"))
                    ) > (-Js(1.0)):
                        var.put(
                            "elementStrings",
                            var.get("elementStringsPush")(
                                var.get("elementStrings"),
                                ((Js("(") + var.get("qualifiersForPrimary").get(var.get("qindex"))) + Js(")")),
                                var.get("gs1AIarray").get(var.get("qualifiersForPrimary").get(var.get("qindex"))),
                                Js(""),
                            ),
                        )
            var.put("sortedAttributes", var.get("attributes").callprop("sort"))
            for PyJsTemp in var.get("sortedAttributes"):
                var.put("a", PyJsTemp)
                var.put(
                    "elementStrings",
                    var.get("elementStringsPush")(
                        var.get("elementStrings"),
                        ((Js("(") + var.get("attributes").get(var.get("a"))) + Js(")")),
                        var.get("gs1AIarray").get(var.get("attributes").get(var.get("a"))),
                        Js(""),
                    ),
                )
    else:
        var.put("fixedLengthPrimaryIdentifier", Js([]))
        var.put("fixedLengthValuesOther", var.get("fixedLengthValues").callprop("slice", Js(0.0)))
        pass
        for PyJsTemp in var.get("fixedLengthValuesOther"):
            var.put("i", PyJsTemp)
            if var.get("identifiers").callprop("indexOf", var.get("fixedLengthValuesOther").get(var.get("i"))) > (
                -Js(1.0)
            ):
                var.get("fixedLengthPrimaryIdentifier").callprop(
                    "push", var.get("fixedLengthValuesOther").get(var.get("i"))
                )
                var.get("fixedLengthValuesOther").callprop("splice", var.get("i"), Js(1.0))
        for PyJsTemp in var.get("fixedLengthPrimaryIdentifier"):
            var.put("i", PyJsTemp)
            var.put(
                "elementStrings",
                var.get("elementStringsPush")(
                    var.get("elementStrings"),
                    var.get("fixedLengthPrimaryIdentifier").get(var.get("i")),
                    var.get("gs1AIarray").get(var.get("fixedLengthPrimaryIdentifier").get(var.get("i"))),
                    Js(""),
                ),
            )
        for PyJsTemp in var.get("fixedLengthValuesOther"):
            var.put("i", PyJsTemp)
            var.put(
                "elementStrings",
                var.get("elementStringsPush")(
                    var.get("elementStrings"),
                    var.get("fixedLengthValuesOther").get(var.get("i")),
                    var.get("gs1AIarray").get(var.get("fixedLengthValuesOther").get(var.get("i"))),
                    Js(""),
                ),
            )
        for PyJsTemp in var.get("variableLengthValues"):
            var.put("i", PyJsTemp)
            var.put("gs", Js(""))
            if var.get("i") < (var.get("variableLengthValues").get("length") - Js(1.0)):
                var.put("gs", var.get("groupSeparator"))
            var.put(
                "elementStrings",
                var.get("elementStringsPush")(
                    var.get("elementStrings"),
                    var.get("variableLengthValues").get(var.get("i")),
                    var.get("gs1AIarray").get(var.get("variableLengthValues").get(var.get("i"))),
                    var.get("gs"),
                ),
            )
    return var.get("elementStrings").callprop("join", Js(""))
    pass


PyJsHoisted_buildGS1elementStrings_.func_name = "buildGS1elementStrings"
var.put("buildGS1elementStrings", PyJsHoisted_buildGS1elementStrings_)


@Js
def PyJsHoisted_gs1ElementStringsToGS1DigitalLink_(elementString, useShortText, uriStem, this, arguments, var=var):
    var = Scope(
        {
            "elementString": elementString,
            "useShortText": useShortText,
            "uriStem": uriStem,
            "this": this,
            "arguments": arguments,
        },
        var,
    )
    var.registers(["uriStem", "elementString", "useShortText"])
    return var.get("buildGS1digitalLink")(
        var.get("extractFromGS1elementStrings")(var.get("elementString")),
        var.get("useShortText"),
        var.get("uriStem"),
        Js({}),
    )


PyJsHoisted_gs1ElementStringsToGS1DigitalLink_.func_name = "gs1ElementStringsToGS1DigitalLink"
var.put("gs1ElementStringsToGS1DigitalLink", PyJsHoisted_gs1ElementStringsToGS1DigitalLink_)


@Js
def PyJsHoisted_gs1digitalLinkToGS1elementStrings_(digitalLinkURI, brackets, this, arguments, var=var):
    var = Scope({"digitalLinkURI": digitalLinkURI, "brackets": brackets, "this": this, "arguments": arguments}, var)
    var.registers(["brackets", "digitalLinkURI"])
    return var.get("buildGS1elementStrings")(
        var.get("extractFromGS1digitalLink")(var.get("digitalLinkURI")).get("GS1"), var.get("brackets")
    )


PyJsHoisted_gs1digitalLinkToGS1elementStrings_.func_name = "gs1digitalLinkToGS1elementStrings"
var.put("gs1digitalLinkToGS1elementStrings", PyJsHoisted_gs1digitalLinkToGS1elementStrings_)


@Js
def PyJsHoisted_gs1compressedDigitalLinkToGS1elementStrings_(digitalLinkURI, brackets, this, arguments, var=var):
    var = Scope({"digitalLinkURI": digitalLinkURI, "brackets": brackets, "this": this, "arguments": arguments}, var)
    var.registers(["brackets", "digitalLinkURI"])
    return var.get("buildGS1elementStrings")(
        var.get("extractFromCompressedGS1digitalLink")(var.get("digitalLinkURI")).get("GS1"), var.get("brackets")
    )


PyJsHoisted_gs1compressedDigitalLinkToGS1elementStrings_.func_name = "gs1compressedDigitalLinkToGS1elementStrings"
var.put("gs1compressedDigitalLinkToGS1elementStrings", PyJsHoisted_gs1compressedDigitalLinkToGS1elementStrings_)


@Js
def PyJsHoisted_handleEncodings_(enc, lengthBits, charstr, binstr, this, arguments, var=var):
    var = Scope(
        {
            "enc": enc,
            "lengthBits": lengthBits,
            "charstr": charstr,
            "binstr": binstr,
            "this": this,
            "arguments": arguments,
        },
        var,
    )
    var.registers(["charstr", "binstr", "binLength", "lengthBits", "binValue", "enc"])
    while 1:
        SWITCHED = False
        CONDITION = var.get("enc")
        if SWITCHED or PyJsStrictEq(CONDITION, Js(0.0)):
            SWITCHED = True
            var.put("binLength", var.get("numberOfValueBits")(var.get("charstr").get("length")))
            var.put("binValue", var.get("parseInt")(var.get("charstr")).callprop("toString", Js(2.0)))
            var.put("binValue", var.get("padToLength")(var.get("binValue"), var.get("binLength")))
            var.put("binstr", ((Js("000") + var.get("lengthBits")) + var.get("binValue")), "+")
            break
        if SWITCHED or PyJsStrictEq(CONDITION, Js(1.0)):
            SWITCHED = True
            var.put(
                "binstr",
                (
                    (Js("001") + var.get("lengthBits"))
                    + var.get("buildBinaryValue")(
                        var.get("charstr").callprop("toUpperCase"), Js(4.0), var.get("hexAlphabet")
                    )
                ),
                "+",
            )
            break
        if SWITCHED or PyJsStrictEq(CONDITION, Js(2.0)):
            SWITCHED = True
            var.put(
                "binstr",
                (
                    (Js("010") + var.get("lengthBits"))
                    + var.get("buildBinaryValue")(
                        var.get("charstr").callprop("toUpperCase"), Js(4.0), var.get("hexAlphabet")
                    )
                ),
                "+",
            )
            break
        if SWITCHED or PyJsStrictEq(CONDITION, Js(3.0)):
            SWITCHED = True
            var.put(
                "binstr",
                (
                    (Js("011") + var.get("lengthBits"))
                    + var.get("buildBinaryValue")(var.get("charstr"), Js(6.0), var.get("safeBase64Alphabet"))
                ),
                "+",
            )
            break
        if SWITCHED or PyJsStrictEq(CONDITION, Js(4.0)):
            SWITCHED = True
            var.put(
                "binstr",
                (
                    (Js("100") + var.get("lengthBits"))
                    + var.get("buildBinaryValue")(var.get("charstr"), Js(7.0), var.get("null"))
                ),
                "+",
            )
            break
        SWITCHED = True
        break
    return var.get("binstr")


PyJsHoisted_handleEncodings_.func_name = "handleEncodings"
var.put("handleEncodings", PyJsHoisted_handleEncodings_)


@Js
def PyJsHoisted_buildBinaryValue_(charstr, n, alphabet, this, arguments, var=var):
    var = Scope({"charstr": charstr, "n": n, "alphabet": alphabet, "this": this, "arguments": arguments}, var)
    var.registers(["charstr", "index", "i", "binLength", "binChar", "binValue", "n", "alphabet"])
    var.put("binValue", Js(""))
    var.put("binLength", (var.get("n") * var.get("charstr").get("length")))
    # for JS loop
    var.put("i", Js(0.0))
    while var.get("i") < var.get("charstr").get("length"):
        try:
            pass
            if var.get("n") == Js(7.0):
                var.put("index", var.get("charstr").callprop("charAt", var.get("i")).callprop("charCodeAt", Js(0.0)))
            else:
                var.put(
                    "index",
                    var.get("alphabet").callprop("indexOf", var.get("charstr").callprop("charAt", var.get("i"))),
                )
            var.put("binChar", var.get("index").callprop("toString", Js(2.0)))
            var.put("binChar", var.get("padToLength")(var.get("binChar"), var.get("n")))
            var.put("binValue", var.get("binChar"), "+")
        finally:
            (var.put("i", Js(var.get("i").to_number()) + Js(1)) - Js(1))
    return var.get("binValue")


PyJsHoisted_buildBinaryValue_.func_name = "buildBinaryValue"
var.put("buildBinaryValue", PyJsHoisted_buildBinaryValue_)


@Js
def PyJsHoisted_handleDecodings_(enc, binstr, cursor, gs1AIarray, key, numChars, this, arguments, var=var):
    var = Scope(
        {
            "enc": enc,
            "binstr": binstr,
            "cursor": cursor,
            "gs1AIarray": gs1AIarray,
            "key": key,
            "numChars": numChars,
            "this": this,
            "arguments": arguments,
        },
        var,
    )
    var.registers(
        ["gs1AIarray", "rv", "binstr", "s", "enc", "numBitsForValue", "cursor", "rbv", "key", "buildString", "numChars"]
    )

    @Js
    def PyJsHoisted_buildString_(numChars, alphabet, cursor, multiplier, binstr, this, arguments, var=var):
        var = Scope(
            {
                "numChars": numChars,
                "alphabet": alphabet,
                "cursor": cursor,
                "multiplier": multiplier,
                "binstr": binstr,
                "this": this,
                "arguments": arguments,
            },
            var,
        )
        var.registers(
            [
                "rv",
                "index",
                "binstr",
                "i",
                "s",
                "cursor",
                "numBitsForValue",
                "rbv",
                "alphabet",
                "numChars",
                "multiplier",
            ]
        )
        var.put("rv", Js({}))
        var.put("s", Js(""))
        var.put("numBitsForValue", (var.get("multiplier") * var.get("numChars")))
        var.put("rbv", var.get("binstr").callprop("substr", var.get("cursor"), var.get("numBitsForValue")))
        var.put("cursor", var.get("numBitsForValue"), "+")
        # for JS loop
        var.put("i", Js(0.0))
        while var.get("i") < var.get("numChars"):
            try:
                var.put(
                    "index",
                    var.get("parseInt")(
                        var.get("rbv").callprop(
                            "substr", (var.get("multiplier") * var.get("i")), var.get("multiplier")
                        ),
                        Js(2.0),
                    ),
                )
                if var.get("multiplier") == Js(7.0):
                    var.put("s", var.get("String").callprop("fromCharCode", var.get("parseInt")(var.get("index"))), "+")
                else:
                    var.put("s", var.get("alphabet").callprop("substr", var.get("index"), Js(1.0)), "+")
            finally:
                (var.put("i", Js(var.get("i").to_number()) + Js(1)) - Js(1))
        var.get("rv").put("cursor", var.get("cursor"))
        var.get("rv").put("s", var.get("s"))
        return var.get("rv")

    PyJsHoisted_buildString_.func_name = "buildString"
    var.put("buildString", PyJsHoisted_buildString_)
    var.put("rv", Js({}))
    while 1:
        SWITCHED = False
        CONDITION = var.get("enc")
        if SWITCHED or PyJsStrictEq(CONDITION, Js(0.0)):
            SWITCHED = True
            var.put("numBitsForValue", var.get("numberOfValueBits")(var.get("numChars")))
            var.put("rbv", var.get("binstr").callprop("substr", var.get("cursor"), var.get("numBitsForValue")))
            var.put("cursor", var.get("numBitsForValue"), "+")
            var.put("s", var.get("parseInt")(var.get("rbv"), Js(2.0)).callprop("toString"))
            var.get("gs1AIarray").put(var.get("key"), var.get("s"))
            break
        if SWITCHED or PyJsStrictEq(CONDITION, Js(1.0)):
            SWITCHED = True
            var.put(
                "rv",
                var.get("buildString")(
                    var.get("numChars"), var.get("hexAlphabet"), var.get("cursor"), Js(4.0), var.get("binstr")
                ),
            )
            var.put("cursor", var.get("rv").get("cursor"))
            var.get("gs1AIarray").put(var.get("key"), var.get("rv").get("s").callprop("toLowerCase"))
            break
        if SWITCHED or PyJsStrictEq(CONDITION, Js(2.0)):
            SWITCHED = True
            var.put(
                "rv",
                var.get("buildString")(
                    var.get("numChars"), var.get("hexAlphabet"), var.get("cursor"), Js(4.0), var.get("binstr")
                ),
            )
            var.put("cursor", var.get("rv").get("cursor"))
            var.get("gs1AIarray").put(var.get("key"), var.get("rv").get("s").callprop("toUpperCase"))
            break
        if SWITCHED or PyJsStrictEq(CONDITION, Js(3.0)):
            SWITCHED = True
            var.put(
                "rv",
                var.get("buildString")(
                    var.get("numChars"), var.get("safeBase64Alphabet"), var.get("cursor"), Js(6.0), var.get("binstr")
                ),
            )
            var.put("cursor", var.get("rv").get("cursor"))
            var.get("gs1AIarray").put(var.get("key"), var.get("rv").get("s"))
            break
        if SWITCHED or PyJsStrictEq(CONDITION, Js(4.0)):
            SWITCHED = True
            var.put(
                "rv",
                var.get("buildString")(
                    var.get("numChars"), var.get("null"), var.get("cursor"), Js(7.0), var.get("binstr")
                ),
            )
            var.put("cursor", var.get("rv").get("cursor"))
            var.get("gs1AIarray").put(var.get("key"), var.get("rv").get("s"))
            break
        SWITCHED = True
        break
    var.get("rv").put("gs1AIarray", var.get("gs1AIarray"))
    var.get("rv").put("cursor", var.get("cursor"))
    return var.get("rv")
    pass


PyJsHoisted_handleDecodings_.func_name = "handleDecodings"
var.put("handleDecodings", PyJsHoisted_handleDecodings_)


@Js
def PyJsHoisted_decompressBinaryToGS1AIarray_(binstr, this, arguments, var=var):
    var = Scope({"binstr": binstr, "this": this, "arguments": arguments}, var)
    var.registers(
        [
            "encBits",
            "l",
            "binstr",
            "enc",
            "h1h2",
            "d2",
            "gs1AIarray",
            "i",
            "d3",
            "d1",
            "totallength",
            "keyBits",
            "h4",
            "numChars",
            "d4",
            "seq",
            "tmp",
            "ai",
            "cursor",
            "h1",
            "rv",
            "index",
            "keyLength",
            "h2",
            "key",
            "bitsIncludingF",
            "h3",
        ]
    )
    var.put("totallength", var.get("binstr").get("length"))
    var.put("cursor", Js(0.0))
    var.put("gs1AIarray", Js({}))
    while (var.get("totallength") - var.get("cursor")) > Js(8.0):
        var.put("h1", var.get("binstrToHex")(var.get("binstr").callprop("substr", var.get("cursor"), Js(4.0))))
        var.put(
            "h2", var.get("binstrToHex")(var.get("binstr").callprop("substr", (Js(4.0) + var.get("cursor")), Js(4.0)))
        )
        var.put("h3", Js(""))
        var.put("h4", Js(""))
        var.put("ai", Js(""))
        var.put("h1h2", ((Js("") + var.get("h1")) + var.get("h2")))
        var.put("cursor", Js(8.0), "+")
        var.put("d1", var.get("parseInt")(var.get("h1"), Js(16.0)))
        var.put("d2", var.get("parseInt")(var.get("h2"), Js(16.0)))
        if (((var.get("d1") >= Js(0.0)) and (var.get("d2") >= Js(0.0))) and (var.get("d1") <= Js(9.0))) and (
            var.get("d2") <= Js(9.0)
        ):
            if var.get("tableP").callprop("hasOwnProperty", var.get("h1h2")):
                var.put("l", var.get("tableP").get(var.get("h1h2")))
                if var.get("l") == Js(2.0):
                    var.put("ai", var.get("h1h2"))
                if (var.get("l") == Js(3.0)) or (var.get("l") == Js(4.0)):
                    var.put(
                        "h3", var.get("binstrToHex")(var.get("binstr").callprop("substr", var.get("cursor"), Js(4.0)))
                    )
                    var.put("cursor", Js(4.0), "+")
                    var.put("d3", var.get("parseInt")(var.get("h3"), Js(16.0)))
                    if var.get("d3") > Js(9.0):
                        PyJsTempException = JsToPyException(
                            var.get("Error").create(
                                (
                                    (
                                        (
                                            Js("GS1 Application Identifier keys should be all-numeric; ")
                                            + var.get("h1h2")
                                        )
                                        + var.get("h3")
                                    )
                                    + Js(" is not all-numeric")
                                )
                            )
                        )
                        raise PyJsTempException
                    var.put("ai", (var.get("h1h2") + var.get("h3")))
                if var.get("l") == Js(4.0):
                    var.put(
                        "h4", var.get("binstrToHex")(var.get("binstr").callprop("substr", var.get("cursor"), Js(4.0)))
                    )
                    var.put("cursor", Js(4.0), "+")
                    var.put("ai", ((var.get("h1h2") + var.get("h3")) + var.get("h4")))
                    var.put("d4", var.get("parseInt")(var.get("h4"), Js(16.0)))
                    if var.get("d4") > Js(9.0):
                        PyJsTempException = JsToPyException(
                            var.get("Error").create(
                                (
                                    (
                                        (
                                            (
                                                Js("GS1 Application Identifier keys should be all-numeric; ")
                                                + var.get("h1h2")
                                            )
                                            + var.get("h3")
                                        )
                                        + var.get("h4")
                                    )
                                    + Js(" is not all-numeric")
                                )
                            )
                        )
                        raise PyJsTempException
                var.put(
                    "tmp",
                    var.get("decodeBinaryValue")(
                        var.get("ai"), var.get("gs1AIarray"), var.get("binstr"), var.get("cursor")
                    ),
                )
                var.put("gs1AIarray", var.get("tmp").get("gs1AIarray"))
                var.put("cursor", var.get("tmp").get("cursor"))
            else:
                PyJsTempException = JsToPyException(
                    var.get("Error").create(
                        (Js("Fail: Unsupported AI (reserved range) - no entry in tableP; h1h2=") + var.get("h1h2"))
                    )
                )
                raise PyJsTempException
        else:
            if var.get("tableOpt").callprop("hasOwnProperty", var.get("h1h2")):
                var.put("seq", var.get("tableOpt").get(var.get("h1h2")))
                for PyJsTemp in var.get("seq"):
                    var.put("i", PyJsTemp)
                    var.put("ai", var.get("seq").get(var.get("i")))
                    var.put(
                        "tmp",
                        var.get("decodeBinaryValue")(
                            var.get("ai"), var.get("gs1AIarray"), var.get("binstr"), var.get("cursor")
                        ),
                    )
                    var.put("gs1AIarray", var.get("tmp").get("gs1AIarray"))
                    var.put("cursor", var.get("tmp").get("cursor"))
            else:
                if var.get("h1") == Js("F"):
                    var.put(
                        "bitsIncludingF", var.get("binstr").callprop("substr", (var.get("cursor") - Js(8.0)), Js(11.0))
                    )
                    var.put(
                        "keyLength",
                        var.get("parseInt")(
                            var.get("binstr").callprop("substr", (var.get("cursor") - Js(4.0)), Js(7.0)), Js(2.0)
                        ),
                    )
                    var.put("cursor", Js(3.0), "+")
                    var.put(
                        "keyBits",
                        var.get("binstr").callprop("substr", var.get("cursor"), (Js(6.0) * var.get("keyLength"))),
                    )
                    var.put("cursor", (Js(6.0) * var.get("keyLength")), "+")
                    var.put("key", Js(""))
                    # for JS loop
                    var.put("i", Js(0.0))
                    while var.get("i") < var.get("keyLength"):
                        try:
                            var.put(
                                "index",
                                var.get("parseInt")(
                                    var.get("keyBits").callprop("substr", (Js(6.0) * var.get("i")), Js(6.0)), Js(2.0)
                                ),
                            )
                            var.put(
                                "key", var.get("safeBase64Alphabet").callprop("substr", var.get("index"), Js(1.0)), "+"
                            )
                        finally:
                            (var.put("i", Js(var.get("i").to_number()) + Js(1)) - Js(1))
                    var.put("encBits", var.get("binstr").callprop("substr", var.get("cursor"), Js(3.0)))
                    var.put("cursor", Js(3.0), "+")
                    var.put("enc", var.get("parseInt")(var.get("encBits"), Js(2.0)))
                    var.put(
                        "numChars",
                        var.get("parseInt")(var.get("binstr").callprop("substr", var.get("cursor"), Js(7.0)), Js(2.0)),
                    )
                    var.put("cursor", Js(7.0), "+")
                    var.put(
                        "rv",
                        var.get("handleDecodings")(
                            var.get("enc"),
                            var.get("binstr"),
                            var.get("cursor"),
                            var.get("gs1AIarray"),
                            var.get("key"),
                            var.get("numChars"),
                        ),
                    )
                    var.put("gs1AIarray", var.get("rv").get("gs1AIarray"))
                    var.put("cursor", var.get("rv").get("cursor"))
                else:
                    PyJsTempException = JsToPyException(
                        var.get("Error").create((Js("No optimisation defined for hex code hh=") + var.get("h1h2")))
                    )
                    raise PyJsTempException
    return var.get("gs1AIarray")


PyJsHoisted_decompressBinaryToGS1AIarray_.func_name = "decompressBinaryToGS1AIarray"
var.put("decompressBinaryToGS1AIarray", PyJsHoisted_decompressBinaryToGS1AIarray_)


@Js
def PyJsHoisted_decodeBinaryValue_(key, gs1AIarray, binstr, cursor, this, arguments, var=var):
    var = Scope(
        {
            "key": key,
            "gs1AIarray": gs1AIarray,
            "binstr": binstr,
            "cursor": cursor,
            "this": this,
            "arguments": arguments,
        },
        var,
    )
    var.registers(
        [
            "j",
            "encBits",
            "binstr",
            "enc",
            "numBitsForValue",
            "v2",
            "gs1AIarray",
            "numDigits",
            "rvd",
            "numChars",
            "v3",
            "tx",
            "b1",
            "cursor",
            "rv",
            "s",
            "lengthBits",
            "rbv",
            "key",
        ]
    )
    var.put("rv", Js({}))
    var.get("gs1AIarray").put(var.get("key"), Js(""))
    if var.get("tableF").callprop("hasOwnProperty", var.get("key")):
        for PyJsTemp in var.get("tableF").get(var.get("key")):
            var.put("j", PyJsTemp)
            var.put("tx", var.get("tableF").get(var.get("key")).get(var.get("j")))
            if var.get("tx").callprop("hasOwnProperty", Js("L")) and (var.get("tx").get("E") == Js("N")):
                var.put("b1", var.get("numberOfValueBits")(var.get("tx").get("L")))
                var.put("rbv", var.get("binstr").callprop("substr", var.get("cursor"), var.get("b1")))
                var.put("cursor", var.get("b1"), "+")
                var.put("s", var.get("parseInt")(var.get("rbv"), Js(2.0)).callprop("toString"))
                var.put("s", var.get("padToLength")(var.get("s"), var.get("tx").get("L")))
                var.get("gs1AIarray").put(var.get("key"), (Js("") + var.get("s")), "+")
            if var.get("tx").callprop("hasOwnProperty", Js("M")) and (var.get("tx").get("E") == Js("N")):
                var.put("v2", var.get("numberOfLengthBits")(var.get("tx").get("M")))
                var.put("lengthBits", var.get("binstr").callprop("substr", var.get("cursor"), var.get("v2")))
                var.put("cursor", var.get("v2"), "+")
                var.put("numDigits", var.get("parseInt")(var.get("lengthBits"), Js(2.0)))
                var.put("numBitsForValue", var.get("numberOfValueBits")(var.get("numDigits")))
                var.put("rbv", var.get("binstr").callprop("substr", var.get("cursor"), var.get("numBitsForValue")))
                var.put("cursor", var.get("numBitsForValue"), "+")
                var.put("s", var.get("parseInt")(var.get("rbv"), Js(2.0)).callprop("toString"))
                if var.get("numDigits") == Js(0.0):
                    var.put("s", Js(""))
                var.get("gs1AIarray").put(var.get("key"), (Js("") + var.get("s")), "+")
            if var.get("tx").callprop("hasOwnProperty", Js("L")) and (var.get("tx").get("E") == Js("X")):
                var.put("encBits", var.get("binstr").callprop("substr", var.get("cursor"), Js(3.0)))
                var.put("cursor", Js(3.0), "+")
                var.put("enc", var.get("parseInt")(var.get("encBits"), Js(2.0)))
                var.put("numChars", var.get("tx").get("L"))
                var.put(
                    "rvd",
                    var.get("handleDecodings")(
                        var.get("enc"),
                        var.get("binstr"),
                        var.get("cursor"),
                        var.get("gs1AIarray"),
                        var.get("key"),
                        var.get("numChars"),
                    ),
                )
                var.put("gs1AIarray", var.get("rvd").get("gs1AIarray"))
                var.put("cursor", var.get("rvd").get("cursor"))
            if var.get("tx").callprop("hasOwnProperty", Js("M")) and (var.get("tx").get("E") == Js("X")):
                var.put("encBits", var.get("binstr").callprop("substr", var.get("cursor"), Js(3.0)))
                var.put("cursor", Js(3.0), "+")
                var.put("v3", var.get("numberOfLengthBits")(var.get("tx").get("M")))
                var.put("lengthBits", var.get("binstr").callprop("substr", var.get("cursor"), var.get("v3")))
                var.put("cursor", var.get("v3"), "+")
                var.put("numChars", var.get("parseInt")(var.get("lengthBits"), Js(2.0)))
                var.put("enc", var.get("parseInt")(var.get("encBits"), Js(2.0)))
                var.put(
                    "rvd",
                    var.get("handleDecodings")(
                        var.get("enc"),
                        var.get("binstr"),
                        var.get("cursor"),
                        var.get("gs1AIarray"),
                        var.get("key"),
                        var.get("numChars"),
                    ),
                )
                var.put("gs1AIarray", var.get("rvd").get("gs1AIarray"))
                var.put("cursor", var.get("rvd").get("cursor"))
    var.get("rv").put("gs1AIarray", var.get("gs1AIarray"))
    var.get("rv").put("cursor", var.get("cursor"))
    return var.get("rv")


PyJsHoisted_decodeBinaryValue_.func_name = "decodeBinaryValue"
var.put("decodeBinaryValue", PyJsHoisted_decodeBinaryValue_)


@Js
def PyJsHoisted_compressGS1AIarrayToBinary_(
    gs1AIarray, useOptimisations, nonGS1keyvaluePairs, this, arguments, var=var
):
    var = Scope(
        {
            "gs1AIarray": gs1AIarray,
            "useOptimisations": useOptimisations,
            "nonGS1keyvaluePairs": nonGS1keyvaluePairs,
            "this": this,
            "arguments": arguments,
        },
        var,
    )
    var.registers(
        [
            "optimisations",
            "binstr",
            "removeOptimisedKeysFromAIlist",
            "v",
            "findCandidatesFromTableOpt",
            "akeys",
            "bestCandidate",
            "gs1AIarray",
            "optArray",
            "findBestOptimisationCandidate",
            "i",
            "nonGS1keyvaluePairs",
            "cursor",
            "useOptimisations",
            "akeysa",
            "index",
            "lengthBits",
            "binChar",
            "key",
            "k",
            "binKey",
            "value",
            "candidatesFromTableOpt",
        ]
    )

    @Js
    def PyJsHoisted_findCandidatesFromTableOpt_(akeysa, tableOpt, this, arguments, var=var):
        var = Scope({"akeysa": akeysa, "tableOpt": tableOpt, "this": this, "arguments": arguments}, var)
        var.registers(["j", "akeysa", "i", "a", "tableOpt", "b", "candidatesFromTableOpt"])
        var.put("candidatesFromTableOpt", Js({}))
        for PyJsTemp in var.get("tableOpt"):
            var.put("i", PyJsTemp)
            var.put("a", var.get("tableOpt").get(var.get("i")))
            var.put("b", Js(True))
            for PyJsTemp in var.get("a"):
                var.put("j", PyJsTemp)
                if var.get("akeysa").callprop("indexOf", var.get("a").get(var.get("j"))) == (-Js(1.0)):
                    var.put("b", Js(False))
            if var.get("b"):
                var.get("candidatesFromTableOpt").put(
                    var.get("i"), var.get("tableOpt").get(var.get("i")).callprop("join", Js("")).get("length")
                )
        return var.get("candidatesFromTableOpt")

    PyJsHoisted_findCandidatesFromTableOpt_.func_name = "findCandidatesFromTableOpt"
    var.put("findCandidatesFromTableOpt", PyJsHoisted_findCandidatesFromTableOpt_)

    @Js
    def PyJsHoisted_findBestOptimisationCandidate_(candidatesFromTableOpt, this, arguments, var=var):
        var = Scope({"candidatesFromTableOpt": candidatesFromTableOpt, "this": this, "arguments": arguments}, var)
        var.registers(["maxkey", "max", "candidatesFromTableOpt", "i"])
        var.put("maxkey", Js(""))
        var.put("max", Js(0.0))
        for PyJsTemp in var.get("candidatesFromTableOpt"):
            var.put("i", PyJsTemp)
            if var.get("candidatesFromTableOpt").get(var.get("i")) > var.get("max"):
                var.put("maxkey", var.get("i"))
                var.put("max", var.get("candidatesFromTableOpt").get(var.get("i")))
        return var.get("maxkey")

    PyJsHoisted_findBestOptimisationCandidate_.func_name = "findBestOptimisationCandidate"
    var.put("findBestOptimisationCandidate", PyJsHoisted_findBestOptimisationCandidate_)

    @Js
    def PyJsHoisted_removeOptimisedKeysFromAIlist_(akeysa, v, this, arguments, var=var):
        var = Scope({"akeysa": akeysa, "v": v, "this": this, "arguments": arguments}, var)
        var.registers(["ind", "akeysa", "v", "i"])
        for PyJsTemp in var.get("v"):
            var.put("i", PyJsTemp)
            var.put("ind", var.get("akeysa").callprop("indexOf", var.get("v").get(var.get("i"))))
            if var.get("ind") > (-Js(1.0)):
                var.get("akeysa").callprop("splice", var.get("ind"), Js(1.0))
        return var.get("akeysa")

    PyJsHoisted_removeOptimisedKeysFromAIlist_.func_name = "removeOptimisedKeysFromAIlist"
    var.put("removeOptimisedKeysFromAIlist", PyJsHoisted_removeOptimisedKeysFromAIlist_)
    var.put("binstr", Js(""))
    pass
    pass
    var.put("akeysa", var.get("Object").callprop("keys", var.get("gs1AIarray")).callprop("sort"))
    var.put("optimisations", Js([]))
    if var.get("useOptimisations"):
        var.put("akeys", var.get("JSON").callprop("stringify", var.get("akeysa")))
        pass
        while 1:
            var.put(
                "candidatesFromTableOpt", var.get("findCandidatesFromTableOpt")(var.get("akeysa"), var.get("tableOpt"))
            )
            var.put("bestCandidate", var.get("findBestOptimisationCandidate")(var.get("candidatesFromTableOpt")))
            var.put("v", var.get("tableOpt").get(var.get("bestCandidate")))
            if PyJsStrictNeq(var.get("bestCandidate"), Js("")):
                var.put(
                    "akeysa",
                    var.get("removeOptimisedKeysFromAIlist")(
                        var.get("akeysa"), var.get("tableOpt").get(var.get("bestCandidate"))
                    ),
                )
                var.get("optimisations").callprop("push", var.get("bestCandidate"))
            var.put(
                "candidatesFromTableOpt", var.get("findCandidatesFromTableOpt")(var.get("akeysa"), var.get("tableOpt"))
            )
            if not (var.get("Object").callprop("keys", var.get("candidatesFromTableOpt")).get("length") > Js(0.0)):
                break
    for PyJsTemp in var.get("optimisations"):
        var.put("i", PyJsTemp)
        var.put("key", var.get("optimisations").get(var.get("i")))
        var.put("binstr", var.get("binaryEncodingOfGS1AIKey")(var.get("key")), "+")
        var.put("optArray", var.get("tableOpt").get(var.get("key")))
        for PyJsTemp in var.get("optArray"):
            var.put("i", PyJsTemp)
            var.put("k", var.get("optArray").get(var.get("i")))
            var.put("binstr", var.get("binaryEncodingOfValue")(var.get("gs1AIarray"), var.get("k")), "+")
    for PyJsTemp in var.get("akeysa"):
        var.put("i", PyJsTemp)
        var.put("key", var.get("akeysa").get(var.get("i")))
        if var.get("gs1AIarray").callprop("hasOwnProperty", var.get("key")):
            var.put("binstr", var.get("binaryEncodingOfGS1AIKey")(var.get("key")), "+")
            var.put("binstr", var.get("binaryEncodingOfValue")(var.get("gs1AIarray"), var.get("key")), "+")
    if var.get("Object").callprop("keys", var.get("nonGS1keyvaluePairs")).get("length") > Js(0.0):
        for PyJsTemp in var.get("nonGS1keyvaluePairs"):
            var.put("key", PyJsTemp)
            var.put("lengthBits", var.get("key").get("length").callprop("toString", Js(2.0)))
            var.put("lengthBits", var.get("padToLength")(var.get("lengthBits"), Js(7.0)))
            var.put("binstr", Js("1111"), "+")
            var.put("binstr", var.get("lengthBits"), "+")
            var.put("binKey", Js(""))
            # for JS loop
            var.put("i", Js(0.0))
            while var.get("i") < var.get("key").get("length"):
                try:
                    var.put(
                        "index",
                        var.get("safeBase64Alphabet").callprop(
                            "indexOf", var.get("key").callprop("charAt", var.get("i"))
                        ),
                    )
                    var.put("binChar", var.get("index").callprop("toString", Js(2.0)))
                    var.put("binChar", var.get("padToLength")(var.get("binChar"), Js(6.0)))
                    var.put("binKey", var.get("binChar"), "+")
                finally:
                    (var.put("i", Js(var.get("i").to_number()) + Js(1)) - Js(1))
            var.put("binstr", var.get("binKey"), "+")
            var.put(
                "binstr",
                var.get("binaryEncodingOfNonGS1Value")(var.get("nonGS1keyvaluePairs").get(var.get("key"))),
                "+",
            )
    return var.get("binstr")
    pass
    pass
    pass


PyJsHoisted_compressGS1AIarrayToBinary_.func_name = "compressGS1AIarrayToBinary"
var.put("compressGS1AIarrayToBinary", PyJsHoisted_compressGS1AIarrayToBinary_)


@Js
def PyJsHoisted_binaryEncodingOfGS1AIKey_(key, this, arguments, var=var):
    var = Scope({"key": key, "this": this, "arguments": arguments}, var)
    var.registers(["binAI", "key", "i"])
    var.put("binAI", Js(""))
    # for JS loop
    var.put("i", Js(0.0))
    while var.get("i") < var.get("key").get("length"):
        try:
            var.put(
                "binAI",
                var.get("padToLength")(
                    var.get("parseInt")(var.get("key").callprop("charAt", var.get("i")), Js(16.0)).callprop(
                        "toString", Js(2.0)
                    ),
                    Js(4.0),
                ),
                "+",
            )
        finally:
            (var.put("i", Js(var.get("i").to_number()) + Js(1)) - Js(1))
    return var.get("binAI")


PyJsHoisted_binaryEncodingOfGS1AIKey_.func_name = "binaryEncodingOfGS1AIKey"
var.put("binaryEncodingOfGS1AIKey", PyJsHoisted_binaryEncodingOfGS1AIKey_)


@Js
def PyJsHoisted_binaryEncodingOfValue_(gs1AIarray, key, this, arguments, var=var):
    var = Scope({"gs1AIarray": gs1AIarray, "key": key, "this": this, "arguments": arguments}, var)
    var.registers(
        ["j", "charstr", "tx", "gs1AIarray", "binstr", "lengthBits", "binValue", "cursor", "enc", "key", "value"]
    )
    var.put("binstr", Js(""))
    if var.get("tableF").callprop("hasOwnProperty", var.get("key")):
        var.put("cursor", Js(0.0))
        var.put("value", var.get("gs1AIarray").get(var.get("key")))
        for PyJsTemp in var.get("tableF").get(var.get("key")):
            var.put("j", PyJsTemp)
            var.put("tx", var.get("tableF").get(var.get("key")).get(var.get("j")))
            if var.get("tx").callprop("hasOwnProperty", Js("L")) and (var.get("tx").get("E") == Js("N")):
                var.put("charstr", var.get("value").callprop("substr", var.get("cursor"), var.get("tx").get("L")))
                var.put("cursor", var.get("parseInt")(var.get("tx").get("L")), "+")
                var.put(
                    "binValue",
                    var.get("padToLength")(
                        var.get("parseInt")(var.get("charstr")).callprop("toString", Js(2.0)),
                        var.get("numberOfValueBits")(var.get("tx").get("L")),
                    ),
                )
                var.put("binstr", var.get("binValue"), "+")
            if var.get("tx").callprop("hasOwnProperty", Js("M")) and (var.get("tx").get("E") == Js("N")):
                var.put("charstr", var.get("value").callprop("substr", var.get("cursor")))
                var.put("cursor", var.get("charstr").get("length"), "+")
                var.put(
                    "lengthBits",
                    var.get("padToLength")(
                        var.get("charstr").get("length").callprop("toString", Js(2.0)),
                        var.get("numberOfLengthBits")(var.get("tx").get("M")),
                    ),
                )
                var.put(
                    "binValue",
                    var.get("padToLength")(
                        var.get("parseInt")(var.get("charstr")).callprop("toString", Js(2.0)),
                        var.get("numberOfValueBits")(var.get("charstr").get("length")),
                    ),
                )
                var.put("binstr", (var.get("lengthBits") + var.get("binValue")), "+")
            if var.get("tx").callprop("hasOwnProperty", Js("L")) and (var.get("tx").get("E") == Js("X")):
                var.put("charstr", var.get("value").callprop("substr", var.get("cursor"), var.get("tx").get("L")))
                var.put("cursor", var.get("parseInt")(var.get("tx").get("L")), "+")
                var.put("enc", var.get("determineEncoding")(var.get("charstr")))
                var.put("lengthBits", Js(""))
                var.put(
                    "binstr",
                    var.get("handleEncodings")(
                        var.get("enc"), var.get("lengthBits"), var.get("charstr"), var.get("binstr")
                    ),
                    "+",
                )
            if var.get("tx").callprop("hasOwnProperty", Js("M")) and (var.get("tx").get("E") == Js("X")):
                var.put("charstr", var.get("value").callprop("substr", var.get("cursor")))
                var.put("cursor", var.get("charstr").get("length"), "+")
                var.put(
                    "lengthBits",
                    var.get("padToLength")(
                        var.get("charstr").get("length").callprop("toString", Js(2.0)),
                        var.get("numberOfLengthBits")(var.get("tx").get("M")),
                    ),
                )
                var.put("enc", var.get("determineEncoding")(var.get("charstr")))
                var.put(
                    "binstr",
                    var.get("handleEncodings")(
                        var.get("enc"), var.get("lengthBits"), var.get("charstr"), var.get("binstr")
                    ),
                    "+",
                )
    return var.get("binstr")


PyJsHoisted_binaryEncodingOfValue_.func_name = "binaryEncodingOfValue"
var.put("binaryEncodingOfValue", PyJsHoisted_binaryEncodingOfValue_)


@Js
def PyJsHoisted_determineEncoding_(charstr, this, arguments, var=var):
    var = Scope({"charstr": charstr, "this": this, "arguments": arguments}, var)
    var.registers(["charstr", "enc"])
    var.put("enc", Js(4.0))
    if var.get("regexSafe64").callprop("test", var.get("charstr")):
        var.put("enc", Js(3.0))
    if var.get("regexHexLower").callprop("test", var.get("charstr")):
        var.put("enc", Js(1.0))
    if var.get("regexHexUpper").callprop("test", var.get("charstr")):
        var.put("enc", Js(2.0))
    if var.get("regexAllNum").callprop("test", var.get("charstr")):
        var.put("enc", Js(0.0))
    return var.get("enc")


PyJsHoisted_determineEncoding_.func_name = "determineEncoding"
var.put("determineEncoding", PyJsHoisted_determineEncoding_)


@Js
def PyJsHoisted_binaryEncodingOfNonGS1Value_(charstr, this, arguments, var=var):
    var = Scope({"charstr": charstr, "this": this, "arguments": arguments}, var)
    var.registers(["charstr", "lengthBits", "binstr", "enc"])
    var.put("lengthBits", var.get("charstr").get("length").callprop("toString", Js(2.0)))
    var.put("lengthBits", var.get("padToLength")(var.get("lengthBits"), Js(7.0)))
    var.put("enc", var.get("determineEncoding")(var.get("charstr")))
    var.put("binstr", var.get("handleEncodings")(var.get("enc"), var.get("lengthBits"), var.get("charstr"), Js("")))
    return var.get("binstr")


PyJsHoisted_binaryEncodingOfNonGS1Value_.func_name = "binaryEncodingOfNonGS1Value"
var.put("binaryEncodingOfNonGS1Value", PyJsHoisted_binaryEncodingOfNonGS1Value_)


@Js
def PyJsHoisted_buildCompressedGS1digitalLink_(
    gs1AIarray,
    useShortText,
    uriStem,
    useOptimisations,
    compressOtherKeyValuePairs,
    nonGS1keyvaluePairs,
    this,
    arguments,
    var=var,
):
    var = Scope(
        {
            "gs1AIarray": gs1AIarray,
            "useShortText": useShortText,
            "uriStem": uriStem,
            "useOptimisations": useOptimisations,
            "compressOtherKeyValuePairs": compressOtherKeyValuePairs,
            "nonGS1keyvaluePairs": nonGS1keyvaluePairs,
            "this": this,
            "arguments": arguments,
        },
        var,
    )
    var.registers(
        [
            "identifiers",
            "queryStringArray",
            "useShortText",
            "uriStem",
            "gs1AIarray",
            "path",
            "compressOtherKeyValuePairs",
            "attributes",
            "queryString",
            "fixedLengthValues",
            "akv",
            "qualifiers",
            "nonGS1keyvaluePairs",
            "canonicalStem",
            "webURI",
            "useOptimisations",
            "variableLengthValues",
            "rv",
            "k",
            "valid",
        ]
    )
    var.put("identifiers", Js([]))
    var.put("qualifiers", Js([]))
    var.put("attributes", Js([]))
    var.put("fixedLengthValues", Js([]))
    var.put("variableLengthValues", Js([]))
    var.put("valid", Js(True))
    var.put("path", Js(""))
    var.put("queryStringArray", Js([]))
    var.put("queryString", Js(""))
    var.put("webURI", Js(""))
    var.put("canonicalStem", Js("https://id.gs1.org"))
    var.put("rv", Js({}))
    if var.get("compressOtherKeyValuePairs").neg():
        var.put("akv", Js([]))
        for PyJsTemp in var.get("nonGS1keyvaluePairs"):
            var.put("k", PyJsTemp)
            var.get("akv").callprop(
                "push", ((var.get("k") + Js("=")) + var.get("nonGS1keyvaluePairs").get(var.get("k")))
            )
        if var.get("akv").get("length") > Js(0.0):
            var.put("queryString", (Js("?") + var.get("akv").callprop("join", Js("&"))))
    if (
        (PyJsStrictNeq(var.get("uriStem"), var.get("undefined")) and PyJsStrictNeq(var.get("uriStem"), var.get("null")))
        and PyJsStrictNeq(var.get("uriStem"), Js(""))
    ) and PyJsStrictEq(var.get("uriStem").callprop("substr", (-Js(1.0))), Js("/")):
        var.put("uriStem", var.get("uriStem").callprop("substr", Js(0.0), var.get("uriStem").get("length")))
    var.put(
        "path",
        (
            Js("/")
            + var.get("bin2base64")(
                var.get("compressGS1AIarrayToBinary")(
                    var.get("gs1AIarray"),
                    var.get("useOptimisations"),
                    (var.get("nonGS1keyvaluePairs") if var.get("compressOtherKeyValuePairs") else Js({})),
                )
            )
        ),
    )
    if (var.get("uriStem") == var.get("null")) or (var.get("uriStem") == Js("")):
        var.put("webURI", ((var.get("canonicalStem") + var.get("path")) + var.get("queryString")))
    else:
        var.put("webURI", ((var.get("uriStem") + var.get("path")) + var.get("queryString")))
    return var.get("webURI")


PyJsHoisted_buildCompressedGS1digitalLink_.func_name = "buildCompressedGS1digitalLink"
var.put("buildCompressedGS1digitalLink", PyJsHoisted_buildCompressedGS1digitalLink_)


@Js
def PyJsHoisted_decompressGS1DigitalLink_(compressedDigitalLinkURI, useShortText, uriStem, this, arguments, var=var):
    var = Scope(
        {
            "compressedDigitalLinkURI": compressedDigitalLinkURI,
            "useShortText": useShortText,
            "uriStem": uriStem,
            "this": this,
            "arguments": arguments,
        },
        var,
    )
    var.registers(
        [
            "otherArray",
            "gs1AIarray",
            "compressedDigitalLinkURI",
            "uriStem",
            "extracted",
            "useShortText",
            "uncompressedDL",
        ]
    )
    var.put("extracted", var.get("extractFromCompressedGS1digitalLink")(var.get("compressedDigitalLinkURI")))
    var.put("gs1AIarray", var.get("extracted").get("GS1"))
    var.put("otherArray", var.get("extracted").get("other"))
    var.put(
        "uncompressedDL",
        var.get("buildGS1digitalLink")(
            var.get("gs1AIarray"), var.get("useShortText"), var.get("uriStem"), var.get("otherArray")
        ),
    )
    return var.get("uncompressedDL")


PyJsHoisted_decompressGS1DigitalLink_.func_name = "decompressGS1DigitalLink"
var.put("decompressGS1DigitalLink", PyJsHoisted_decompressGS1DigitalLink_)


@Js
def PyJsHoisted_decompressGS1DigitalLinkToStructuredArray_(compressedDigitalLinkURI, this, arguments, var=var):
    var = Scope({"compressedDigitalLinkURI": compressedDigitalLinkURI, "this": this, "arguments": arguments}, var)
    var.registers(["otherArray", "gs1AIarray", "compressedDigitalLinkURI", "structuredArray", "extracted"])
    var.put("extracted", var.get("extractFromCompressedGS1digitalLink")(var.get("compressedDigitalLinkURI")))
    var.put("gs1AIarray", var.get("extracted").get("GS1"))
    var.put("otherArray", var.get("extracted").get("other"))
    var.put("structuredArray", var.get("buildStructuredArray")(var.get("gs1AIarray"), var.get("otherArray")))
    return var.get("structuredArray")


PyJsHoisted_decompressGS1DigitalLinkToStructuredArray_.func_name = "decompressGS1DigitalLinkToStructuredArray"
var.put("decompressGS1DigitalLinkToStructuredArray", PyJsHoisted_decompressGS1DigitalLinkToStructuredArray_)


@Js
def PyJsHoisted_compressGS1DigitalLink_(
    digitalLinkURI,
    useShortText,
    uriStem,
    uncompressedPrimary,
    useOptimisations,
    compressOtherKeyValuePairs,
    this,
    arguments,
    var=var,
):
    var = Scope(
        {
            "digitalLinkURI": digitalLinkURI,
            "useShortText": useShortText,
            "uriStem": uriStem,
            "uncompressedPrimary": uncompressedPrimary,
            "useOptimisations": useOptimisations,
            "compressOtherKeyValuePairs": compressOtherKeyValuePairs,
            "this": this,
            "arguments": arguments,
        },
        var,
    )
    var.registers(
        [
            "queryString",
            "firstQuestionMark",
            "pairs",
            "gs1AIarray",
            "compressedDL",
            "uriStem",
            "uncompressedPrimary",
            "i",
            "nonGS1keyvaluePairs",
            "firstFragment",
            "digitalLinkURI",
            "useShortText",
            "compressOtherKeyValuePairs",
            "p",
            "useOptimisations",
        ]
    )
    var.put("firstQuestionMark", var.get("digitalLinkURI").callprop("indexOf", Js("?")))
    var.put("queryString", Js(""))
    var.put("nonGS1keyvaluePairs", Js({}))
    if var.get("firstQuestionMark") > (-Js(1.0)):
        var.put("queryString", var.get("digitalLinkURI").callprop("substr", (Js(1.0) + var.get("firstQuestionMark"))))
    if PyJsStrictNeq(var.get("queryString"), Js("")):
        var.put(
            "queryString",
            var.get("queryString").callprop("replace", var.get("RegExp").create(Js(";"), Js("g")), Js("&")),
        )
        var.put("firstFragment", var.get("queryString").callprop("indexOf", Js("#")))
        if var.get("firstFragment") > (-Js(1.0)):
            var.put("queryString", var.get("queryString").callprop("substring", Js(0.0), var.get("firstFragment")))
        var.put("pairs", var.get("queryString").callprop("split", Js("&")))
        # for JS loop
        var.put("i", Js(0.0))
        while var.get("i") < var.get("pairs").get("length"):
            try:
                var.put("p", var.get("pairs").get(var.get("i")).callprop("split", Js("=")))
                if (
                    PyJsStrictNeq(var.get("p").get("0"), var.get("null"))
                    and PyJsStrictNeq(var.get("p").get("1"), var.get("null"))
                ) and (
                    var.get("regexAllNum").callprop("test", var.get("p").get("0")).neg()
                    and var.get("shortCodeToNumeric").callprop("hasOwnProperty", var.get("p").get("0")).neg()
                ):
                    var.get("nonGS1keyvaluePairs").put(
                        var.get("p").get("0"), var.get("percentDecode")(var.get("p").get("1"))
                    )
            finally:
                (var.put("i", Js(var.get("i").to_number()) + Js(1)) - Js(1))
    var.put("gs1AIarray", var.get("extractFromGS1digitalLink")(var.get("digitalLinkURI")).get("GS1"))
    var.put(
        "compressedDL",
        var.get("buildCompressedGS1digitalLink")(
            var.get("gs1AIarray"),
            var.get("useShortText"),
            var.get("uriStem"),
            var.get("useOptimisations"),
            var.get("compressOtherKeyValuePairs"),
            var.get("nonGS1keyvaluePairs"),
        ),
    )
    return var.get("compressedDL")


PyJsHoisted_compressGS1DigitalLink_.func_name = "compressGS1DigitalLink"
var.put("compressGS1DigitalLink", PyJsHoisted_compressGS1DigitalLink_)


@Js
def PyJsHoisted_gs1ElementStringsToCompressedGS1DigitalLink_(
    elementString, useShortText, uriStem, uncompressedPrimary, useOptimisations, this, arguments, var=var
):
    var = Scope(
        {
            "elementString": elementString,
            "useShortText": useShortText,
            "uriStem": uriStem,
            "uncompressedPrimary": uncompressedPrimary,
            "useOptimisations": useOptimisations,
            "this": this,
            "arguments": arguments,
        },
        var,
    )
    var.registers(
        [
            "uriStem",
            "gs1AIarray",
            "elementString",
            "uncompressedPrimary",
            "useShortText",
            "useOptimisations",
            "separated",
        ]
    )
    var.put("gs1AIarray", var.get("extractFromGS1elementStrings")(var.get("elementString")))
    var.put("separated", var.get("separateIDnonID")(var.get("gs1AIarray")))
    if var.get("uncompressedPrimary"):
        return (
            var.get("buildGS1digitalLink")(
                var.get("separated").get("ID"), var.get("useShortText"), var.get("uriStem"), Js({})
            )
            + Js("/")
        ) + var.get("bin2base64")(
            var.get("compressGS1AIarrayToBinary")(
                var.get("separated").get("nonID"), var.get("useOptimisations"), Js({})
            )
        )
    else:
        return var.get("buildCompressedGS1digitalLink")(
            var.get("extractFromGS1elementStrings")(var.get("elementString")),
            var.get("useShortText"),
            var.get("uriStem"),
            var.get("useOptimisations"),
            Js(False),
            Js({}),
        )


PyJsHoisted_gs1ElementStringsToCompressedGS1DigitalLink_.func_name = "gs1ElementStringsToCompressedGS1DigitalLink"
var.put("gs1ElementStringsToCompressedGS1DigitalLink", PyJsHoisted_gs1ElementStringsToCompressedGS1DigitalLink_)


@Js
def PyJsHoisted_separateIDnonID_(gs1AIarray, this, arguments, var=var):
    var = Scope({"gs1AIarray": gs1AIarray, "this": this, "arguments": arguments}, var)
    var.registers(["gs1AIarray", "keys", "rv", "i", "nonIDarray", "idArray"])
    var.put("rv", Js({}))
    var.put("idArray", Js({}))
    var.put("nonIDarray", Js({}))
    var.put("keys", var.get("Object").callprop("keys", var.get("gs1AIarray")))
    for PyJsTemp in var.get("keys"):
        var.put("i", PyJsTemp)
        if var.get("gs1AIarray").callprop("hasOwnProperty", var.get("keys").get(var.get("i"))):
            if var.get("aiMaps").get("identifiers").callprop("indexOf", var.get("keys").get(var.get("i"))) > (-Js(1.0)):
                var.get("idArray").put(
                    var.get("keys").get(var.get("i")), var.get("gs1AIarray").get(var.get("keys").get(var.get("i")))
                )
            else:
                var.get("nonIDarray").put(
                    var.get("keys").get(var.get("i")), var.get("gs1AIarray").get(var.get("keys").get(var.get("i")))
                )
    var.get("rv").put("ID", var.get("idArray"))
    var.get("rv").put("nonID", var.get("nonIDarray"))
    return var.get("rv")


PyJsHoisted_separateIDnonID_.func_name = "separateIDnonID"
var.put("separateIDnonID", PyJsHoisted_separateIDnonID_)


def PyJs_LONG_0_(var=var):
    return var.put(
        "aitable",
        Js(
            [
                Js(
                    {
                        "title": Js("Serial Shipping Container Code (SSCC) "),
                        "label": Js("SSCC"),
                        "shortcode": Js("sscc"),
                        "ai": Js("00"),
                        "format": Js("N18"),
                        "type": Js("I"),
                        "fixedLength": Js(True),
                        "checkDigit": Js("L"),
                        "regex": Js("(\\d{18})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Global Trade Item Number (GTIN)"),
                        "label": Js("GTIN"),
                        "shortcode": Js("gtin"),
                        "ai": Js("01"),
                        "format": Js("N14"),
                        "type": Js("I"),
                        "fixedLength": Js(True),
                        "checkDigit": Js("L"),
                        "qualifiers": Js([Js("22"), Js("10"), Js("21")]),
                        "regex": Js("(\\d{12,14}|\\d{8})"),
                    }
                ),
                Js(
                    {
                        "title": Js("GTIN of contained trade items"),
                        "label": Js("CONTENT"),
                        "ai": Js("02"),
                        "format": Js("N14"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "checkDigit": Js("L"),
                        "regex": Js("(\\d{14})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Batch or lot number"),
                        "label": Js("BATCH/LOT"),
                        "shortcode": Js("lot"),
                        "ai": Js("10"),
                        "format": Js("X..20"),
                        "type": Js("Q"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,20})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Production date (YYMMDD)"),
                        "label": Js("PROD DATE"),
                        "ai": Js("11"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Due date (YYMMDD)"),
                        "label": Js("DUE DATE"),
                        "ai": Js("12"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Packaging date (YYMMDD)"),
                        "label": Js("PACK DATE"),
                        "ai": Js("13"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Best before date (YYMMDD)"),
                        "label": Js("BEST BEFORE or BEST BY"),
                        "ai": Js("15"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Sell by date (YYMMDD)"),
                        "label": Js("SELL BY"),
                        "ai": Js("16"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Expiration date (YYMMDD)"),
                        "label": Js("USE BY OR EXPIRY"),
                        "shortcode": Js("exp"),
                        "ai": Js("17"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Internal product variant"),
                        "label": Js("VARIANT"),
                        "ai": Js("20"),
                        "format": Js("N2"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{2})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Serial number"),
                        "label": Js("SERIAL"),
                        "shortcode": Js("ser"),
                        "ai": Js("21"),
                        "format": Js("X..20"),
                        "type": Js("Q"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,20})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Consumer product variant"),
                        "label": Js("CPV"),
                        "shortcode": Js("cpv"),
                        "ai": Js("22"),
                        "format": Js("X..20"),
                        "type": Js("Q"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,20})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Additional product identification assigned by the manufacturer"),
                        "label": Js("ADDITIONAL ID"),
                        "ai": Js("240"),
                        "format": Js("X..30"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Customer part number"),
                        "label": Js("CUST. PART NO."),
                        "ai": Js("241"),
                        "format": Js("X..30"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Made-to-Order variation number"),
                        "label": Js("MTO VARIANT"),
                        "ai": Js("242"),
                        "format": Js("N..6"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Packaging component number"),
                        "label": Js("PCN"),
                        "ai": Js("243"),
                        "format": Js("X..20"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,20})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Secondary serial number"),
                        "label": Js("SECONDARY SERIAL"),
                        "ai": Js("250"),
                        "format": Js("X..30"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Reference to source entity"),
                        "label": Js("REF. TO SOURCE "),
                        "ai": Js("251"),
                        "format": Js("X..30"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Global Document Type Identifier (GDTI)"),
                        "label": Js("GDTI"),
                        "shortcode": Js("gdti"),
                        "ai": Js("253"),
                        "format": Js("N13+X..17"),
                        "type": Js("I"),
                        "fixedLength": Js(False),
                        "checkDigit": Js("13"),
                        "regex": Js("(\\d{13})([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,17})"),
                    }
                ),
                Js(
                    {
                        "title": Js("GLN extension component"),
                        "label": Js("GLN EXTENSION COMPONENT"),
                        "shortcode": Js("glnx"),
                        "ai": Js("254"),
                        "format": Js("X..20"),
                        "type": Js("Q"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,20})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Global Coupon Number (GCN)"),
                        "label": Js("GCN"),
                        "shortcode": Js("gcn"),
                        "ai": Js("255"),
                        "format": Js("N13+N..12"),
                        "type": Js("I"),
                        "fixedLength": Js(False),
                        "checkDigit": Js("13"),
                        "regex": Js("(\\d{13})(\\d{0,12})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Variable count of items (variable measure trade item)"),
                        "label": Js("VAR. COUNT"),
                        "ai": Js("30"),
                        "format": Js("N..8"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,8})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, kilograms (variable measure trade item)"),
                        "label": Js("NET WEIGHT (kg)"),
                        "ai": Js("3100"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, kilograms (variable measure trade item)"),
                        "label": Js("NET WEIGHT (kg)"),
                        "ai": Js("3101"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, kilograms (variable measure trade item)"),
                        "label": Js("NET WEIGHT (kg)"),
                        "ai": Js("3102"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, kilograms (variable measure trade item)"),
                        "label": Js("NET WEIGHT (kg)"),
                        "ai": Js("3103"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, kilograms (variable measure trade item)"),
                        "label": Js("NET WEIGHT (kg)"),
                        "ai": Js("3104"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, kilograms (variable measure trade item)"),
                        "label": Js("NET WEIGHT (kg)"),
                        "ai": Js("3105"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, metres (variable measure trade item)"),
                        "label": Js("LENGTH (m)"),
                        "ai": Js("3110"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, metres (variable measure trade item)"),
                        "label": Js("LENGTH (m)"),
                        "ai": Js("3111"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, metres (variable measure trade item)"),
                        "label": Js("LENGTH (m)"),
                        "ai": Js("3112"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, metres (variable measure trade item)"),
                        "label": Js("LENGTH (m)"),
                        "ai": Js("3113"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, metres (variable measure trade item)"),
                        "label": Js("LENGTH (m)"),
                        "ai": Js("3114"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, metres (variable measure trade item)"),
                        "label": Js("LENGTH (m)"),
                        "ai": Js("3115"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, metres (variable measure trade item)"),
                        "label": Js("WIDTH (m)"),
                        "ai": Js("3120"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, metres (variable measure trade item)"),
                        "label": Js("WIDTH (m)"),
                        "ai": Js("3121"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, metres (variable measure trade item)"),
                        "label": Js("WIDTH (m)"),
                        "ai": Js("3122"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, metres (variable measure trade item)"),
                        "label": Js("WIDTH (m)"),
                        "ai": Js("3123"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, metres (variable measure trade item)"),
                        "label": Js("WIDTH (m)"),
                        "ai": Js("3124"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, metres (variable measure trade item)"),
                        "label": Js("WIDTH (m)"),
                        "ai": Js("3125"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, metres (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (m)"),
                        "ai": Js("3130"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, metres (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (m)"),
                        "ai": Js("3131"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, metres (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (m)"),
                        "ai": Js("3132"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, metres (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (m)"),
                        "ai": Js("3133"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, metres (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (m)"),
                        "ai": Js("3134"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, metres (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (m)"),
                        "ai": Js("3135"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square metres (variable measure trade item)"),
                        "label": Js("AREA (m^2)"),
                        "ai": Js("3140"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square metres (variable measure trade item)"),
                        "label": Js("AREA (m^2)"),
                        "ai": Js("3141"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square metres (variable measure trade item)"),
                        "label": Js("AREA (m^2)"),
                        "ai": Js("3142"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square metres (variable measure trade item)"),
                        "label": Js("AREA (m^2)"),
                        "ai": Js("3143"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square metres (variable measure trade item)"),
                        "label": Js("AREA (m^2)"),
                        "ai": Js("3144"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square metres (variable measure trade item)"),
                        "label": Js("AREA (m^2)"),
                        "ai": Js("3145"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, litres (variable measure trade item)"),
                        "label": Js("NET VOLUME (l)"),
                        "ai": Js("3150"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, litres (variable measure trade item)"),
                        "label": Js("NET VOLUME (l)"),
                        "ai": Js("3151"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, litres (variable measure trade item)"),
                        "label": Js("NET VOLUME (l)"),
                        "ai": Js("3152"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, litres (variable measure trade item)"),
                        "label": Js("NET VOLUME (l)"),
                        "ai": Js("3153"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, litres (variable measure trade item)"),
                        "label": Js("NET VOLUME (l)"),
                        "ai": Js("3154"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, litres (variable measure trade item)"),
                        "label": Js("NET VOLUME (l)"),
                        "ai": Js("3155"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic metres (variable measure trade item)"),
                        "label": Js("NET VOLUME (m^3)"),
                        "ai": Js("3160"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic metres (variable measure trade item)"),
                        "label": Js("NET VOLUME (m^3)"),
                        "ai": Js("3161"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic metres (variable measure trade item)"),
                        "label": Js("NET VOLUME (m^3)"),
                        "ai": Js("3162"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic metres (variable measure trade item)"),
                        "label": Js("NET VOLUME (m^3)"),
                        "ai": Js("3163"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic metres (variable measure trade item)"),
                        "label": Js("NET VOLUME (m^3)"),
                        "ai": Js("3164"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic metres (variable measure trade item)"),
                        "label": Js("NET VOLUME (m^3)"),
                        "ai": Js("3165"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, pounds (variable measure trade item)"),
                        "label": Js("NET WEIGHT (lb)"),
                        "ai": Js("3200"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, pounds (variable measure trade item)"),
                        "label": Js("NET WEIGHT (lb)"),
                        "ai": Js("3201"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, pounds (variable measure trade item)"),
                        "label": Js("NET WEIGHT (lb)"),
                        "ai": Js("3202"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, pounds (variable measure trade item)"),
                        "label": Js("NET WEIGHT (lb)"),
                        "ai": Js("3203"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, pounds (variable measure trade item)"),
                        "label": Js("NET WEIGHT (lb)"),
                        "ai": Js("3204"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, pounds (variable measure trade item)"),
                        "label": Js("NET WEIGHT (lb)"),
                        "ai": Js("3205"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, inches (variable measure trade item)"),
                        "label": Js("LENGTH (in)"),
                        "ai": Js("3210"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, inches (variable measure trade item)"),
                        "label": Js("LENGTH (in)"),
                        "ai": Js("3211"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, inches (variable measure trade item)"),
                        "label": Js("LENGTH (in)"),
                        "ai": Js("3212"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, inches (variable measure trade item)"),
                        "label": Js("LENGTH (in)"),
                        "ai": Js("3213"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, inches (variable measure trade item)"),
                        "label": Js("LENGTH (in)"),
                        "ai": Js("3214"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, inches (variable measure trade item)"),
                        "label": Js("LENGTH (in)"),
                        "ai": Js("3215"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, feet (variable measure trade item)"),
                        "label": Js("LENGTH (ft)"),
                        "ai": Js("3220"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, feet (variable measure trade item)"),
                        "label": Js("LENGTH (ft)"),
                        "ai": Js("3221"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, feet (variable measure trade item)"),
                        "label": Js("LENGTH (ft)"),
                        "ai": Js("3222"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, feet (variable measure trade item)"),
                        "label": Js("LENGTH (ft)"),
                        "ai": Js("3223"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, feet (variable measure trade item)"),
                        "label": Js("LENGTH (ft)"),
                        "ai": Js("3224"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, feet (variable measure trade item)"),
                        "label": Js("LENGTH (ft)"),
                        "ai": Js("3225"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, yards (variable measure trade item)"),
                        "label": Js("LENGTH (yd)"),
                        "ai": Js("3230"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, yards (variable measure trade item)"),
                        "label": Js("LENGTH (yd)"),
                        "ai": Js("3231"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, yards (variable measure trade item)"),
                        "label": Js("LENGTH (yd)"),
                        "ai": Js("3232"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, yards (variable measure trade item)"),
                        "label": Js("LENGTH (yd)"),
                        "ai": Js("3233"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, yards (variable measure trade item)"),
                        "label": Js("LENGTH (yd)"),
                        "ai": Js("3234"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, yards (variable measure trade item)"),
                        "label": Js("LENGTH (yd)"),
                        "ai": Js("3235"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, inches (variable measure trade item)"),
                        "label": Js("WIDTH (in)"),
                        "ai": Js("3240"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, inches (variable measure trade item)"),
                        "label": Js("WIDTH (in)"),
                        "ai": Js("3241"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, inches (variable measure trade item)"),
                        "label": Js("WIDTH (in)"),
                        "ai": Js("3242"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, inches (variable measure trade item)"),
                        "label": Js("WIDTH (in)"),
                        "ai": Js("3243"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, inches (variable measure trade item)"),
                        "label": Js("WIDTH (in)"),
                        "ai": Js("3244"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, inches (variable measure trade item)"),
                        "label": Js("WIDTH (in)"),
                        "ai": Js("3245"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, feet (variable measure trade item)"),
                        "label": Js("WIDTH (ft)"),
                        "ai": Js("3250"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, feet (variable measure trade item)"),
                        "label": Js("WIDTH (ft)"),
                        "ai": Js("3251"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, feet (variable measure trade item)"),
                        "label": Js("WIDTH (ft)"),
                        "ai": Js("3252"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, feet (variable measure trade item)"),
                        "label": Js("WIDTH (ft)"),
                        "ai": Js("3253"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, feet (variable measure trade item)"),
                        "label": Js("WIDTH (ft)"),
                        "ai": Js("3254"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, feet (variable measure trade item)"),
                        "label": Js("WIDTH (ft)"),
                        "ai": Js("3255"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, yards (variable measure trade item)"),
                        "label": Js("WIDTH (yd)"),
                        "ai": Js("3260"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, yards (variable measure trade item)"),
                        "label": Js("WIDTH (yd)"),
                        "ai": Js("3261"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, yards (variable measure trade item)"),
                        "label": Js("WIDTH (yd)"),
                        "ai": Js("3262"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, yards (variable measure trade item)"),
                        "label": Js("WIDTH (yd)"),
                        "ai": Js("3263"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, yards (variable measure trade item)"),
                        "label": Js("WIDTH (yd)"),
                        "ai": Js("3264"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, yards (variable measure trade item)"),
                        "label": Js("WIDTH (yd)"),
                        "ai": Js("3265"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, inches (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (in)"),
                        "ai": Js("3270"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, inches (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (in)"),
                        "ai": Js("3271"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, inches (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (in)"),
                        "ai": Js("3272"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, inches (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (in)"),
                        "ai": Js("3273"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, inches (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (in)"),
                        "ai": Js("3274"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, inches (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (in)"),
                        "ai": Js("3275"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, feet (variable measure trade item)"),
                        "label": Js("HEIGHT (ft)"),
                        "ai": Js("3280"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, feet (variable measure trade item)"),
                        "label": Js("HEIGHT (ft)"),
                        "ai": Js("3281"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, feet (variable measure trade item)"),
                        "label": Js("HEIGHT (ft)"),
                        "ai": Js("3282"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, feet (variable measure trade item)"),
                        "label": Js("HEIGHT (ft)"),
                        "ai": Js("3283"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, feet (variable measure trade item)"),
                        "label": Js("HEIGHT (ft)"),
                        "ai": Js("3284"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, feet (variable measure trade item)"),
                        "label": Js("HEIGHT (ft)"),
                        "ai": Js("3285"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, yards (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (yd)"),
                        "ai": Js("3290"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, yards (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (yd)"),
                        "ai": Js("3291"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, yards (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (yd)"),
                        "ai": Js("3292"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, yards (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (yd)"),
                        "ai": Js("3293"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, yards (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (yd)"),
                        "ai": Js("3294"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js(
                            "Depth, thickness, height, or third dimension, yards (variable measure trade item)"
                        ),
                        "label": Js("HEIGHT (yd)"),
                        "ai": Js("3295"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic weight, kilograms"),
                        "label": Js("GROSS WEIGHT (kg)"),
                        "ai": Js("3300"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic weight, kilograms"),
                        "label": Js("GROSS WEIGHT (kg)"),
                        "ai": Js("3301"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic weight, kilograms"),
                        "label": Js("GROSS WEIGHT (kg)"),
                        "ai": Js("3302"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic weight, kilograms"),
                        "label": Js("GROSS WEIGHT (kg)"),
                        "ai": Js("3303"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic weight, kilograms"),
                        "label": Js("GROSS WEIGHT (kg)"),
                        "ai": Js("3304"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic weight, kilograms"),
                        "label": Js("GROSS WEIGHT (kg)"),
                        "ai": Js("3305"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, metres"),
                        "label": Js("LENGTH (m), log"),
                        "ai": Js("3310"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, metres"),
                        "label": Js("LENGTH (m), log"),
                        "ai": Js("3311"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, metres"),
                        "label": Js("LENGTH (m), log"),
                        "ai": Js("3312"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, metres"),
                        "label": Js("LENGTH (m), log"),
                        "ai": Js("3313"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, metres"),
                        "label": Js("LENGTH (m), log"),
                        "ai": Js("3314"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, metres"),
                        "label": Js("LENGTH (m), log"),
                        "ai": Js("3315"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, metres"),
                        "label": Js("WIDTH (m), log"),
                        "ai": Js("3320"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, metres"),
                        "label": Js("WIDTH (m), log"),
                        "ai": Js("3321"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, metres"),
                        "label": Js("WIDTH (m), log"),
                        "ai": Js("3322"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, metres"),
                        "label": Js("WIDTH (m), log"),
                        "ai": Js("3323"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, metres"),
                        "label": Js("WIDTH (m), log"),
                        "ai": Js("3324"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, metres"),
                        "label": Js("WIDTH (m), log"),
                        "ai": Js("3325"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, metres"),
                        "label": Js("HEIGHT (m), log"),
                        "ai": Js("3330"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, metres"),
                        "label": Js("HEIGHT (m), log"),
                        "ai": Js("3331"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, metres"),
                        "label": Js("HEIGHT (m), log"),
                        "ai": Js("3332"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, metres"),
                        "label": Js("HEIGHT (m), log"),
                        "ai": Js("3333"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, metres"),
                        "label": Js("HEIGHT (m), log"),
                        "ai": Js("3334"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, metres"),
                        "label": Js("HEIGHT (m), log"),
                        "ai": Js("3335"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square metres"),
                        "label": Js("AREA (m^2), log"),
                        "ai": Js("3340"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square metres"),
                        "label": Js("AREA (m^2), log"),
                        "ai": Js("3341"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square metres"),
                        "label": Js("AREA (m^2), log"),
                        "ai": Js("3342"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square metres"),
                        "label": Js("AREA (m^2), log"),
                        "ai": Js("3343"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square metres"),
                        "label": Js("AREA (m^2), log"),
                        "ai": Js("3344"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square metres"),
                        "label": Js("AREA (m^2), log"),
                        "ai": Js("3345"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, litres"),
                        "label": Js("VOLUME (l), log"),
                        "ai": Js("3350"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, litres"),
                        "label": Js("VOLUME (l), log"),
                        "ai": Js("3351"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, litres"),
                        "label": Js("VOLUME (l), log"),
                        "ai": Js("3352"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, litres"),
                        "label": Js("VOLUME (l), log"),
                        "ai": Js("3353"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, litres"),
                        "label": Js("VOLUME (l), log"),
                        "ai": Js("3354"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, litres"),
                        "label": Js("VOLUME (l), log"),
                        "ai": Js("3355"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic metres"),
                        "label": Js("VOLUME (m^3), log"),
                        "ai": Js("3360"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic metres"),
                        "label": Js("VOLUME (m^3), log"),
                        "ai": Js("3361"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic metres"),
                        "label": Js("VOLUME (m^3), log"),
                        "ai": Js("3362"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic metres"),
                        "label": Js("VOLUME (m^3), log"),
                        "ai": Js("3363"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic metres"),
                        "label": Js("VOLUME (m^3), log"),
                        "ai": Js("3364"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic metres"),
                        "label": Js("VOLUME (m^3), log"),
                        "ai": Js("3365"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Kilograms per square metre"),
                        "label": Js("KG PER m^2"),
                        "ai": Js("3370"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Kilograms per square metre"),
                        "label": Js("KG PER m^2"),
                        "ai": Js("3371"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Kilograms per square metre"),
                        "label": Js("KG PER m^2"),
                        "ai": Js("3372"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Kilograms per square metre"),
                        "label": Js("KG PER m^2"),
                        "ai": Js("3373"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Kilograms per square metre"),
                        "label": Js("KG PER m^2"),
                        "ai": Js("3374"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Kilograms per square metre"),
                        "label": Js("KG PER m^2"),
                        "ai": Js("3375"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic weight, pounds"),
                        "label": Js("GROSS WEIGHT (lb)"),
                        "ai": Js("3400"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic weight, pounds"),
                        "label": Js("GROSS WEIGHT (lb)"),
                        "ai": Js("3401"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic weight, pounds"),
                        "label": Js("GROSS WEIGHT (lb)"),
                        "ai": Js("3402"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic weight, pounds"),
                        "label": Js("GROSS WEIGHT (lb)"),
                        "ai": Js("3403"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic weight, pounds"),
                        "label": Js("GROSS WEIGHT (lb)"),
                        "ai": Js("3404"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic weight, pounds"),
                        "label": Js("GROSS WEIGHT (lb)"),
                        "ai": Js("3405"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, inches"),
                        "label": Js("LENGTH (in), log"),
                        "ai": Js("3410"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, inches"),
                        "label": Js("LENGTH (in), log"),
                        "ai": Js("3411"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, inches"),
                        "label": Js("LENGTH (in), log"),
                        "ai": Js("3412"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, inches"),
                        "label": Js("LENGTH (in), log"),
                        "ai": Js("3413"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, inches"),
                        "label": Js("LENGTH (in), log"),
                        "ai": Js("3414"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, inches"),
                        "label": Js("LENGTH (in), log"),
                        "ai": Js("3415"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, feet"),
                        "label": Js("LENGTH (ft), log"),
                        "ai": Js("3420"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, feet"),
                        "label": Js("LENGTH (ft), log"),
                        "ai": Js("3421"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, feet"),
                        "label": Js("LENGTH (ft), log"),
                        "ai": Js("3422"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, feet"),
                        "label": Js("LENGTH (ft), log"),
                        "ai": Js("3423"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, feet"),
                        "label": Js("LENGTH (ft), log"),
                        "ai": Js("3424"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, feet"),
                        "label": Js("LENGTH (ft), log"),
                        "ai": Js("3425"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, yards"),
                        "label": Js("LENGTH (yd), log"),
                        "ai": Js("3430"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, yards"),
                        "label": Js("LENGTH (yd), log"),
                        "ai": Js("3431"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, yards"),
                        "label": Js("LENGTH (yd), log"),
                        "ai": Js("3432"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, yards"),
                        "label": Js("LENGTH (yd), log"),
                        "ai": Js("3433"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, yards"),
                        "label": Js("LENGTH (yd), log"),
                        "ai": Js("3434"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Length or first dimension, yards"),
                        "label": Js("LENGTH (yd), log"),
                        "ai": Js("3435"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, inches"),
                        "label": Js("WIDTH (in), log"),
                        "ai": Js("3440"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, inches"),
                        "label": Js("WIDTH (in), log"),
                        "ai": Js("3441"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, inches"),
                        "label": Js("WIDTH (in), log"),
                        "ai": Js("3442"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, inches"),
                        "label": Js("WIDTH (in), log"),
                        "ai": Js("3443"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, inches"),
                        "label": Js("WIDTH (in), log"),
                        "ai": Js("3444"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, inches"),
                        "label": Js("WIDTH (in), log"),
                        "ai": Js("3445"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, feet"),
                        "label": Js("WIDTH (ft), log"),
                        "ai": Js("3450"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, feet"),
                        "label": Js("WIDTH (ft), log"),
                        "ai": Js("3451"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, feet"),
                        "label": Js("WIDTH (ft), log"),
                        "ai": Js("3452"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, feet"),
                        "label": Js("WIDTH (ft), log"),
                        "ai": Js("3453"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, feet"),
                        "label": Js("WIDTH (ft), log"),
                        "ai": Js("3454"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, feet"),
                        "label": Js("WIDTH (ft), log"),
                        "ai": Js("3455"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, yard"),
                        "label": Js("WIDTH (yd), log"),
                        "ai": Js("3460"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, yard"),
                        "label": Js("WIDTH (yd), log"),
                        "ai": Js("3461"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, yard"),
                        "label": Js("WIDTH (yd), log"),
                        "ai": Js("3462"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, yard"),
                        "label": Js("WIDTH (yd), log"),
                        "ai": Js("3463"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, yard"),
                        "label": Js("WIDTH (yd), log"),
                        "ai": Js("3464"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Width, diameter, or second dimension, yard"),
                        "label": Js("WIDTH (yd), log"),
                        "ai": Js("3465"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, inches"),
                        "label": Js("HEIGHT (in), log"),
                        "ai": Js("3470"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, inches"),
                        "label": Js("HEIGHT (in), log"),
                        "ai": Js("3471"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, inches"),
                        "label": Js("HEIGHT (in), log"),
                        "ai": Js("3472"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, inches"),
                        "label": Js("HEIGHT (in), log"),
                        "ai": Js("3473"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, inches"),
                        "label": Js("HEIGHT (in), log"),
                        "ai": Js("3474"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, inches"),
                        "label": Js("HEIGHT (in), log"),
                        "ai": Js("3475"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, feet"),
                        "label": Js("HEIGHT (ft), log"),
                        "ai": Js("3480"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, feet"),
                        "label": Js("HEIGHT (ft), log"),
                        "ai": Js("3481"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, feet"),
                        "label": Js("HEIGHT (ft), log"),
                        "ai": Js("3482"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, feet"),
                        "label": Js("HEIGHT (ft), log"),
                        "ai": Js("3483"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, feet"),
                        "label": Js("HEIGHT (ft), log"),
                        "ai": Js("3484"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, feet"),
                        "label": Js("HEIGHT (ft), log"),
                        "ai": Js("3485"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, yards"),
                        "label": Js("HEIGHT (yd), log"),
                        "ai": Js("3490"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, yards"),
                        "label": Js("HEIGHT (yd), log"),
                        "ai": Js("3491"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, yards"),
                        "label": Js("HEIGHT (yd), log"),
                        "ai": Js("3492"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, yards"),
                        "label": Js("HEIGHT (yd), log"),
                        "ai": Js("3493"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, yards"),
                        "label": Js("HEIGHT (yd), log"),
                        "ai": Js("3494"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Depth, thickness, height, or third dimension, yards"),
                        "label": Js("HEIGHT (yd), log"),
                        "ai": Js("3495"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square inches (variable measure trade item)"),
                        "label": Js("AREA (in^2)"),
                        "ai": Js("3500"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square inches (variable measure trade item)"),
                        "label": Js("AREA (in^2)"),
                        "ai": Js("3501"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square inches (variable measure trade item)"),
                        "label": Js("AREA (in^2)"),
                        "ai": Js("3502"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square inches (variable measure trade item)"),
                        "label": Js("AREA (in^2)"),
                        "ai": Js("3503"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square inches (variable measure trade item)"),
                        "label": Js("AREA (in^2)"),
                        "ai": Js("3504"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square inches (variable measure trade item)"),
                        "label": Js("AREA (in^2)"),
                        "ai": Js("3505"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square feet (variable measure trade item)"),
                        "label": Js("AREA (ft^2)"),
                        "ai": Js("3510"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square feet (variable measure trade item)"),
                        "label": Js("AREA (ft^2)"),
                        "ai": Js("3511"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square feet (variable measure trade item)"),
                        "label": Js("AREA (ft^2)"),
                        "ai": Js("3512"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square feet (variable measure trade item)"),
                        "label": Js("AREA (ft^2)"),
                        "ai": Js("3513"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square feet (variable measure trade item)"),
                        "label": Js("AREA (ft^2)"),
                        "ai": Js("3514"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square feet (variable measure trade item)"),
                        "label": Js("AREA (ft^2)"),
                        "ai": Js("3515"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square yards (variable measure trade item)"),
                        "label": Js("AREA (yd^2)"),
                        "ai": Js("3520"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square yards (variable measure trade item)"),
                        "label": Js("AREA (yd^2)"),
                        "ai": Js("3521"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square yards (variable measure trade item)"),
                        "label": Js("AREA (yd^2)"),
                        "ai": Js("3522"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square yards (variable measure trade item)"),
                        "label": Js("AREA (yd^2)"),
                        "ai": Js("3523"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square yards (variable measure trade item)"),
                        "label": Js("AREA (yd^2)"),
                        "ai": Js("3524"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square yards (variable measure trade item)"),
                        "label": Js("AREA (yd^2)"),
                        "ai": Js("3525"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square inches"),
                        "label": Js("AREA (in^2), log"),
                        "ai": Js("3530"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square inches"),
                        "label": Js("AREA (in^2), log"),
                        "ai": Js("3531"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square inches"),
                        "label": Js("AREA (in^2), log"),
                        "ai": Js("3532"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square inches"),
                        "label": Js("AREA (in^2), log"),
                        "ai": Js("3533"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square inches"),
                        "label": Js("AREA (in^2), log"),
                        "ai": Js("3534"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square inches"),
                        "label": Js("AREA (in^2), log"),
                        "ai": Js("3535"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square feet"),
                        "label": Js("AREA (ft^2), log"),
                        "ai": Js("3540"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square feet"),
                        "label": Js("AREA (ft^2), log"),
                        "ai": Js("3541"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square feet"),
                        "label": Js("AREA (ft^2), log"),
                        "ai": Js("3542"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square feet"),
                        "label": Js("AREA (ft^2), log"),
                        "ai": Js("3543"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square feet"),
                        "label": Js("AREA (ft^2), log"),
                        "ai": Js("3544"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square feet"),
                        "label": Js("AREA (ft^2), log"),
                        "ai": Js("3545"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square yards"),
                        "label": Js("AREA (yd^2), log"),
                        "ai": Js("3550"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square yards"),
                        "label": Js("AREA (yd^2), log"),
                        "ai": Js("3551"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square yards"),
                        "label": Js("AREA (yd^2), log"),
                        "ai": Js("3552"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square yards"),
                        "label": Js("AREA (yd^2), log"),
                        "ai": Js("3553"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square yards"),
                        "label": Js("AREA (yd^2), log"),
                        "ai": Js("3554"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Area, square yards"),
                        "label": Js("AREA (yd^2), log"),
                        "ai": Js("3555"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, troy ounces (variable measure trade item)"),
                        "label": Js("NET WEIGHT (t oz)"),
                        "ai": Js("3560"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, troy ounces (variable measure trade item)"),
                        "label": Js("NET WEIGHT (t oz)"),
                        "ai": Js("3561"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, troy ounces (variable measure trade item)"),
                        "label": Js("NET WEIGHT (t oz)"),
                        "ai": Js("3562"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, troy ounces (variable measure trade item)"),
                        "label": Js("NET WEIGHT (t oz)"),
                        "ai": Js("3563"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, troy ounces (variable measure trade item)"),
                        "label": Js("NET WEIGHT (t oz)"),
                        "ai": Js("3564"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight, troy ounces (variable measure trade item)"),
                        "label": Js("NET WEIGHT (t oz)"),
                        "ai": Js("3565"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight (or volume), ounces (variable measure trade item)"),
                        "label": Js("NET VOLUME (oz)"),
                        "ai": Js("3570"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight (or volume), ounces (variable measure trade item)"),
                        "label": Js("NET VOLUME (oz)"),
                        "ai": Js("3571"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight (or volume), ounces (variable measure trade item)"),
                        "label": Js("NET VOLUME (oz)"),
                        "ai": Js("3572"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight (or volume), ounces (variable measure trade item)"),
                        "label": Js("NET VOLUME (oz)"),
                        "ai": Js("3573"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight (or volume), ounces (variable measure trade item)"),
                        "label": Js("NET VOLUME (oz)"),
                        "ai": Js("3574"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net weight (or volume), ounces (variable measure trade item)"),
                        "label": Js("NET VOLUME (oz)"),
                        "ai": Js("3575"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, quarts (variable measure trade item)"),
                        "label": Js("NET VOLUME (qt)"),
                        "ai": Js("3600"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, quarts (variable measure trade item)"),
                        "label": Js("NET VOLUME (qt)"),
                        "ai": Js("3601"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, quarts (variable measure trade item)"),
                        "label": Js("NET VOLUME (qt)"),
                        "ai": Js("3602"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, quarts (variable measure trade item)"),
                        "label": Js("NET VOLUME (qt)"),
                        "ai": Js("3603"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, quarts (variable measure trade item)"),
                        "label": Js("NET VOLUME (qt)"),
                        "ai": Js("3604"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, quarts (variable measure trade item)"),
                        "label": Js("NET VOLUME (qt)"),
                        "ai": Js("3605"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, gallons U.S. (variable measure trade item)"),
                        "label": Js("NET VOLUME (gal.)"),
                        "ai": Js("3610"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, gallons U.S. (variable measure trade item)"),
                        "label": Js("NET VOLUME (gal.)"),
                        "ai": Js("3611"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, gallons U.S. (variable measure trade item)"),
                        "label": Js("NET VOLUME (gal.)"),
                        "ai": Js("3612"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, gallons U.S. (variable measure trade item)"),
                        "label": Js("NET VOLUME (gal.)"),
                        "ai": Js("3613"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, gallons U.S. (variable measure trade item)"),
                        "label": Js("NET VOLUME (gal.)"),
                        "ai": Js("3614"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, gallons U.S. (variable measure trade item)"),
                        "label": Js("NET VOLUME (gal.)"),
                        "ai": Js("3615"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, quarts"),
                        "label": Js("VOLUME (qt), log"),
                        "ai": Js("3620"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, quarts"),
                        "label": Js("VOLUME (qt), log"),
                        "ai": Js("3621"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, quarts"),
                        "label": Js("VOLUME (qt), log"),
                        "ai": Js("3622"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, quarts"),
                        "label": Js("VOLUME (qt), log"),
                        "ai": Js("3623"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, quarts"),
                        "label": Js("VOLUME (qt), log"),
                        "ai": Js("3624"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, quarts"),
                        "label": Js("VOLUME (qt), log"),
                        "ai": Js("3625"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, gallons U.S."),
                        "label": Js("VOLUME (gal.), log"),
                        "ai": Js("3630"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, gallons U.S."),
                        "label": Js("VOLUME (gal.), log"),
                        "ai": Js("3631"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, gallons U.S."),
                        "label": Js("VOLUME (gal.), log"),
                        "ai": Js("3632"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, gallons U.S."),
                        "label": Js("VOLUME (gal.), log"),
                        "ai": Js("3633"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, gallons U.S."),
                        "label": Js("VOLUME (gal.), log"),
                        "ai": Js("3634"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, gallons U.S."),
                        "label": Js("VOLUME (gal.), log"),
                        "ai": Js("3635"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic inches (variable measure trade item)"),
                        "label": Js("VOLUME (in^3) "),
                        "ai": Js("3640"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic inches (variable measure trade item)"),
                        "label": Js("VOLUME (in^3) "),
                        "ai": Js("3641"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic inches (variable measure trade item)"),
                        "label": Js("VOLUME (in^3) "),
                        "ai": Js("3642"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic inches (variable measure trade item)"),
                        "label": Js("VOLUME (in^3) "),
                        "ai": Js("3643"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic inches (variable measure trade item)"),
                        "label": Js("VOLUME (in^3) "),
                        "ai": Js("3644"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic inches (variable measure trade item)"),
                        "label": Js("VOLUME (in^3) "),
                        "ai": Js("3645"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic feet (variable measure trade item)"),
                        "label": Js("VOLUME (ft^3) "),
                        "ai": Js("3650"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic feet (variable measure trade item)"),
                        "label": Js("VOLUME (ft^3) "),
                        "ai": Js("3651"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic feet (variable measure trade item)"),
                        "label": Js("VOLUME (ft^3) "),
                        "ai": Js("3652"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic feet (variable measure trade item)"),
                        "label": Js("VOLUME (ft^3) "),
                        "ai": Js("3653"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic feet (variable measure trade item)"),
                        "label": Js("VOLUME (ft^3) "),
                        "ai": Js("3654"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic feet (variable measure trade item)"),
                        "label": Js("VOLUME (ft^3) "),
                        "ai": Js("3655"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic yards (variable measure trade item)"),
                        "label": Js("VOLUME (yd^3) "),
                        "ai": Js("3660"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic yards (variable measure trade item)"),
                        "label": Js("VOLUME (yd^3) "),
                        "ai": Js("3661"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic yards (variable measure trade item)"),
                        "label": Js("VOLUME (yd^3) "),
                        "ai": Js("3662"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic yards (variable measure trade item)"),
                        "label": Js("VOLUME (yd^3) "),
                        "ai": Js("3663"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic yards (variable measure trade item)"),
                        "label": Js("VOLUME (yd^3) "),
                        "ai": Js("3664"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Net volume, cubic yards (variable measure trade item)"),
                        "label": Js("VOLUME (yd^3) "),
                        "ai": Js("3665"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic inches"),
                        "label": Js("VOLUME (in^3), log"),
                        "ai": Js("3670"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic inches"),
                        "label": Js("VOLUME (in^3), log"),
                        "ai": Js("3671"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic inches"),
                        "label": Js("VOLUME (in^3), log"),
                        "ai": Js("3672"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic inches"),
                        "label": Js("VOLUME (in^3), log"),
                        "ai": Js("3673"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic inches"),
                        "label": Js("VOLUME (in^3), log"),
                        "ai": Js("3674"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic inches"),
                        "label": Js("VOLUME (in^3), log"),
                        "ai": Js("3675"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic feet"),
                        "label": Js("VOLUME (ft^3), log"),
                        "ai": Js("3680"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic feet"),
                        "label": Js("VOLUME (ft^3), log"),
                        "ai": Js("3681"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic feet"),
                        "label": Js("VOLUME (ft^3), log"),
                        "ai": Js("3682"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic feet"),
                        "label": Js("VOLUME (ft^3), log"),
                        "ai": Js("3683"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic feet"),
                        "label": Js("VOLUME (ft^3), log"),
                        "ai": Js("3684"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic feet"),
                        "label": Js("VOLUME (ft^3), log"),
                        "ai": Js("3685"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic yards"),
                        "label": Js("VOLUME (yd^3), log"),
                        "ai": Js("3690"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic yards"),
                        "label": Js("VOLUME (yd^3), log"),
                        "ai": Js("3691"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic yards"),
                        "label": Js("VOLUME (yd^3), log"),
                        "ai": Js("3692"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic yards"),
                        "label": Js("VOLUME (yd^3), log"),
                        "ai": Js("3693"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic yards"),
                        "label": Js("VOLUME (yd^3), log"),
                        "ai": Js("3694"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Logistic volume, cubic yards"),
                        "label": Js("VOLUME (yd^3), log"),
                        "ai": Js("3695"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Count of trade items"),
                        "label": Js("COUNT"),
                        "ai": Js("37"),
                        "format": Js("N..8"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,8})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable or Coupon value, local currency"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3900"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable or Coupon value, local currency"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3901"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable or Coupon value, local currency"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3902"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable or Coupon value, local currency"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3903"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable or Coupon value, local currency"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3904"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable or Coupon value, local currency"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3905"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable or Coupon value, local currency"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3906"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable or Coupon value, local currency"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3907"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable or Coupon value, local currency"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3908"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable or Coupon value, local currency"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3909"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3910"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3911"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3912"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3913"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3914"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3915"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3916"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3917"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3918"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code"),
                        "label": Js("AMOUNT"),
                        "ai": Js("3919"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable, single monetary area (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3920"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable, single monetary area (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3921"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable, single monetary area (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3922"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable, single monetary area (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3923"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable, single monetary area (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3924"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable, single monetary area (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3925"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable, single monetary area (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3926"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable, single monetary area (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3927"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable, single monetary area (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3928"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable, single monetary area (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3929"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3930"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3931"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3932"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3933"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3934"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3935"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3936"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3937"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3938"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Applicable amount payable with ISO currency code (variable measure trade item)"),
                        "label": Js("PRICE"),
                        "ai": Js("3939"),
                        "format": Js("N..15"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,15})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Percentage discount of a coupon"),
                        "label": Js("PRCNT OFF"),
                        "ai": Js("3940"),
                        "format": Js("N4"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{4})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Percentage discount of a coupon"),
                        "label": Js("PRCNT OFF"),
                        "ai": Js("3941"),
                        "format": Js("N4"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{4})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Percentage discount of a coupon"),
                        "label": Js("PRCNT OFF"),
                        "ai": Js("3942"),
                        "format": Js("N4"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{4})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Percentage discount of a coupon"),
                        "label": Js("PRCNT OFF"),
                        "ai": Js("3943"),
                        "format": Js("N4"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{4})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Customer's purchase order number"),
                        "label": Js("ORDER NUMBER"),
                        "ai": Js("400"),
                        "format": Js("X..30"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Global Identification Number for Consignment (GINC)"),
                        "label": Js("GINC"),
                        "shortcode": Js("ginc"),
                        "ai": Js("401"),
                        "format": Js("X..30"),
                        "type": Js("I"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Global Shipment Identification Number (GSIN)"),
                        "label": Js("GSIN"),
                        "shortcode": Js("gsin"),
                        "ai": Js("402"),
                        "format": Js("N17"),
                        "type": Js("I"),
                        "fixedLength": Js(True),
                        "checkDigit": Js("L"),
                        "regex": Js("(\\d{17})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Routing code"),
                        "label": Js("ROUTE"),
                        "ai": Js("403"),
                        "format": Js("X..30"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Ship to - Deliver to Global Location Number"),
                        "label": Js("SHIP TO LOC"),
                        "ai": Js("410"),
                        "format": Js("N13"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "checkDigit": Js("L"),
                        "regex": Js("(\\d{13})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Bill to - Invoice to Global Location Number"),
                        "label": Js("BILL TO "),
                        "ai": Js("411"),
                        "format": Js("N13"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "checkDigit": Js("L"),
                        "regex": Js("(\\d{13})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Purchased from Global Location Number"),
                        "label": Js("PURCHASE FROM"),
                        "ai": Js("412"),
                        "format": Js("N13"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "checkDigit": Js("L"),
                        "regex": Js("(\\d{13})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Ship for - Deliver for - Forward to Global Location Number"),
                        "label": Js("SHIP FOR LOC"),
                        "ai": Js("413"),
                        "format": Js("N13"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "checkDigit": Js("L"),
                        "regex": Js("(\\d{13})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Identification of a physical location - Global Location Number"),
                        "label": Js("LOC No"),
                        "shortcode": Js("gln"),
                        "ai": Js("414"),
                        "format": Js("N13"),
                        "type": Js("I"),
                        "fixedLength": Js(True),
                        "checkDigit": Js("L"),
                        "qualifiers": Js([Js("254")]),
                        "regex": Js("(\\d{13})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Global Location Number of the invoicing party"),
                        "label": Js("PAY TO"),
                        "shortcode": Js("payto"),
                        "ai": Js("415"),
                        "format": Js("N13"),
                        "type": Js("I"),
                        "fixedLength": Js(True),
                        "checkDigit": Js("L"),
                        "regex": Js("(\\d{13})"),
                    }
                ),
                Js(
                    {
                        "title": Js("GLN of the production or service location"),
                        "label": Js("PROD/SERV LOC"),
                        "ai": Js("416"),
                        "format": Js("N13"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "checkDigit": Js("L"),
                        "regex": Js("(\\d{13})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Ship to - Deliver to postal code within a single postal authority"),
                        "label": Js("SHIP TO POST"),
                        "ai": Js("420"),
                        "format": Js("X..20"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,20})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Ship to - Deliver to postal code with ISO country code"),
                        "label": Js("SHIP TO POST"),
                        "ai": Js("421"),
                        "format": Js("N3+X..9"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,9})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Country of origin of a trade item"),
                        "label": Js("ORIGIN"),
                        "ai": Js("422"),
                        "format": Js("N3"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{3})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Country of initial processing"),
                        "label": Js("COUNTRY - INITIAL PROCESS."),
                        "ai": Js("423"),
                        "format": Js("N3+N..12"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,12})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Country of processing"),
                        "label": Js("COUNTRY - PROCESS."),
                        "ai": Js("424"),
                        "format": Js("N3"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{3})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Country of disassembly"),
                        "label": Js("COUNTRY - DISASSEMBLY"),
                        "ai": Js("425"),
                        "format": Js("N3+N..12"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})(\\d{0,12})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Country covering full process chain"),
                        "label": Js("COUNTRY - FULL PROCESS"),
                        "ai": Js("426"),
                        "format": Js("N3"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{3})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Country subdivision Of origin"),
                        "label": Js("ORIGIN SUBDIVISION"),
                        "ai": Js("427"),
                        "format": Js("X..3"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,3})"),
                    }
                ),
                Js(
                    {
                        "title": Js("NATO Stock Number (NSN)"),
                        "label": Js("NSN"),
                        "ai": Js("7001"),
                        "format": Js("N13"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{13})"),
                    }
                ),
                Js(
                    {
                        "title": Js("UN/ECE meat carcasses and cuts classification"),
                        "label": Js("MEAT CUT"),
                        "ai": Js("7002"),
                        "format": Js("X..30"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Expiration date and time"),
                        "label": Js("EXPIRY TIME"),
                        "shortcode": Js("expdt"),
                        "ai": Js("7003"),
                        "format": Js("N10"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{10})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Active potency"),
                        "label": Js("ACTIVE POTENCY"),
                        "ai": Js("7004"),
                        "format": Js("N..4"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,4})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Catch area"),
                        "label": Js("CATCH AREA"),
                        "ai": Js("7005"),
                        "format": Js("X..12"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,12})"),
                    }
                ),
                Js(
                    {
                        "title": Js("First freeze date "),
                        "label": Js("FIRST FREEZE DATE"),
                        "ai": Js("7006"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Harvest date"),
                        "label": Js("HARVEST DATE"),
                        "ai": Js("7007"),
                        "format": Js("N6..12"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{6,12})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Species for fishery purposes"),
                        "label": Js("AQUATIC SPECIES"),
                        "ai": Js("7008"),
                        "format": Js("X..3"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,3})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Fishing gear type"),
                        "label": Js("FISHING GEAR TYPE"),
                        "ai": Js("7009"),
                        "format": Js("X..10"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,10})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Production method"),
                        "label": Js("PROD METHOD"),
                        "ai": Js("7010"),
                        "format": Js("X..2"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,2})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Refurbishment lot ID"),
                        "label": Js("REFURB LOT"),
                        "ai": Js("7020"),
                        "format": Js("X..20"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,20})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Functional status"),
                        "label": Js("FUNC STAT"),
                        "ai": Js("7021"),
                        "format": Js("X..20"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,20})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Revision status"),
                        "label": Js("REV STAT"),
                        "ai": Js("7022"),
                        "format": Js("X..20"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,20})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Global Individual Asset Identifier (GIAI) of an assembly"),
                        "label": Js("GIAI - ASSEMBLY"),
                        "ai": Js("7023"),
                        "format": Js("X..30"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Number of processor with ISO Country Code"),
                        "label": Js("PROCESSOR # 0"),
                        "ai": Js("7030"),
                        "format": Js("X..27"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,27})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Number of processor with ISO Country Code"),
                        "label": Js("PROCESSOR # 1"),
                        "ai": Js("7031"),
                        "format": Js("X..27"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,27})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Number of processor with ISO Country Code"),
                        "label": Js("PROCESSOR # 2"),
                        "ai": Js("7032"),
                        "format": Js("X..27"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,27})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Number of processor with ISO Country Code"),
                        "label": Js("PROCESSOR # 3"),
                        "ai": Js("7033"),
                        "format": Js("X..27"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,27})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Number of processor with ISO Country Code"),
                        "label": Js("PROCESSOR # 4"),
                        "ai": Js("7034"),
                        "format": Js("X..27"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,27})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Number of processor with ISO Country Code"),
                        "label": Js("PROCESSOR # 5"),
                        "ai": Js("7035"),
                        "format": Js("X..27"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,27})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Number of processor with ISO Country Code"),
                        "label": Js("PROCESSOR # 6"),
                        "ai": Js("7036"),
                        "format": Js("X..27"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,27})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Number of processor with ISO Country Code"),
                        "label": Js("PROCESSOR # 7"),
                        "ai": Js("7037"),
                        "format": Js("X..27"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,27})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Number of processor with ISO Country Code"),
                        "label": Js("PROCESSOR # 8"),
                        "ai": Js("7038"),
                        "format": Js("X..27"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,27})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Number of processor with ISO Country Code"),
                        "label": Js("PROCESSOR # 9"),
                        "ai": Js("7039"),
                        "format": Js("X..27"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{3})([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,27})"),
                    }
                ),
                Js(
                    {
                        "title": Js("National Healthcare Reimbursement Number (NHRN) - Germany PZN"),
                        "label": Js("NHRN PZN"),
                        "ai": Js("710"),
                        "format": Js("X..20"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,20})"),
                    }
                ),
                Js(
                    {
                        "title": Js("National Healthcare Reimbursement Number (NHRN) - France CIP"),
                        "label": Js("NHRN CIP"),
                        "ai": Js("711"),
                        "format": Js("X..20"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,20})"),
                    }
                ),
                Js(
                    {
                        "title": Js("National Healthcare Reimbursement Number (NHRN) - Spain CN"),
                        "label": Js("NHRN CN"),
                        "ai": Js("712"),
                        "format": Js("X..20"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,20})"),
                    }
                ),
                Js(
                    {
                        "title": Js("National Healthcare Reimbursement Number (NHRN) - Brasil DRN"),
                        "label": Js("NHRN DRN"),
                        "ai": Js("713"),
                        "format": Js("X..20"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,20})"),
                    }
                ),
                Js(
                    {
                        "title": Js("National Healthcare Reimbursement Number (NHRN) - Portugal AIM"),
                        "label": Js("NHRN AIM"),
                        "ai": Js("714"),
                        "format": Js("X..20"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,20})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Certification reference # 0"),
                        "label": Js("CERT # 0"),
                        "ai": Js("7230"),
                        "format": Js("X2+X..28"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{2,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Certification reference # 1"),
                        "label": Js("CERT # 1"),
                        "ai": Js("7231"),
                        "format": Js("X2+X..28"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{2,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Certification reference # 2"),
                        "label": Js("CERT # 2"),
                        "ai": Js("7232"),
                        "format": Js("X2+X..28"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{2,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Certification reference # 3"),
                        "label": Js("CERT # 3"),
                        "ai": Js("7233"),
                        "format": Js("X2+X..28"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{2,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Certification reference # 4"),
                        "label": Js("CERT # 4"),
                        "ai": Js("7234"),
                        "format": Js("X2+X..28"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{2,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Certification reference # 5"),
                        "label": Js("CERT # 5"),
                        "ai": Js("7235"),
                        "format": Js("X2+X..28"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{2,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Certification reference # 6"),
                        "label": Js("CERT # 6"),
                        "ai": Js("7236"),
                        "format": Js("X2+X..28"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{2,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Certification reference # 7"),
                        "label": Js("CERT # 7"),
                        "ai": Js("7237"),
                        "format": Js("X2+X..28"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{2,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Certification reference # 8"),
                        "label": Js("CERT # 8"),
                        "ai": Js("7238"),
                        "format": Js("X2+X..28"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{2,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Certification reference # 9"),
                        "label": Js("CERT # 9"),
                        "ai": Js("7239"),
                        "format": Js("X2+X..28"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{2,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Roll products (width, length, core diameter, direction, splices)"),
                        "label": Js("DIMENSIONS"),
                        "ai": Js("8001"),
                        "format": Js("N14"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{14})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Cellular mobile telephone identifier"),
                        "label": Js("CMT No"),
                        "ai": Js("8002"),
                        "format": Js("X..20"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,20})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Global Returnable Asset Identifier (GRAI)"),
                        "label": Js("GRAI"),
                        "shortcode": Js("grai"),
                        "ai": Js("8003"),
                        "format": Js("N14+X..16"),
                        "type": Js("I"),
                        "fixedLength": Js(False),
                        "checkDigit": Js("13"),
                        "regex": Js("(\\d{14})([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,16})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Global Individual Asset Identifier (GIAI)"),
                        "label": Js("GIAI"),
                        "shortcode": Js("giai"),
                        "ai": Js("8004"),
                        "format": Js("X..30"),
                        "type": Js("I"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Price per unit of measure"),
                        "label": Js("PRICE PER UNIT"),
                        "ai": Js("8005"),
                        "format": Js("N6"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{6})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Identification of an individual trade item piece"),
                        "label": Js("ITIP"),
                        "shortcode": Js("itip"),
                        "ai": Js("8006"),
                        "format": Js("N14+N2+N2"),
                        "type": Js("I"),
                        "fixedLength": Js(True),
                        "checkDigit": Js("14"),
                        "qualifiers": Js([Js("22"), Js("10"), Js("21")]),
                        "regex": Js("(\\d{14})(\\d{2})(\\d{2})"),
                    }
                ),
                Js(
                    {
                        "title": Js("International Bank Account Number (IBAN) "),
                        "label": Js("IBAN"),
                        "ai": Js("8007"),
                        "format": Js("X..34"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,34})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Date and time of production"),
                        "label": Js("PROD TIME"),
                        "ai": Js("8008"),
                        "format": Js("N8+N..4"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{8})(\\d{0,4})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Optically Readable Sensor Indicator"),
                        "label": Js("OPT SEN"),
                        "ai": Js("8009"),
                        "format": Js("X..50"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,50})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Component/Part Identifier (CPID)"),
                        "label": Js("CPID"),
                        "shortcode": Js("cpid"),
                        "ai": Js("8010"),
                        "format": Js("Y..30"),
                        "type": Js("I"),
                        "fixedLength": Js(False),
                        "qualifiers": Js([Js("8011")]),
                        "regex": Js("([\\x23\\x2D\\x2F\\x30-\\x39\\x41-\\x5A]{0,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Component/Part Identifier serial number (CPID SERIAL)"),
                        "label": Js("CPID SERIAL"),
                        "shortcode": Js("cpsn"),
                        "ai": Js("8011"),
                        "format": Js("N..12"),
                        "type": Js("Q"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,12})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Software version"),
                        "label": Js("VERSION"),
                        "ai": Js("8012"),
                        "format": Js("X..20"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,20})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Global Model Number (GMN)"),
                        "label": Js("GMN (for medical devices, the default, global data title is BUDI-DI )"),
                        "ai": Js("8013"),
                        "format": Js("X..30"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Global Service Relation Number - Provider"),
                        "label": Js("GSRN - PROVIDER"),
                        "shortcode": Js("gsrnp"),
                        "ai": Js("8017"),
                        "format": Js("N18"),
                        "type": Js("I"),
                        "fixedLength": Js(True),
                        "checkDigit": Js("L"),
                        "qualifiers": Js([Js("8019")]),
                        "regex": Js("(\\d{18})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Global Service Relation Number - Recipient"),
                        "label": Js("GSRN - RECIPIENT"),
                        "shortcode": Js("gsrn"),
                        "ai": Js("8018"),
                        "format": Js("N18"),
                        "type": Js("I"),
                        "fixedLength": Js(True),
                        "checkDigit": Js("L"),
                        "qualifiers": Js([Js("8019")]),
                        "regex": Js("(\\d{18})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Service Relation Instance Number (SRIN)"),
                        "label": Js("SRIN"),
                        "shortcode": Js("srin"),
                        "ai": Js("8019"),
                        "format": Js("N..10"),
                        "type": Js("Q"),
                        "fixedLength": Js(False),
                        "regex": Js("(\\d{0,10})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Payment slip reference number"),
                        "label": Js("REF No"),
                        "ai": Js("8020"),
                        "format": Js("X..25"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,25})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Identification of pieces of a trade item contained in a logistics unit"),
                        "label": Js("ITIP CONTENT"),
                        "ai": Js("8026"),
                        "format": Js("N14+N2+N2"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "checkDigit": Js("14"),
                        "regex": Js("(\\d{14})(\\d{2})(\\d{2})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Coupon code identification for use in North America"),
                        "ai": Js("8110"),
                        "format": Js("X..70"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,70})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Loyalty points of a coupon"),
                        "label": Js("POINTS"),
                        "ai": Js("8111"),
                        "format": Js("N4"),
                        "type": Js("D"),
                        "fixedLength": Js(True),
                        "regex": Js("(\\d{4})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Paperless coupon code identification for use in North America"),
                        "ai": Js("8112"),
                        "format": Js("X..70"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,70})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Extended Packaging URL "),
                        "label": Js("PRODUCT URL"),
                        "ai": Js("8200"),
                        "format": Js("X..70"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,70})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Information mutually agreed between trading partners"),
                        "label": Js("INTERNAL"),
                        "ai": Js("90"),
                        "format": Js("X..30"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,30})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Company internal information"),
                        "label": Js("INTERNAL"),
                        "ai": Js("91"),
                        "format": Js("X..90"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,90})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Company internal information"),
                        "label": Js("INTERNAL"),
                        "ai": Js("92"),
                        "format": Js("X..90"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,90})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Company internal information"),
                        "label": Js("INTERNAL"),
                        "ai": Js("93"),
                        "format": Js("X..90"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,90})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Company internal information"),
                        "label": Js("INTERNAL"),
                        "ai": Js("94"),
                        "format": Js("X..90"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,90})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Company internal information"),
                        "label": Js("INTERNAL"),
                        "ai": Js("95"),
                        "format": Js("X..90"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,90})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Company internal information"),
                        "label": Js("INTERNAL"),
                        "ai": Js("96"),
                        "format": Js("X..90"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,90})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Company internal information"),
                        "label": Js("INTERNAL"),
                        "ai": Js("97"),
                        "format": Js("X..90"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,90})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Company internal information"),
                        "label": Js("INTERNAL"),
                        "ai": Js("98"),
                        "format": Js("X..90"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,90})"),
                    }
                ),
                Js(
                    {
                        "title": Js("Company internal information"),
                        "label": Js("INTERNAL"),
                        "ai": Js("99"),
                        "format": Js("X..90"),
                        "type": Js("D"),
                        "fixedLength": Js(False),
                        "regex": Js("([\\x21-\\x22\\x25-\\x2F\\x30-\\x39\\x41-\\x5A\\x5F\\x61-\\x7A]{0,90})"),
                    }
                ),
            ]
        ),
    )


PyJs_LONG_0_()
var.put(
    "fixedLengthTable",
    Js(
        {
            "00": Js(20.0),
            "01": Js(16.0),
            "02": Js(16.0),
            "03": Js(16.0),
            "04": Js(18.0),
            "11": Js(8.0),
            "12": Js(8.0),
            "13": Js(8.0),
            "14": Js(8.0),
            "15": Js(8.0),
            "16": Js(8.0),
            "17": Js(8.0),
            "18": Js(8.0),
            "19": Js(4.0),
            "20": Js(4.0),
            "31": Js(10.0),
            "32": Js(10.0),
            "33": Js(10.0),
            "34": Js(10.0),
            "35": Js(10.0),
            "36": Js(10.0),
            "41": Js(16.0),
        }
    ),
)
var.put(
    "tableP",
    Js(
        {
            "00": Js(2.0),
            "01": Js(2.0),
            "02": Js(2.0),
            "10": Js(2.0),
            "11": Js(2.0),
            "12": Js(2.0),
            "13": Js(2.0),
            "15": Js(2.0),
            "16": Js(2.0),
            "17": Js(2.0),
            "20": Js(2.0),
            "21": Js(2.0),
            "22": Js(2.0),
            "23": Js(3.0),
            "24": Js(3.0),
            "25": Js(3.0),
            "30": Js(2.0),
            "31": Js(4.0),
            "32": Js(4.0),
            "33": Js(4.0),
            "34": Js(4.0),
            "35": Js(4.0),
            "36": Js(4.0),
            "37": Js(2.0),
            "39": Js(4.0),
            "40": Js(3.0),
            "41": Js(3.0),
            "42": Js(3.0),
            "70": Js(4.0),
            "71": Js(3.0),
            "72": Js(4.0),
            "80": Js(4.0),
            "81": Js(4.0),
            "82": Js(4.0),
            "90": Js(2.0),
            "91": Js(2.0),
            "92": Js(2.0),
            "93": Js(2.0),
            "94": Js(2.0),
            "95": Js(2.0),
            "96": Js(2.0),
            "97": Js(2.0),
            "98": Js(2.0),
            "99": Js(2.0),
        }
    ),
)
var.put(
    "tableF",
    Js(
        {
            "00": Js([Js({"E": Js("N"), "L": Js("18")})]),
            "01": Js([Js({"E": Js("N"), "L": Js("14")})]),
            "02": Js([Js({"E": Js("N"), "L": Js("14")})]),
            "10": Js([Js({"E": Js("X"), "M": Js("20")})]),
            "11": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "12": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "13": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "15": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "16": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "17": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "20": Js([Js({"E": Js("N"), "L": Js("2")})]),
            "21": Js([Js({"E": Js("X"), "M": Js("20")})]),
            "22": Js([Js({"E": Js("X"), "M": Js("20")})]),
            "240": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "241": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "242": Js([Js({"E": Js("N"), "M": Js("6")})]),
            "243": Js([Js({"E": Js("X"), "M": Js("20")})]),
            "250": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "251": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "253": Js([Js({"E": Js("N"), "L": Js("13")}), Js({"E": Js("X"), "M": Js("17")})]),
            "254": Js([Js({"E": Js("X"), "M": Js("20")})]),
            "255": Js([Js({"E": Js("N"), "L": Js("13")}), Js({"E": Js("N"), "M": Js("12")})]),
            "30": Js([Js({"E": Js("N"), "M": Js("8")})]),
            "3100": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3101": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3102": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3103": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3104": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3105": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3110": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3111": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3112": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3113": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3114": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3115": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3120": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3121": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3122": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3123": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3124": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3125": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3130": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3131": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3132": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3133": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3134": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3135": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3140": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3141": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3142": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3143": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3144": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3145": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3150": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3151": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3152": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3153": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3154": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3155": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3160": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3161": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3162": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3163": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3164": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3165": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3200": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3201": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3202": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3203": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3204": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3205": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3210": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3211": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3212": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3213": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3214": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3215": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3220": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3221": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3222": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3223": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3224": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3225": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3230": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3231": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3232": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3233": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3234": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3235": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3240": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3241": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3242": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3243": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3244": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3245": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3250": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3251": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3252": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3253": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3254": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3255": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3260": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3261": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3262": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3263": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3264": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3265": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3270": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3271": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3272": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3273": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3274": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3275": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3280": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3281": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3282": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3283": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3284": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3285": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3290": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3291": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3292": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3293": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3294": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3295": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3300": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3301": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3302": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3303": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3304": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3305": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3310": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3311": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3312": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3313": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3314": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3315": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3320": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3321": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3322": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3323": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3324": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3325": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3330": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3331": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3332": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3333": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3334": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3335": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3340": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3341": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3342": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3343": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3344": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3345": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3350": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3351": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3352": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3353": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3354": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3355": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3360": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3361": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3362": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3363": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3364": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3365": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3370": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3371": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3372": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3373": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3374": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3375": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3400": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3401": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3402": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3403": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3404": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3405": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3410": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3411": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3412": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3413": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3414": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3415": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3420": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3421": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3422": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3423": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3424": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3425": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3430": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3431": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3432": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3433": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3434": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3435": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3440": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3441": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3442": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3443": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3444": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3445": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3450": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3451": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3452": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3453": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3454": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3455": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3460": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3461": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3462": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3463": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3464": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3465": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3470": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3471": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3472": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3473": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3474": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3475": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3480": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3481": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3482": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3483": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3484": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3485": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3490": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3491": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3492": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3493": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3494": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3495": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3500": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3501": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3502": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3503": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3504": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3505": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3510": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3511": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3512": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3513": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3514": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3515": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3520": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3521": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3522": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3523": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3524": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3525": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3530": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3531": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3532": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3533": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3534": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3535": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3540": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3541": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3542": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3543": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3544": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3545": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3550": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3551": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3552": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3553": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3554": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3555": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3560": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3561": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3562": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3563": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3564": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3565": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3570": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3571": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3572": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3573": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3574": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3575": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3600": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3601": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3602": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3603": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3604": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3605": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3610": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3611": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3612": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3613": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3614": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3615": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3620": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3621": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3622": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3623": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3624": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3625": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3630": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3631": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3632": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3633": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3634": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3635": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3640": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3641": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3642": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3643": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3644": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3645": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3650": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3651": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3652": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3653": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3654": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3655": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3660": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3661": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3662": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3663": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3664": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3665": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3670": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3671": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3672": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3673": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3674": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3675": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3680": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3681": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3682": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3683": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3684": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3685": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3690": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3691": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3692": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3693": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3694": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "3695": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "37": Js([Js({"E": Js("N"), "M": Js("8")})]),
            "3900": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3901": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3902": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3903": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3904": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3905": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3906": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3907": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3908": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3909": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3910": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3911": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3912": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3913": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3914": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3915": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3916": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3917": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3918": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3919": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3920": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3921": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3922": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3923": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3924": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3925": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3926": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3927": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3928": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3929": Js([Js({"E": Js("N"), "M": Js("15")})]),
            "3930": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3931": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3932": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3933": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3934": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3935": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3936": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3937": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3938": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3939": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("15")})]),
            "3940": Js([Js({"E": Js("N"), "L": Js("4")})]),
            "3941": Js([Js({"E": Js("N"), "L": Js("4")})]),
            "3942": Js([Js({"E": Js("N"), "L": Js("4")})]),
            "3943": Js([Js({"E": Js("N"), "L": Js("4")})]),
            "400": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "401": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "402": Js([Js({"E": Js("N"), "L": Js("17")})]),
            "403": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "410": Js([Js({"E": Js("N"), "L": Js("13")})]),
            "411": Js([Js({"E": Js("N"), "L": Js("13")})]),
            "412": Js([Js({"E": Js("N"), "L": Js("13")})]),
            "413": Js([Js({"E": Js("N"), "L": Js("13")})]),
            "414": Js([Js({"E": Js("N"), "L": Js("13")})]),
            "415": Js([Js({"E": Js("N"), "L": Js("13")})]),
            "416": Js([Js({"E": Js("N"), "L": Js("13")})]),
            "420": Js([Js({"E": Js("X"), "M": Js("20")})]),
            "421": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("X"), "M": Js("9")})]),
            "422": Js([Js({"E": Js("N"), "L": Js("3")})]),
            "423": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("12")})]),
            "424": Js([Js({"E": Js("N"), "L": Js("3")})]),
            "425": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("N"), "M": Js("12")})]),
            "426": Js([Js({"E": Js("N"), "L": Js("3")})]),
            "427": Js([Js({"E": Js("X"), "M": Js("3")})]),
            "7001": Js([Js({"E": Js("N"), "L": Js("13")})]),
            "7002": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "7003": Js([Js({"E": Js("N"), "L": Js("10")})]),
            "7004": Js([Js({"E": Js("N"), "M": Js("4")})]),
            "7005": Js([Js({"E": Js("X"), "M": Js("12")})]),
            "7006": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "7007": Js([Js({"E": Js("N"), "L": Js("6")}), Js({"E": Js("N"), "M": Js("6")})]),
            "7008": Js([Js({"E": Js("X"), "M": Js("3")})]),
            "7009": Js([Js({"E": Js("X"), "M": Js("10")})]),
            "7010": Js([Js({"E": Js("X"), "M": Js("2")})]),
            "7020": Js([Js({"E": Js("X"), "M": Js("20")})]),
            "7021": Js([Js({"E": Js("X"), "M": Js("20")})]),
            "7022": Js([Js({"E": Js("X"), "M": Js("20")})]),
            "7023": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "7030": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("X"), "M": Js("27")})]),
            "7031": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("X"), "M": Js("27")})]),
            "7032": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("X"), "M": Js("27")})]),
            "7033": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("X"), "M": Js("27")})]),
            "7034": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("X"), "M": Js("27")})]),
            "7035": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("X"), "M": Js("27")})]),
            "7036": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("X"), "M": Js("27")})]),
            "7037": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("X"), "M": Js("27")})]),
            "7038": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("X"), "M": Js("27")})]),
            "7039": Js([Js({"E": Js("N"), "L": Js("3")}), Js({"E": Js("X"), "M": Js("27")})]),
            "710": Js([Js({"E": Js("X"), "M": Js("20")})]),
            "711": Js([Js({"E": Js("X"), "M": Js("20")})]),
            "712": Js([Js({"E": Js("X"), "M": Js("20")})]),
            "713": Js([Js({"E": Js("X"), "M": Js("20")})]),
            "714": Js([Js({"E": Js("X"), "M": Js("20")})]),
            "7230": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "7231": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "7232": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "7233": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "7234": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "7235": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "7236": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "7237": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "7238": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "7239": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "8001": Js([Js({"E": Js("N"), "L": Js("14")})]),
            "8002": Js([Js({"E": Js("X"), "M": Js("20")})]),
            "8003": Js([Js({"E": Js("N"), "L": Js("14")}), Js({"E": Js("X"), "M": Js("16")})]),
            "8004": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "8005": Js([Js({"E": Js("N"), "L": Js("6")})]),
            "8006": Js([Js({"E": Js("N"), "L": Js("18")})]),
            "8007": Js([Js({"E": Js("X"), "M": Js("24")})]),
            "8008": Js([Js({"E": Js("N"), "L": Js("8")}), Js({"E": Js("N"), "M": Js("4")})]),
            "8009": Js([Js({"E": Js("X"), "M": Js("50")})]),
            "8010": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "8011": Js([Js({"E": Js("N"), "M": Js("12")})]),
            "8012": Js([Js({"E": Js("X"), "M": Js("20")})]),
            "8013": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "8017": Js([Js({"E": Js("N"), "L": Js("18")})]),
            "8018": Js([Js({"E": Js("N"), "L": Js("18")})]),
            "8019": Js([Js({"E": Js("N"), "M": Js("10")})]),
            "8020": Js([Js({"E": Js("X"), "M": Js("25")})]),
            "8026": Js([Js({"E": Js("N"), "L": Js("18")})]),
            "8110": Js([Js({"E": Js("X"), "M": Js("70")})]),
            "8111": Js([Js({"E": Js("N"), "L": Js("4")})]),
            "8112": Js([Js({"E": Js("X"), "M": Js("70")})]),
            "8200": Js([Js({"E": Js("X"), "M": Js("70")})]),
            "90": Js([Js({"E": Js("X"), "M": Js("30")})]),
            "91": Js([Js({"E": Js("X"), "M": Js("90")})]),
            "92": Js([Js({"E": Js("X"), "M": Js("90")})]),
            "93": Js([Js({"E": Js("X"), "M": Js("90")})]),
            "94": Js([Js({"E": Js("X"), "M": Js("90")})]),
            "95": Js([Js({"E": Js("X"), "M": Js("90")})]),
            "96": Js([Js({"E": Js("X"), "M": Js("90")})]),
            "97": Js([Js({"E": Js("X"), "M": Js("90")})]),
            "98": Js([Js({"E": Js("X"), "M": Js("90")})]),
            "99": Js([Js({"E": Js("X"), "M": Js("90")})]),
        }
    ),
)
var.put(
    "tableOpt",
    Js(
        {
            "0A": Js([Js("01"), Js("22")]),
            "0B": Js([Js("01"), Js("10")]),
            "0C": Js([Js("01"), Js("21")]),
            "0D": Js([Js("01"), Js("17")]),
            "0E": Js([Js("01"), Js("7003")]),
            "0F": Js([Js("01"), Js("30")]),
            "1A": Js([Js("01"), Js("10"), Js("21"), Js("17")]),
            "1B": Js([Js("01"), Js("15")]),
            "1C": Js([Js("01"), Js("11")]),
            "1D": Js([Js("01"), Js("16")]),
            "1E": Js([Js("01"), Js("91")]),
            "1F": Js([Js("01"), Js("10"), Js("15")]),
            "2A": Js([Js("01"), Js("3100")]),
            "2B": Js([Js("01"), Js("3101")]),
            "2C": Js([Js("01"), Js("3102")]),
            "2D": Js([Js("01"), Js("3103")]),
            "2E": Js([Js("01"), Js("3104")]),
            "2F": Js([Js("01"), Js("3105")]),
            "3A": Js([Js("01"), Js("3200")]),
            "3B": Js([Js("01"), Js("3201")]),
            "3C": Js([Js("01"), Js("3202")]),
            "3D": Js([Js("01"), Js("3203")]),
            "3E": Js([Js("01"), Js("3204")]),
            "3F": Js([Js("01"), Js("3205")]),
            "9A": Js([Js("8010"), Js("8011")]),
            "9B": Js([Js("8017"), Js("8019")]),
            "9C": Js([Js("8018"), Js("8019")]),
            "9D": Js([Js("414"), Js("254")]),
            "A0": Js([Js("01"), Js("3920")]),
            "A1": Js([Js("01"), Js("3921")]),
            "A2": Js([Js("01"), Js("3922")]),
            "A3": Js([Js("01"), Js("3923")]),
            "A4": Js([Js("01"), Js("3924")]),
            "A5": Js([Js("01"), Js("3925")]),
            "A6": Js([Js("01"), Js("3926")]),
            "A7": Js([Js("01"), Js("3927")]),
            "A8": Js([Js("01"), Js("3928")]),
            "A9": Js([Js("01"), Js("3929")]),
            "C0": Js([Js("255"), Js("3900")]),
            "C1": Js([Js("255"), Js("3901")]),
            "C2": Js([Js("255"), Js("3902")]),
            "C3": Js([Js("255"), Js("3903")]),
            "C4": Js([Js("255"), Js("3904")]),
            "C5": Js([Js("255"), Js("3905")]),
            "C6": Js([Js("255"), Js("3906")]),
            "C7": Js([Js("255"), Js("3907")]),
            "C8": Js([Js("255"), Js("3908")]),
            "C9": Js([Js("255"), Js("3909")]),
            "CA": Js([Js("255"), Js("3940")]),
            "CB": Js([Js("255"), Js("3941")]),
            "CC": Js([Js("255"), Js("3942")]),
            "CD": Js([Js("255"), Js("3943")]),
        }
    ),
)
var.put(
    "tableS1",
    Js(
        {
            "01": Js({"requires": Js([Js("21"), Js("235")])}),
            "00": Js({"requires": var.get("null")}),
            "8006": Js({"requires": Js([Js("21")])}),
            "8010": Js({"requires": Js([Js("8011")])}),
            "8004": Js({"requires": var.get("null")}),
            "8003": Js({"minLength": Js(15.0)}),
            "253": Js({"minLength": Js(14.0)}),
            "254": Js({"minLength": Js(14.0)}),
        }
    ),
)
var.put(
    "stringSemantics",
    Js(
        {
            "01": Js([Js("gs1:gtin"), Js("schema:gtin")]),
            "10": Js([Js("gs1:hasBatchLot")]),
            "21": Js([Js("gs1:hasSerialNumber")]),
            "235": Js([Js("gs1:hasThirdPartyControlledSerialNumber")]),
            "22": Js([Js("gs1:consumerProductVariant")]),
        }
    ),
)
var.put(
    "classSemantics",
    Js(
        {
            "01": Js([Js("gs1:Product"), Js("schema:Product")]),
            "8006": Js([Js("gs1:Product"), Js("schema:Product")]),
            "414": Js([Js("gs1:Place"), Js("schema:Place")]),
            "417": Js([Js("gs1:Organization"), Js("schema:Organization")]),
        }
    ),
)
var.put(
    "dateSemantics",
    Js(
        {
            "11": Js([Js("gs1:productionDate")]),
            "12": Js([Js("gs1:dueDate")]),
            "13": Js([Js("gs1:packagingDate")]),
            "15": Js([Js("gs1:bestBeforeDate")]),
            "16": Js([Js("gs1:sellByDate")]),
            "17": Js([Js("gs1:expirationDate")]),
            "7006": Js([Js("gs1:firstFreezeDate")]),
        }
    ),
)
var.put("dateTimeSecondsSemantics", Js({"8008": Js([Js("gs1:productionDateTime")])}))
var.put("dateTimeMinutesSemantics", Js({"7003": Js([Js("gs1:expirationDateTime")])}))
var.put("dateRangeSemantics", Js({"7007": Js([Js("gs1:harvestDate")])}))
var.put(
    "quantitativeValueSemantics",
    Js(
        {
            "3100": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("KGM")}),
            "3101": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("KGM")}),
            "3102": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("KGM")}),
            "3103": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("KGM")}),
            "3104": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("KGM")}),
            "3105": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("KGM")}),
            "3200": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("LBR")}),
            "3201": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("LBR")}),
            "3202": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("LBR")}),
            "3203": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("LBR")}),
            "3204": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("LBR")}),
            "3205": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("LBR")}),
            "3560": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("APZ")}),
            "3561": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("APZ")}),
            "3562": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("APZ")}),
            "3563": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("APZ")}),
            "3564": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("APZ")}),
            "3565": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("APZ")}),
            "3570": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("ONZ")}),
            "3571": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("ONZ")}),
            "3572": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("ONZ")}),
            "3573": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("ONZ")}),
            "3574": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("ONZ")}),
            "3575": Js({"p": Js([Js("gs1:netWeight")]), "rec20": Js("ONZ")}),
            "3300": Js({"p": Js([Js("gs1:grossWeight")]), "rec20": Js("KGM")}),
            "3301": Js({"p": Js([Js("gs1:grossWeight")]), "rec20": Js("KGM")}),
            "3302": Js({"p": Js([Js("gs1:grossWeight")]), "rec20": Js("KGM")}),
            "3303": Js({"p": Js([Js("gs1:grossWeight")]), "rec20": Js("KGM")}),
            "3304": Js({"p": Js([Js("gs1:grossWeight")]), "rec20": Js("KGM")}),
            "3305": Js({"p": Js([Js("gs1:grossWeight")]), "rec20": Js("KGM")}),
            "3400": Js({"p": Js([Js("gs1:grossWeight")]), "rec20": Js("LBR")}),
            "3401": Js({"p": Js([Js("gs1:grossWeight")]), "rec20": Js("LBR")}),
            "3402": Js({"p": Js([Js("gs1:grossWeight")]), "rec20": Js("LBR")}),
            "3403": Js({"p": Js([Js("gs1:grossWeight")]), "rec20": Js("LBR")}),
            "3404": Js({"p": Js([Js("gs1:grossWeight")]), "rec20": Js("LBR")}),
            "3405": Js({"p": Js([Js("gs1:grossWeight")]), "rec20": Js("LBR")}),
            "3150": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("LTR")}),
            "3151": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("LTR")}),
            "3152": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("LTR")}),
            "3153": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("LTR")}),
            "3154": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("LTR")}),
            "3155": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("LTR")}),
            "3160": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("MTQ")}),
            "3161": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("MTQ")}),
            "3162": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("MTQ")}),
            "3163": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("MTQ")}),
            "3164": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("MTQ")}),
            "3165": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("MTQ")}),
            "3600": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("QT")}),
            "3601": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("QT")}),
            "3602": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("QT")}),
            "3603": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("QT")}),
            "3604": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("QT")}),
            "3605": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("QT")}),
            "3610": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("GLL")}),
            "3611": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("GLL")}),
            "3612": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("GLL")}),
            "3613": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("GLL")}),
            "3614": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("GLL")}),
            "3615": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("GLL")}),
            "3650": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("FTQ")}),
            "3651": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("FTQ")}),
            "3652": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("FTQ")}),
            "3653": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("FTQ")}),
            "3654": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("FTQ")}),
            "3655": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("FTQ")}),
            "3640": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("INQ")}),
            "3641": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("INQ")}),
            "3642": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("INQ")}),
            "3643": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("INQ")}),
            "3644": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("INQ")}),
            "3645": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("INQ")}),
            "3660": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("YDQ")}),
            "3661": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("YDQ")}),
            "3662": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("YDQ")}),
            "3663": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("YDQ")}),
            "3664": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("YDQ")}),
            "3665": Js({"p": Js([Js("gs1:netContent")]), "rec20": Js("YDQ")}),
            "3350": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("LTR")}),
            "3351": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("LTR")}),
            "3352": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("LTR")}),
            "3353": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("LTR")}),
            "3354": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("LTR")}),
            "3355": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("LTR")}),
            "3360": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("MTQ")}),
            "3361": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("MTQ")}),
            "3362": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("MTQ")}),
            "3363": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("MTQ")}),
            "3364": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("MTQ")}),
            "3365": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("MTQ")}),
            "3680": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("FTQ")}),
            "3681": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("FTQ")}),
            "3682": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("FTQ")}),
            "3683": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("FTQ")}),
            "3684": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("FTQ")}),
            "3685": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("FTQ")}),
            "3670": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("INQ")}),
            "3671": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("INQ")}),
            "3672": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("INQ")}),
            "3673": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("INQ")}),
            "3674": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("INQ")}),
            "3675": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("INQ")}),
            "3690": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("YDQ")}),
            "3691": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("YDQ")}),
            "3692": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("YDQ")}),
            "3693": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("YDQ")}),
            "3694": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("YDQ")}),
            "3695": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("YDQ")}),
            "3630": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("GLL")}),
            "3631": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("GLL")}),
            "3632": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("GLL")}),
            "3633": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("GLL")}),
            "3634": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("GLL")}),
            "3635": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("GLL")}),
            "3620": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("QT")}),
            "3621": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("QT")}),
            "3622": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("QT")}),
            "3623": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("QT")}),
            "3624": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("QT")}),
            "3625": Js({"p": Js([Js("gs1:grossVolume")]), "rec20": Js("QT")}),
            "3280": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("FOT")}),
            "3281": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("FOT")}),
            "3282": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("FOT")}),
            "3283": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("FOT")}),
            "3284": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("FOT")}),
            "3285": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("FOT")}),
            "3270": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("INH")}),
            "3271": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("INH")}),
            "3272": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("INH")}),
            "3273": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("INH")}),
            "3274": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("INH")}),
            "3275": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("INH")}),
            "3130": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("MTR")}),
            "3131": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("MTR")}),
            "3132": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("MTR")}),
            "3133": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("MTR")}),
            "3134": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("MTR")}),
            "3135": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("MTR")}),
            "3290": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("YRD")}),
            "3291": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("YRD")}),
            "3292": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("YRD")}),
            "3293": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("YRD")}),
            "3294": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("YRD")}),
            "3295": Js({"p": Js([Js("gs1:outOfPackageDepth")]), "rec20": Js("YRD")}),
            "3480": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("FOT")}),
            "3481": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("FOT")}),
            "3482": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("FOT")}),
            "3483": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("FOT")}),
            "3484": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("FOT")}),
            "3485": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("FOT")}),
            "3470": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("INH")}),
            "3471": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("INH")}),
            "3472": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("INH")}),
            "3473": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("INH")}),
            "3474": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("INH")}),
            "3475": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("INH")}),
            "3330": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("MTR")}),
            "3331": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("MTR")}),
            "3332": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("MTR")}),
            "3333": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("MTR")}),
            "3334": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("MTR")}),
            "3335": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("MTR")}),
            "3490": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("YRD")}),
            "3491": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("YRD")}),
            "3492": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("YRD")}),
            "3493": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("YRD")}),
            "3494": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("YRD")}),
            "3495": Js({"p": Js([Js("gs1:inPackageDepth")]), "rec20": Js("YRD")}),
            "3220": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("FOT")}),
            "3221": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("FOT")}),
            "3222": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("FOT")}),
            "3223": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("FOT")}),
            "3224": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("FOT")}),
            "3225": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("FOT")}),
            "3210": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("INH")}),
            "3211": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("INH")}),
            "3212": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("INH")}),
            "3213": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("INH")}),
            "3214": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("INH")}),
            "3215": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("INH")}),
            "3110": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("MTR")}),
            "3111": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("MTR")}),
            "3112": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("MTR")}),
            "3113": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("MTR")}),
            "3114": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("MTR")}),
            "3115": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("MTR")}),
            "3230": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("YRD")}),
            "3231": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("YRD")}),
            "3232": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("YRD")}),
            "3233": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("YRD")}),
            "3234": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("YRD")}),
            "3235": Js({"p": Js([Js("gs1:outOfPackageLength")]), "rec20": Js("YRD")}),
            "3420": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("FOT")}),
            "3421": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("FOT")}),
            "3422": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("FOT")}),
            "3423": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("FOT")}),
            "3424": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("FOT")}),
            "3425": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("FOT")}),
            "3410": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("INH")}),
            "3411": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("INH")}),
            "3412": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("INH")}),
            "3413": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("INH")}),
            "3414": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("INH")}),
            "3415": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("INH")}),
            "3310": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("MTR")}),
            "3311": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("MTR")}),
            "3312": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("MTR")}),
            "3313": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("MTR")}),
            "3314": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("MTR")}),
            "3315": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("MTR")}),
            "3430": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("YRD")}),
            "3431": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("YRD")}),
            "3432": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("YRD")}),
            "3433": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("YRD")}),
            "3434": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("YRD")}),
            "3435": Js({"p": Js([Js("gs1:inPackageLength")]), "rec20": Js("YRD")}),
            "3250": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("FOT")}),
            "3251": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("FOT")}),
            "3252": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("FOT")}),
            "3253": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("FOT")}),
            "3254": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("FOT")}),
            "3255": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("FOT")}),
            "3240": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("INH")}),
            "3241": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("INH")}),
            "3242": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("INH")}),
            "3243": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("INH")}),
            "3244": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("INH")}),
            "3245": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("INH")}),
            "3120": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("MTR")}),
            "3121": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("MTR")}),
            "3122": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("MTR")}),
            "3123": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("MTR")}),
            "3124": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("MTR")}),
            "3125": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("MTR")}),
            "3460": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("YRD")}),
            "3461": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("YRD")}),
            "3462": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("YRD")}),
            "3463": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("YRD")}),
            "3464": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("YRD")}),
            "3465": Js({"p": Js([Js("gs1:outOfPackageWidth")]), "rec20": Js("YRD")}),
            "3450": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("FOT")}),
            "3451": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("FOT")}),
            "3452": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("FOT")}),
            "3453": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("FOT")}),
            "3454": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("FOT")}),
            "3455": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("FOT")}),
            "3440": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("INH")}),
            "3441": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("INH")}),
            "3442": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("INH")}),
            "3443": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("INH")}),
            "3444": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("INH")}),
            "3445": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("INH")}),
            "3320": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("MTR")}),
            "3321": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("MTR")}),
            "3322": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("MTR")}),
            "3323": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("MTR")}),
            "3324": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("MTR")}),
            "3325": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("MTR")}),
            "3460": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("YRD")}),
            "3461": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("YRD")}),
            "3462": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("YRD")}),
            "3463": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("YRD")}),
            "3464": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("YRD")}),
            "3465": Js({"p": Js([Js("gs1:inPackageWidth")]), "rec20": Js("YRD")}),
            "3510": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("FTK")}),
            "3511": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("FTK")}),
            "3512": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("FTK")}),
            "3513": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("FTK")}),
            "3514": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("FTK")}),
            "3515": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("FTK")}),
            "3500": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("INK")}),
            "3501": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("INK")}),
            "3502": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("INK")}),
            "3503": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("INK")}),
            "3504": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("INK")}),
            "3505": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("INK")}),
            "3140": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("MTK")}),
            "3141": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("MTK")}),
            "3142": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("MTK")}),
            "3143": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("MTK")}),
            "3144": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("MTK")}),
            "3145": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("MTK")}),
            "3520": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("YDK")}),
            "3521": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("YDK")}),
            "3522": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("YDK")}),
            "3523": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("YDK")}),
            "3524": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("YDK")}),
            "3525": Js({"p": Js([Js("gs1:netArea")]), "rec20": Js("YDK")}),
            "3540": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("FTK")}),
            "3541": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("FTK")}),
            "3542": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("FTK")}),
            "3543": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("FTK")}),
            "3544": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("FTK")}),
            "3545": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("FTK")}),
            "3530": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("INK")}),
            "3531": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("INK")}),
            "3532": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("INK")}),
            "3533": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("INK")}),
            "3534": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("INK")}),
            "3535": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("INK")}),
            "3340": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("MTK")}),
            "3341": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("MTK")}),
            "3342": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("MTK")}),
            "3343": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("MTK")}),
            "3344": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("MTK")}),
            "3345": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("MTK")}),
            "3550": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("YDK")}),
            "3551": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("YDK")}),
            "3552": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("YDK")}),
            "3553": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("YDK")}),
            "3554": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("YDK")}),
            "3555": Js({"p": Js([Js("gs1:grossArea")]), "rec20": Js("YDK")}),
            "3370": Js({"p": Js([Js("gs1:massPerUnitArea")]), "rec20": Js("28")}),
            "3371": Js({"p": Js([Js("gs1:massPerUnitArea")]), "rec20": Js("28")}),
            "3372": Js({"p": Js([Js("gs1:massPerUnitArea")]), "rec20": Js("28")}),
            "3373": Js({"p": Js([Js("gs1:massPerUnitArea")]), "rec20": Js("28")}),
            "3374": Js({"p": Js([Js("gs1:massPerUnitArea")]), "rec20": Js("28")}),
            "3375": Js({"p": Js([Js("gs1:massPerUnitArea")]), "rec20": Js("28")}),
        }
    ),
)
var.put("safeBase64Alphabet", Js("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"))
var.put("hexAlphabet", Js("0123456789ABCDEF"))
var.put("regexAllNum", var.get("RegExp").create(Js("^[0-9]+$")))
var.put("regexHexLower", var.get("RegExp").create(Js("^[0-9a-f]+$")))
var.put("regexHexUpper", var.get("RegExp").create(Js("^[0-9A-F]+$")))
var.put("regexSafe64", var.get("RegExp").create(Js("^[A-Za-z0-9_-]+$")))
var.put("tableOptReverse", Js({}))
var.put("tableOptKeys", var.get("Object").callprop("keys", var.get("tableOpt")))
for PyJsTemp in var.get("tableOptKeys"):
    var.put("i", PyJsTemp)
    var.get("tableOptReverse").put(
        var.get("JSON").callprop(
            "stringify", var.get("tableOpt").get(var.get("tableOptKeys").get(var.get("i"))).callprop("sort")
        ),
        var.get("tableOptKeys").get(var.get("i")),
    )
var.put("aiRegex", Js({}))
var.put("aiShortCode", Js({}))
var.put("aiQualifiers", Js({}))
var.put("aiCheckDigitPosition", Js({}))
for PyJsTemp in var.get("aitable"):
    var.put("a", PyJsTemp)
    if PyJsStrictNeq(var.get("aitable").get(var.get("a")), var.get("undefined")):
        var.get("aiRegex").put(
            var.get("aitable").get(var.get("a")).get("ai"),
            var.get("RegExp").create(((Js("^") + var.get("aitable").get(var.get("a")).get("regex")) + Js("$"))),
        )
        if PyJsStrictNeq(var.get("aitable").get(var.get("a")).get("shortcode"), var.get("undefined")):
            var.get("aiShortCode").put(
                var.get("aitable").get(var.get("a")).get("ai"), var.get("aitable").get(var.get("a")).get("shortcode")
            )
        if PyJsStrictNeq(var.get("aitable").get(var.get("a")).get("qualifiers"), var.get("undefined")):
            var.get("aiQualifiers").put(
                var.get("aitable").get(var.get("a")).get("ai"), var.get("aitable").get(var.get("a")).get("qualifiers")
            )
        if PyJsStrictNeq(var.get("aitable").get(var.get("a")).get("checkDigit"), var.get("undefined")):
            var.get("aiCheckDigitPosition").put(
                var.get("aitable").get(var.get("a")).get("ai"), var.get("aitable").get(var.get("a")).get("checkDigit")
            )
pass
pass
pass
pass
pass
pass
pass
pass
pass
var.put("identifiers", var.get("aitable").callprop("filter", var.get("getIdentifiers")))
var.put("qualifiers", var.get("aitable").callprop("filter", var.get("getQualifiers")))
var.put("dataAttributes", var.get("aitable").callprop("filter", var.get("getDataAttributes")))
var.put("fixedLength", var.get("aitable").callprop("filter", var.get("getFixedLength")))
var.put("variableLength", var.get("aitable").callprop("filter", var.get("getVariableLength")))
var.put("identifierMap", Js({}))
for PyJsTemp in var.get("identifiers"):
    var.put("i", PyJsTemp)
    var.get("identifierMap").put(
        var.get("identifiers").get(var.get("i")).get("ai"), var.get("identifiers").get(var.get("i"))
    )
var.put("qualifierMap", Js({}))
for PyJsTemp in var.get("qualifiers"):
    var.put("q", PyJsTemp)
    if PyJsStrictNeq(var.get("qualifiers").get(var.get("q")), var.get("undefined")):
        var.get("qualifierMap").put(
            var.get("qualifiers").get(var.get("q")).get("ai"), var.get("qualifiers").get(var.get("q"))
        )
var.put("attributeMap", Js({}))
for PyJsTemp in var.get("dataAttributes"):
    var.put("a", PyJsTemp)
    if PyJsStrictNeq(var.get("dataAttributes").get(var.get("a")), var.get("undefined")):
        var.get("attributeMap").put(
            var.get("dataAttributes").get(var.get("a")).get("ai"), var.get("dataAttributes").get(var.get("a"))
        )
var.put("fixedLengthMap", Js({}))
for PyJsTemp in var.get("fixedLength"):
    var.put("f", PyJsTemp)
    if PyJsStrictNeq(var.get("fixedLength").get(var.get("f")), var.get("undefined")):
        var.get("fixedLengthMap").put(
            var.get("fixedLength").get(var.get("f")).get("ai"), var.get("fixedLength").get(var.get("f"))
        )
var.put("variableLengthMap", Js({}))
for PyJsTemp in var.get("variableLength"):
    var.put("v", PyJsTemp)
    if PyJsStrictNeq(var.get("variableLength").get(var.get("v")), var.get("undefined")):
        var.get("variableLengthMap").put(
            var.get("variableLength").get(var.get("v")).get("ai"), var.get("variableLength").get(var.get("v"))
        )
var.put("aiMaps", Js({}))
var.get("aiMaps").put("identifiers", var.get("Object").callprop("keys", var.get("identifierMap")))
var.get("aiMaps").put("qualifiers", var.get("Object").callprop("keys", var.get("qualifierMap")))
var.get("aiMaps").put("dataAttributes", var.get("Object").callprop("keys", var.get("attributeMap")))
var.get("aiMaps").put("fixedLength", var.get("Object").callprop("keys", var.get("fixedLengthMap")))
var.get("aiMaps").put("variableLength", var.get("Object").callprop("keys", var.get("variableLengthMap")))
var.put(
    "invalidAssociations",
    Js(
        [
            Js(
                {
                    "rule": Js(
                        "All occurrences of GTIN SHALL have one value.  It is for example not allowed to include GTINs of other packaging levels."
                    ),
                    "condition1": Js("01"),
                    "condition2": Js([Js("01")]),
                }
            ),
            Js(
                {
                    "rule": Js(
                        "GTIN of contained trade items is intended to list the trade items contained in a logistic unit, and SHALL NOT be used to identify the contents of a trade item"
                    ),
                    "condition1": Js("02"),
                    "condition2": Js([Js("01")]),
                }
            ),
            Js(
                {
                    "rule": Js("The count of units contained SHALL only be used with GTIN of contained trade items."),
                    "condition1": Js("37"),
                    "condition2": Js([Js("01")]),
                }
            ),
            Js(
                {
                    "rule": Js("A trade item SHALL NOT be identified as a coupon."),
                    "condition1": Js("255"),
                    "condition2": Js([Js("01")]),
                }
            ),
            Js(
                {
                    "rule": Js("Only one ship to postal code SHALL be applied on the same physical entity"),
                    "condition1": Js("420"),
                    "condition2": Js([Js("421")]),
                }
            ),
            Js(
                {
                    "rule": Js(
                        "Country of origin, initial processing, processing, or disassembly SHALL NOT be used in combination with country of full porcessing, since this would lead to ambiguous data."
                    ),
                    "condition1": Js("426"),
                    "condition2": Js([Js("422"), Js("423"), Js("424"), Js("425")]),
                }
            ),
            Js(
                {
                    "rule": Js(
                        "The element strings coupon value, percentage discount of a coupon and loyalty points of a coupon SHALL NOT be applied in combination."
                    ),
                    "condition1": Js("390d"),
                    "condition2": Js([Js("394d"), Js("8111")]),
                }
            ),
            Js(
                {
                    "rule": Js("Only one amount patable element string SHALL be applied on a payment slip."),
                    "condition1": Js("391d"),
                    "condition2": Js([Js("390d")]),
                }
            ),
            Js(
                {
                    "rule": Js(
                        "Only one amount payable element string SHALL be applied on a variable measure trade item."
                    ),
                    "condition1": Js("392d"),
                    "condition2": Js([Js("393d")]),
                }
            ),
            Js(
                {
                    "rule": Js(
                        "The element strings percentage discount of a coupon and the loyalty points of a coupon SHALL NOT be applied in combination."
                    ),
                    "condition1": Js("394d"),
                    "condition2": Js([Js("8111")]),
                }
            ),
            Js(
                {
                    "rule": Js(
                        "The GTIN SHALL NOT be used in combination with the identification of an individual trade item piece.  The GTIN of the trade item to which the individual trade item piece belongs is contained in the element string"
                    ),
                    "condition1": Js("8006"),
                    "condition2": Js([Js("01")]),
                }
            ),
            Js(
                {
                    "rule": Js(
                        "Only one Global Service Relation Number (recipient of provider) SHALL be applied at one time for identification of an individual in a given service relationship"
                    ),
                    "condition1": Js("8018"),
                    "condition2": Js([Js("8017")]),
                }
            ),
        ]
    ),
)
var.put(
    "mandatoryAssociations",
    Js(
        [
            Js(
                {
                    "designation": Js("GTIN of a variable measure trade item scanned at POS"),
                    "rule": Js(
                        "The GTIN of a variable measure trade item scanned at POS SHALL occur in combination with: * variable count of items; or * a trade measure ; Note: Master data will be needed to determine whether the GTIN represents a variable measure trade item scanned at POS. Also see the note below this table."
                    ),
                    "condition": Js([Js("01")]),
                    "conditionN1": Js("0"),
                    "OR": Js([Js("30"), Js("3d{3}")]),
                }
            ),
            Js(
                {
                    "designation": Js("GTIN of a variable measure trade item not scanned at POS"),
                    "rule": Js(
                        "The GTIN of a variable measure trade item not scanned at POS SHALL occur in combination with: * variable count of items; or * a trade measure; or * the dimensions of a roll product. Note: The first position of the GTIN is '9' for such trade items. Also see the note below this table."
                    ),
                    "condition": Js([Js("01"), Js("02")]),
                    "conditionN1": Js("9"),
                    "OR": Js([Js("30"), Js("3d{3}"), Js("8001")]),
                }
            ),
            Js(
                {
                    "designation": Js("GTIN of a custom trade item."),
                    "rule": Js(
                        "The GTIN of a custom trade item SHALL be used in combination with the Made-to-Order variation number. Note: The first position of the GTIN is '9' for such trade items."
                    ),
                    "condition": Js([Js("01")]),
                    "conditionN1": Js("9"),
                    "EXACTLY": Js([Js("242")]),
                }
            ),
            Js(
                {
                    "designation": Js("GTIN of contained trade items"),
                    "rule": Js(
                        "The GTIN of contained trade items SHALL occur in combination with an SSCC and the count of the trade items."
                    ),
                    "condition": Js([Js("02")]),
                    "AND": Js([Js("00"), Js("37")]),
                }
            ),
            Js(
                {
                    "designation": Js("Batch/lot number"),
                    "rule": Js(
                        "Batch/lot number SHALL occur in combination with: * a GTIN; or * a GTIN of contained trade items; or * the identification of an individual trade item piece."
                    ),
                    "condition": Js([Js("10")]),
                    "XOR": Js([Js("01"), Js("02"), Js("8006")]),
                }
            ),
            Js(
                {
                    "designation": Js(
                        "Production date, packaging date, best before date, sell by date, expiration date (of a trade item)"
                    ),
                    "rule": Js(
                        "These dates SHALL occur in combination with: * a GTIN; or * a GTIN of contained trade items; or * the identification of an individual trade item piece."
                    ),
                    "condition": Js([Js("11"), Js("13"), Js("15"), Js("16"), Js("17")]),
                    "XOR": Js([Js("01"), Js("02"), Js("8006")]),
                }
            ),
            Js(
                {
                    "designation": Js("Due date"),
                    "rule": Js(
                        "The due date SHALL occur in combination with the payment slip reference number and the GLN of the invoicing party"
                    ),
                    "condition": Js([Js("12")]),
                    "AND": Js([Js("8020"), Js("415")]),
                }
            ),
            Js(
                {
                    "designation": Js("Expiration date (of a coupon)"),
                    "rule": Js("The expiration date of a coupon SHALL occur in combination with the GCN."),
                    "condition": Js([Js("17")]),
                    "EXACTLY": Js([Js("255")]),
                }
            ),
            Js(
                {
                    "designation": Js(""),
                    "rule": Js(""),
                    "condition": Js([Js("20")]),
                    "XOR": Js([Js("01"), Js("02"), Js("8006")]),
                }
            ),
            Js({"designation": Js(""), "rule": Js(""), "condition": Js([Js("21")]), "XOR": Js([Js("01"), Js("8006")])}),
            Js({"designation": Js(""), "rule": Js(""), "condition": Js([Js("22")]), "EXACTLY": Js([Js("01")])}),
            Js(
                {
                    "designation": Js(""),
                    "rule": Js(""),
                    "condition": Js([Js("240")]),
                    "XOR": Js([Js("01"), Js("02"), Js("8006")]),
                }
            ),
            Js(
                {
                    "designation": Js(""),
                    "rule": Js(""),
                    "condition": Js([Js("241")]),
                    "XOR": Js([Js("01"), Js("02"), Js("8006")]),
                }
            ),
            Js({"designation": Js(""), "rule": Js(""), "condition": Js([Js("243")]), "EXACTLY": Js([Js("01")])}),
            Js(
                {
                    "designation": Js(""),
                    "rule": Js(""),
                    "condition": Js([Js("250")]),
                    "AND": Js([Js("21")]),
                    "XOR": Js([Js("01"), Js("8006")]),
                }
            ),
            Js(
                {"designation": Js(""), "rule": Js(""), "condition": Js([Js("251")]), "XOR": Js([Js("01"), Js("8006")])}
            ),
            Js({"designation": Js(""), "rule": Js(""), "condition": Js([Js("254")]), "EXACTLY": Js([Js("414")])}),
            Js({"designation": Js(""), "rule": Js(""), "condition": Js([Js("30")]), "XOR": Js([Js("01"), Js("02")])}),
            Js(
                {"designation": Js(""), "rule": Js(""), "condition": Js([Js("3d{3}")]), "XOR": Js([Js("01"), Js("02")])}
            ),
            Js({"designation": Js(""), "rule": Js(""), "condition": Js([Js("3d{3}")]), "OR": Js([Js("00"), Js("01")])}),
            Js({"designation": Js(""), "rule": Js(""), "condition": Js([Js("337d")]), "EXACTLY": Js([Js("01")])}),
            Js({"designation": Js(""), "rule": Js(""), "condition": Js([Js("37")]), "EXACTLY": Js([Js("02")])}),
            Js(
                {
                    "designation": Js(""),
                    "rule": Js(""),
                    "condition": Js([Js("390d")]),
                    "AND": Js([Js("8020"), Js("415")]),
                }
            ),
            Js({"designation": Js(""), "rule": Js(""), "condition": Js([Js("390d")]), "EXACTLY": Js([Js("255")])}),
        ]
    ),
)
var.put("shortCodeToNumeric", Js({}))
for PyJsTemp in var.get("aiShortCode"):
    var.put("key", PyJsTemp)
    var.get("shortCodeToNumeric").put(var.get("aiShortCode").get(var.get("key")), var.get("key"))
var.put("AIsByLength", Js([]))
# for JS loop
var.put("i", Js(2.0))
while var.get("i") <= Js(4.0):
    try:
        var.get("AIsByLength").put(
            var.get("i"), var.get("getAIs")(var.get("aitable").callprop("filter", var.get("byLength")(var.get("i"))))
        )
    finally:
        (var.put("i", Js(var.get("i").to_number()) + Js(1)) - Js(1))
var.put("groupSeparator", var.get("String").callprop("fromCharCode", Js(29.0)))
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass
pass


# Add lib to the module scope
gs1_util = var.to_python()
