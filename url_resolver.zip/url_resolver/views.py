import requests
from django.db.models import Q
from django.shortcuts import redirect, render
from rest_framework import status
from rest_framework.decorators import api_view, renderer_classes
from rest_framework.renderers import JSONRenderer, TemplateHTMLRenderer
from rest_framework.response import Response
from rest_framework.views import APIView
from django.conf import settings

from custom_drf_renderers import LinksetRenderer
from gs1_helpers import GS1URLValidators, decompress_url
from usermgmt.models import Product


class URLResolverView(APIView):
    serializer_class = None
    authentication_classes = []
    permission_classes = []
    renderer_classes = (LinksetRenderer, JSONRenderer)

    def get(self, request, *args, **kwargs):
        input_url = request.build_absolute_uri()
        decompressed_url = None
        try:
            decompressed_url = decompress_url(
                input_url, f"{request.scheme}://{request.get_host()}"
            )
            from urllib.parse import parse_qs, urlparse

            parser = urlparse(decompressed_url)
            request_path = parser.path.rstrip("/")
            params = parse_qs(parser.query)
            query_params_string = parser.query
        except Exception:
            request_path = request.path.rstrip("/")
            params = request.query_params
            query_params_string = request.query_params.urlencode()
        fail_response = Response(
            {"success": False, "error": "Digital Link ERROR"},
            status=status.HTTP_400_BAD_REQUEST,
            content_type="application/json",
        )
        if not request_path:
            self.renderer_classes = (TemplateHTMLRenderer,)
            return render(
                request, "home.html"
            )
        context = {}
        url_data = request_path[1:].split("/")
        if not request_path:
            return fail_response
        else:
            if len(url_data) % 2 == 1:
                return fail_response
            else:
                identifier_array = list(map(int, url_data[0::2]))
                value_array = url_data[1::2]
                if "17" in params:
                    identifier_array.append(17)
                    value_array.append(
                        params.get("17")[0]
                        if type(params.get("17")) == list
                        else params.get("17")
                    )
                url_data_parsed = GS1URLValidators().validate_indentifier_values_tree(
                    identifier_array, value_array
                )
                if not url_data_parsed:
                    return fail_response
                else:
                    if 1 in url_data_parsed:
                        product_data = Product.objects.filter(
                            gtin__endswith=url_data_parsed.get(1).lstrip("0")
                        ).first()
                        if product_data:
                            context["gtin"] = product_data.gtin
                        else:
                            return fail_response
                    else:
                        return fail_response
                    batch_number = url_data_parsed.get(10, None)
                    serial_number = url_data_parsed.get(21, None)
        language = request.META.get("HTTP_ACCEPT_LANGUAGE", "")
        link_type = params.get("linkType", None) or request.query_params.get(
            "linktype", None
        )
        product_urls = product_data.producturl_set.all()
        default_links = product_urls.filter(
            link_type__tag='gs1:pip',
        )
        if language:
            product_urls = product_urls.filter(
                Q(language__iso_639_1_code=language)
                | Q(language__iso_639_2_code=language)
            )
        if link_type and link_type != "all":
            product_urls = product_urls.filter(link_type__tag=link_type)
        if batch_number:
            batch_number_filter = (
                Q(allowed_batch_numbers__iexact="")
                | Q(allowed_batch_numbers__isnull=True)
                | Q(allowed_batch_numbers__icontains=batch_number)
            )
            product_urls = product_urls.filter(batch_number_filter)
        else:
            batch_number_filter = Q(allowed_batch_numbers__iexact="") | Q(
                allowed_batch_numbers__isnull=True
            )
            product_urls = product_urls.filter(batch_number_filter)
        if serial_number:
            serial_number_filter = (
                Q(allowed_serial_numbers__iexact="")
                | Q(allowed_serial_numbers__isnull=True)
                | Q(allowed_serial_numbers__icontains=serial_number)
            )
            product_urls = product_urls.filter(serial_number_filter)
        else:
            serial_number_filter = Q(allowed_serial_numbers__iexact="") | Q(
                allowed_serial_numbers__isnull=True
            )
            product_urls = product_urls.filter(serial_number_filter)
        accept_header = request.headers.get("Accept")
        link_header_data = f'<https://{request.get_host()}/01/{product_data.gtin}?linkType=metadata>;rel="gs1:pip"; type="text/html"; hreflang="en"; title="Product information"'
        for product_url in product_data.producturl_set.all():
            link_header_data += f'<{product_url.url}>;rel="{product_url.link_type.tag}"; type="text/html"; hreflang="{product_url.language.iso_639_1_code}"; title="{product_url.link_type.name}",'
        link_header_data = f'<https://{request.get_host()}/01/{product_data.gtin}?linkType=metadata>;rel="gs1:whatsInTheBox"; type="text/html"; hreflang="en"; title="What\'s in the box?"'
        same_as_url = decompressed_url if decompressed_url else input_url
        # must be a bug in azure devops have to figure out why
        same_as_url = same_as_url.replace("http://", "https://")
        same_as_url = (
            same_as_url + "/"
            if not same_as_url.endswith("/") and not bool(request.query_params)
            else same_as_url
        )
        link_header_data += f'<{same_as_url}>;rel="owl:sameAs"'

        if accept_header in ["application/linkset+json", "application/json"]:
            if not product_data:
                return fail_response
            else:
                default_data = [
                    {
                        "href": f"https://{request.get_host()}/01/{product_data.gtin}?linkType=metadata",
                        "fwqs": True,
                        "title": "General Information",
                        "linktype_uri": "gs1:pip",
                        "hreflang": [ "en" ],
                    }
                ]
                for default_link in default_links.iterator():
                    default_data.append(
                        {
                            "href": default_link.url,
                            "fwqs": True,
                            "title": default_link.link_type.name,
                            "linktype_uri": default_link.link_type.tag,
                            "hreflang": [default_link.language.iso_639_1_code],
                        }
                    )
                response_data = {"linkset": []}
                gtin_data = {
                    "_id": "/01/" + product_data.gtin,
                    "anchor": f"https://{request.get_host()}/01/{product_data.gtin}",
                    "itemDescription": product_data.product_description,
                    "https://gs1.org/voc/defaultLink": [default_data[0]],
                    "https://gs1.org/voc/defaultLinkMulti": default_data,
                }
                gtin_data["https://gs1.org/voc/pip"] = [default_data[0]]
                if link_type == "all":
                    product_urls = product_data.producturl_set.all()
                for product_url in product_urls.iterator():
                    gtin_data.setdefault(product_url.link_type.voc_link, [])
                    gtin_data[product_url.link_type.voc_link].append(
                        {
                            "href": product_url.url,
                            "fwqs": True,
                            "title": product_url.link_type.name,
                            "linktype_uri": product_url.link_type.tag,
                            "hreflang": [product_url.language.iso_639_1_code],
                        }
                    )
                response_data["linkset"].append(gtin_data)
            return Response(
                response_data,
                status=200,
                headers={"link": link_header_data, "vary": "Accept"},
                content_type="application/json",
            )
        if link_type == "all":
            self.renderer_classes = (TemplateHTMLRenderer,)
            product_urls = product_data.producturl_set.all()
            return render(
                request,
                "linktype_all.html",
                context={
                    "urls_to_render": product_urls,
                    "gtin": product_data.gtin,
                    "product_description": product_data.product_description,
                },
            )
        elif link_type == "metadata":
            self.renderer_classes = (TemplateHTMLRenderer,)
            return render(
                request,
                "linktype_none.html",
                context={
                    "gtin": product_data.gtin,
                    "product_description": product_data.product_description,
                },
            )

        if link_type == None:
            link_to_redirect = f"https://{request.get_host()}/01/{product_data.gtin}?linkType=metadata"
        elif link_type == "gs1:pip" and (language == "en" or language == ""):
            link_to_redirect = f"https://{request.get_host()}/01/{product_data.gtin}?linkType=metadata"
        elif product_urls.exists():
            link_to_redirect = product_urls.first().url
        elif default_links.exists():
            link_to_redirect = default_links.first().url
        else:
            return fail_response
        if query_params_string and link_type != "gs1:pip":
            link_to_redirect = f"{link_to_redirect}?{query_params_string}"
        response = redirect(link_to_redirect)
        response["Link"] = link_header_data
        response["vary"] = "Accept"
        response["Access-Control-Allow-Origin"] = "*"
        return response


@api_view(["GET"])
def template_renderer(request, template_name=None):
    return render(request, f"{template_name}.html")


@api_view(["GET"])
def indiaapi_dummy(request, unique_code=None):
    datamap = {
        "076010010000000018": {
            "upic": "91000018",
            "api_name": "Tramadol Hydrochloride 50 kg",
            "brand_name": "Tramadol Hydrochloride 50 kg",
            "name_address_manufacturer": "Proto Chemicals AG, Tschachen 2, 8756 Mitloedi, Switzerland",
            "license_number": "IL/BD004588 BD114",
            "special_storage_conditions": "N.A",
            "batch_no": "T7344",
            "batch_size": "1,550.00",
            "date_manufacturing": "2-May-21",
            "date_expiry": "June 2025",
            "sscc": "076010010000000018",
        },
        "076010010000000025": {
            "upic": "91000018",
            "api_name": "Tramadol Hydrochloride 50 kg",
            "brand_name": "Tramadol Hydrochloride 50 kg",
            "name_address_manufacturer": "Proto Chemicals AG, Tschachen 2, 8756 Mitloedi, Switzerland",
            "license_number": "IL/BD009365 BD114",
            "special_storage_conditions": "N.A",
            "batch_no": "T7344",
            "batch_size": "1,550.00",
            "date_manufacturing": "15-Nov-20",
            "date_expiry": "June 2025",
            "sscc": "'076010010000000025",
        },
        "076010010000000032": {
            "upic": "91000018",
            "api_name": "Tramadol Hydrochloride 50 kg",
            "brand_name": "Tramadol Hydrochloride 50 kg",
            "name_address_manufacturer": "Proto Chemicals AG, Tschachen 2, 8756 Mitloedi, Switzerland",
            "license_number": "IL/BD-006334-BD02020",
            "special_storage_conditions": "N.A",
            "batch_no": "T7344",
            "batch_size": "1,550.00",
            "date_manufacturing": "1-Oct-21",
            "date_expiry": "June 2025",
            "sscc": "076010010000000032",
        },
        "076010010000000049": {
            "upic": "91000018",
            "api_name": "Tramadol Hydrochloride 50 kg",
            "brand_name": "Tramadol Hydrochloride 50 kg",
            "name_address_manufacturer": "Proto Chemicals AG, Tschachen 2, 8756 Mitloedi, Switzerland",
            "license_number": "IL/BD000898 RC/BD002021",
            "special_storage_conditions": "N.A",
            "batch_no": "T7344",
            "batch_size": "1,550.00",
            "date_manufacturing": "NOV/2021",
            "date_expiry": "June 2025",
            "sscc": "'076010010000000049",
        },
        "076010010000000056": {
            "upic": "91000018",
            "api_name": "Tramadol Hydrochloride 50 kg",
            "brand_name": "Tramadol Hydrochloride 50 kg",
            "name_address_manufacturer": "Proto Chemicals AG, Tschachen 2, 8756 Mitloedi, Switzerland",
            "license_number": "IL/BD007406 BD20",
            "special_storage_conditions": "N.A",
            "batch_no": "T7344",
            "batch_size": "1,550.00",
            "date_manufacturing": "Dec 20",
            "date_expiry": "June 2025",
            "sscc": "076010010000000056",
        },
        "076010010000000063": {
            "upic": "91000018",
            "api_name": "Tramadol Hydrochloride 50 kg",
            "brand_name": "Tramadol Hydrochloride 50 kg",
            "name_address_manufacturer": "Proto Chemicals AG, Tschachen 2, 8756 Mitloedi, Switzerland",
            "license_number": "IL/BD006130 RC/BD002280",
            "special_storage_conditions": "N.A",
            "batch_no": "T7344",
            "batch_size": "1,550.00",
            "date_manufacturing": "12.2021",
            "date_expiry": "June 2025",
            "sscc": "076010010000000063",
        },
    }
    context = datamap.get(unique_code)
    return render(request, "indiaapi.html", context=context)


@api_view(["GET"])
@renderer_classes((JSONRenderer,))
def well_known_gs1resolver(request, template_name=None):
    response_data = {
        "_id": "gs1resolver.json",
        "name": "The GS1 AISBL Resolver",
        "resolverRoot": "https://id.gs1.org",
        "termsOfUse": "https://www.gs1.org/standards/resolver/terms-of-use",
        "supportedLinkType": [
            {
                "namespace": "http://gs1.org/voc/",
                "prefix": "gs1:"
            },
            {
                "namespace": "http://schema.org/",
                "prefix": "schema:"
            }
        ],
        "supportedPrimaryKeys": [
            "all"
        ],
        "supportedContextValuesEnumerated": [
            "dscsaSaleableReturn"
        ],
        "supportedContextValuesExternal": [
            {
                "nameOfList": "ISO-3166 Alpha-2",
                "url": "https://en.wikipedia.org/wiki/List_of_ISO_3166_country_codes"
            }
        ],
        "linkTypeDefaultCanBeAll": True,
        "contact": {
            "fn": "GS1 AISBL",
            "hasAddress": {
                "streetAddress": "Avenue Louise 326",
                "locality": "Brussels",
                "country-name": "Belgium",
                "postal-code": "1050"
            },
            "hasTelephone": "tel:+32 2 788 78 00"
        },
        "supportsLanguageVariants": True,
        "supportsSemanticInterpretation": True,
        "validatesAIcombinations": True,
        "activeLinkTypes": {
            "en-GB": {
                "activityIdeas": {
                    "title": "Activity ideas",
                    "description": "Ideas for using the product, particularly with children.",
                    "gs1key": "gtin"
                },
                "consumerHandlingStorageInfo": {
                    "title": "Consumer handling and storage information",
                    "description": "A link to information about safe handling and storage of the product.",
                    "gs1key": "gtin"
                },
                "epcis": {
                    "title": "EPCIS repository",
                    "description": "A link to an EPCIS repository of visibility event data.",
                    "gs1key": "gtin"
                },
                "faqs": {
                    "title": "FAQs",
                    "description": "A link to a set of frequently asked questions.",
                    "gs1key": "gtin"
                },
                "ingredientsInfo": {
                    "title": "Ingredients information",
                    "description": "A document providing facts about the product's ingredients.",
                    "gs1key": "gtin"
                },
                "instructions": {
                    "title": "Instructions",
                    "description": "A document, video or graphic that provides instructions related to the item, including assembly instructions, usage tips etc.",
                    "gs1key": "gtin"
                },
                "masterData": {
                    "title": "Master data",
                    "description": "A link to a source of structured master data for the entity. This is typically for B2B applications, rather than for consumers, and likely to be subject to access control.",
                    "gs1key": "gtin"
                },
                "brandHomepagePatient": {
                    "title": "More information for patients about this brand",
                    "description": "Link to a brand presence aimed at patients.",
                    "gs1key": "gtin"
                },
                "brandHomepageClinical": {
                    "title": "More information for professionals about this bran",
                    "description": "Link to brand presence aimed at clinical professionals.",
                    "gs1key": "gtin"
                },
                "nutritionalInfo": {
                    "title": "Nutritional information",
                    "description": "A document providing nutritional facts about the product.",
                    "gs1key": "gtin"
                },
                "epil": {
                    "title": "Patient information",
                    "description": "Link to an electronic patient information leaflet.",
                    "gs1key": "gtin"
                },
                "pip": {
                    "title": "Product information page",
                    "description": "A document that provides information about the identified item, typically operated by the brand owner or a retailer of the product. It may include links to further information, product description, specifications etc. N.B. The page may be human or machine readable, or a combination of the two (such as an HTML page with embedded structured data).",
                    "gs1key": "gtin"
                },
                "promotion": {
                    "title": "Promotion",
                    "description": "A link to a promotion for the product.",
                    "gs1key": "gtin"
                },
                "recallStatus": {
                    "title": "Recall status",
                    "description": "A link to information about whether the product has been recalled or not, typically an API.",
                    "gs1key": "gtin"
                },
                "recipeInfo": {
                    "title": "Recipe website",
                    "description": "A link to a recipe website for the product.",
                    "gs1key": "gtin"
                },
                "relatedVideo": {
                    "title": "Related Video",
                    "description": "A link to a related Video (or the web UI  within which the video is embedded)",
                    "gs1key": "gtin"
                },
                "hasRetailers": {
                    "title": "Retailers",
                    "description": "A link to a list of retailers for this item",
                    "gs1key": "gtin"
                },
                "review": {
                    "title": "Review",
                    "description": "A link to one or more reviews of the product or service.",
                    "gs1key": "gtin"
                },
                "safetyInfo": {
                    "title": "Safety information",
                    "description": "A document, video or graphic that provides safety information about the item",
                    "gs1key": "gtin"
                },
                "serviceInfo": {
                    "title": "Service information",
                    "description": "A document that provides service or maintenance instructions for the item.",
                    "gs1key": "gtin"
                },
                "smartLabel": {
                    "title": "SmartLabel",
                    "description": "A link to the product's SmartLabel page.",
                    "gs1key": "gtin"
                },
                "socialMedia": {
                    "title": "Social media",
                    "description": "A link to a social media channel. The title will typically be replaced by the name of the channel.",
                    "gs1key": "gtin"
                },
                "smpc": {
                    "title": "Summary product characteristics (SmPC)",
                    "description": "Link to Summary Product Characteristics for healthcare professionals.",
                    "gs1key": "gtin"
                },
                "support": {
                    "title": "Support",
                    "description": "A link to a source of support such as a helpdesk, chat support, email etc.",
                    "gs1key": "gtin"
                },
                "productSustainabilityInfo": {
                    "title": "sustainability and recycling",
                    "description": "Information about the productís sustainability of manufacture, recycling information etc.",
                    "gs1key": "gtin"
                },
                "traceability": {
                    "title": "Traceability information",
                    "description": "A link to traceability information about the product.",
                    "gs1key": "gtin"
                },
                "tutorial": {
                    "title": "Tutorial",
                    "description": "A link to a tutorial or set of tutorials, such as online classes, how-to videos etc.",
                    "gs1key": "gtin"
                }
            }
        }
    }
    return Response(response_data, status=200)


@api_view(["GET"])
@renderer_classes((JSONRenderer,))
def botminds_proxy(request, template_name=None):
    url = "https://portal.botminds.ai/a/webapi/api/document/getdocumentdetails/fb9b2aec3ca74083b39db5250baf33c3/3b76c9d45a9bd5f10f89256381339fd2/2fdf33a6220e54eb0c9fdf0a7b6b258e"
    payload = {}
    headers = {
        "subscriptionId": "fb9b2aec3ca74083b39db5250baf33c3",
        "finonId": "3b76c9d45a9bd5f10f89256381339fd2",
        "Content-Type": "application/json",
    }
    response = requests.request("GET", url, headers=headers, data=payload)
    return Response(response.json(), status=200)

@api_view(["GET"])
@renderer_classes((JSONRenderer,))
def version(request, template_name=None):
    data = {
        "version": settings.VERSION,
    }
    return Response(data, status=200)
